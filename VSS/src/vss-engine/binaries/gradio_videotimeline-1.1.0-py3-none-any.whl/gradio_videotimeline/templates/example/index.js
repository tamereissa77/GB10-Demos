var Gi = (a) => {
  throw TypeError(a);
};
var Ki = (a, e, t) => e.has(a) || Gi("Cannot " + t);
var nt = (a, e, t) => (Ki(a, e, "read from private field"), t ? t.call(a) : e.get(a)), Vi = (a, e, t) => e.has(a) ? Gi("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(a) : e.set(a, t), Hi = (a, e, t, s) => (Ki(a, e, "write to private field"), s ? s.call(a, t) : e.set(a, t), t);
var Wi;
(function(a) {
  a.LOAD = "LOAD", a.EXEC = "EXEC", a.FFPROBE = "FFPROBE", a.WRITE_FILE = "WRITE_FILE", a.READ_FILE = "READ_FILE", a.DELETE_FILE = "DELETE_FILE", a.RENAME = "RENAME", a.CREATE_DIR = "CREATE_DIR", a.LIST_DIR = "LIST_DIR", a.DELETE_DIR = "DELETE_DIR", a.ERROR = "ERROR", a.DOWNLOAD = "DOWNLOAD", a.PROGRESS = "PROGRESS", a.LOG = "LOG", a.MOUNT = "MOUNT", a.UNMOUNT = "UNMOUNT";
})(Wi || (Wi = {}));
var Yi;
(function(a) {
  a.MEMFS = "MEMFS", a.NODEFS = "NODEFS", a.NODERAWFS = "NODERAWFS", a.IDBFS = "IDBFS", a.WORKERFS = "WORKERFS", a.PROXYFS = "PROXYFS";
})(Yi || (Yi = {}));
function Ha(a, { autoplay: e }) {
  async function t() {
    e && await a.play();
  }
  return a.addEventListener("loadeddata", t), {
    destroy() {
      a.removeEventListener("loadeddata", t);
    }
  };
}
const { setContext: Md, getContext: Wa } = window.__gradio__svelte__internal, Ya = "WORKER_PROXY_CONTEXT_KEY";
function qa() {
  return Wa(Ya);
}
const ja = "lite.local";
function Xa(a) {
  return a.host === window.location.host || a.host === "localhost:7860" || a.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  a.host === ja;
}
function za(a, e) {
  const t = e.toLowerCase();
  for (const [s, i] of Object.entries(a))
    if (s.toLowerCase() === t)
      return i;
}
function Qa(a) {
  const e = typeof window < "u";
  if (a == null || !e)
    return !1;
  const t = new URL(a, window.location.href);
  return !(!Xa(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let Mt;
async function Za(a) {
  const e = typeof window < "u";
  if (a == null || !e || !Qa(a))
    return a;
  if (Mt == null)
    try {
      Mt = qa();
    } catch {
      return a;
    }
  if (Mt == null)
    return a;
  const s = new URL(a, window.location.href).pathname;
  return Mt.httpRequest({
    method: "GET",
    path: s,
    headers: {},
    query_string: ""
  }).then((i) => {
    if (i.status !== 200)
      throw new Error(`Failed to get file ${s} from the Wasm worker.`);
    const r = new Blob([i.body], {
      type: za(i.headers, "content-type")
    });
    return URL.createObjectURL(r);
  });
}
const {
  SvelteComponent: Nd,
  assign: Bd,
  check_outros: Ud,
  children: $d,
  claim_element: Gd,
  compute_rest_props: Kd,
  create_slot: Vd,
  detach: Hd,
  element: Wd,
  empty: Yd,
  exclude_internal_props: qd,
  get_all_dirty_from_scope: jd,
  get_slot_changes: Xd,
  get_spread_update: zd,
  group_outros: Qd,
  init: Zd,
  insert_hydration: Jd,
  listen: ef,
  prevent_default: tf,
  safe_not_equal: sf,
  set_attributes: rf,
  set_style: nf,
  toggle_class: af,
  transition_in: of,
  transition_out: lf,
  update_slot_base: cf
} = window.__gradio__svelte__internal, { createEventDispatcher: hf, onMount: uf } = window.__gradio__svelte__internal, M = Number.isFinite || function(a) {
  return typeof a == "number" && isFinite(a);
}, Ja = Number.isSafeInteger || function(a) {
  return typeof a == "number" && Math.abs(a) <= eo;
}, eo = Number.MAX_SAFE_INTEGER || 9007199254740991;
let K = /* @__PURE__ */ function(a) {
  return a.NETWORK_ERROR = "networkError", a.MEDIA_ERROR = "mediaError", a.KEY_SYSTEM_ERROR = "keySystemError", a.MUX_ERROR = "muxError", a.OTHER_ERROR = "otherError", a;
}({}), R = /* @__PURE__ */ function(a) {
  return a.KEY_SYSTEM_NO_KEYS = "keySystemNoKeys", a.KEY_SYSTEM_NO_ACCESS = "keySystemNoAccess", a.KEY_SYSTEM_NO_SESSION = "keySystemNoSession", a.KEY_SYSTEM_NO_CONFIGURED_LICENSE = "keySystemNoConfiguredLicense", a.KEY_SYSTEM_LICENSE_REQUEST_FAILED = "keySystemLicenseRequestFailed", a.KEY_SYSTEM_SERVER_CERTIFICATE_REQUEST_FAILED = "keySystemServerCertificateRequestFailed", a.KEY_SYSTEM_SERVER_CERTIFICATE_UPDATE_FAILED = "keySystemServerCertificateUpdateFailed", a.KEY_SYSTEM_SESSION_UPDATE_FAILED = "keySystemSessionUpdateFailed", a.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED = "keySystemStatusOutputRestricted", a.KEY_SYSTEM_STATUS_INTERNAL_ERROR = "keySystemStatusInternalError", a.KEY_SYSTEM_DESTROY_MEDIA_KEYS_ERROR = "keySystemDestroyMediaKeysError", a.KEY_SYSTEM_DESTROY_CLOSE_SESSION_ERROR = "keySystemDestroyCloseSessionError", a.KEY_SYSTEM_DESTROY_REMOVE_SESSION_ERROR = "keySystemDestroyRemoveSessionError", a.MANIFEST_LOAD_ERROR = "manifestLoadError", a.MANIFEST_LOAD_TIMEOUT = "manifestLoadTimeOut", a.MANIFEST_PARSING_ERROR = "manifestParsingError", a.MANIFEST_INCOMPATIBLE_CODECS_ERROR = "manifestIncompatibleCodecsError", a.LEVEL_EMPTY_ERROR = "levelEmptyError", a.LEVEL_LOAD_ERROR = "levelLoadError", a.LEVEL_LOAD_TIMEOUT = "levelLoadTimeOut", a.LEVEL_PARSING_ERROR = "levelParsingError", a.LEVEL_SWITCH_ERROR = "levelSwitchError", a.AUDIO_TRACK_LOAD_ERROR = "audioTrackLoadError", a.AUDIO_TRACK_LOAD_TIMEOUT = "audioTrackLoadTimeOut", a.SUBTITLE_LOAD_ERROR = "subtitleTrackLoadError", a.SUBTITLE_TRACK_LOAD_TIMEOUT = "subtitleTrackLoadTimeOut", a.FRAG_LOAD_ERROR = "fragLoadError", a.FRAG_LOAD_TIMEOUT = "fragLoadTimeOut", a.FRAG_DECRYPT_ERROR = "fragDecryptError", a.FRAG_PARSING_ERROR = "fragParsingError", a.FRAG_GAP = "fragGap", a.REMUX_ALLOC_ERROR = "remuxAllocError", a.KEY_LOAD_ERROR = "keyLoadError", a.KEY_LOAD_TIMEOUT = "keyLoadTimeOut", a.BUFFER_ADD_CODEC_ERROR = "bufferAddCodecError", a.BUFFER_INCOMPATIBLE_CODECS_ERROR = "bufferIncompatibleCodecsError", a.BUFFER_APPEND_ERROR = "bufferAppendError", a.BUFFER_APPENDING_ERROR = "bufferAppendingError", a.BUFFER_STALLED_ERROR = "bufferStalledError", a.BUFFER_FULL_ERROR = "bufferFullError", a.BUFFER_SEEK_OVER_HOLE = "bufferSeekOverHole", a.BUFFER_NUDGE_ON_STALL = "bufferNudgeOnStall", a.ASSET_LIST_LOAD_ERROR = "assetListLoadError", a.ASSET_LIST_LOAD_TIMEOUT = "assetListLoadTimeout", a.ASSET_LIST_PARSING_ERROR = "assetListParsingError", a.INTERSTITIAL_ASSET_ITEM_ERROR = "interstitialAssetItemError", a.INTERNAL_EXCEPTION = "internalException", a.INTERNAL_ABORTED = "aborted", a.ATTACH_MEDIA_ERROR = "attachMediaError", a.UNKNOWN = "unknown", a;
}({}), m = /* @__PURE__ */ function(a) {
  return a.MEDIA_ATTACHING = "hlsMediaAttaching", a.MEDIA_ATTACHED = "hlsMediaAttached", a.MEDIA_DETACHING = "hlsMediaDetaching", a.MEDIA_DETACHED = "hlsMediaDetached", a.MEDIA_ENDED = "hlsMediaEnded", a.STALL_RESOLVED = "hlsStallResolved", a.BUFFER_RESET = "hlsBufferReset", a.BUFFER_CODECS = "hlsBufferCodecs", a.BUFFER_CREATED = "hlsBufferCreated", a.BUFFER_APPENDING = "hlsBufferAppending", a.BUFFER_APPENDED = "hlsBufferAppended", a.BUFFER_EOS = "hlsBufferEos", a.BUFFERED_TO_END = "hlsBufferedToEnd", a.BUFFER_FLUSHING = "hlsBufferFlushing", a.BUFFER_FLUSHED = "hlsBufferFlushed", a.MANIFEST_LOADING = "hlsManifestLoading", a.MANIFEST_LOADED = "hlsManifestLoaded", a.MANIFEST_PARSED = "hlsManifestParsed", a.LEVEL_SWITCHING = "hlsLevelSwitching", a.LEVEL_SWITCHED = "hlsLevelSwitched", a.LEVEL_LOADING = "hlsLevelLoading", a.LEVEL_LOADED = "hlsLevelLoaded", a.LEVEL_UPDATED = "hlsLevelUpdated", a.LEVEL_PTS_UPDATED = "hlsLevelPtsUpdated", a.LEVELS_UPDATED = "hlsLevelsUpdated", a.AUDIO_TRACKS_UPDATED = "hlsAudioTracksUpdated", a.AUDIO_TRACK_SWITCHING = "hlsAudioTrackSwitching", a.AUDIO_TRACK_SWITCHED = "hlsAudioTrackSwitched", a.AUDIO_TRACK_LOADING = "hlsAudioTrackLoading", a.AUDIO_TRACK_LOADED = "hlsAudioTrackLoaded", a.AUDIO_TRACK_UPDATED = "hlsAudioTrackUpdated", a.SUBTITLE_TRACKS_UPDATED = "hlsSubtitleTracksUpdated", a.SUBTITLE_TRACKS_CLEARED = "hlsSubtitleTracksCleared", a.SUBTITLE_TRACK_SWITCH = "hlsSubtitleTrackSwitch", a.SUBTITLE_TRACK_LOADING = "hlsSubtitleTrackLoading", a.SUBTITLE_TRACK_LOADED = "hlsSubtitleTrackLoaded", a.SUBTITLE_TRACK_UPDATED = "hlsSubtitleTrackUpdated", a.SUBTITLE_FRAG_PROCESSED = "hlsSubtitleFragProcessed", a.CUES_PARSED = "hlsCuesParsed", a.NON_NATIVE_TEXT_TRACKS_FOUND = "hlsNonNativeTextTracksFound", a.INIT_PTS_FOUND = "hlsInitPtsFound", a.FRAG_LOADING = "hlsFragLoading", a.FRAG_LOAD_EMERGENCY_ABORTED = "hlsFragLoadEmergencyAborted", a.FRAG_LOADED = "hlsFragLoaded", a.FRAG_DECRYPTED = "hlsFragDecrypted", a.FRAG_PARSING_INIT_SEGMENT = "hlsFragParsingInitSegment", a.FRAG_PARSING_USERDATA = "hlsFragParsingUserdata", a.FRAG_PARSING_METADATA = "hlsFragParsingMetadata", a.FRAG_PARSED = "hlsFragParsed", a.FRAG_BUFFERED = "hlsFragBuffered", a.FRAG_CHANGED = "hlsFragChanged", a.FPS_DROP = "hlsFpsDrop", a.FPS_DROP_LEVEL_CAPPING = "hlsFpsDropLevelCapping", a.MAX_AUTO_LEVEL_UPDATED = "hlsMaxAutoLevelUpdated", a.ERROR = "hlsError", a.DESTROYING = "hlsDestroying", a.KEY_LOADING = "hlsKeyLoading", a.KEY_LOADED = "hlsKeyLoaded", a.LIVE_BACK_BUFFER_REACHED = "hlsLiveBackBufferReached", a.BACK_BUFFER_REACHED = "hlsBackBufferReached", a.STEERING_MANIFEST_LOADED = "hlsSteeringManifestLoaded", a.ASSET_LIST_LOADING = "hlsAssetListLoading", a.ASSET_LIST_LOADED = "hlsAssetListLoaded", a.INTERSTITIALS_UPDATED = "hlsInterstitialsUpdated", a.INTERSTITIALS_BUFFERED_TO_BOUNDARY = "hlsInterstitialsBufferedToBoundary", a.INTERSTITIAL_ASSET_PLAYER_CREATED = "hlsInterstitialAssetPlayerCreated", a.INTERSTITIAL_STARTED = "hlsInterstitialStarted", a.INTERSTITIAL_ASSET_STARTED = "hlsInterstitialAssetStarted", a.INTERSTITIAL_ASSET_ENDED = "hlsInterstitialAssetEnded", a.INTERSTITIAL_ASSET_ERROR = "hlsInterstitialAssetError", a.INTERSTITIAL_ENDED = "hlsInterstitialEnded", a.INTERSTITIALS_PRIMARY_RESUMED = "hlsInterstitialsPrimaryResumed", a.PLAYOUT_LIMIT_REACHED = "hlsPlayoutLimitReached", a.EVENT_CUE_ENTER = "hlsEventCueEnter", a;
}({});
var z = {
  MANIFEST: "manifest",
  LEVEL: "level",
  AUDIO_TRACK: "audioTrack",
  SUBTITLE_TRACK: "subtitleTrack"
}, G = {
  MAIN: "main",
  AUDIO: "audio",
  SUBTITLE: "subtitle"
};
class at {
  //  About half of the estimated value will be from the last |halfLife| samples by weight.
  constructor(e, t = 0, s = 0) {
    this.halfLife = void 0, this.alpha_ = void 0, this.estimate_ = void 0, this.totalWeight_ = void 0, this.halfLife = e, this.alpha_ = e ? Math.exp(Math.log(0.5) / e) : 0, this.estimate_ = t, this.totalWeight_ = s;
  }
  sample(e, t) {
    const s = Math.pow(this.alpha_, e);
    this.estimate_ = t * (1 - s) + s * this.estimate_, this.totalWeight_ += e;
  }
  getTotalWeight() {
    return this.totalWeight_;
  }
  getEstimate() {
    if (this.alpha_) {
      const e = 1 - Math.pow(this.alpha_, this.totalWeight_);
      if (e)
        return this.estimate_ / e;
    }
    return this.estimate_;
  }
}
class to {
  constructor(e, t, s, i = 100) {
    this.defaultEstimate_ = void 0, this.minWeight_ = void 0, this.minDelayMs_ = void 0, this.slow_ = void 0, this.fast_ = void 0, this.defaultTTFB_ = void 0, this.ttfb_ = void 0, this.defaultEstimate_ = s, this.minWeight_ = 1e-3, this.minDelayMs_ = 50, this.slow_ = new at(e), this.fast_ = new at(t), this.defaultTTFB_ = i, this.ttfb_ = new at(e);
  }
  update(e, t) {
    const {
      slow_: s,
      fast_: i,
      ttfb_: r
    } = this;
    s.halfLife !== e && (this.slow_ = new at(e, s.getEstimate(), s.getTotalWeight())), i.halfLife !== t && (this.fast_ = new at(t, i.getEstimate(), i.getTotalWeight())), r.halfLife !== e && (this.ttfb_ = new at(e, r.getEstimate(), r.getTotalWeight()));
  }
  sample(e, t) {
    e = Math.max(e, this.minDelayMs_);
    const s = 8 * t, i = e / 1e3, r = s / i;
    this.fast_.sample(i, r), this.slow_.sample(i, r);
  }
  sampleTTFB(e) {
    const t = e / 1e3, s = Math.sqrt(2) * Math.exp(-Math.pow(t, 2) / 2);
    this.ttfb_.sample(s, Math.max(e, 5));
  }
  canEstimate() {
    return this.fast_.getTotalWeight() >= this.minWeight_;
  }
  getEstimate() {
    return this.canEstimate() ? Math.min(this.fast_.getEstimate(), this.slow_.getEstimate()) : this.defaultEstimate_;
  }
  getEstimateTTFB() {
    return this.ttfb_.getTotalWeight() >= this.minWeight_ ? this.ttfb_.getEstimate() : this.defaultTTFB_;
  }
  get defaultEstimate() {
    return this.defaultEstimate_;
  }
  destroy() {
  }
}
function so(a, e, t) {
  return (e = ro(e)) in a ? Object.defineProperty(a, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : a[e] = t, a;
}
function re() {
  return re = Object.assign ? Object.assign.bind() : function(a) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var s in t) ({}).hasOwnProperty.call(t, s) && (a[s] = t[s]);
    }
    return a;
  }, re.apply(null, arguments);
}
function qi(a, e) {
  var t = Object.keys(a);
  if (Object.getOwnPropertySymbols) {
    var s = Object.getOwnPropertySymbols(a);
    e && (s = s.filter(function(i) {
      return Object.getOwnPropertyDescriptor(a, i).enumerable;
    })), t.push.apply(t, s);
  }
  return t;
}
function te(a) {
  for (var e = 1; e < arguments.length; e++) {
    var t = arguments[e] != null ? arguments[e] : {};
    e % 2 ? qi(Object(t), !0).forEach(function(s) {
      so(a, s, t[s]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(a, Object.getOwnPropertyDescriptors(t)) : qi(Object(t)).forEach(function(s) {
      Object.defineProperty(a, s, Object.getOwnPropertyDescriptor(t, s));
    });
  }
  return a;
}
function io(a, e) {
  if (typeof a != "object" || !a) return a;
  var t = a[Symbol.toPrimitive];
  if (t !== void 0) {
    var s = t.call(a, e);
    if (typeof s != "object") return s;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(a);
}
function ro(a) {
  var e = io(a, "string");
  return typeof e == "symbol" ? e : e + "";
}
class Ve {
  constructor(e, t) {
    this.trace = void 0, this.debug = void 0, this.log = void 0, this.warn = void 0, this.info = void 0, this.error = void 0;
    const s = `[${e}]:`;
    this.trace = je, this.debug = t.debug.bind(null, s), this.log = t.log.bind(null, s), this.warn = t.warn.bind(null, s), this.info = t.info.bind(null, s), this.error = t.error.bind(null, s);
  }
}
const je = function() {
}, no = {
  trace: je,
  debug: je,
  log: je,
  warn: je,
  info: je,
  error: je
};
function Xs() {
  return re({}, no);
}
function ao(a, e) {
  const t = self.console[a];
  return t ? t.bind(self.console, `${e ? "[" + e + "] " : ""}[${a}] >`) : je;
}
function ji(a, e, t) {
  return e[a] ? e[a].bind(e) : ao(a, t);
}
const zs = Xs();
function oo(a, e, t) {
  const s = Xs();
  if (typeof console == "object" && a === !0 || typeof a == "object") {
    const i = [
      // Remove out from list here to hard-disable a log-level
      // 'trace',
      "debug",
      "log",
      "info",
      "warn",
      "error"
    ];
    i.forEach((r) => {
      s[r] = ji(r, a, t);
    });
    try {
      s.log(`Debug logs enabled for "${e}" in hls.js version 1.6.2`);
    } catch {
      return Xs();
    }
    i.forEach((r) => {
      zs[r] = ji(r, a);
    });
  } else
    re(zs, s);
  return s;
}
const Q = zs;
function ze(a = !0) {
  return typeof self > "u" ? void 0 : (a || !self.MediaSource) && self.ManagedMediaSource || self.MediaSource || self.WebKitMediaSource;
}
function lo(a) {
  return typeof self < "u" && a === self.ManagedMediaSource;
}
function En(a, e) {
  const t = Object.keys(a), s = Object.keys(e), i = t.length, r = s.length;
  return !i || !r || i === r && !t.some((n) => s.indexOf(n) === -1);
}
function ve(a, e = !1) {
  if (typeof TextDecoder < "u") {
    const l = new TextDecoder("utf-8").decode(a);
    if (e) {
      const h = l.indexOf("\0");
      return h !== -1 ? l.substring(0, h) : l;
    }
    return l.replace(/\0/g, "");
  }
  const t = a.length;
  let s, i, r, n = "", o = 0;
  for (; o < t; ) {
    if (s = a[o++], s === 0 && e)
      return n;
    if (s === 0 || s === 3)
      continue;
    switch (s >> 4) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
        n += String.fromCharCode(s);
        break;
      case 12:
      case 13:
        i = a[o++], n += String.fromCharCode((s & 31) << 6 | i & 63);
        break;
      case 14:
        i = a[o++], r = a[o++], n += String.fromCharCode((s & 15) << 12 | (i & 63) << 6 | (r & 63) << 0);
        break;
    }
  }
  return n;
}
const Pe = {
  hexDump: function(a) {
    let e = "";
    for (let t = 0; t < a.length; t++) {
      let s = a[t].toString(16);
      s.length < 2 && (s = "0" + s), e += s;
    }
    return e;
  }
};
function co(a) {
  return a && a.__esModule && Object.prototype.hasOwnProperty.call(a, "default") ? a.default : a;
}
var As = { exports: {} }, Xi;
function ho() {
  return Xi || (Xi = 1, function(a, e) {
    (function(t) {
      var s = /^(?=((?:[a-zA-Z0-9+\-.]+:)?))\1(?=((?:\/\/[^\/?#]*)?))\2(?=((?:(?:[^?#\/]*\/)*[^;?#\/]*)?))\3((?:;[^?#]*)?)(\?[^#]*)?(#[^]*)?$/, i = /^(?=([^\/?#]*))\1([^]*)$/, r = /(?:\/|^)\.(?=\/)/g, n = /(?:\/|^)\.\.\/(?!\.\.\/)[^\/]*(?=\/)/g, o = {
        // If opts.alwaysNormalize is true then the path will always be normalized even when it starts with / or //
        // E.g
        // With opts.alwaysNormalize = false (default, spec compliant)
        // http://a.com/b/cd + /e/f/../g => http://a.com/e/f/../g
        // With opts.alwaysNormalize = true (not spec compliant)
        // http://a.com/b/cd + /e/f/../g => http://a.com/e/g
        buildAbsoluteURL: function(c, l, h) {
          if (h = h || {}, c = c.trim(), l = l.trim(), !l) {
            if (!h.alwaysNormalize)
              return c;
            var u = o.parseURL(c);
            if (!u)
              throw new Error("Error trying to parse base URL.");
            return u.path = o.normalizePath(
              u.path
            ), o.buildURLFromParts(u);
          }
          var d = o.parseURL(l);
          if (!d)
            throw new Error("Error trying to parse relative URL.");
          if (d.scheme)
            return h.alwaysNormalize ? (d.path = o.normalizePath(d.path), o.buildURLFromParts(d)) : l;
          var f = o.parseURL(c);
          if (!f)
            throw new Error("Error trying to parse base URL.");
          if (!f.netLoc && f.path && f.path[0] !== "/") {
            var g = i.exec(f.path);
            f.netLoc = g[1], f.path = g[2];
          }
          f.netLoc && !f.path && (f.path = "/");
          var p = {
            // 2c) Otherwise, the embedded URL inherits the scheme of
            // the base URL.
            scheme: f.scheme,
            netLoc: d.netLoc,
            path: null,
            params: d.params,
            query: d.query,
            fragment: d.fragment
          };
          if (!d.netLoc && (p.netLoc = f.netLoc, d.path[0] !== "/"))
            if (!d.path)
              p.path = f.path, d.params || (p.params = f.params, d.query || (p.query = f.query));
            else {
              var E = f.path, y = E.substring(0, E.lastIndexOf("/") + 1) + d.path;
              p.path = o.normalizePath(y);
            }
          return p.path === null && (p.path = h.alwaysNormalize ? o.normalizePath(d.path) : d.path), o.buildURLFromParts(p);
        },
        parseURL: function(c) {
          var l = s.exec(c);
          return l ? {
            scheme: l[1] || "",
            netLoc: l[2] || "",
            path: l[3] || "",
            params: l[4] || "",
            query: l[5] || "",
            fragment: l[6] || ""
          } : null;
        },
        normalizePath: function(c) {
          for (c = c.split("").reverse().join("").replace(r, ""); c.length !== (c = c.replace(n, "")).length; )
            ;
          return c.split("").reverse().join("");
        },
        buildURLFromParts: function(c) {
          return c.scheme + c.netLoc + c.path + c.params + c.query + c.fragment;
        }
      };
      a.exports = o;
    })();
  }(As)), As.exports;
}
var fi = ho();
class gi {
  constructor() {
    this.aborted = !1, this.loaded = 0, this.retry = 0, this.total = 0, this.chunkCount = 0, this.bwEstimate = 0, this.loading = {
      start: 0,
      first: 0,
      end: 0
    }, this.parsing = {
      start: 0,
      end: 0
    }, this.buffering = {
      start: 0,
      first: 0,
      end: 0
    };
  }
}
var ie = {
  AUDIO: "audio",
  VIDEO: "video",
  AUDIOVIDEO: "audiovideo"
};
class yn {
  constructor(e) {
    this._byteRange = null, this._url = null, this._stats = null, this._streams = null, this.base = void 0, this.relurl = void 0, typeof e == "string" && (e = {
      url: e
    }), this.base = e, fo(this, "stats");
  }
  // setByteRange converts a EXT-X-BYTERANGE attribute into a two element array
  setByteRange(e, t) {
    const s = e.split("@", 2);
    let i;
    s.length === 1 ? i = (t == null ? void 0 : t.byteRangeEndOffset) || 0 : i = parseInt(s[1]), this._byteRange = [i, parseInt(s[0]) + i];
  }
  get baseurl() {
    return this.base.url;
  }
  get byteRange() {
    return this._byteRange === null ? [] : this._byteRange;
  }
  get byteRangeStartOffset() {
    return this.byteRange[0];
  }
  get byteRangeEndOffset() {
    return this.byteRange[1];
  }
  get elementaryStreams() {
    return this._streams === null && (this._streams = {
      [ie.AUDIO]: null,
      [ie.VIDEO]: null,
      [ie.AUDIOVIDEO]: null
    }), this._streams;
  }
  set elementaryStreams(e) {
    this._streams = e;
  }
  get hasStats() {
    return this._stats !== null;
  }
  get hasStreams() {
    return this._streams !== null;
  }
  get stats() {
    return this._stats === null && (this._stats = new gi()), this._stats;
  }
  set stats(e) {
    this._stats = e;
  }
  get url() {
    return !this._url && this.baseurl && this.relurl && (this._url = fi.buildAbsoluteURL(this.baseurl, this.relurl, {
      alwaysNormalize: !0
    })), this._url || "";
  }
  set url(e) {
    this._url = e;
  }
  clearElementaryStreamInfo() {
    const {
      elementaryStreams: e
    } = this;
    e[ie.AUDIO] = null, e[ie.VIDEO] = null, e[ie.AUDIOVIDEO] = null;
  }
}
function ue(a) {
  return a.sn !== "initSegment";
}
class Ls extends yn {
  constructor(e, t) {
    super(t), this._decryptdata = null, this._programDateTime = null, this._ref = null, this._bitrate = void 0, this.rawProgramDateTime = null, this.tagList = [], this.duration = 0, this.sn = 0, this.levelkeys = void 0, this.type = void 0, this.loader = null, this.keyLoader = null, this.level = -1, this.cc = 0, this.startPTS = void 0, this.endPTS = void 0, this.startDTS = void 0, this.endDTS = void 0, this.start = 0, this.playlistOffset = 0, this.deltaPTS = void 0, this.maxStartPTS = void 0, this.minEndPTS = void 0, this.data = void 0, this.bitrateTest = !1, this.title = null, this.initSegment = null, this.endList = void 0, this.gap = void 0, this.urlId = 0, this.type = e;
  }
  get byteLength() {
    if (this.hasStats) {
      const e = this.stats.total;
      if (e)
        return e;
    }
    if (this.byteRange) {
      const e = this.byteRange[0], t = this.byteRange[1];
      if (M(e) && M(t))
        return t - e;
    }
    return null;
  }
  get bitrate() {
    return this.byteLength ? this.byteLength * 8 / this.duration : this._bitrate ? this._bitrate : null;
  }
  set bitrate(e) {
    this._bitrate = e;
  }
  get decryptdata() {
    const {
      levelkeys: e
    } = this;
    if (!e && !this._decryptdata)
      return null;
    if (!this._decryptdata && this.levelkeys && !this.levelkeys.NONE) {
      const t = this.levelkeys.identity;
      if (t)
        this._decryptdata = t.getDecryptData(this.sn);
      else {
        const s = Object.keys(this.levelkeys);
        if (s.length === 1)
          return this._decryptdata = this.levelkeys[s[0]].getDecryptData(this.sn);
      }
    }
    return this._decryptdata;
  }
  get end() {
    return this.start + this.duration;
  }
  get endProgramDateTime() {
    if (this.programDateTime === null)
      return null;
    const e = M(this.duration) ? this.duration : 0;
    return this.programDateTime + e * 1e3;
  }
  get encrypted() {
    var e;
    if ((e = this._decryptdata) != null && e.encrypted)
      return !0;
    if (this.levelkeys) {
      const t = Object.keys(this.levelkeys), s = t.length;
      if (s > 1 || s === 1 && this.levelkeys[t[0]].encrypted)
        return !0;
    }
    return !1;
  }
  get programDateTime() {
    return this._programDateTime === null && this.rawProgramDateTime && (this.programDateTime = Date.parse(this.rawProgramDateTime)), this._programDateTime;
  }
  set programDateTime(e) {
    if (!M(e)) {
      this._programDateTime = this.rawProgramDateTime = null;
      return;
    }
    this._programDateTime = e;
  }
  get ref() {
    return ue(this) ? (this._ref || (this._ref = {
      base: this.base,
      start: this.start,
      duration: this.duration,
      sn: this.sn,
      programDateTime: this.programDateTime
    }), this._ref) : null;
  }
  addStart(e) {
    this.setStart(this.start + e);
  }
  setStart(e) {
    this.start = e, this._ref && (this._ref.start = e);
  }
  setDuration(e) {
    this.duration = e, this._ref && (this._ref.duration = e);
  }
  setKeyFormat(e) {
    if (this.levelkeys) {
      const t = this.levelkeys[e];
      t && !this._decryptdata && (this._decryptdata = t.getDecryptData(this.sn));
    }
  }
  abortRequests() {
    var e, t;
    (e = this.loader) == null || e.abort(), (t = this.keyLoader) == null || t.abort();
  }
  setElementaryStreamInfo(e, t, s, i, r, n = !1) {
    const {
      elementaryStreams: o
    } = this, c = o[e];
    if (!c) {
      o[e] = {
        startPTS: t,
        endPTS: s,
        startDTS: i,
        endDTS: r,
        partial: n
      };
      return;
    }
    c.startPTS = Math.min(c.startPTS, t), c.endPTS = Math.max(c.endPTS, s), c.startDTS = Math.min(c.startDTS, i), c.endDTS = Math.max(c.endDTS, r);
  }
}
class uo extends yn {
  constructor(e, t, s, i, r) {
    super(s), this.fragOffset = 0, this.duration = 0, this.gap = !1, this.independent = !1, this.relurl = void 0, this.fragment = void 0, this.index = void 0, this.duration = e.decimalFloatingPoint("DURATION"), this.gap = e.bool("GAP"), this.independent = e.bool("INDEPENDENT"), this.relurl = e.enumeratedString("URI"), this.fragment = t, this.index = i;
    const n = e.enumeratedString("BYTERANGE");
    n && this.setByteRange(n, r), r && (this.fragOffset = r.fragOffset + r.duration);
  }
  get start() {
    return this.fragment.start + this.fragOffset;
  }
  get end() {
    return this.start + this.duration;
  }
  get loaded() {
    const {
      elementaryStreams: e
    } = this;
    return !!(e.audio || e.video || e.audiovideo);
  }
}
function Tn(a, e) {
  const t = Object.getPrototypeOf(a);
  if (t) {
    const s = Object.getOwnPropertyDescriptor(t, e);
    return s || Tn(t, e);
  }
}
function fo(a, e) {
  const t = Tn(a, e);
  t && (t.enumerable = !0, Object.defineProperty(a, e, t));
}
const ns = Math.pow(2, 32) - 1, go = [].push, Sn = {
  video: 1,
  audio: 2,
  id3: 3,
  text: 4
};
function le(a) {
  return String.fromCharCode.apply(null, a);
}
function vn(a, e) {
  const t = a[e] << 8 | a[e + 1];
  return t < 0 ? 65536 + t : t;
}
function V(a, e) {
  const t = xn(a, e);
  return t < 0 ? 4294967296 + t : t;
}
function zi(a, e) {
  let t = V(a, e);
  return t *= Math.pow(2, 32), t += V(a, e + 4), t;
}
function xn(a, e) {
  return a[e] << 24 | a[e + 1] << 16 | a[e + 2] << 8 | a[e + 3];
}
function Is(a, e, t) {
  a[e] = t >> 24, a[e + 1] = t >> 16 & 255, a[e + 2] = t >> 8 & 255, a[e + 3] = t & 255;
}
function mo(a) {
  const e = a.byteLength;
  for (let t = 0; t < e; ) {
    const s = V(a, t);
    if (s > 8 && a[t + 4] === 109 && a[t + 5] === 111 && a[t + 6] === 111 && a[t + 7] === 102)
      return !0;
    t = s > 1 ? t + s : e;
  }
  return !1;
}
function Y(a, e) {
  const t = [];
  if (!e.length)
    return t;
  const s = a.byteLength;
  for (let i = 0; i < s; ) {
    const r = V(a, i), n = le(a.subarray(i + 4, i + 8)), o = r > 1 ? i + r : s;
    if (n === e[0])
      if (e.length === 1)
        t.push(a.subarray(i + 8, o));
      else {
        const c = Y(a.subarray(i + 8, o), e.slice(1));
        c.length && go.apply(t, c);
      }
    i = o;
  }
  return t;
}
function po(a) {
  const e = [], t = a[0];
  let s = 8;
  const i = V(a, s);
  s += 4;
  let r = 0, n = 0;
  t === 0 ? (r = V(a, s), n = V(a, s + 4), s += 8) : (r = zi(a, s), n = zi(a, s + 8), s += 16), s += 2;
  let o = a.length + n;
  const c = vn(a, s);
  s += 2;
  for (let l = 0; l < c; l++) {
    let h = s;
    const u = V(a, h);
    h += 4;
    const d = u & 2147483647;
    if ((u & 2147483648) >>> 31 === 1)
      return Q.warn("SIDX has hierarchical references (not supported)"), null;
    const g = V(a, h);
    h += 4, e.push({
      referenceSize: d,
      subsegmentDuration: g,
      // unscaled
      info: {
        duration: g / i,
        start: o,
        end: o + d - 1
      }
    }), o += d, h += 4, s = h;
  }
  return {
    earliestPresentationTime: r,
    timescale: i,
    version: t,
    referencesCount: c,
    references: e
  };
}
function An(a) {
  const e = [], t = Y(a, ["moov", "trak"]);
  for (let i = 0; i < t.length; i++) {
    const r = t[i], n = Y(r, ["tkhd"])[0];
    if (n) {
      let o = n[0];
      const c = V(n, o === 0 ? 12 : 20), l = Y(r, ["mdia", "mdhd"])[0];
      if (l) {
        o = l[0];
        const h = V(l, o === 0 ? 12 : 20), u = Y(r, ["mdia", "hdlr"])[0];
        if (u) {
          const d = le(u.subarray(8, 12)), f = {
            soun: ie.AUDIO,
            vide: ie.VIDEO
          }[d], g = Y(r, ["mdia", "minf", "stbl", "stsd"])[0], p = Eo(g);
          f ? (e[c] = {
            timescale: h,
            type: f,
            stsd: p
          }, e[f] = te({
            timescale: h,
            id: c
          }, p)) : e[c] = {
            timescale: h,
            type: d,
            stsd: p
          };
        }
      }
    }
  }
  return Y(a, ["moov", "mvex", "trex"]).forEach((i) => {
    const r = V(i, 4), n = e[r];
    n && (n.default = {
      duration: V(i, 12),
      flags: V(i, 20)
    });
  }), e;
}
function Eo(a) {
  const e = a.subarray(8), t = e.subarray(86), s = le(e.subarray(4, 8));
  let i = s, r;
  const n = s === "enca" || s === "encv";
  if (n) {
    const l = Y(e, [s])[0].subarray(s === "enca" ? 28 : 78);
    Y(l, ["sinf"]).forEach((u) => {
      const d = Y(u, ["schm"])[0];
      if (d) {
        const f = le(d.subarray(4, 8));
        if (f === "cbcs" || f === "cenc") {
          const g = Y(u, ["frma"])[0];
          g && (i = le(g));
        }
      }
    });
  }
  const o = i;
  switch (i) {
    case "avc1":
    case "avc2":
    case "avc3":
    case "avc4": {
      const c = Y(t, ["avcC"])[0];
      c && c.length > 3 && (i += "." + Bt(c[1]) + Bt(c[2]) + Bt(c[3]), r = Nt(o === "avc1" ? "dva1" : "dvav", t));
      break;
    }
    case "mp4a": {
      const c = Y(e, [s])[0], l = Y(c.subarray(28), ["esds"])[0];
      if (l && l.length > 7) {
        let h = 4;
        if (l[h++] !== 3)
          break;
        h = Rs(l, h), h += 2;
        const u = l[h++];
        if (u & 128 && (h += 2), u & 64 && (h += l[h++]), l[h++] !== 4)
          break;
        h = Rs(l, h);
        const d = l[h++];
        if (d === 64)
          i += "." + Bt(d);
        else
          break;
        if (h += 12, l[h++] !== 5)
          break;
        h = Rs(l, h);
        const f = l[h++];
        let g = (f & 248) >> 3;
        g === 31 && (g += 1 + ((f & 7) << 3) + ((l[h] & 224) >> 5)), i += "." + g;
      }
      break;
    }
    case "hvc1":
    case "hev1": {
      const c = Y(t, ["hvcC"])[0];
      if (c && c.length > 12) {
        const l = c[1], h = ["", "A", "B", "C"][l >> 6], u = l & 31, d = V(c, 2), f = (l & 32) >> 5 ? "H" : "L", g = c[12], p = c.subarray(6, 12);
        i += "." + h + u, i += "." + d.toString(16).toUpperCase(), i += "." + f + g;
        let E = "";
        for (let y = p.length; y--; ) {
          const S = p[y];
          (S || E) && (E = "." + S.toString(16).toUpperCase() + E);
        }
        i += E;
      }
      r = Nt(o == "hev1" ? "dvhe" : "dvh1", t);
      break;
    }
    case "dvh1":
    case "dvhe":
    case "dvav":
    case "dva1":
    case "dav1": {
      i = Nt(i, t) || i;
      break;
    }
    case "vp09": {
      const c = Y(t, ["vpcC"])[0];
      if (c && c.length > 6) {
        const l = c[4], h = c[5], u = c[6] >> 4 & 15;
        i += "." + Ce(l) + "." + Ce(h) + "." + Ce(u);
      }
      break;
    }
    case "av01": {
      const c = Y(t, ["av1C"])[0];
      if (c && c.length > 2) {
        const l = c[1] >>> 5, h = c[1] & 31, u = c[2] >>> 7 ? "H" : "M", d = (c[2] & 64) >> 6, f = (c[2] & 32) >> 5, g = l === 2 && d ? f ? 12 : 10 : d ? 10 : 8, p = (c[2] & 16) >> 4, E = (c[2] & 8) >> 3, y = (c[2] & 4) >> 2, S = c[2] & 3;
        i += "." + l + "." + Ce(h) + u + "." + Ce(g) + "." + p + "." + E + y + S + "." + Ce(1) + "." + Ce(1) + "." + Ce(1) + "." + 0, r = Nt("dav1", t);
      }
      break;
    }
  }
  return {
    codec: i,
    encrypted: n,
    supplemental: r
  };
}
function Nt(a, e) {
  const t = Y(e, ["dvvC"]), s = t.length ? t[0] : Y(e, ["dvcC"])[0];
  if (s) {
    const i = s[2] >> 1 & 127, r = s[2] << 5 & 32 | s[3] >> 3 & 31;
    return a + "." + Ce(i) + "." + Ce(r);
  }
}
function Rs(a, e) {
  const t = e + 5;
  for (; a[e++] & 128 && e < t; )
    ;
  return e;
}
function Bt(a) {
  return ("0" + a.toString(16).toUpperCase()).slice(-2);
}
function Ce(a) {
  return (a < 10 ? "0" : "") + a;
}
function yo(a, e) {
  if (!a || !e)
    return a;
  const t = e.keyId;
  return t && e.isCommonEncryption && Y(a, ["moov", "trak"]).forEach((i) => {
    const n = Y(i, ["mdia", "minf", "stbl", "stsd"])[0].subarray(8);
    let o = Y(n, ["enca"]);
    const c = o.length > 0;
    c || (o = Y(n, ["encv"])), o.forEach((l) => {
      const h = c ? l.subarray(28) : l.subarray(78);
      Y(h, ["sinf"]).forEach((d) => {
        const f = Ln(d);
        if (f) {
          const g = f.subarray(8, 24);
          g.some((p) => p !== 0) || (Q.log(`[eme] Patching keyId in 'enc${c ? "a" : "v"}>sinf>>tenc' box: ${Pe.hexDump(g)} -> ${Pe.hexDump(t)}`), f.set(t, 8));
        }
      });
    });
  }), a;
}
function Ln(a) {
  const e = Y(a, ["schm"])[0];
  if (e) {
    const t = le(e.subarray(4, 8));
    if (t === "cbcs" || t === "cenc")
      return Y(a, ["schi", "tenc"])[0];
  }
  return null;
}
function To(a, e) {
  return Y(e, ["moof", "traf"]).reduce((t, s) => {
    const i = Y(s, ["tfdt"])[0], r = i[0], n = Y(s, ["tfhd"]).reduce((o, c) => {
      const l = V(c, 4), h = a[l];
      if (h) {
        let u = V(i, 4);
        if (r === 1) {
          if (u === ns)
            return Q.warn("[mp4-demuxer]: Ignoring assumed invalid signed 64-bit track fragment decode time"), o;
          u *= ns + 1, u += V(i, 8);
        }
        const d = h.timescale || 9e4, f = u / d;
        if (M(f) && (o === null || f < o))
          return f;
      }
      return o;
    }, null);
    return n !== null && M(n) && (t === null || n < t) ? n : t;
  }, null);
}
function So(a, e) {
  let t = 0, s = 0, i = 0;
  const r = Y(a, ["moof", "traf"]);
  for (let n = 0; n < r.length; n++) {
    const o = r[n], c = Y(o, ["tfhd"])[0], l = V(c, 4), h = e[l];
    if (!h)
      continue;
    const u = h.default, d = V(c, 0) | (u == null ? void 0 : u.flags);
    let f = u == null ? void 0 : u.duration;
    d & 8 && (d & 2 ? f = V(c, 12) : f = V(c, 8));
    const g = h.timescale || 9e4, p = Y(o, ["trun"]);
    for (let E = 0; E < p.length; E++) {
      if (t = vo(p[E]), !t && f) {
        const y = V(p[E], 4);
        t = f * y;
      }
      h.type === ie.VIDEO ? s += t / g : h.type === ie.AUDIO && (i += t / g);
    }
  }
  if (s === 0 && i === 0) {
    let n = 1 / 0, o = 0, c = 0;
    const l = Y(a, ["sidx"]);
    for (let h = 0; h < l.length; h++) {
      const u = po(l[h]);
      if (u != null && u.references) {
        n = Math.min(n, u.earliestPresentationTime / u.timescale);
        const d = u.references.reduce((f, g) => f + g.info.duration || 0, 0);
        o = Math.max(o, d + u.earliestPresentationTime / u.timescale), c = o - n;
      }
    }
    if (c && M(c))
      return c;
  }
  return s || i;
}
function vo(a) {
  const e = V(a, 0);
  let t = 8;
  e & 1 && (t += 4), e & 4 && (t += 4);
  let s = 0;
  const i = V(a, 4);
  for (let r = 0; r < i; r++) {
    if (e & 256) {
      const n = V(a, t);
      s += n, t += 4;
    }
    e & 512 && (t += 4), e & 1024 && (t += 4), e & 2048 && (t += 4);
  }
  return s;
}
function xo(a, e, t) {
  Y(e, ["moof", "traf"]).forEach((s) => {
    Y(s, ["tfhd"]).forEach((i) => {
      const r = V(i, 4), n = a[r];
      if (!n)
        return;
      const o = n.timescale || 9e4;
      Y(s, ["tfdt"]).forEach((c) => {
        const l = c[0], h = t * o;
        if (h) {
          let u = V(c, 4);
          if (l === 0)
            u -= h, u = Math.max(u, 0), Is(c, 4, u);
          else {
            u *= Math.pow(2, 32), u += V(c, 8), u -= h, u = Math.max(u, 0);
            const d = Math.floor(u / (ns + 1)), f = Math.floor(u % (ns + 1));
            Is(c, 4, d), Is(c, 8, f);
          }
        }
      });
    });
  });
}
function Ao(a) {
  const e = {
    valid: null,
    remainder: null
  }, t = Y(a, ["moof"]);
  if (t.length < 2)
    return e.remainder = a, e;
  const s = t[t.length - 1];
  return e.valid = a.slice(0, s.byteOffset - 8), e.remainder = a.slice(s.byteOffset - 8), e;
}
function Ie(a, e) {
  const t = new Uint8Array(a.length + e.length);
  return t.set(a), t.set(e, a.length), t;
}
function Qi(a, e) {
  const t = [], s = e.samples, i = e.timescale, r = e.id;
  let n = !1;
  return Y(s, ["moof"]).map((c) => {
    const l = c.byteOffset - 8;
    Y(c, ["traf"]).map((u) => {
      const d = Y(u, ["tfdt"]).map((f) => {
        const g = f[0];
        let p = V(f, 4);
        return g === 1 && (p *= Math.pow(2, 32), p += V(f, 8)), p / i;
      })[0];
      return d !== void 0 && (a = d), Y(u, ["tfhd"]).map((f) => {
        const g = V(f, 4), p = V(f, 0) & 16777215, E = (p & 1) !== 0, y = (p & 2) !== 0, S = (p & 8) !== 0;
        let T = 0;
        const v = (p & 16) !== 0;
        let x = 0;
        const _ = (p & 32) !== 0;
        let A = 8;
        g === r && (E && (A += 8), y && (A += 4), S && (T = V(f, A), A += 4), v && (x = V(f, A), A += 4), _ && (A += 4), e.type === "video" && (n = ys(e.codec)), Y(u, ["trun"]).map((b) => {
          const D = b[0], L = V(b, 0) & 16777215, k = (L & 1) !== 0;
          let F = 0;
          const j = (L & 4) !== 0, w = (L & 256) !== 0;
          let U = 0;
          const N = (L & 512) !== 0;
          let B = 0;
          const $ = (L & 1024) !== 0, P = (L & 2048) !== 0;
          let O = 0;
          const W = V(b, 4);
          let H = 8;
          k && (F = V(b, H), H += 4), j && (H += 4);
          let X = F + l;
          for (let Z = 0; Z < W; Z++) {
            if (w ? (U = V(b, H), H += 4) : U = T, N ? (B = V(b, H), H += 4) : B = x, $ && (H += 4), P && (D === 0 ? O = V(b, H) : O = xn(b, H), H += 4), e.type === ie.VIDEO) {
              let ee = 0;
              for (; ee < B; ) {
                const ne = V(s, X);
                if (X += 4, Lo(n, s[X])) {
                  const me = s.subarray(X, X + ne);
                  mi(me, n ? 2 : 1, a + O / i, t);
                }
                X += ne, ee += ne + 4;
              }
            }
            a += U / i;
          }
        }));
      });
    });
  }), t;
}
function ys(a) {
  if (!a)
    return !1;
  const e = a.substring(0, 4);
  return e === "hvc1" || e === "hev1" || // Dolby Vision
  e === "dvh1" || e === "dvhe";
}
function Lo(a, e) {
  if (a) {
    const t = e >> 1 & 63;
    return t === 39 || t === 40;
  } else
    return (e & 31) === 6;
}
function mi(a, e, t, s) {
  const i = In(a);
  let r = 0;
  r += e;
  let n = 0, o = 0, c = 0;
  for (; r < i.length; ) {
    n = 0;
    do {
      if (r >= i.length)
        break;
      c = i[r++], n += c;
    } while (c === 255);
    o = 0;
    do {
      if (r >= i.length)
        break;
      c = i[r++], o += c;
    } while (c === 255);
    const l = i.length - r;
    let h = r;
    if (o < l)
      r += o;
    else if (o > l) {
      Q.error(`Malformed SEI payload. ${o} is too small, only ${l} bytes left to parse.`);
      break;
    }
    if (n === 4) {
      if (i[h++] === 181) {
        const d = vn(i, h);
        if (h += 2, d === 49) {
          const f = V(i, h);
          if (h += 4, f === 1195456820) {
            const g = i[h++];
            if (g === 3) {
              const p = i[h++], E = 31 & p, y = 64 & p, S = y ? 2 + E * 3 : 0, T = new Uint8Array(S);
              if (y) {
                T[0] = p;
                for (let v = 1; v < S; v++)
                  T[v] = i[h++];
              }
              s.push({
                type: g,
                payloadType: n,
                pts: t,
                bytes: T
              });
            }
          }
        }
      }
    } else if (n === 5 && o > 16) {
      const u = [];
      for (let g = 0; g < 16; g++) {
        const p = i[h++].toString(16);
        u.push(p.length == 1 ? "0" + p : p), (g === 3 || g === 5 || g === 7 || g === 9) && u.push("-");
      }
      const d = o - 16, f = new Uint8Array(d);
      for (let g = 0; g < d; g++)
        f[g] = i[h++];
      s.push({
        payloadType: n,
        pts: t,
        uuid: u.join(""),
        userData: ve(f),
        userDataBytes: f
      });
    }
  }
}
function In(a) {
  const e = a.byteLength, t = [];
  let s = 1;
  for (; s < e - 2; )
    a[s] === 0 && a[s + 1] === 0 && a[s + 2] === 3 ? (t.push(s + 2), s += 2) : s++;
  if (t.length === 0)
    return a;
  const i = e - t.length, r = new Uint8Array(i);
  let n = 0;
  for (s = 0; s < i; n++, s++)
    n === t[0] && (n++, t.shift()), r[s] = a[n];
  return r;
}
function Io(a) {
  const e = a[0];
  let t = "", s = "", i = 0, r = 0, n = 0, o = 0, c = 0, l = 0;
  if (e === 0) {
    for (; le(a.subarray(l, l + 1)) !== "\0"; )
      t += le(a.subarray(l, l + 1)), l += 1;
    for (t += le(a.subarray(l, l + 1)), l += 1; le(a.subarray(l, l + 1)) !== "\0"; )
      s += le(a.subarray(l, l + 1)), l += 1;
    s += le(a.subarray(l, l + 1)), l += 1, i = V(a, 12), r = V(a, 16), o = V(a, 20), c = V(a, 24), l = 28;
  } else if (e === 1) {
    l += 4, i = V(a, l), l += 4;
    const u = V(a, l);
    l += 4;
    const d = V(a, l);
    for (l += 4, n = 2 ** 32 * u + d, Ja(n) || (n = Number.MAX_SAFE_INTEGER, Q.warn("Presentation time exceeds safe integer limit and wrapped to max safe integer in parsing emsg box")), o = V(a, l), l += 4, c = V(a, l), l += 4; le(a.subarray(l, l + 1)) !== "\0"; )
      t += le(a.subarray(l, l + 1)), l += 1;
    for (t += le(a.subarray(l, l + 1)), l += 1; le(a.subarray(l, l + 1)) !== "\0"; )
      s += le(a.subarray(l, l + 1)), l += 1;
    s += le(a.subarray(l, l + 1)), l += 1;
  }
  const h = a.subarray(l, a.byteLength);
  return {
    schemeIdUri: t,
    value: s,
    timeScale: i,
    presentationTime: n,
    presentationTimeDelta: r,
    eventDuration: o,
    id: c,
    payload: h
  };
}
function Ro(a, ...e) {
  const t = e.length;
  let s = 8, i = t;
  for (; i--; )
    s += e[i].byteLength;
  const r = new Uint8Array(s);
  for (r[0] = s >> 24 & 255, r[1] = s >> 16 & 255, r[2] = s >> 8 & 255, r[3] = s & 255, r.set(a, 4), i = 0, s = 8; i < t; i++)
    r.set(e[i], s), s += e[i].byteLength;
  return r;
}
function bo(a, e, t) {
  if (a.byteLength !== 16)
    throw new RangeError("Invalid system id");
  let s, i;
  s = 0, i = new Uint8Array();
  let r;
  s > 0 ? (r = new Uint8Array(4), e.length > 0 && new DataView(r.buffer).setUint32(0, e.length, !1)) : r = new Uint8Array();
  const n = new Uint8Array(4);
  return t && t.byteLength > 0 && new DataView(n.buffer).setUint32(0, t.byteLength, !1), Ro(
    [112, 115, 115, 104],
    new Uint8Array([
      s,
      0,
      0,
      0
      // Flags
    ]),
    a,
    // 16 bytes
    r,
    i,
    n,
    t || new Uint8Array()
  );
}
function _o(a) {
  const e = [];
  if (a instanceof ArrayBuffer) {
    const t = a.byteLength;
    let s = 0;
    for (; s + 32 < t; ) {
      const i = new DataView(a, s), r = Do(i);
      e.push(r), s += r.size;
    }
  }
  return e;
}
function Do(a) {
  const e = a.getUint32(0), t = a.byteOffset, s = a.byteLength;
  if (s < e)
    return {
      offset: t,
      size: s
    };
  if (a.getUint32(4) !== 1886614376)
    return {
      offset: t,
      size: e
    };
  const r = a.getUint32(8) >>> 24;
  if (r !== 0 && r !== 1)
    return {
      offset: t,
      size: e
    };
  const n = a.buffer, o = Pe.hexDump(new Uint8Array(n, t + 12, 16)), c = a.getUint32(28);
  let l = null, h = null;
  if (r === 0) {
    if (e - 32 < c || c < 22)
      return {
        offset: t,
        size: e
      };
    h = new Uint8Array(n, t + 32, c);
  } else if (r === 1) {
    if (!c || s < t + 32 + c * 16 + 16)
      return {
        offset: t,
        size: e
      };
    l = [];
    for (let u = 0; u < c; u++)
      l.push(new Uint8Array(n, t + 32 + u * 16, 16));
  }
  return {
    version: r,
    systemId: o,
    kids: l,
    data: h,
    offset: t,
    size: e
  };
}
const Rn = () => /\(Windows.+Firefox\//i.test(navigator.userAgent), mt = {
  audio: {
    a3ds: 1,
    "ac-3": 0.95,
    "ac-4": 1,
    alac: 0.9,
    alaw: 1,
    dra1: 1,
    "dts+": 1,
    "dts-": 1,
    dtsc: 1,
    dtse: 1,
    dtsh: 1,
    "ec-3": 0.9,
    enca: 1,
    fLaC: 0.9,
    // MP4-RA listed codec entry for FLAC
    flac: 0.9,
    // legacy browser codec name for FLAC
    FLAC: 0.9,
    // some manifests may list "FLAC" with Apple's tools
    g719: 1,
    g726: 1,
    m4ae: 1,
    mha1: 1,
    mha2: 1,
    mhm1: 1,
    mhm2: 1,
    mlpa: 1,
    mp4a: 1,
    "raw ": 1,
    Opus: 1,
    opus: 1,
    // browsers expect this to be lowercase despite MP4RA says 'Opus'
    samr: 1,
    sawb: 1,
    sawp: 1,
    sevc: 1,
    sqcp: 1,
    ssmv: 1,
    twos: 1,
    ulaw: 1
  },
  video: {
    avc1: 1,
    avc2: 1,
    avc3: 1,
    avc4: 1,
    avcp: 1,
    av01: 0.8,
    dav1: 0.8,
    drac: 1,
    dva1: 1,
    dvav: 1,
    dvh1: 0.7,
    dvhe: 0.7,
    encv: 1,
    hev1: 0.75,
    hvc1: 0.75,
    mjp2: 1,
    mp4v: 1,
    mvc1: 1,
    mvc2: 1,
    mvc3: 1,
    mvc4: 1,
    resv: 1,
    rv60: 1,
    s263: 1,
    svc1: 1,
    svc2: 1,
    "vc-1": 1,
    vp08: 1,
    vp09: 0.9
  },
  text: {
    stpp: 1,
    wvtt: 1
  }
};
function bn(a, e) {
  const t = mt[e];
  return !!t && !!t[a.slice(0, 4)];
}
function Qs(a, e, t = !0) {
  return !a.split(",").some((s) => !_n(s, e, t));
}
function _n(a, e, t = !0) {
  var s;
  const i = ze(t);
  return (s = i == null ? void 0 : i.isTypeSupported(bt(a, e))) != null ? s : !1;
}
function bt(a, e) {
  return `${e}/mp4;codecs=${a}`;
}
function Zi(a) {
  if (a) {
    const e = a.substring(0, 4);
    return mt.video[e];
  }
  return 2;
}
function as(a) {
  const e = Rn();
  return a.split(",").reduce((t, s) => {
    const r = e && ys(s) ? 9 : mt.video[s];
    return r ? (r * 2 + t) / (t ? 3 : 2) : (mt.audio[s] + t) / (t ? 2 : 1);
  }, 0);
}
const bs = {};
function Co(a, e = !0) {
  if (bs[a])
    return bs[a];
  const t = {
    // Idealy fLaC and Opus would be first (spec-compliant) but
    // some browsers will report that fLaC is supported then fail.
    // see: https://bugs.chromium.org/p/chromium/issues/detail?id=1422728
    flac: ["flac", "fLaC", "FLAC"],
    opus: ["opus", "Opus"],
    // Replace audio codec info if browser does not support mp4a.40.34,
    // and demuxer can fallback to 'audio/mpeg' or 'audio/mp4;codecs="mp3"'
    "mp4a.40.34": ["mp3"]
  }[a];
  for (let i = 0; i < t.length; i++) {
    var s;
    if (_n(t[i], "audio", e))
      return bs[a] = t[i], t[i];
    if (t[i] === "mp3" && (s = ze(e)) != null && s.isTypeSupported("audio/mpeg"))
      return "";
  }
  return a;
}
const Po = /flac|opus|mp4a\.40\.34/i;
function os(a, e = !0) {
  return a.replace(Po, (t) => Co(t.toLowerCase(), e));
}
function ko(a, e) {
  const t = [];
  if (a) {
    const s = a.split(",");
    for (let i = 0; i < s.length; i++)
      bn(s[i], "video") || t.push(s[i]);
  }
  return e && t.push(e), t.join(",");
}
function Zt(a, e) {
  if (a && (a.length > 4 || ["ac-3", "ec-3", "alac", "fLaC", "Opus"].indexOf(a) !== -1))
    return a;
  if (e) {
    const t = e.split(",");
    if (t.length > 1) {
      if (a) {
        for (let s = t.length; s--; )
          if (t[s].substring(0, 4) === a.substring(0, 4))
            return t[s];
      }
      return t[0];
    }
  }
  return e || a;
}
function wo(a) {
  const e = a.split(",");
  for (let t = 0; t < e.length; t++) {
    const s = e[t].split(".");
    if (s.length > 2) {
      let i = s.shift() + ".";
      i += parseInt(s.shift()).toString(16), i += ("000" + parseInt(s.shift()).toString(16)).slice(-4), e[t] = i;
    }
  }
  return e.join(",");
}
function Oo(a) {
  if (a.startsWith("av01.")) {
    const e = a.split("."), t = ["0", "111", "01", "01", "01", "0"];
    for (let s = e.length; s > 4 && s < 10; s++)
      e[s] = t[s - 4];
    return e.join(".");
  }
  return a;
}
function Ji(a) {
  const e = ze(a) || {
    isTypeSupported: () => !1
  };
  return {
    mpeg: e.isTypeSupported("audio/mpeg"),
    mp3: e.isTypeSupported('audio/mp4; codecs="mp3"'),
    ac3: e.isTypeSupported('audio/mp4; codecs="ac-3"')
  };
}
function Dn(a) {
  return a.replace(/^.+codecs=["']?([^"']+).*$/, "$1");
}
const Cn = {
  supported: !0,
  configurations: [],
  decodingInfoResults: [{
    supported: !0,
    powerEfficient: !0,
    smooth: !0
  }]
};
function Pn(a, e) {
  return {
    supported: !1,
    configurations: e,
    decodingInfoResults: [{
      supported: !1,
      smooth: !1,
      powerEfficient: !1
    }],
    error: a
  };
}
const er = {};
function Fo(a, e, t, s, i, r) {
  const n = a.audioCodec ? a.audioGroups : null, o = r == null ? void 0 : r.audioCodec, c = r == null ? void 0 : r.channels, l = c ? parseInt(c) : o ? 1 / 0 : 2;
  let h = null;
  if (n != null && n.length)
    try {
      n.length === 1 && n[0] ? h = e.groups[n[0]].channels : h = n.reduce((u, d) => {
        if (d) {
          const f = e.groups[d];
          if (!f)
            throw new Error(`Audio track group ${d} not found`);
          Object.keys(f.channels).forEach((g) => {
            u[g] = (u[g] || 0) + f.channels[g];
          });
        }
        return u;
      }, {
        2: 0
      });
    } catch {
      return !0;
    }
  return a.videoCodec !== void 0 && (a.width > 1920 && a.height > 1088 || a.height > 1920 && a.width > 1088 || a.frameRate > Math.max(s, 30) || a.videoRange !== "SDR" && a.videoRange !== t || a.bitrate > Math.max(i, 8e6)) || !!h && M(l) && Object.keys(h).some((u) => parseInt(u) > l);
}
function kn(a, e, t) {
  const s = a.videoCodec, i = a.audioCodec;
  if (!s && !i || !t)
    return Promise.resolve(Cn);
  const r = [];
  if (s) {
    const n = {
      width: a.width,
      height: a.height,
      bitrate: Math.ceil(Math.max(a.bitrate * 0.9, a.averageBitrate)),
      // Assume a framerate of 30fps since MediaCapabilities will not accept Level default of 0.
      framerate: a.frameRate || 30
    }, o = a.videoRange;
    o !== "SDR" && (n.transferFunction = o.toLowerCase());
    const c = s.split(","), l = navigator.userAgent;
    if (c.some((h) => ys(h)) && Rn())
      return Promise.resolve(Pn(new Error(`Overriding Windows Firefox HEVC MediaCapabilities result based on user-agent sting: (${l})`), r));
    r.push.apply(r, c.map((h) => ({
      type: "media-source",
      video: te(te({}, n), {}, {
        contentType: bt(Oo(h), "video")
      })
    })));
  }
  return i && a.audioGroups && a.audioGroups.forEach((n) => {
    var o;
    n && ((o = e.groups[n]) == null || o.tracks.forEach((c) => {
      if (c.groupId === n) {
        const l = c.channels || "", h = parseFloat(l);
        M(h) && h > 2 && r.push.apply(r, i.split(",").map((u) => ({
          type: "media-source",
          audio: {
            contentType: bt(u, "audio"),
            channels: "" + h
            // spatialRendering:
            //   audioCodec === 'ec-3' && channels.indexOf('JOC'),
          }
        })));
      }
    }));
  }), Promise.all(r.map((n) => {
    const o = Mo(n);
    return er[o] || (er[o] = t.decodingInfo(n));
  })).then((n) => ({
    supported: !n.some((o) => !o.supported),
    configurations: r,
    decodingInfoResults: n
  })).catch((n) => ({
    supported: !1,
    configurations: r,
    decodingInfoResults: [],
    error: n
  }));
}
function Mo(a) {
  const {
    audio: e,
    video: t
  } = a, s = t || e;
  if (s) {
    const i = Dn(s.contentType);
    if (t)
      return `r${t.height}x${t.width}f${Math.ceil(t.framerate)}${t.transferFunction || "sd"}_${i}_${Math.ceil(t.bitrate / 1e5)}`;
    if (e)
      return `c${e.channels}${e.spatialRendering ? "s" : "n"}_${i}`;
  }
  return "";
}
const Zs = ["NONE", "TYPE-0", "TYPE-1", null];
function No(a) {
  return Zs.indexOf(a) > -1;
}
const ls = ["SDR", "PQ", "HLG"];
function Bo(a) {
  return !!a && ls.indexOf(a) > -1;
}
var Jt = {
  No: "",
  Yes: "YES",
  v2: "v2"
};
function tr(a) {
  const {
    canSkipUntil: e,
    canSkipDateRanges: t,
    age: s
  } = a, i = s < e / 2;
  return e && i ? t ? Jt.v2 : Jt.Yes : Jt.No;
}
class sr {
  constructor(e, t, s) {
    this.msn = void 0, this.part = void 0, this.skip = void 0, this.msn = e, this.part = t, this.skip = s;
  }
  addDirectives(e) {
    const t = new self.URL(e);
    return this.msn !== void 0 && t.searchParams.set("_HLS_msn", this.msn.toString()), this.part !== void 0 && t.searchParams.set("_HLS_part", this.part.toString()), this.skip && t.searchParams.set("_HLS_skip", this.skip), t.href;
  }
}
class _t {
  constructor(e) {
    if (this._attrs = void 0, this.audioCodec = void 0, this.bitrate = void 0, this.codecSet = void 0, this.url = void 0, this.frameRate = void 0, this.height = void 0, this.id = void 0, this.name = void 0, this.supplemental = void 0, this.videoCodec = void 0, this.width = void 0, this.details = void 0, this.fragmentError = 0, this.loadError = 0, this.loaded = void 0, this.realBitrate = 0, this.supportedPromise = void 0, this.supportedResult = void 0, this._avgBitrate = 0, this._audioGroups = void 0, this._subtitleGroups = void 0, this._urlId = 0, this.url = [e.url], this._attrs = [e.attrs], this.bitrate = e.bitrate, e.details && (this.details = e.details), this.id = e.id || 0, this.name = e.name, this.width = e.width || 0, this.height = e.height || 0, this.frameRate = e.attrs.optionalFloat("FRAME-RATE", 0), this._avgBitrate = e.attrs.decimalInteger("AVERAGE-BANDWIDTH"), this.audioCodec = e.audioCodec, this.videoCodec = e.videoCodec, this.codecSet = [e.videoCodec, e.audioCodec].filter((s) => !!s).map((s) => s.substring(0, 4)).join(","), "supplemental" in e) {
      var t;
      this.supplemental = e.supplemental;
      const s = (t = e.supplemental) == null ? void 0 : t.videoCodec;
      s && s !== e.videoCodec && (this.codecSet += `,${s.substring(0, 4)}`);
    }
    this.addGroupId("audio", e.attrs.AUDIO), this.addGroupId("text", e.attrs.SUBTITLES);
  }
  get maxBitrate() {
    return Math.max(this.realBitrate, this.bitrate);
  }
  get averageBitrate() {
    return this._avgBitrate || this.realBitrate || this.bitrate;
  }
  get attrs() {
    return this._attrs[0];
  }
  get codecs() {
    return this.attrs.CODECS || "";
  }
  get pathwayId() {
    return this.attrs["PATHWAY-ID"] || ".";
  }
  get videoRange() {
    return this.attrs["VIDEO-RANGE"] || "SDR";
  }
  get score() {
    return this.attrs.optionalFloat("SCORE", 0);
  }
  get uri() {
    return this.url[0] || "";
  }
  hasAudioGroup(e) {
    return ir(this._audioGroups, e);
  }
  hasSubtitleGroup(e) {
    return ir(this._subtitleGroups, e);
  }
  get audioGroups() {
    return this._audioGroups;
  }
  get subtitleGroups() {
    return this._subtitleGroups;
  }
  addGroupId(e, t) {
    if (t) {
      if (e === "audio") {
        let s = this._audioGroups;
        s || (s = this._audioGroups = []), s.indexOf(t) === -1 && s.push(t);
      } else if (e === "text") {
        let s = this._subtitleGroups;
        s || (s = this._subtitleGroups = []), s.indexOf(t) === -1 && s.push(t);
      }
    }
  }
  // Deprecated methods (retained for backwards compatibility)
  get urlId() {
    return 0;
  }
  set urlId(e) {
  }
  get audioGroupIds() {
    return this.audioGroups ? [this.audioGroupId] : void 0;
  }
  get textGroupIds() {
    return this.subtitleGroups ? [this.textGroupId] : void 0;
  }
  get audioGroupId() {
    var e;
    return (e = this.audioGroups) == null ? void 0 : e[0];
  }
  get textGroupId() {
    var e;
    return (e = this.subtitleGroups) == null ? void 0 : e[0];
  }
  addFallback() {
  }
}
function ir(a, e) {
  return !e || !a ? !1 : a.indexOf(e) !== -1;
}
function Uo() {
  if (typeof matchMedia == "function") {
    const a = matchMedia("(dynamic-range: high)"), e = matchMedia("bad query");
    if (a.media !== e.media)
      return a.matches === !0;
  }
  return !1;
}
function $o(a, e) {
  let t = !1, s = [];
  if (a && (t = a !== "SDR", s = [a]), e) {
    s = e.allowedVideoRanges || ls.slice(0);
    const i = s.join("") !== "SDR" && !e.videoCodec;
    t = e.preferHDR !== void 0 ? e.preferHDR : i && Uo(), t || (s = ["SDR"]);
  }
  return {
    preferHDR: t,
    allowedVideoRanges: s
  };
}
const Go = (a) => {
  const e = /* @__PURE__ */ new WeakSet();
  return (t, s) => {
    if (a && (s = a(t, s)), typeof s == "object" && s !== null) {
      if (e.has(s))
        return;
      e.add(s);
    }
    return s;
  };
}, ae = (a, e) => JSON.stringify(a, Go(e));
function Ko(a, e, t, s, i) {
  const r = Object.keys(a), n = s == null ? void 0 : s.channels, o = s == null ? void 0 : s.audioCodec, c = i == null ? void 0 : i.videoCodec, l = n && parseInt(n) === 2;
  let h = !1, u = !1, d = 1 / 0, f = 1 / 0, g = 1 / 0, p = 1 / 0, E = 0, y = [];
  const {
    preferHDR: S,
    allowedVideoRanges: T
  } = $o(e, i);
  for (let b = r.length; b--; ) {
    const D = a[r[b]];
    h || (h = D.channels[2] > 0), d = Math.min(d, D.minHeight), f = Math.min(f, D.minFramerate), g = Math.min(g, D.minBitrate), T.filter((k) => D.videoRanges[k] > 0).length > 0 && (u = !0);
  }
  d = M(d) ? d : 0, f = M(f) ? f : 0;
  const v = Math.max(1080, d), x = Math.max(30, f);
  g = M(g) ? g : t, t = Math.max(g, t), u || (e = void 0);
  const _ = r.length > 1;
  return {
    codecSet: r.reduce((b, D) => {
      const L = a[D];
      if (D === b)
        return b;
      if (y = u ? T.filter((k) => L.videoRanges[k] > 0) : [], _) {
        if (L.minBitrate > t)
          return De(D, `min bitrate of ${L.minBitrate} > current estimate of ${t}`), b;
        if (!L.hasDefaultAudio)
          return De(D, "no renditions with default or auto-select sound found"), b;
        if (o && D.indexOf(o.substring(0, 4)) % 5 !== 0)
          return De(D, `audio codec preference "${o}" not found`), b;
        if (n && !l) {
          if (!L.channels[n])
            return De(D, `no renditions with ${n} channel sound found (channels options: ${Object.keys(L.channels)})`), b;
        } else if ((!o || l) && h && L.channels[2] === 0)
          return De(D, "no renditions with stereo sound found"), b;
        if (L.minHeight > v)
          return De(D, `min resolution of ${L.minHeight} > maximum of ${v}`), b;
        if (L.minFramerate > x)
          return De(D, `min framerate of ${L.minFramerate} > maximum of ${x}`), b;
        if (!y.some((k) => L.videoRanges[k] > 0))
          return De(D, `no variants with VIDEO-RANGE of ${ae(y)} found`), b;
        if (c && D.indexOf(c.substring(0, 4)) % 5 !== 0)
          return De(D, `video codec preference "${c}" not found`), b;
        if (L.maxScore < E)
          return De(D, `max score of ${L.maxScore} < selected max of ${E}`), b;
      }
      return b && (as(D) >= as(b) || L.fragmentError > a[b].fragmentError) ? b : (p = L.minIndex, E = L.maxScore, D);
    }, void 0),
    videoRanges: y,
    preferHDR: S,
    minFramerate: f,
    minBitrate: g,
    minIndex: p
  };
}
function De(a, e) {
  Q.log(`[abr] start candidates with "${a}" ignored because ${e}`);
}
function wn(a) {
  return a.reduce((e, t) => {
    let s = e.groups[t.groupId];
    s || (s = e.groups[t.groupId] = {
      tracks: [],
      channels: {
        2: 0
      },
      hasDefault: !1,
      hasAutoSelect: !1
    }), s.tracks.push(t);
    const i = t.channels || "2";
    return s.channels[i] = (s.channels[i] || 0) + 1, s.hasDefault = s.hasDefault || t.default, s.hasAutoSelect = s.hasAutoSelect || t.autoselect, s.hasDefault && (e.hasDefaultAudio = !0), s.hasAutoSelect && (e.hasAutoSelectAudio = !0), e;
  }, {
    hasDefaultAudio: !1,
    hasAutoSelectAudio: !1,
    groups: {}
  });
}
function Vo(a, e, t, s) {
  return a.slice(t, s + 1).reduce((i, r, n) => {
    if (!r.codecSet)
      return i;
    const o = r.audioGroups;
    let c = i[r.codecSet];
    c || (i[r.codecSet] = c = {
      minBitrate: 1 / 0,
      minHeight: 1 / 0,
      minFramerate: 1 / 0,
      minIndex: n,
      maxScore: 0,
      videoRanges: {
        SDR: 0
      },
      channels: {
        2: 0
      },
      hasDefaultAudio: !o,
      fragmentError: 0
    }), c.minBitrate = Math.min(c.minBitrate, r.bitrate);
    const l = Math.min(r.height, r.width);
    return c.minHeight = Math.min(c.minHeight, l), c.minFramerate = Math.min(c.minFramerate, r.frameRate), c.minIndex = Math.min(c.minIndex, n), c.maxScore = Math.max(c.maxScore, r.score), c.fragmentError += r.fragmentError, c.videoRanges[r.videoRange] = (c.videoRanges[r.videoRange] || 0) + 1, o && o.forEach((h) => {
      if (!h)
        return;
      const u = e.groups[h];
      u && (c.hasDefaultAudio = c.hasDefaultAudio || e.hasDefaultAudio ? u.hasDefault : u.hasAutoSelect || !e.hasDefaultAudio && !e.hasAutoSelectAudio, Object.keys(u.channels).forEach((d) => {
        c.channels[d] = (c.channels[d] || 0) + u.channels[d];
      }));
    }), i;
  }, {});
}
function rr(a) {
  if (!a)
    return a;
  const {
    lang: e,
    assocLang: t,
    characteristics: s,
    channels: i,
    audioCodec: r
  } = a;
  return {
    lang: e,
    assocLang: t,
    characteristics: s,
    channels: i,
    audioCodec: r
  };
}
function we(a, e, t) {
  if ("attrs" in a) {
    const s = e.indexOf(a);
    if (s !== -1)
      return s;
  }
  for (let s = 0; s < e.length; s++) {
    const i = e[s];
    if (st(a, i, t))
      return s;
  }
  return -1;
}
function st(a, e, t) {
  const {
    groupId: s,
    name: i,
    lang: r,
    assocLang: n,
    default: o
  } = a, c = a.forced;
  return (s === void 0 || e.groupId === s) && (i === void 0 || e.name === i) && (r === void 0 || Ho(r, e.lang)) && (r === void 0 || e.assocLang === n) && (o === void 0 || e.default === o) && (c === void 0 || e.forced === c) && (!("characteristics" in a) || Wo(a.characteristics || "", e.characteristics)) && (t === void 0 || t(a, e));
}
function Ho(a, e = "--") {
  return a.length === e.length ? a === e : a.startsWith(e) || e.startsWith(a);
}
function Wo(a, e = "") {
  const t = a.split(","), s = e.split(",");
  return t.length === s.length && !t.some((i) => s.indexOf(i) === -1);
}
function tt(a, e) {
  const {
    audioCodec: t,
    channels: s
  } = a;
  return (t === void 0 || (e.audioCodec || "").substring(0, 4) === t.substring(0, 4)) && (s === void 0 || s === (e.channels || "2"));
}
function Yo(a, e, t, s, i) {
  const r = e[s], o = e.reduce((d, f, g) => {
    const p = f.uri;
    return (d[p] || (d[p] = [])).push(g), d;
  }, {})[r.uri];
  o.length > 1 && (s = Math.max.apply(Math, o));
  const c = r.videoRange, l = r.frameRate, h = r.codecSet.substring(0, 4), u = nr(e, s, (d) => {
    if (d.videoRange !== c || d.frameRate !== l || d.codecSet.substring(0, 4) !== h)
      return !1;
    const f = d.audioGroups, g = t.filter((p) => !f || f.indexOf(p.groupId) !== -1);
    return we(a, g, i) > -1;
  });
  return u > -1 ? u : nr(e, s, (d) => {
    const f = d.audioGroups, g = t.filter((p) => !f || f.indexOf(p.groupId) !== -1);
    return we(a, g, i) > -1;
  });
}
function nr(a, e, t) {
  for (let s = e; s > -1; s--)
    if (t(a[s]))
      return s;
  for (let s = e + 1; s < a.length; s++)
    if (t(a[s]))
      return s;
  return -1;
}
function cs(a, e) {
  var t;
  return !!a && a !== ((t = e.loadLevelObj) == null ? void 0 : t.uri);
}
class qo extends Ve {
  constructor(e) {
    super("abr", e.logger), this.hls = void 0, this.lastLevelLoadSec = 0, this.lastLoadedFragLevel = -1, this.firstSelection = -1, this._nextAutoLevel = -1, this.nextAutoLevelKey = "", this.audioTracksByGroup = null, this.codecTiers = null, this.timer = -1, this.fragCurrent = null, this.partCurrent = null, this.bitrateTestDelay = 0, this.rebufferNotice = -1, this.bwEstimator = void 0, this._abandonRulesCheck = (t) => {
      var s;
      const {
        fragCurrent: i,
        partCurrent: r,
        hls: n
      } = this, {
        autoLevelEnabled: o,
        media: c
      } = n;
      if (!i || !c)
        return;
      const l = performance.now(), h = r ? r.stats : i.stats, u = r ? r.duration : i.duration, d = l - h.loading.start, f = n.minAutoLevel, g = i.level, p = this._nextAutoLevel;
      if (h.aborted || h.loaded && h.loaded === h.total || g <= f) {
        this.clearTimer(), this._nextAutoLevel = -1;
        return;
      }
      if (!o)
        return;
      const E = p > -1 && p !== g, y = !!t || E;
      if (!y && (c.paused || !c.playbackRate || !c.readyState))
        return;
      const S = n.mainForwardBufferInfo;
      if (!y && S === null)
        return;
      const T = this.bwEstimator.getEstimateTTFB(), v = Math.abs(c.playbackRate);
      if (d <= Math.max(T, 1e3 * (u / (v * 2))))
        return;
      const x = S ? S.len / v : 0, _ = h.loading.first ? h.loading.first - h.loading.start : -1, A = h.loaded && _ > -1, b = this.getBwEstimate(), D = n.levels, L = D[g], k = Math.max(h.loaded, Math.round(u * (i.bitrate || L.averageBitrate) / 8));
      let F = A ? d - _ : d;
      F < 1 && A && (F = Math.min(d, h.loaded * 8 / b));
      const j = A ? h.loaded * 1e3 / F : 0, w = T / 1e3, U = j ? (k - h.loaded) / j : k * 8 / b + w;
      if (U <= x)
        return;
      const N = j ? j * 8 : b, B = ((s = (t == null ? void 0 : t.details) || this.hls.latestLevelDetails) == null ? void 0 : s.live) === !0, $ = this.hls.config.abrBandWidthUpFactor;
      let P = Number.POSITIVE_INFINITY, O;
      for (O = g - 1; O > f; O--) {
        const Z = D[O].maxBitrate, ee = !D[O].details || B;
        if (P = this.getTimeToLoadFrag(w, N, u * Z, ee), P < Math.min(x, u + w))
          break;
      }
      if (P >= U || P > u * 10)
        return;
      A ? this.bwEstimator.sample(d - Math.min(T, _), h.loaded) : this.bwEstimator.sampleTTFB(d);
      const W = D[O].maxBitrate;
      this.getBwEstimate() * $ > W && this.resetEstimator(W);
      const H = this.findBestLevel(W, f, O, 0, x, 1, 1);
      H > -1 && (O = H), this.warn(`Fragment ${i.sn}${r ? " part " + r.index : ""} of level ${g} is loading too slowly;
      Fragment duration: ${i.duration.toFixed(3)}
      Time to underbuffer: ${x.toFixed(3)} s
      Estimated load time for current fragment: ${U.toFixed(3)} s
      Estimated load time for down switch fragment: ${P.toFixed(3)} s
      TTFB estimate: ${_ | 0} ms
      Current BW estimate: ${M(b) ? b | 0 : "Unknown"} bps
      New BW estimate: ${this.getBwEstimate() | 0} bps
      Switching to level ${O} @ ${W | 0} bps`), n.nextLoadLevel = n.nextAutoLevel = O, this.clearTimer();
      const X = () => {
        if (this.clearTimer(), this.fragCurrent === i && this.hls.loadLevel === O && O > 0) {
          const Z = this.getStarvationDelay();
          if (this.warn(`Aborting inflight request ${O > 0 ? "and switching down" : ""}
      Fragment duration: ${i.duration.toFixed(3)} s
      Time to underbuffer: ${Z.toFixed(3)} s`), i.abortRequests(), this.fragCurrent = this.partCurrent = null, O > f) {
            let ee = this.findBestLevel(this.hls.levels[f].bitrate, f, O, 0, Z, 1, 1);
            ee === -1 && (ee = f), this.hls.nextLoadLevel = this.hls.nextAutoLevel = ee, this.resetEstimator(this.hls.levels[ee].bitrate);
          }
        }
      };
      E || U > P * 2 ? X() : this.timer = self.setInterval(X, P * 1e3), n.trigger(m.FRAG_LOAD_EMERGENCY_ABORTED, {
        frag: i,
        part: r,
        stats: h
      });
    }, this.hls = e, this.bwEstimator = this.initEstimator(), this.registerListeners();
  }
  resetEstimator(e) {
    e && (this.log(`setting initial bwe to ${e}`), this.hls.config.abrEwmaDefaultEstimate = e), this.firstSelection = -1, this.bwEstimator = this.initEstimator();
  }
  initEstimator() {
    const e = this.hls.config;
    return new to(e.abrEwmaSlowVoD, e.abrEwmaFastVoD, e.abrEwmaDefaultEstimate);
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.FRAG_LOADING, this.onFragLoading, this), e.on(m.FRAG_LOADED, this.onFragLoaded, this), e.on(m.FRAG_BUFFERED, this.onFragBuffered, this), e.on(m.LEVEL_SWITCHING, this.onLevelSwitching, this), e.on(m.LEVEL_LOADED, this.onLevelLoaded, this), e.on(m.LEVELS_UPDATED, this.onLevelsUpdated, this), e.on(m.MAX_AUTO_LEVEL_UPDATED, this.onMaxAutoLevelUpdated, this), e.on(m.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e && (e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.FRAG_LOADING, this.onFragLoading, this), e.off(m.FRAG_LOADED, this.onFragLoaded, this), e.off(m.FRAG_BUFFERED, this.onFragBuffered, this), e.off(m.LEVEL_SWITCHING, this.onLevelSwitching, this), e.off(m.LEVEL_LOADED, this.onLevelLoaded, this), e.off(m.LEVELS_UPDATED, this.onLevelsUpdated, this), e.off(m.MAX_AUTO_LEVEL_UPDATED, this.onMaxAutoLevelUpdated, this), e.off(m.ERROR, this.onError, this));
  }
  destroy() {
    this.unregisterListeners(), this.clearTimer(), this.hls = this._abandonRulesCheck = null, this.fragCurrent = this.partCurrent = null;
  }
  onManifestLoading(e, t) {
    this.lastLoadedFragLevel = -1, this.firstSelection = -1, this.lastLevelLoadSec = 0, this.fragCurrent = this.partCurrent = null, this.onLevelsUpdated(), this.clearTimer();
  }
  onLevelsUpdated() {
    this.lastLoadedFragLevel > -1 && this.fragCurrent && (this.lastLoadedFragLevel = this.fragCurrent.level), this._nextAutoLevel = -1, this.onMaxAutoLevelUpdated(), this.codecTiers = null, this.audioTracksByGroup = null;
  }
  onMaxAutoLevelUpdated() {
    this.firstSelection = -1, this.nextAutoLevelKey = "";
  }
  onFragLoading(e, t) {
    const s = t.frag;
    if (!this.ignoreFragment(s)) {
      if (!s.bitrateTest) {
        var i;
        this.fragCurrent = s, this.partCurrent = (i = t.part) != null ? i : null;
      }
      this.clearTimer(), this.timer = self.setInterval(this._abandonRulesCheck, 100);
    }
  }
  onLevelSwitching(e, t) {
    this.clearTimer();
  }
  onError(e, t) {
    if (!t.fatal)
      switch (t.details) {
        case R.BUFFER_ADD_CODEC_ERROR:
        case R.BUFFER_APPEND_ERROR:
          this.lastLoadedFragLevel = -1, this.firstSelection = -1;
          break;
        case R.FRAG_LOAD_TIMEOUT: {
          const s = t.frag, {
            fragCurrent: i,
            partCurrent: r
          } = this;
          if (s && i && s.sn === i.sn && s.level === i.level) {
            const n = performance.now(), o = r ? r.stats : s.stats, c = n - o.loading.start, l = o.loading.first ? o.loading.first - o.loading.start : -1;
            if (o.loaded && l > -1) {
              const u = this.bwEstimator.getEstimateTTFB();
              this.bwEstimator.sample(c - Math.min(u, l), o.loaded);
            } else
              this.bwEstimator.sampleTTFB(c);
          }
          break;
        }
      }
  }
  getTimeToLoadFrag(e, t, s, i) {
    const r = e + s / t, n = i ? e + this.lastLevelLoadSec : 0;
    return r + n;
  }
  onLevelLoaded(e, t) {
    const s = this.hls.config, {
      loading: i
    } = t.stats, r = i.end - i.first;
    M(r) && (this.lastLevelLoadSec = r / 1e3), t.details.live ? this.bwEstimator.update(s.abrEwmaSlowLive, s.abrEwmaFastLive) : this.bwEstimator.update(s.abrEwmaSlowVoD, s.abrEwmaFastVoD), this.timer > -1 && this._abandonRulesCheck(t.levelInfo);
  }
  onFragLoaded(e, {
    frag: t,
    part: s
  }) {
    const i = s ? s.stats : t.stats;
    if (t.type === G.MAIN && this.bwEstimator.sampleTTFB(i.loading.first - i.loading.start), !this.ignoreFragment(t)) {
      if (this.clearTimer(), t.level === this._nextAutoLevel && (this._nextAutoLevel = -1), this.firstSelection = -1, this.hls.config.abrMaxWithRealBitrate) {
        const r = s ? s.duration : t.duration, n = this.hls.levels[t.level], o = (n.loaded ? n.loaded.bytes : 0) + i.loaded, c = (n.loaded ? n.loaded.duration : 0) + r;
        n.loaded = {
          bytes: o,
          duration: c
        }, n.realBitrate = Math.round(8 * o / c);
      }
      if (t.bitrateTest) {
        const r = {
          stats: i,
          frag: t,
          part: s,
          id: t.type
        };
        this.onFragBuffered(m.FRAG_BUFFERED, r), t.bitrateTest = !1;
      } else
        this.lastLoadedFragLevel = t.level;
    }
  }
  onFragBuffered(e, t) {
    const {
      frag: s,
      part: i
    } = t, r = i != null && i.stats.loaded ? i.stats : s.stats;
    if (r.aborted || this.ignoreFragment(s))
      return;
    const n = r.parsing.end - r.loading.start - Math.min(r.loading.first - r.loading.start, this.bwEstimator.getEstimateTTFB());
    this.bwEstimator.sample(n, r.loaded), r.bwEstimate = this.getBwEstimate(), s.bitrateTest ? this.bitrateTestDelay = n / 1e3 : this.bitrateTestDelay = 0;
  }
  ignoreFragment(e) {
    return e.type !== G.MAIN || e.sn === "initSegment";
  }
  clearTimer() {
    this.timer > -1 && (self.clearInterval(this.timer), this.timer = -1);
  }
  get firstAutoLevel() {
    const {
      maxAutoLevel: e,
      minAutoLevel: t
    } = this.hls, s = this.getBwEstimate(), i = this.hls.config.maxStarvationDelay, r = this.findBestLevel(s, t, e, 0, i, 1, 1);
    if (r > -1)
      return r;
    const n = this.hls.firstLevel, o = Math.min(Math.max(n, t), e);
    return this.warn(`Could not find best starting auto level. Defaulting to first in playlist ${n} clamped to ${o}`), o;
  }
  get forcedAutoLevel() {
    return this.nextAutoLevelKey ? -1 : this._nextAutoLevel;
  }
  // return next auto level
  get nextAutoLevel() {
    const e = this.forcedAutoLevel, s = this.bwEstimator.canEstimate(), i = this.lastLoadedFragLevel > -1;
    if (e !== -1 && (!s || !i || this.nextAutoLevelKey === this.getAutoLevelKey()))
      return e;
    const r = s && i ? this.getNextABRAutoLevel() : this.firstAutoLevel;
    if (e !== -1) {
      const n = this.hls.levels;
      if (n.length > Math.max(e, r) && n[e].loadError <= n[r].loadError)
        return e;
    }
    return this._nextAutoLevel = r, this.nextAutoLevelKey = this.getAutoLevelKey(), r;
  }
  getAutoLevelKey() {
    return `${this.getBwEstimate()}_${this.getStarvationDelay().toFixed(2)}`;
  }
  getNextABRAutoLevel() {
    const {
      fragCurrent: e,
      partCurrent: t,
      hls: s
    } = this;
    if (s.levels.length <= 1)
      return s.loadLevel;
    const {
      maxAutoLevel: i,
      config: r,
      minAutoLevel: n
    } = s, o = t ? t.duration : e ? e.duration : 0, c = this.getBwEstimate(), l = this.getStarvationDelay();
    let h = r.abrBandWidthFactor, u = r.abrBandWidthUpFactor;
    if (l) {
      const E = this.findBestLevel(c, n, i, l, 0, h, u);
      if (E >= 0)
        return this.rebufferNotice = -1, E;
    }
    let d = o ? Math.min(o, r.maxStarvationDelay) : r.maxStarvationDelay;
    if (!l) {
      const E = this.bitrateTestDelay;
      E && (d = (o ? Math.min(o, r.maxLoadingDelay) : r.maxLoadingDelay) - E, this.info(`bitrate test took ${Math.round(1e3 * E)}ms, set first fragment max fetchDuration to ${Math.round(1e3 * d)} ms`), h = u = 1);
    }
    const f = this.findBestLevel(c, n, i, l, d, h, u);
    if (this.rebufferNotice !== f && (this.rebufferNotice = f, this.info(`${l ? "rebuffering expected" : "buffer is empty"}, optimal quality level ${f}`)), f > -1)
      return f;
    const g = s.levels[n], p = s.loadLevelObj;
    return p && (g == null ? void 0 : g.bitrate) < p.bitrate ? n : s.loadLevel;
  }
  getStarvationDelay() {
    const e = this.hls, t = e.media;
    if (!t)
      return 1 / 0;
    const s = t && t.playbackRate !== 0 ? Math.abs(t.playbackRate) : 1, i = e.mainForwardBufferInfo;
    return (i ? i.len : 0) / s;
  }
  getBwEstimate() {
    return this.bwEstimator.canEstimate() ? this.bwEstimator.getEstimate() : this.hls.config.abrEwmaDefaultEstimate;
  }
  findBestLevel(e, t, s, i, r, n, o) {
    var c;
    const l = i + r, h = this.lastLoadedFragLevel, u = h === -1 ? this.hls.firstLevel : h, {
      fragCurrent: d,
      partCurrent: f
    } = this, {
      levels: g,
      allAudioTracks: p,
      loadLevel: E,
      config: y
    } = this.hls;
    if (g.length === 1)
      return 0;
    const S = g[u], T = !!((c = this.hls.latestLevelDetails) != null && c.live), v = E === -1 || h === -1;
    let x, _ = "SDR", A = (S == null ? void 0 : S.frameRate) || 0;
    const {
      audioPreference: b,
      videoPreference: D
    } = y, L = this.audioTracksByGroup || (this.audioTracksByGroup = wn(p));
    let k = -1;
    if (v) {
      if (this.firstSelection !== -1)
        return this.firstSelection;
      const N = this.codecTiers || (this.codecTiers = Vo(g, L, t, s)), B = Ko(N, _, e, b, D), {
        codecSet: $,
        videoRanges: P,
        minFramerate: O,
        minBitrate: W,
        minIndex: H,
        preferHDR: X
      } = B;
      k = H, x = $, _ = X ? P[P.length - 1] : P[0], A = O, e = Math.max(e, W), this.log(`picked start tier ${ae(B)}`);
    } else
      x = S == null ? void 0 : S.codecSet, _ = S == null ? void 0 : S.videoRange;
    const F = f ? f.duration : d ? d.duration : 0, j = this.bwEstimator.getEstimateTTFB() / 1e3, w = [];
    for (let N = s; N >= t; N--) {
      var U;
      const B = g[N], $ = N > u;
      if (!B)
        continue;
      if (y.useMediaCapabilities && !B.supportedResult && !B.supportedPromise) {
        const ee = navigator.mediaCapabilities;
        typeof (ee == null ? void 0 : ee.decodingInfo) == "function" && (Fo(B, L, _, A, e, b) || ys(B.videoCodec)) ? (B.supportedPromise = kn(B, L, ee), B.supportedPromise.then((ne) => {
          if (!this.hls)
            return;
          B.supportedResult = ne;
          const me = this.hls.levels, pe = me.indexOf(B);
          ne.error ? this.warn(`MediaCapabilities decodingInfo error: "${ne.error}" for level ${pe} ${ae(ne)}`) : ne.supported || (this.warn(`Unsupported MediaCapabilities decodingInfo result for level ${pe} ${ae(ne)}`), pe > -1 && me.length > 1 && (this.log(`Removing unsupported level ${pe}`), this.hls.removeLevel(pe), this.hls.loadLevel === -1 && (this.hls.nextLoadLevel = 0)));
        })) : B.supportedResult = Cn;
      }
      if ((x && B.codecSet !== x || _ && B.videoRange !== _ || $ && A > B.frameRate || !$ && A > 0 && A < B.frameRate || B.supportedResult && !((U = B.supportedResult.decodingInfoResults) != null && U[0].smooth)) && (!v || N !== k)) {
        w.push(N);
        continue;
      }
      const P = B.details, O = (f ? P == null ? void 0 : P.partTarget : P == null ? void 0 : P.averagetargetduration) || F;
      let W;
      $ ? W = o * e : W = n * e;
      const H = F && i >= F * 2 && r === 0 ? B.averageBitrate : B.maxBitrate, X = this.getTimeToLoadFrag(j, W, H * O, P === void 0);
      if (
        // if adjusted bw is greater than level bitrate AND
        W >= H && // no level change, or new level has no error history
        (N === h || B.loadError === 0 && B.fragmentError === 0) && // fragment fetchDuration unknown OR live stream OR fragment fetchDuration less than max allowed fetch duration, then this level matches
        // we don't account for max Fetch Duration for live streams, this is to avoid switching down when near the edge of live sliding window ...
        // special case to support startLevel = -1 (bitrateTest) on live streams : in that case we should not exit loop so that findBestLevel will return -1
        (X <= j || !M(X) || T && !this.bitrateTestDelay || X < l)
      ) {
        const ee = this.forcedAutoLevel;
        return N !== E && (ee === -1 || ee !== E) && (w.length && this.trace(`Skipped level(s) ${w.join(",")} of ${s} max with CODECS and VIDEO-RANGE:"${g[w[0]].codecs}" ${g[w[0]].videoRange}; not compatible with "${x}" ${_}`), this.info(`switch candidate:${u}->${N} adjustedbw(${Math.round(W)})-bitrate=${Math.round(W - H)} ttfb:${j.toFixed(1)} avgDuration:${O.toFixed(1)} maxFetchDuration:${l.toFixed(1)} fetchDuration:${X.toFixed(1)} firstSelection:${v} codecSet:${B.codecSet} videoRange:${B.videoRange} hls.loadLevel:${E}`)), v && (this.firstSelection = N), N;
      }
    }
    return -1;
  }
  set nextAutoLevel(e) {
    const t = this.deriveNextAutoLevel(e);
    this._nextAutoLevel !== t && (this.nextAutoLevelKey = "", this._nextAutoLevel = t);
  }
  deriveNextAutoLevel(e) {
    const {
      maxAutoLevel: t,
      minAutoLevel: s
    } = this.hls;
    return Math.min(Math.max(e, s), t);
  }
}
const pi = {
  /**
   * Searches for an item in an array which matches a certain condition.
   * This requires the condition to only match one item in the array,
   * and for the array to be ordered.
   *
   * @param list The array to search.
   * @param comparisonFn
   *      Called and provided a candidate item as the first argument.
   *      Should return:
   *          > -1 if the item should be located at a lower index than the provided item.
   *          > 1 if the item should be located at a higher index than the provided item.
   *          > 0 if the item is the item you're looking for.
   *
   * @returns the object if found, otherwise returns null
   */
  search: function(a, e) {
    let t = 0, s = a.length - 1, i = null, r = null;
    for (; t <= s; ) {
      i = (t + s) / 2 | 0, r = a[i];
      const n = e(r);
      if (n > 0)
        t = i + 1;
      else if (n < 0)
        s = i - 1;
      else
        return r;
    }
    return null;
  }
};
function jo(a, e, t) {
  if (e === null || !Array.isArray(a) || !a.length || !M(e))
    return null;
  const s = a[0].programDateTime;
  if (e < (s || 0))
    return null;
  const i = a[a.length - 1].endProgramDateTime;
  if (e >= (i || 0))
    return null;
  t = t || 0;
  for (let r = 0; r < a.length; ++r) {
    const n = a[r];
    if (zo(e, t, n))
      return n;
  }
  return null;
}
function it(a, e, t = 0, s = 0, i = 5e-3) {
  let r = null;
  if (a) {
    r = e[1 + a.sn - e[0].sn] || null;
    const o = a.endDTS - t;
    o > 0 && o < 15e-7 && (t += 15e-7), r && a.level !== r.level && r.end <= a.end && (r = e[2 + a.sn - e[0].sn] || null);
  } else t === 0 && e[0].start === 0 && (r = e[0]);
  if (r && ((!a || a.level === r.level) && ar(t, s, r) === 0 || Xo(r, a, Math.min(i, s))))
    return r;
  const n = pi.search(e, ar.bind(null, t, s));
  return n && (n !== a || !r) ? n : r;
}
function Xo(a, e, t) {
  if (e && e.start === 0 && e.level < a.level && (e.endPTS || 0) > 0) {
    const s = e.tagList.reduce((i, r) => (r[0] === "INF" && (i += parseFloat(r[1])), i), t);
    return a.start <= s;
  }
  return !1;
}
function ar(a = 0, e = 0, t) {
  if (t.start <= a && t.start + t.duration > a)
    return 0;
  const s = Math.min(e, t.duration + (t.deltaPTS ? t.deltaPTS : 0));
  return t.start + t.duration - s <= a ? 1 : t.start - s > a && t.start ? -1 : 0;
}
function zo(a, e, t) {
  const s = Math.min(e, t.duration + (t.deltaPTS ? t.deltaPTS : 0)) * 1e3;
  return (t.endProgramDateTime || 0) - s > a;
}
function On(a, e) {
  return pi.search(a, (t) => t.cc < e ? 1 : t.cc > e ? -1 : 0);
}
function Qo(a, e, t) {
  if (a && a.startCC <= e && a.endCC >= e) {
    const s = t.start, i = t.end;
    let r = a.fragments;
    if (!t.relurl) {
      const {
        fragmentHint: n
      } = a;
      n && (r = r.concat(n));
    }
    return pi.search(r, (n) => n.cc < e || n.end <= s ? 1 : n.cc > e || n.start >= i ? -1 : 0);
  }
  return null;
}
function hs(a) {
  switch (a.details) {
    case R.FRAG_LOAD_TIMEOUT:
    case R.KEY_LOAD_TIMEOUT:
    case R.LEVEL_LOAD_TIMEOUT:
    case R.MANIFEST_LOAD_TIMEOUT:
      return !0;
  }
  return !1;
}
function or(a, e) {
  const t = hs(e);
  return a.default[`${t ? "timeout" : "error"}Retry`];
}
function Ei(a, e) {
  const t = a.backoff === "linear" ? 1 : Math.pow(2, e);
  return Math.min(t * a.retryDelayMs, a.maxRetryDelayMs);
}
function lr(a) {
  return te(te({}, a), {
    errorRetry: null,
    timeoutRetry: null
  });
}
function us(a, e, t, s) {
  if (!a)
    return !1;
  const i = s == null ? void 0 : s.code, r = e < a.maxNumRetry && (Zo(i) || !!t);
  return a.shouldRetry ? a.shouldRetry(a, e, t, s, r) : r;
}
function Zo(a) {
  return a === 0 && navigator.onLine === !1 || !!a && (a < 400 || a > 499);
}
var ge = {
  DoNothing: 0,
  SendAlternateToPenaltyBox: 2,
  RemoveAlternatePermanently: 3,
  RetryRequest: 5
}, _e = {
  None: 0,
  MoveAllAlternatesMatchingHost: 1,
  MoveAllAlternatesMatchingHDCP: 2
};
class Jo extends Ve {
  constructor(e) {
    super("error-controller", e.logger), this.hls = void 0, this.playlistError = 0, this.penalizedRenditions = {}, this.hls = e, this.registerListeners();
  }
  registerListeners() {
    const e = this.hls;
    e.on(m.ERROR, this.onError, this), e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.LEVEL_UPDATED, this.onLevelUpdated, this);
  }
  unregisterListeners() {
    const e = this.hls;
    e && (e.off(m.ERROR, this.onError, this), e.off(m.ERROR, this.onErrorOut, this), e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.LEVEL_UPDATED, this.onLevelUpdated, this));
  }
  destroy() {
    this.unregisterListeners(), this.hls = null, this.penalizedRenditions = {};
  }
  startLoad(e) {
  }
  stopLoad() {
    this.playlistError = 0;
  }
  getVariantLevelIndex(e) {
    return (e == null ? void 0 : e.type) === G.MAIN ? e.level : this.hls.loadLevel;
  }
  onManifestLoading() {
    this.playlistError = 0, this.penalizedRenditions = {};
  }
  onLevelUpdated() {
    this.playlistError = 0;
  }
  onError(e, t) {
    var s;
    if (t.fatal)
      return;
    const i = this.hls, r = t.context;
    switch (t.details) {
      case R.FRAG_LOAD_ERROR:
      case R.FRAG_LOAD_TIMEOUT:
      case R.KEY_LOAD_ERROR:
      case R.KEY_LOAD_TIMEOUT:
        t.errorAction = this.getFragRetryOrSwitchAction(t);
        return;
      case R.FRAG_PARSING_ERROR:
        if ((s = t.frag) != null && s.gap) {
          t.errorAction = Dt();
          return;
        }
      case R.FRAG_GAP:
      case R.FRAG_DECRYPT_ERROR: {
        t.errorAction = this.getFragRetryOrSwitchAction(t), t.errorAction.action = ge.SendAlternateToPenaltyBox;
        return;
      }
      case R.LEVEL_EMPTY_ERROR:
      case R.LEVEL_PARSING_ERROR:
        {
          var n, o;
          const l = t.parent === G.MAIN ? t.level : i.loadLevel;
          t.details === R.LEVEL_EMPTY_ERROR && ((n = t.context) != null && (o = n.levelDetails) != null && o.live) ? t.errorAction = this.getPlaylistRetryOrSwitchAction(t, l) : (t.levelRetry = !1, t.errorAction = this.getLevelSwitchAction(t, l));
        }
        return;
      case R.LEVEL_LOAD_ERROR:
      case R.LEVEL_LOAD_TIMEOUT:
        typeof (r == null ? void 0 : r.level) == "number" && (t.errorAction = this.getPlaylistRetryOrSwitchAction(t, r.level));
        return;
      case R.AUDIO_TRACK_LOAD_ERROR:
      case R.AUDIO_TRACK_LOAD_TIMEOUT:
      case R.SUBTITLE_LOAD_ERROR:
      case R.SUBTITLE_TRACK_LOAD_TIMEOUT:
        if (r) {
          const l = i.loadLevelObj;
          if (l && (r.type === z.AUDIO_TRACK && l.hasAudioGroup(r.groupId) || r.type === z.SUBTITLE_TRACK && l.hasSubtitleGroup(r.groupId))) {
            t.errorAction = this.getPlaylistRetryOrSwitchAction(t, i.loadLevel), t.errorAction.action = ge.SendAlternateToPenaltyBox, t.errorAction.flags = _e.MoveAllAlternatesMatchingHost;
            return;
          }
        }
        return;
      case R.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED:
        {
          const l = i.loadLevelObj, h = l == null ? void 0 : l.attrs["HDCP-LEVEL"];
          h ? t.errorAction = {
            action: ge.SendAlternateToPenaltyBox,
            flags: _e.MoveAllAlternatesMatchingHDCP,
            hdcpLevel: h
          } : this.keySystemError(t);
        }
        return;
      case R.BUFFER_ADD_CODEC_ERROR:
      case R.REMUX_ALLOC_ERROR:
      case R.BUFFER_APPEND_ERROR:
        if (!t.errorAction) {
          var c;
          t.errorAction = this.getLevelSwitchAction(t, (c = t.level) != null ? c : i.loadLevel);
        }
        return;
      case R.INTERNAL_EXCEPTION:
      case R.BUFFER_APPENDING_ERROR:
      case R.BUFFER_FULL_ERROR:
      case R.LEVEL_SWITCH_ERROR:
      case R.BUFFER_STALLED_ERROR:
      case R.BUFFER_SEEK_OVER_HOLE:
      case R.BUFFER_NUDGE_ON_STALL:
        t.errorAction = Dt();
        return;
    }
    t.type === K.KEY_SYSTEM_ERROR && this.keySystemError(t);
  }
  keySystemError(e) {
    const t = this.getVariantLevelIndex(e.frag);
    e.levelRetry = !1, e.errorAction = this.getLevelSwitchAction(e, t);
  }
  getPlaylistRetryOrSwitchAction(e, t) {
    const s = this.hls, i = or(s.config.playlistLoadPolicy, e), r = this.playlistError++;
    if (us(i, r, hs(e), e.response))
      return {
        action: ge.RetryRequest,
        flags: _e.None,
        retryConfig: i,
        retryCount: r
      };
    const o = this.getLevelSwitchAction(e, t);
    return i && (o.retryConfig = i, o.retryCount = r), o;
  }
  getFragRetryOrSwitchAction(e) {
    const t = this.hls, s = this.getVariantLevelIndex(e.frag), i = t.levels[s], {
      fragLoadPolicy: r,
      keyLoadPolicy: n
    } = t.config, o = or(e.details.startsWith("key") ? n : r, e), c = t.levels.reduce((h, u) => h + u.fragmentError, 0);
    if (i && (e.details !== R.FRAG_GAP && i.fragmentError++, us(o, c, hs(e), e.response)))
      return {
        action: ge.RetryRequest,
        flags: _e.None,
        retryConfig: o,
        retryCount: c
      };
    const l = this.getLevelSwitchAction(e, s);
    return o && (l.retryConfig = o, l.retryCount = c), l;
  }
  getLevelSwitchAction(e, t) {
    const s = this.hls;
    t == null && (t = s.loadLevel);
    const i = this.hls.levels[t];
    if (i) {
      var r, n;
      const l = e.details;
      i.loadError++, l === R.BUFFER_APPEND_ERROR && i.fragmentError++;
      let h = -1;
      const {
        levels: u,
        loadLevel: d,
        minAutoLevel: f,
        maxAutoLevel: g
      } = s;
      s.autoLevelEnabled || (s.loadLevel = -1);
      const p = (r = e.frag) == null ? void 0 : r.type, y = (p === G.AUDIO && l === R.FRAG_PARSING_ERROR || e.sourceBufferName === "audio" && (l === R.BUFFER_ADD_CODEC_ERROR || l === R.BUFFER_APPEND_ERROR)) && u.some(({
        audioCodec: _
      }) => i.audioCodec !== _), T = e.sourceBufferName === "video" && (l === R.BUFFER_ADD_CODEC_ERROR || l === R.BUFFER_APPEND_ERROR) && u.some(({
        codecSet: _,
        audioCodec: A
      }) => i.codecSet !== _ && i.audioCodec === A), {
        type: v,
        groupId: x
      } = (n = e.context) != null ? n : {};
      for (let _ = u.length; _--; ) {
        const A = (_ + d) % u.length;
        if (A !== d && A >= f && A <= g && u[A].loadError === 0) {
          var o, c;
          const b = u[A];
          if (l === R.FRAG_GAP && p === G.MAIN && e.frag) {
            const D = u[A].details;
            if (D) {
              const L = it(e.frag, D.fragments, e.frag.start);
              if (L != null && L.gap)
                continue;
            }
          } else {
            if (v === z.AUDIO_TRACK && b.hasAudioGroup(x) || v === z.SUBTITLE_TRACK && b.hasSubtitleGroup(x))
              continue;
            if (p === G.AUDIO && (o = i.audioGroups) != null && o.some((D) => b.hasAudioGroup(D)) || p === G.SUBTITLE && (c = i.subtitleGroups) != null && c.some((D) => b.hasSubtitleGroup(D)) || y && i.audioCodec === b.audioCodec || !y && i.audioCodec !== b.audioCodec || T && i.codecSet === b.codecSet)
              continue;
          }
          h = A;
          break;
        }
      }
      if (h > -1 && s.loadLevel !== h)
        return e.levelRetry = !0, this.playlistError = 0, {
          action: ge.SendAlternateToPenaltyBox,
          flags: _e.None,
          nextAutoLevel: h
        };
    }
    return {
      action: ge.SendAlternateToPenaltyBox,
      flags: _e.MoveAllAlternatesMatchingHost
    };
  }
  onErrorOut(e, t) {
    var s;
    switch ((s = t.errorAction) == null ? void 0 : s.action) {
      case ge.DoNothing:
        break;
      case ge.SendAlternateToPenaltyBox:
        this.sendAlternateToPenaltyBox(t), !t.errorAction.resolved && t.details !== R.FRAG_GAP ? t.fatal = !0 : /MediaSource readyState: ended/.test(t.error.message) && (this.warn(`MediaSource ended after "${t.sourceBufferName}" sourceBuffer append error. Attempting to recover from media error.`), this.hls.recoverMediaError());
        break;
    }
    if (t.fatal) {
      this.hls.stopLoad();
      return;
    }
  }
  sendAlternateToPenaltyBox(e) {
    const t = this.hls, s = e.errorAction;
    if (!s)
      return;
    const {
      flags: i,
      hdcpLevel: r,
      nextAutoLevel: n
    } = s;
    switch (i) {
      case _e.None:
        this.switchLevel(e, n);
        break;
      case _e.MoveAllAlternatesMatchingHDCP:
        r && (t.maxHdcpLevel = Zs[Zs.indexOf(r) - 1], s.resolved = !0), this.warn(`Restricting playback to HDCP-LEVEL of "${t.maxHdcpLevel}" or lower`);
        break;
    }
    s.resolved || this.switchLevel(e, n);
  }
  switchLevel(e, t) {
    if (t !== void 0 && e.errorAction && (this.warn(`switching to level ${t} after ${e.details}`), this.hls.nextAutoLevel = t, e.errorAction.resolved = !0, this.hls.nextLoadLevel = this.hls.nextAutoLevel, e.details === R.BUFFER_ADD_CODEC_ERROR && e.mimeType && e.sourceBufferName !== "audiovideo")) {
      const s = Dn(e.mimeType), i = this.hls.levels;
      for (let r = i.length; r--; )
        i[r][`${e.sourceBufferName}Codec`] === s && this.hls.removeLevel(r);
    }
  }
}
function Dt(a) {
  const e = {
    action: ge.DoNothing,
    flags: _e.None
  };
  return a && (e.resolved = !0), e;
}
var ce = {
  NOT_LOADED: "NOT_LOADED",
  APPENDING: "APPENDING",
  PARTIAL: "PARTIAL",
  OK: "OK"
};
class el {
  constructor(e) {
    this.activePartLists = /* @__PURE__ */ Object.create(null), this.endListFragments = /* @__PURE__ */ Object.create(null), this.fragments = /* @__PURE__ */ Object.create(null), this.timeRanges = /* @__PURE__ */ Object.create(null), this.bufferPadding = 0.2, this.hls = void 0, this.hasGaps = !1, this.hls = e, this._registerListeners();
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.BUFFER_APPENDED, this.onBufferAppended, this), e.on(m.FRAG_BUFFERED, this.onFragBuffered, this), e.on(m.FRAG_LOADED, this.onFragLoaded, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.BUFFER_APPENDED, this.onBufferAppended, this), e.off(m.FRAG_BUFFERED, this.onFragBuffered, this), e.off(m.FRAG_LOADED, this.onFragLoaded, this);
  }
  destroy() {
    this._unregisterListeners(), this.fragments = // @ts-ignore
    this.activePartLists = // @ts-ignore
    this.endListFragments = this.timeRanges = null;
  }
  /**
   * Return a Fragment or Part with an appended range that matches the position and levelType
   * Otherwise, return null
   */
  getAppendedFrag(e, t) {
    const s = this.activePartLists[t];
    if (s)
      for (let i = s.length; i--; ) {
        const r = s[i];
        if (!r)
          break;
        const n = r.end;
        if (r.start <= e && n !== null && e <= n)
          return r;
      }
    return this.getBufferedFrag(e, t);
  }
  /**
   * Return a buffered Fragment that matches the position and levelType.
   * A buffered Fragment is one whose loading, parsing and appending is done (completed or "partial" meaning aborted).
   * If not found any Fragment, return null
   */
  getBufferedFrag(e, t) {
    return this.getFragAtPos(e, t, !0);
  }
  getFragAtPos(e, t, s) {
    const {
      fragments: i
    } = this, r = Object.keys(i);
    for (let n = r.length; n--; ) {
      const o = i[r[n]];
      if ((o == null ? void 0 : o.body.type) === t && (!s || o.buffered)) {
        const c = o.body;
        if (c.start <= e && e <= c.end)
          return c;
      }
    }
    return null;
  }
  /**
   * Partial fragments effected by coded frame eviction will be removed
   * The browser will unload parts of the buffer to free up memory for new buffer data
   * Fragments will need to be reloaded when the buffer is freed up, removing partial fragments will allow them to reload(since there might be parts that are still playable)
   */
  detectEvictedFragments(e, t, s, i, r) {
    this.timeRanges && (this.timeRanges[e] = t);
    const n = (i == null ? void 0 : i.fragment.sn) || -1;
    Object.keys(this.fragments).forEach((o) => {
      const c = this.fragments[o];
      if (!c || n >= c.body.sn)
        return;
      if (!c.buffered && (!c.loaded || r)) {
        c.body.type === s && this.removeFragment(c.body);
        return;
      }
      const l = c.range[e];
      if (l) {
        if (l.time.length === 0) {
          this.removeFragment(c.body);
          return;
        }
        l.time.some((h) => {
          const u = !this.isTimeBuffered(h.startPTS, h.endPTS, t);
          return u && this.removeFragment(c.body), u;
        });
      }
    });
  }
  /**
   * Checks if the fragment passed in is loaded in the buffer properly
   * Partially loaded fragments will be registered as a partial fragment
   */
  detectPartialFragments(e) {
    const t = this.timeRanges;
    if (!t || e.frag.sn === "initSegment")
      return;
    const s = e.frag, i = ot(s), r = this.fragments[i];
    if (!r || r.buffered && s.gap)
      return;
    const n = !s.relurl;
    Object.keys(t).forEach((o) => {
      const c = s.elementaryStreams[o];
      if (!c)
        return;
      const l = t[o], h = n || c.partial === !0;
      r.range[o] = this.getBufferedTimes(s, e.part, h, l);
    }), r.loaded = null, Object.keys(r.range).length ? (r.buffered = !0, (r.body.endList = s.endList || r.body.endList) && (this.endListFragments[r.body.type] = r), Ut(r) || this.removeParts(s.sn - 1, s.type)) : this.removeFragment(r.body);
  }
  removeParts(e, t) {
    const s = this.activePartLists[t];
    s && (this.activePartLists[t] = cr(s, (i) => i.fragment.sn >= e));
  }
  fragBuffered(e, t) {
    const s = ot(e);
    let i = this.fragments[s];
    !i && t && (i = this.fragments[s] = {
      body: e,
      appendedPTS: null,
      loaded: null,
      buffered: !1,
      range: /* @__PURE__ */ Object.create(null)
    }, e.gap && (this.hasGaps = !0)), i && (i.loaded = null, i.buffered = !0);
  }
  getBufferedTimes(e, t, s, i) {
    const r = {
      time: [],
      partial: s
    }, n = e.start, o = e.end, c = e.minEndPTS || o, l = e.maxStartPTS || n;
    for (let h = 0; h < i.length; h++) {
      const u = i.start(h) - this.bufferPadding, d = i.end(h) + this.bufferPadding;
      if (l >= u && c <= d) {
        r.time.push({
          startPTS: Math.max(n, i.start(h)),
          endPTS: Math.min(o, i.end(h))
        });
        break;
      } else if (n < d && o > u) {
        const f = Math.max(n, i.start(h)), g = Math.min(o, i.end(h));
        g > f && (r.partial = !0, r.time.push({
          startPTS: f,
          endPTS: g
        }));
      } else if (o <= u)
        break;
    }
    return r;
  }
  /**
   * Gets the partial fragment for a certain time
   */
  getPartialFragment(e) {
    let t = null, s, i, r, n = 0;
    const {
      bufferPadding: o,
      fragments: c
    } = this;
    return Object.keys(c).forEach((l) => {
      const h = c[l];
      h && Ut(h) && (i = h.body.start - o, r = h.body.end + o, e >= i && e <= r && (s = Math.min(e - i, r - e), n <= s && (t = h.body, n = s)));
    }), t;
  }
  isEndListAppended(e) {
    const t = this.endListFragments[e];
    return t !== void 0 && (t.buffered || Ut(t));
  }
  getState(e) {
    const t = ot(e), s = this.fragments[t];
    return s ? s.buffered ? Ut(s) ? ce.PARTIAL : ce.OK : ce.APPENDING : ce.NOT_LOADED;
  }
  isTimeBuffered(e, t, s) {
    let i, r;
    for (let n = 0; n < s.length; n++) {
      if (i = s.start(n) - this.bufferPadding, r = s.end(n) + this.bufferPadding, e >= i && t <= r)
        return !0;
      if (t <= i)
        return !1;
    }
    return !1;
  }
  onManifestLoading() {
    this.removeAllFragments();
  }
  onFragLoaded(e, t) {
    if (t.frag.sn === "initSegment" || t.frag.bitrateTest)
      return;
    const s = t.frag, i = t.part ? null : t, r = ot(s);
    this.fragments[r] = {
      body: s,
      appendedPTS: null,
      loaded: i,
      buffered: !1,
      range: /* @__PURE__ */ Object.create(null)
    };
  }
  onBufferAppended(e, t) {
    const {
      frag: s,
      part: i,
      timeRanges: r,
      type: n
    } = t;
    if (s.sn === "initSegment")
      return;
    const o = s.type;
    if (i) {
      let l = this.activePartLists[o];
      l || (this.activePartLists[o] = l = []), l.push(i);
    }
    this.timeRanges = r;
    const c = r[n];
    this.detectEvictedFragments(n, c, o, i);
  }
  onFragBuffered(e, t) {
    this.detectPartialFragments(t);
  }
  hasFragment(e) {
    const t = ot(e);
    return !!this.fragments[t];
  }
  hasFragments(e) {
    const {
      fragments: t
    } = this, s = Object.keys(t);
    if (!e)
      return s.length > 0;
    for (let i = s.length; i--; ) {
      const r = t[s[i]];
      if ((r == null ? void 0 : r.body.type) === e)
        return !0;
    }
    return !1;
  }
  hasParts(e) {
    var t;
    return !!((t = this.activePartLists[e]) != null && t.length);
  }
  removeFragmentsInRange(e, t, s, i, r) {
    i && !this.hasGaps || Object.keys(this.fragments).forEach((n) => {
      const o = this.fragments[n];
      if (!o)
        return;
      const c = o.body;
      c.type !== s || i && !c.gap || c.start < t && c.end > e && (o.buffered || r) && this.removeFragment(c);
    });
  }
  removeFragment(e) {
    const t = ot(e);
    e.clearElementaryStreamInfo();
    const s = this.activePartLists[e.type];
    if (s) {
      const i = e.sn;
      this.activePartLists[e.type] = cr(s, (r) => r.fragment.sn !== i);
    }
    delete this.fragments[t], e.endList && delete this.endListFragments[e.type];
  }
  removeAllFragments() {
    var e, t;
    this.fragments = /* @__PURE__ */ Object.create(null), this.endListFragments = /* @__PURE__ */ Object.create(null), this.activePartLists = /* @__PURE__ */ Object.create(null), this.hasGaps = !1;
    const s = (e = this.hls) == null || (t = e.latestLevelDetails) == null ? void 0 : t.partList;
    s && s.forEach((i) => i.clearElementaryStreamInfo());
  }
}
function Ut(a) {
  var e, t, s;
  return a.buffered && (a.body.gap || ((e = a.range.video) == null ? void 0 : e.partial) || ((t = a.range.audio) == null ? void 0 : t.partial) || ((s = a.range.audiovideo) == null ? void 0 : s.partial));
}
function ot(a) {
  return `${a.type}_${a.level}_${a.sn}`;
}
function cr(a, e) {
  return a.filter((t) => {
    const s = e(t);
    return s || t.clearElementaryStreamInfo(), s;
  });
}
var Qe = {
  cbc: 0,
  ctr: 1
};
class tl {
  constructor(e, t, s) {
    this.subtle = void 0, this.aesIV = void 0, this.aesMode = void 0, this.subtle = e, this.aesIV = t, this.aesMode = s;
  }
  decrypt(e, t) {
    switch (this.aesMode) {
      case Qe.cbc:
        return this.subtle.decrypt({
          name: "AES-CBC",
          iv: this.aesIV
        }, t, e);
      case Qe.ctr:
        return this.subtle.decrypt(
          {
            name: "AES-CTR",
            counter: this.aesIV,
            length: 64
          },
          //64 : NIST SP800-38A standard suggests that the counter should occupy half of the counter block
          t,
          e
        );
      default:
        throw new Error(`[AESCrypto] invalid aes mode ${this.aesMode}`);
    }
  }
}
function sl(a) {
  const e = a.byteLength, t = e && new DataView(a.buffer).getUint8(e - 1);
  return t ? a.slice(0, e - t) : a;
}
class il {
  constructor() {
    this.rcon = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54], this.subMix = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)], this.invSubMix = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)], this.sBox = new Uint32Array(256), this.invSBox = new Uint32Array(256), this.key = new Uint32Array(0), this.ksRows = 0, this.keySize = 0, this.keySchedule = void 0, this.invKeySchedule = void 0, this.initTable();
  }
  // Using view.getUint32() also swaps the byte order.
  uint8ArrayToUint32Array_(e) {
    const t = new DataView(e), s = new Uint32Array(4);
    for (let i = 0; i < 4; i++)
      s[i] = t.getUint32(i * 4);
    return s;
  }
  initTable() {
    const e = this.sBox, t = this.invSBox, s = this.subMix, i = s[0], r = s[1], n = s[2], o = s[3], c = this.invSubMix, l = c[0], h = c[1], u = c[2], d = c[3], f = new Uint32Array(256);
    let g = 0, p = 0, E = 0;
    for (E = 0; E < 256; E++)
      E < 128 ? f[E] = E << 1 : f[E] = E << 1 ^ 283;
    for (E = 0; E < 256; E++) {
      let y = p ^ p << 1 ^ p << 2 ^ p << 3 ^ p << 4;
      y = y >>> 8 ^ y & 255 ^ 99, e[g] = y, t[y] = g;
      const S = f[g], T = f[S], v = f[T];
      let x = f[y] * 257 ^ y * 16843008;
      i[g] = x << 24 | x >>> 8, r[g] = x << 16 | x >>> 16, n[g] = x << 8 | x >>> 24, o[g] = x, x = v * 16843009 ^ T * 65537 ^ S * 257 ^ g * 16843008, l[y] = x << 24 | x >>> 8, h[y] = x << 16 | x >>> 16, u[y] = x << 8 | x >>> 24, d[y] = x, g ? (g = S ^ f[f[f[v ^ S]]], p ^= f[f[p]]) : g = p = 1;
    }
  }
  expandKey(e) {
    const t = this.uint8ArrayToUint32Array_(e);
    let s = !0, i = 0;
    for (; i < t.length && s; )
      s = t[i] === this.key[i], i++;
    if (s)
      return;
    this.key = t;
    const r = this.keySize = t.length;
    if (r !== 4 && r !== 6 && r !== 8)
      throw new Error("Invalid aes key size=" + r);
    const n = this.ksRows = (r + 6 + 1) * 4;
    let o, c;
    const l = this.keySchedule = new Uint32Array(n), h = this.invKeySchedule = new Uint32Array(n), u = this.sBox, d = this.rcon, f = this.invSubMix, g = f[0], p = f[1], E = f[2], y = f[3];
    let S, T;
    for (o = 0; o < n; o++) {
      if (o < r) {
        S = l[o] = t[o];
        continue;
      }
      T = S, o % r === 0 ? (T = T << 8 | T >>> 24, T = u[T >>> 24] << 24 | u[T >>> 16 & 255] << 16 | u[T >>> 8 & 255] << 8 | u[T & 255], T ^= d[o / r | 0] << 24) : r > 6 && o % r === 4 && (T = u[T >>> 24] << 24 | u[T >>> 16 & 255] << 16 | u[T >>> 8 & 255] << 8 | u[T & 255]), l[o] = S = (l[o - r] ^ T) >>> 0;
    }
    for (c = 0; c < n; c++)
      o = n - c, c & 3 ? T = l[o] : T = l[o - 4], c < 4 || o <= 4 ? h[c] = T : h[c] = g[u[T >>> 24]] ^ p[u[T >>> 16 & 255]] ^ E[u[T >>> 8 & 255]] ^ y[u[T & 255]], h[c] = h[c] >>> 0;
  }
  // Adding this as a method greatly improves performance.
  networkToHostOrderSwap(e) {
    return e << 24 | (e & 65280) << 8 | (e & 16711680) >> 8 | e >>> 24;
  }
  decrypt(e, t, s) {
    const i = this.keySize + 6, r = this.invKeySchedule, n = this.invSBox, o = this.invSubMix, c = o[0], l = o[1], h = o[2], u = o[3], d = this.uint8ArrayToUint32Array_(s);
    let f = d[0], g = d[1], p = d[2], E = d[3];
    const y = new Int32Array(e), S = new Int32Array(y.length);
    let T, v, x, _, A, b, D, L, k, F, j, w, U, N;
    const B = this.networkToHostOrderSwap;
    for (; t < y.length; ) {
      for (k = B(y[t]), F = B(y[t + 1]), j = B(y[t + 2]), w = B(y[t + 3]), A = k ^ r[0], b = w ^ r[1], D = j ^ r[2], L = F ^ r[3], U = 4, N = 1; N < i; N++)
        T = c[A >>> 24] ^ l[b >> 16 & 255] ^ h[D >> 8 & 255] ^ u[L & 255] ^ r[U], v = c[b >>> 24] ^ l[D >> 16 & 255] ^ h[L >> 8 & 255] ^ u[A & 255] ^ r[U + 1], x = c[D >>> 24] ^ l[L >> 16 & 255] ^ h[A >> 8 & 255] ^ u[b & 255] ^ r[U + 2], _ = c[L >>> 24] ^ l[A >> 16 & 255] ^ h[b >> 8 & 255] ^ u[D & 255] ^ r[U + 3], A = T, b = v, D = x, L = _, U = U + 4;
      T = n[A >>> 24] << 24 ^ n[b >> 16 & 255] << 16 ^ n[D >> 8 & 255] << 8 ^ n[L & 255] ^ r[U], v = n[b >>> 24] << 24 ^ n[D >> 16 & 255] << 16 ^ n[L >> 8 & 255] << 8 ^ n[A & 255] ^ r[U + 1], x = n[D >>> 24] << 24 ^ n[L >> 16 & 255] << 16 ^ n[A >> 8 & 255] << 8 ^ n[b & 255] ^ r[U + 2], _ = n[L >>> 24] << 24 ^ n[A >> 16 & 255] << 16 ^ n[b >> 8 & 255] << 8 ^ n[D & 255] ^ r[U + 3], S[t] = B(T ^ f), S[t + 1] = B(_ ^ g), S[t + 2] = B(x ^ p), S[t + 3] = B(v ^ E), f = k, g = F, p = j, E = w, t = t + 4;
    }
    return S.buffer;
  }
}
class rl {
  constructor(e, t, s) {
    this.subtle = void 0, this.key = void 0, this.aesMode = void 0, this.subtle = e, this.key = t, this.aesMode = s;
  }
  expandKey() {
    const e = nl(this.aesMode);
    return this.subtle.importKey("raw", this.key, {
      name: e
    }, !1, ["encrypt", "decrypt"]);
  }
}
function nl(a) {
  switch (a) {
    case Qe.cbc:
      return "AES-CBC";
    case Qe.ctr:
      return "AES-CTR";
    default:
      throw new Error(`[FastAESKey] invalid aes mode ${a}`);
  }
}
const al = 16;
class yi {
  constructor(e, {
    removePKCS7Padding: t = !0
  } = {}) {
    if (this.logEnabled = !0, this.removePKCS7Padding = void 0, this.subtle = null, this.softwareDecrypter = null, this.key = null, this.fastAesKey = null, this.remainderData = null, this.currentIV = null, this.currentResult = null, this.useSoftware = void 0, this.enableSoftwareAES = void 0, this.enableSoftwareAES = e.enableSoftwareAES, this.removePKCS7Padding = t, t)
      try {
        const s = self.crypto;
        s && (this.subtle = s.subtle || s.webkitSubtle);
      } catch {
      }
    this.useSoftware = !this.subtle;
  }
  destroy() {
    this.subtle = null, this.softwareDecrypter = null, this.key = null, this.fastAesKey = null, this.remainderData = null, this.currentIV = null, this.currentResult = null;
  }
  isSync() {
    return this.useSoftware;
  }
  flush() {
    const {
      currentResult: e,
      remainderData: t
    } = this;
    if (!e || t)
      return this.reset(), null;
    const s = new Uint8Array(e);
    return this.reset(), this.removePKCS7Padding ? sl(s) : s;
  }
  reset() {
    this.currentResult = null, this.currentIV = null, this.remainderData = null, this.softwareDecrypter && (this.softwareDecrypter = null);
  }
  decrypt(e, t, s, i) {
    return this.useSoftware ? new Promise((r, n) => {
      const o = ArrayBuffer.isView(e) ? e : new Uint8Array(e);
      this.softwareDecrypt(o, t, s, i);
      const c = this.flush();
      c ? r(c.buffer) : n(new Error("[softwareDecrypt] Failed to decrypt data"));
    }) : this.webCryptoDecrypt(new Uint8Array(e), t, s, i);
  }
  // Software decryption is progressive. Progressive decryption may not return a result on each call. Any cached
  // data is handled in the flush() call
  softwareDecrypt(e, t, s, i) {
    const {
      currentIV: r,
      currentResult: n,
      remainderData: o
    } = this;
    if (i !== Qe.cbc || t.byteLength !== 16)
      return Q.warn("SoftwareDecrypt: can only handle AES-128-CBC"), null;
    this.logOnce("JS AES decrypt"), o && (e = Ie(o, e), this.remainderData = null);
    const c = this.getValidChunk(e);
    if (!c.length)
      return null;
    r && (s = r);
    let l = this.softwareDecrypter;
    l || (l = this.softwareDecrypter = new il()), l.expandKey(t);
    const h = n;
    return this.currentResult = l.decrypt(c.buffer, 0, s), this.currentIV = c.slice(-16).buffer, h || null;
  }
  webCryptoDecrypt(e, t, s, i) {
    if (this.key !== t || !this.fastAesKey) {
      if (!this.subtle)
        return Promise.resolve(this.onWebCryptoError(e, t, s, i));
      this.key = t, this.fastAesKey = new rl(this.subtle, t, i);
    }
    return this.fastAesKey.expandKey().then((r) => this.subtle ? (this.logOnce("WebCrypto AES decrypt"), new tl(this.subtle, new Uint8Array(s), i).decrypt(e.buffer, r)) : Promise.reject(new Error("web crypto not initialized"))).catch((r) => (Q.warn(`[decrypter]: WebCrypto Error, disable WebCrypto API, ${r.name}: ${r.message}`), this.onWebCryptoError(e, t, s, i)));
  }
  onWebCryptoError(e, t, s, i) {
    const r = this.enableSoftwareAES;
    if (r) {
      this.useSoftware = !0, this.logEnabled = !0, this.softwareDecrypt(e, t, s, i);
      const n = this.flush();
      if (n)
        return n.buffer;
    }
    throw new Error("WebCrypto" + (r ? " and softwareDecrypt" : "") + ": failed to decrypt data");
  }
  getValidChunk(e) {
    let t = e;
    const s = e.length - e.length % al;
    return s !== e.length && (t = e.slice(0, s), this.remainderData = e.slice(s)), t;
  }
  logOnce(e) {
    this.logEnabled && (Q.log(`[decrypter]: ${e}`), this.logEnabled = !1);
  }
}
const hr = Math.pow(2, 17);
class ol {
  constructor(e) {
    this.config = void 0, this.loader = null, this.partLoadTimeout = -1, this.config = e;
  }
  destroy() {
    this.loader && (this.loader.destroy(), this.loader = null);
  }
  abort() {
    this.loader && this.loader.abort();
  }
  load(e, t) {
    const s = e.url;
    if (!s)
      return Promise.reject(new Ue({
        type: K.NETWORK_ERROR,
        details: R.FRAG_LOAD_ERROR,
        fatal: !1,
        frag: e,
        error: new Error(`Fragment does not have a ${s ? "part list" : "url"}`),
        networkDetails: null
      }));
    this.abort();
    const i = this.config, r = i.fLoader, n = i.loader;
    return new Promise((o, c) => {
      if (this.loader && this.loader.destroy(), e.gap)
        if (e.tagList.some((g) => g[0] === "GAP")) {
          c(dr(e));
          return;
        } else
          e.gap = !1;
      const l = this.loader = r ? new r(i) : new n(i), h = ur(e);
      e.loader = l;
      const u = lr(i.fragLoadPolicy.default), d = {
        loadPolicy: u,
        timeout: u.maxLoadTimeMs,
        maxRetry: 0,
        retryDelay: 0,
        maxRetryDelay: 0,
        highWaterMark: e.sn === "initSegment" ? 1 / 0 : hr
      };
      e.stats = l.stats;
      const f = {
        onSuccess: (g, p, E, y) => {
          this.resetLoader(e, l);
          let S = g.data;
          E.resetIV && e.decryptdata && (e.decryptdata.iv = new Uint8Array(S.slice(0, 16)), S = S.slice(16)), o({
            frag: e,
            part: null,
            payload: S,
            networkDetails: y
          });
        },
        onError: (g, p, E, y) => {
          this.resetLoader(e, l), c(new Ue({
            type: K.NETWORK_ERROR,
            details: R.FRAG_LOAD_ERROR,
            fatal: !1,
            frag: e,
            response: te({
              url: s,
              data: void 0
            }, g),
            error: new Error(`HTTP Error ${g.code} ${g.text}`),
            networkDetails: E,
            stats: y
          }));
        },
        onAbort: (g, p, E) => {
          this.resetLoader(e, l), c(new Ue({
            type: K.NETWORK_ERROR,
            details: R.INTERNAL_ABORTED,
            fatal: !1,
            frag: e,
            error: new Error("Aborted"),
            networkDetails: E,
            stats: g
          }));
        },
        onTimeout: (g, p, E) => {
          this.resetLoader(e, l), c(new Ue({
            type: K.NETWORK_ERROR,
            details: R.FRAG_LOAD_TIMEOUT,
            fatal: !1,
            frag: e,
            error: new Error(`Timeout after ${d.timeout}ms`),
            networkDetails: E,
            stats: g
          }));
        }
      };
      t && (f.onProgress = (g, p, E, y) => t({
        frag: e,
        part: null,
        payload: E,
        networkDetails: y
      })), l.load(h, d, f);
    });
  }
  loadPart(e, t, s) {
    this.abort();
    const i = this.config, r = i.fLoader, n = i.loader;
    return new Promise((o, c) => {
      if (this.loader && this.loader.destroy(), e.gap || t.gap) {
        c(dr(e, t));
        return;
      }
      const l = this.loader = r ? new r(i) : new n(i), h = ur(e, t);
      e.loader = l;
      const u = lr(i.fragLoadPolicy.default), d = {
        loadPolicy: u,
        timeout: u.maxLoadTimeMs,
        maxRetry: 0,
        retryDelay: 0,
        maxRetryDelay: 0,
        highWaterMark: hr
      };
      t.stats = l.stats, l.load(h, d, {
        onSuccess: (f, g, p, E) => {
          this.resetLoader(e, l), this.updateStatsFromPart(e, t);
          const y = {
            frag: e,
            part: t,
            payload: f.data,
            networkDetails: E
          };
          s(y), o(y);
        },
        onError: (f, g, p, E) => {
          this.resetLoader(e, l), c(new Ue({
            type: K.NETWORK_ERROR,
            details: R.FRAG_LOAD_ERROR,
            fatal: !1,
            frag: e,
            part: t,
            response: te({
              url: h.url,
              data: void 0
            }, f),
            error: new Error(`HTTP Error ${f.code} ${f.text}`),
            networkDetails: p,
            stats: E
          }));
        },
        onAbort: (f, g, p) => {
          e.stats.aborted = t.stats.aborted, this.resetLoader(e, l), c(new Ue({
            type: K.NETWORK_ERROR,
            details: R.INTERNAL_ABORTED,
            fatal: !1,
            frag: e,
            part: t,
            error: new Error("Aborted"),
            networkDetails: p,
            stats: f
          }));
        },
        onTimeout: (f, g, p) => {
          this.resetLoader(e, l), c(new Ue({
            type: K.NETWORK_ERROR,
            details: R.FRAG_LOAD_TIMEOUT,
            fatal: !1,
            frag: e,
            part: t,
            error: new Error(`Timeout after ${d.timeout}ms`),
            networkDetails: p,
            stats: f
          }));
        }
      });
    });
  }
  updateStatsFromPart(e, t) {
    const s = e.stats, i = t.stats, r = i.total;
    if (s.loaded += i.loaded, r) {
      const c = Math.round(e.duration / t.duration), l = Math.min(Math.round(s.loaded / r), c), u = (c - l) * Math.round(s.loaded / l);
      s.total = s.loaded + u;
    } else
      s.total = Math.max(s.loaded, s.total);
    const n = s.loading, o = i.loading;
    n.start ? n.first += o.first - o.start : (n.start = o.start, n.first = o.first), n.end = o.end;
  }
  resetLoader(e, t) {
    e.loader = null, this.loader === t && (self.clearTimeout(this.partLoadTimeout), this.loader = null), t.destroy();
  }
}
function ur(a, e = null) {
  const t = e || a, s = {
    frag: a,
    part: e,
    responseType: "arraybuffer",
    url: t.url,
    headers: {},
    rangeStart: 0,
    rangeEnd: 0
  }, i = t.byteRangeStartOffset, r = t.byteRangeEndOffset;
  if (M(i) && M(r)) {
    var n;
    let o = i, c = r;
    if (a.sn === "initSegment" && ll((n = a.decryptdata) == null ? void 0 : n.method)) {
      const l = r - i;
      l % 16 && (c = r + (16 - l % 16)), i !== 0 && (s.resetIV = !0, o = i - 16);
    }
    s.rangeStart = o, s.rangeEnd = c;
  }
  return s;
}
function dr(a, e) {
  const t = new Error(`GAP ${a.gap ? "tag" : "attribute"} found`), s = {
    type: K.MEDIA_ERROR,
    details: R.FRAG_GAP,
    fatal: !1,
    frag: a,
    error: t,
    networkDetails: null
  };
  return e && (s.part = e), (e || a).stats.aborted = !0, new Ue(s);
}
function ll(a) {
  return a === "AES-128" || a === "AES-256";
}
class Ue extends Error {
  constructor(e) {
    super(e.error.message), this.data = void 0, this.data = e;
  }
}
class Fn extends Ve {
  constructor(e, t) {
    super(e, t), this._boundTick = void 0, this._tickTimer = null, this._tickInterval = null, this._tickCallCount = 0, this._boundTick = this.tick.bind(this);
  }
  destroy() {
    this.onHandlerDestroying(), this.onHandlerDestroyed();
  }
  onHandlerDestroying() {
    this.clearNextTick(), this.clearInterval();
  }
  onHandlerDestroyed() {
  }
  hasInterval() {
    return !!this._tickInterval;
  }
  hasNextTick() {
    return !!this._tickTimer;
  }
  /**
   * @param millis - Interval time (ms)
   * @eturns True when interval has been scheduled, false when already scheduled (no effect)
   */
  setInterval(e) {
    return this._tickInterval ? !1 : (this._tickCallCount = 0, this._tickInterval = self.setInterval(this._boundTick, e), !0);
  }
  /**
   * @returns True when interval was cleared, false when none was set (no effect)
   */
  clearInterval() {
    return this._tickInterval ? (self.clearInterval(this._tickInterval), this._tickInterval = null, !0) : !1;
  }
  /**
   * @returns True when timeout was cleared, false when none was set (no effect)
   */
  clearNextTick() {
    return this._tickTimer ? (self.clearTimeout(this._tickTimer), this._tickTimer = null, !0) : !1;
  }
  /**
   * Will call the subclass doTick implementation in this main loop tick
   * or in the next one (via setTimeout(,0)) in case it has already been called
   * in this tick (in case this is a re-entrant call).
   */
  tick() {
    this._tickCallCount++, this._tickCallCount === 1 && (this.doTick(), this._tickCallCount > 1 && this.tickImmediate(), this._tickCallCount = 0);
  }
  tickImmediate() {
    this.clearNextTick(), this._tickTimer = self.setTimeout(this._boundTick, 0);
  }
  /**
   * For subclass to implement task logic
   * @abstract
   */
  doTick() {
  }
}
class Ti {
  constructor(e, t, s, i = 0, r = -1, n = !1) {
    this.level = void 0, this.sn = void 0, this.part = void 0, this.id = void 0, this.size = void 0, this.partial = void 0, this.transmuxing = $t(), this.buffering = {
      audio: $t(),
      video: $t(),
      audiovideo: $t()
    }, this.level = e, this.sn = t, this.id = s, this.size = i, this.part = r, this.partial = n;
  }
}
function $t() {
  return {
    start: 0,
    executeStart: 0,
    executeEnd: 0,
    end: 0
  };
}
const fr = {
  length: 0,
  start: () => 0,
  end: () => 0
};
class q {
  /**
   * Return true if `media`'s buffered include `position`
   */
  static isBuffered(e, t) {
    if (e) {
      const s = q.getBuffered(e);
      for (let i = s.length; i--; )
        if (t >= s.start(i) && t <= s.end(i))
          return !0;
    }
    return !1;
  }
  static bufferedRanges(e) {
    if (e) {
      const t = q.getBuffered(e);
      return q.timeRangesToArray(t);
    }
    return [];
  }
  static timeRangesToArray(e) {
    const t = [];
    for (let s = 0; s < e.length; s++)
      t.push({
        start: e.start(s),
        end: e.end(s)
      });
    return t;
  }
  static bufferInfo(e, t, s) {
    if (e) {
      const i = q.bufferedRanges(e);
      if (i.length)
        return q.bufferedInfo(i, t, s);
    }
    return {
      len: 0,
      start: t,
      end: t,
      bufferedIndex: -1
    };
  }
  static bufferedInfo(e, t, s) {
    t = Math.max(0, t), e.length > 1 && e.sort((h, u) => h.start - u.start || u.end - h.end);
    let i = -1, r = [];
    if (s)
      for (let h = 0; h < e.length; h++) {
        t >= e[h].start && t <= e[h].end && (i = h);
        const u = r.length;
        if (u) {
          const d = r[u - 1].end;
          e[h].start - d < s ? e[h].end > d && (r[u - 1].end = e[h].end) : r.push(e[h]);
        } else
          r.push(e[h]);
      }
    else
      r = e;
    let n = 0, o, c = t, l = t;
    for (let h = 0; h < r.length; h++) {
      const u = r[h].start, d = r[h].end;
      if (i === -1 && t >= u && t <= d && (i = h), t + s >= u && t < d)
        c = u, l = d, n = l - t;
      else if (t + s < u) {
        o = u;
        break;
      }
    }
    return {
      len: n,
      start: c || 0,
      end: l || 0,
      nextStart: o,
      buffered: e,
      bufferedIndex: i
    };
  }
  /**
   * Safe method to get buffered property.
   * SourceBuffer.buffered may throw if SourceBuffer is removed from it's MediaSource
   */
  static getBuffered(e) {
    try {
      return e.buffered || fr;
    } catch (t) {
      return Q.log("failed to get media.buffered", t), fr;
    }
  }
}
const Mn = /\{\$([a-zA-Z0-9-_]+)\}/g;
function gr(a) {
  return Mn.test(a);
}
function Js(a, e) {
  if (a.variableList !== null || a.hasVariableRefs) {
    const t = a.variableList;
    return e.replace(Mn, (s) => {
      const i = s.substring(2, s.length - 1), r = t == null ? void 0 : t[i];
      return r === void 0 ? (a.playlistParsingError || (a.playlistParsingError = new Error(`Missing preceding EXT-X-DEFINE tag for Variable Reference: "${i}"`)), s) : r;
    });
  }
  return e;
}
function mr(a, e, t) {
  let s = a.variableList;
  s || (a.variableList = s = {});
  let i, r;
  if ("QUERYPARAM" in e) {
    i = e.QUERYPARAM;
    try {
      const n = new self.URL(t).searchParams;
      if (n.has(i))
        r = n.get(i);
      else
        throw new Error(`"${i}" does not match any query parameter in URI: "${t}"`);
    } catch (n) {
      a.playlistParsingError || (a.playlistParsingError = new Error(`EXT-X-DEFINE QUERYPARAM: ${n.message}`));
    }
  } else
    i = e.NAME, r = e.VALUE;
  i in s ? a.playlistParsingError || (a.playlistParsingError = new Error(`EXT-X-DEFINE duplicate Variable Name declarations: "${i}"`)) : s[i] = r || "";
}
function cl(a, e, t) {
  const s = e.IMPORT;
  if (t && s in t) {
    let i = a.variableList;
    i || (a.variableList = i = {}), i[s] = t[s];
  } else
    a.playlistParsingError || (a.playlistParsingError = new Error(`EXT-X-DEFINE IMPORT attribute not found in Multivariant Playlist: "${s}"`));
}
const hl = /^(\d+)x(\d+)$/, pr = /(.+?)=(".*?"|.*?)(?:,|$)/g;
class oe {
  constructor(e, t) {
    typeof e == "string" && (e = oe.parseAttrList(e, t)), re(this, e);
  }
  get clientAttrs() {
    return Object.keys(this).filter((e) => e.substring(0, 2) === "X-");
  }
  decimalInteger(e) {
    const t = parseInt(this[e], 10);
    return t > Number.MAX_SAFE_INTEGER ? 1 / 0 : t;
  }
  hexadecimalInteger(e) {
    if (this[e]) {
      let t = (this[e] || "0x").slice(2);
      t = (t.length & 1 ? "0" : "") + t;
      const s = new Uint8Array(t.length / 2);
      for (let i = 0; i < t.length / 2; i++)
        s[i] = parseInt(t.slice(i * 2, i * 2 + 2), 16);
      return s;
    }
    return null;
  }
  hexadecimalIntegerAsNumber(e) {
    const t = parseInt(this[e], 16);
    return t > Number.MAX_SAFE_INTEGER ? 1 / 0 : t;
  }
  decimalFloatingPoint(e) {
    return parseFloat(this[e]);
  }
  optionalFloat(e, t) {
    const s = this[e];
    return s ? parseFloat(s) : t;
  }
  enumeratedString(e) {
    return this[e];
  }
  enumeratedStringList(e, t) {
    const s = this[e];
    return (s ? s.split(/[ ,]+/) : []).reduce((i, r) => (i[r.toLowerCase()] = !0, i), t);
  }
  bool(e) {
    return this[e] === "YES";
  }
  decimalResolution(e) {
    const t = hl.exec(this[e]);
    if (t !== null)
      return {
        width: parseInt(t[1], 10),
        height: parseInt(t[2], 10)
      };
  }
  static parseAttrList(e, t) {
    let s;
    const i = {}, r = '"';
    for (pr.lastIndex = 0; (s = pr.exec(e)) !== null; ) {
      const n = s[1].trim();
      let o = s[2];
      const c = o.indexOf(r) === 0 && o.lastIndexOf(r) === o.length - 1;
      let l = !1;
      if (c)
        o = o.slice(1, -1);
      else
        switch (n) {
          case "IV":
          case "SCTE35-CMD":
          case "SCTE35-IN":
          case "SCTE35-OUT":
            l = !0;
        }
      if (t && (c || l))
        o = Js(t, o);
      else if (!l && !c)
        switch (n) {
          case "CLOSED-CAPTIONS":
            if (o === "NONE")
              break;
          case "ALLOWED-CPC":
          case "CLASS":
          case "ASSOC-LANGUAGE":
          case "AUDIO":
          case "BYTERANGE":
          case "CHANNELS":
          case "CHARACTERISTICS":
          case "CODECS":
          case "DATA-ID":
          case "END-DATE":
          case "GROUP-ID":
          case "ID":
          case "IMPORT":
          case "INSTREAM-ID":
          case "KEYFORMAT":
          case "KEYFORMATVERSIONS":
          case "LANGUAGE":
          case "NAME":
          case "PATHWAY-ID":
          case "QUERYPARAM":
          case "RECENTLY-REMOVED-DATERANGES":
          case "SERVER-URI":
          case "STABLE-RENDITION-ID":
          case "STABLE-VARIANT-ID":
          case "START-DATE":
          case "SUBTITLES":
          case "SUPPLEMENTAL-CODECS":
          case "URI":
          case "VALUE":
          case "VIDEO":
          case "X-ASSET-LIST":
          case "X-ASSET-URI":
            Q.warn(`${e}: attribute ${n} is missing quotes`);
        }
      i[n] = o;
    }
    return i;
  }
}
const ul = "com.apple.hls.interstitial";
function dl(a) {
  return a !== "ID" && a !== "CLASS" && a !== "CUE" && a !== "START-DATE" && a !== "DURATION" && a !== "END-DATE" && a !== "END-ON-NEXT";
}
function fl(a) {
  return a === "SCTE35-OUT" || a === "SCTE35-IN" || a === "SCTE35-CMD";
}
class Nn {
  constructor(e, t, s = 0) {
    var i;
    if (this.attr = void 0, this.tagAnchor = void 0, this.tagOrder = void 0, this._startDate = void 0, this._endDate = void 0, this._dateAtEnd = void 0, this._cue = void 0, this._badValueForSameId = void 0, this.tagAnchor = (t == null ? void 0 : t.tagAnchor) || null, this.tagOrder = (i = t == null ? void 0 : t.tagOrder) != null ? i : s, t) {
      const r = t.attr;
      for (const n in r)
        if (Object.prototype.hasOwnProperty.call(e, n) && e[n] !== r[n]) {
          Q.warn(`DATERANGE tag attribute: "${n}" does not match for tags with ID: "${e.ID}"`), this._badValueForSameId = n;
          break;
        }
      e = re(new oe({}), r, e);
    }
    if (this.attr = e, t ? (this._startDate = t._startDate, this._cue = t._cue, this._endDate = t._endDate, this._dateAtEnd = t._dateAtEnd) : this._startDate = new Date(e["START-DATE"]), "END-DATE" in this.attr) {
      const r = (t == null ? void 0 : t.endDate) || new Date(this.attr["END-DATE"]);
      M(r.getTime()) && (this._endDate = r);
    }
  }
  get id() {
    return this.attr.ID;
  }
  get class() {
    return this.attr.CLASS;
  }
  get cue() {
    const e = this._cue;
    return e === void 0 ? this._cue = this.attr.enumeratedStringList(this.attr.CUE ? "CUE" : "X-CUE", {
      pre: !1,
      post: !1,
      once: !1
    }) : e;
  }
  get startTime() {
    const {
      tagAnchor: e
    } = this;
    return e === null || e.programDateTime === null ? (Q.warn(`Expected tagAnchor Fragment with PDT set for DateRange "${this.id}": ${e}`), NaN) : e.start + (this.startDate.getTime() - e.programDateTime) / 1e3;
  }
  get startDate() {
    return this._startDate;
  }
  get endDate() {
    const e = this._endDate || this._dateAtEnd;
    if (e)
      return e;
    const t = this.duration;
    return t !== null ? this._dateAtEnd = new Date(this._startDate.getTime() + t * 1e3) : null;
  }
  get duration() {
    if ("DURATION" in this.attr) {
      const e = this.attr.decimalFloatingPoint("DURATION");
      if (M(e))
        return e;
    } else if (this._endDate)
      return (this._endDate.getTime() - this._startDate.getTime()) / 1e3;
    return null;
  }
  get plannedDuration() {
    return "PLANNED-DURATION" in this.attr ? this.attr.decimalFloatingPoint("PLANNED-DURATION") : null;
  }
  get endOnNext() {
    return this.attr.bool("END-ON-NEXT");
  }
  get isInterstitial() {
    return this.class === ul;
  }
  get isValid() {
    return !!this.id && !this._badValueForSameId && M(this.startDate.getTime()) && (this.duration === null || this.duration >= 0) && (!this.endOnNext || !!this.class) && (!this.attr.CUE || !this.cue.pre && !this.cue.post || this.cue.pre !== this.cue.post) && (!this.isInterstitial || "X-ASSET-URI" in this.attr || "X-ASSET-LIST" in this.attr);
  }
}
const gl = 10;
class ml {
  constructor(e) {
    this.PTSKnown = !1, this.alignedSliding = !1, this.averagetargetduration = void 0, this.endCC = 0, this.endSN = 0, this.fragments = void 0, this.fragmentHint = void 0, this.partList = null, this.dateRanges = void 0, this.dateRangeTagCount = 0, this.live = !0, this.requestScheduled = -1, this.ageHeader = 0, this.advancedDateTime = void 0, this.updated = !0, this.advanced = !0, this.misses = 0, this.startCC = 0, this.startSN = 0, this.startTimeOffset = null, this.targetduration = 0, this.totalduration = 0, this.type = null, this.url = void 0, this.m3u8 = "", this.version = null, this.canBlockReload = !1, this.canSkipUntil = 0, this.canSkipDateRanges = !1, this.skippedSegments = 0, this.recentlyRemovedDateranges = void 0, this.partHoldBack = 0, this.holdBack = 0, this.partTarget = 0, this.preloadHint = void 0, this.renditionReports = void 0, this.tuneInGoal = 0, this.deltaUpdateFailed = void 0, this.driftStartTime = 0, this.driftEndTime = 0, this.driftStart = 0, this.driftEnd = 0, this.encryptedFragments = void 0, this.playlistParsingError = null, this.variableList = null, this.hasVariableRefs = !1, this.appliedTimelineOffset = void 0, this.fragments = [], this.encryptedFragments = [], this.dateRanges = {}, this.url = e;
  }
  reloaded(e) {
    if (!e) {
      this.advanced = !0, this.updated = !0;
      return;
    }
    const t = this.lastPartSn - e.lastPartSn, s = this.lastPartIndex - e.lastPartIndex;
    this.updated = this.endSN !== e.endSN || !!s || !!t || !this.live, this.advanced = this.endSN > e.endSN || t > 0 || t === 0 && s > 0, this.updated || this.advanced ? this.misses = Math.floor(e.misses * 0.6) : this.misses = e.misses + 1;
  }
  get hasProgramDateTime() {
    return this.fragments.length ? M(this.fragments[this.fragments.length - 1].programDateTime) : !1;
  }
  get levelTargetDuration() {
    return this.averagetargetduration || this.targetduration || gl;
  }
  get drift() {
    const e = this.driftEndTime - this.driftStartTime;
    return e > 0 ? (this.driftEnd - this.driftStart) * 1e3 / e : 1;
  }
  get edge() {
    return this.partEnd || this.fragmentEnd;
  }
  get partEnd() {
    var e;
    return (e = this.partList) != null && e.length ? this.partList[this.partList.length - 1].end : this.fragmentEnd;
  }
  get fragmentEnd() {
    var e;
    return (e = this.fragments) != null && e.length ? this.fragments[this.fragments.length - 1].end : 0;
  }
  get fragmentStart() {
    var e;
    return (e = this.fragments) != null && e.length ? this.fragments[0].start : 0;
  }
  get age() {
    return this.advancedDateTime ? Math.max(Date.now() - this.advancedDateTime, 0) / 1e3 : 0;
  }
  get lastPartIndex() {
    var e;
    return (e = this.partList) != null && e.length ? this.partList[this.partList.length - 1].index : -1;
  }
  get maxPartIndex() {
    const e = this.partList;
    if (e) {
      const t = this.lastPartIndex;
      if (t !== -1) {
        for (let s = e.length; s--; )
          if (e[s].index > t)
            return e[s].index;
        return t;
      }
    }
    return 0;
  }
  get lastPartSn() {
    var e;
    return (e = this.partList) != null && e.length ? this.partList[this.partList.length - 1].fragment.sn : this.endSN;
  }
  get expired() {
    if (this.live && this.age && this.misses < 3) {
      const e = this.partEnd - this.fragmentStart;
      return this.age > Math.max(e, this.totalduration) + this.levelTargetDuration;
    }
    return !1;
  }
}
function dt(a) {
  return a === "AES-128" || a === "AES-256" || a === "AES-256-CTR";
}
function Si(a) {
  switch (a) {
    case "AES-128":
    case "AES-256":
      return Qe.cbc;
    case "AES-256-CTR":
      return Qe.ctr;
    default:
      throw new Error(`invalid full segment method ${a}`);
  }
}
function vi(a) {
  return Uint8Array.from(atob(a), (e) => e.charCodeAt(0));
}
function ei(a) {
  return Uint8Array.from(unescape(encodeURIComponent(a)), (e) => e.charCodeAt(0));
}
function pl(a) {
  const e = ei(a).subarray(0, 16), t = new Uint8Array(16);
  return t.set(e, 16 - e.length), t;
}
function El(a) {
  const e = function(s, i, r) {
    const n = s[i];
    s[i] = s[r], s[r] = n;
  };
  e(a, 0, 3), e(a, 1, 2), e(a, 4, 5), e(a, 6, 7);
}
function yl(a) {
  const e = a.split(":");
  let t = null;
  if (e[0] === "data" && e.length === 2) {
    const s = e[1].split(";"), i = s[s.length - 1].split(",");
    if (i.length === 2) {
      const r = i[0] === "base64", n = i[1];
      r ? (s.splice(-1, 1), t = vi(n)) : t = pl(n);
    }
  }
  return t;
}
const ds = typeof self < "u" ? self : void 0;
var se = {
  CLEARKEY: "org.w3.clearkey",
  FAIRPLAY: "com.apple.fps",
  PLAYREADY: "com.microsoft.playready",
  WIDEVINE: "com.widevine.alpha"
}, ye = {
  CLEARKEY: "org.w3.clearkey",
  FAIRPLAY: "com.apple.streamingkeydelivery",
  PLAYREADY: "com.microsoft.playready",
  WIDEVINE: "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"
};
function _s(a) {
  switch (a) {
    case ye.FAIRPLAY:
      return se.FAIRPLAY;
    case ye.PLAYREADY:
      return se.PLAYREADY;
    case ye.WIDEVINE:
      return se.WIDEVINE;
    case ye.CLEARKEY:
      return se.CLEARKEY;
  }
}
var Gt = {
  CENC: "1077efecc0b24d02ace33c1e52e2fb4b",
  CLEARKEY: "e2719d58a985b3c9781ab030af78d30e",
  PLAYREADY: "9a04f07998404286ab92e65be0885f95",
  WIDEVINE: "edef8ba979d64acea3c827dcd51d21ed"
};
function Ds(a) {
  if (a === Gt.WIDEVINE)
    return se.WIDEVINE;
  if (a === Gt.PLAYREADY)
    return se.PLAYREADY;
  if (a === Gt.CENC || a === Gt.CLEARKEY)
    return se.CLEARKEY;
}
function Cs(a) {
  switch (a) {
    case se.FAIRPLAY:
      return ye.FAIRPLAY;
    case se.PLAYREADY:
      return ye.PLAYREADY;
    case se.WIDEVINE:
      return ye.WIDEVINE;
    case se.CLEARKEY:
      return ye.CLEARKEY;
  }
}
function Kt(a) {
  const {
    drmSystems: e,
    widevineLicenseUrl: t
  } = a, s = e ? [se.FAIRPLAY, se.WIDEVINE, se.PLAYREADY, se.CLEARKEY].filter((i) => !!e[i]) : [];
  return !s[se.WIDEVINE] && t && s.push(se.WIDEVINE), s;
}
const Bn = function(a) {
  return ds != null && (a = ds.navigator) != null && a.requestMediaKeySystemAccess ? self.navigator.requestMediaKeySystemAccess.bind(self.navigator) : null;
}();
function Tl(a, e, t, s) {
  let i;
  switch (a) {
    case se.FAIRPLAY:
      i = ["cenc", "sinf"];
      break;
    case se.WIDEVINE:
    case se.PLAYREADY:
      i = ["cenc"];
      break;
    case se.CLEARKEY:
      i = ["cenc", "keyids"];
      break;
    default:
      throw new Error(`Unknown key-system: ${a}`);
  }
  return Sl(i, e, t, s);
}
function Sl(a, e, t, s) {
  return [{
    initDataTypes: a,
    persistentState: s.persistentState || "optional",
    distinctiveIdentifier: s.distinctiveIdentifier || "optional",
    sessionTypes: s.sessionTypes || [s.sessionType || "temporary"],
    audioCapabilities: e.map((r) => ({
      contentType: `audio/mp4; codecs=${r}`,
      robustness: s.audioRobustness || "",
      encryptionScheme: s.audioEncryptionScheme || null
    })),
    videoCapabilities: t.map((r) => ({
      contentType: `video/mp4; codecs=${r}`,
      robustness: s.videoRobustness || "",
      encryptionScheme: s.videoEncryptionScheme || null
    }))
  }];
}
function vl(a) {
  var e;
  return a.sessionType === "persistent-license" || !!((e = a.sessionTypes) != null && e.some((t) => t === "persistent-license"));
}
function Un(a) {
  const e = new Uint16Array(a.buffer, a.byteOffset, a.byteLength / 2), t = String.fromCharCode.apply(null, Array.from(e)), s = t.substring(t.indexOf("<"), t.length), n = new DOMParser().parseFromString(s, "text/xml").getElementsByTagName("KID")[0];
  if (n) {
    const o = n.childNodes[0] ? n.childNodes[0].nodeValue : n.getAttribute("VALUE");
    if (o) {
      const c = vi(o).subarray(0, 16);
      return El(c), c;
    }
  }
  return null;
}
let Vt = {};
class Ct {
  static clearKeyUriToKeyIdMap() {
    Vt = {};
  }
  constructor(e, t, s, i = [1], r = null) {
    this.uri = void 0, this.method = void 0, this.keyFormat = void 0, this.keyFormatVersions = void 0, this.encrypted = void 0, this.isCommonEncryption = void 0, this.iv = null, this.key = null, this.keyId = null, this.pssh = null, this.method = e, this.uri = t, this.keyFormat = s, this.keyFormatVersions = i, this.iv = r, this.encrypted = e ? e !== "NONE" : !1, this.isCommonEncryption = this.encrypted && !dt(e);
  }
  isSupported() {
    if (this.method) {
      if (dt(this.method) || this.method === "NONE")
        return !0;
      if (this.keyFormat === "identity")
        return this.method === "SAMPLE-AES";
      switch (this.keyFormat) {
        case ye.FAIRPLAY:
        case ye.WIDEVINE:
        case ye.PLAYREADY:
        case ye.CLEARKEY:
          return ["ISO-23001-7", "SAMPLE-AES", "SAMPLE-AES-CENC", "SAMPLE-AES-CTR"].indexOf(this.method) !== -1;
      }
    }
    return !1;
  }
  getDecryptData(e) {
    if (!this.encrypted || !this.uri)
      return null;
    if (dt(this.method) && this.uri && !this.iv) {
      typeof e != "number" && (Q.warn(`missing IV for initialization segment with method="${this.method}" - compliance issue`), e = 0);
      const s = xl(e);
      return new Ct(this.method, this.uri, "identity", this.keyFormatVersions, s);
    }
    const t = yl(this.uri);
    if (t)
      switch (this.keyFormat) {
        case ye.WIDEVINE:
          this.pssh = t, t.length >= 22 && (this.keyId = t.subarray(t.length - 22, t.length - 6));
          break;
        case ye.PLAYREADY: {
          const s = new Uint8Array([154, 4, 240, 121, 152, 64, 66, 134, 171, 146, 230, 91, 224, 136, 95, 149]);
          this.pssh = bo(s, null, t), this.keyId = Un(t);
          break;
        }
        default: {
          let s = t.subarray(0, 16);
          if (s.length !== 16) {
            const i = new Uint8Array(16);
            i.set(s, 16 - s.length), s = i;
          }
          this.keyId = s;
          break;
        }
      }
    if (!this.keyId || this.keyId.byteLength !== 16) {
      let s = Vt[this.uri];
      if (!s) {
        const i = Object.keys(Vt).length % Number.MAX_SAFE_INTEGER;
        s = new Uint8Array(16), new DataView(s.buffer, 12, 4).setUint32(0, i), Vt[this.uri] = s;
      }
      this.keyId = s;
    }
    return this;
  }
}
function xl(a) {
  const e = new Uint8Array(16);
  for (let t = 12; t < 16; t++)
    e[t] = a >> 8 * (15 - t) & 255;
  return e;
}
const Er = /#EXT-X-STREAM-INF:([^\r\n]*)(?:[\r\n](?:#[^\r\n]*)?)*([^\r\n]+)|#EXT-X-(SESSION-DATA|SESSION-KEY|DEFINE|CONTENT-STEERING|START):([^\r\n]*)[\r\n]+/g, yr = /#EXT-X-MEDIA:(.*)/g, Al = /^#EXT(?:INF|-X-TARGETDURATION):/m, Ps = new RegExp([
  /#EXTINF:\s*(\d*(?:\.\d+)?)(?:,(.*)\s+)?/.source,
  // duration (#EXTINF:<duration>,<title>), group 1 => duration, group 2 => title
  /(?!#) *(\S[^\r\n]*)/.source,
  // segment URI, group 3 => the URI (note newline is not eaten)
  /#.*/.source
  // All other non-segment oriented tags will match with all groups empty
].join("|"), "g"), Ll = new RegExp([/#EXT-X-(PROGRAM-DATE-TIME|BYTERANGE|DATERANGE|DEFINE|KEY|MAP|PART|PART-INF|PLAYLIST-TYPE|PRELOAD-HINT|RENDITION-REPORT|SERVER-CONTROL|SKIP|START):(.+)/.source, /#EXT-X-(BITRATE|DISCONTINUITY-SEQUENCE|MEDIA-SEQUENCE|TARGETDURATION|VERSION): *(\d+)/.source, /#EXT-X-(DISCONTINUITY|ENDLIST|GAP|INDEPENDENT-SEGMENTS)/.source, /(#)([^:]*):(.*)/.source, /(#)(.*)(?:.*)\r?\n?/.source].join("|"));
class Oe {
  static findGroup(e, t) {
    for (let s = 0; s < e.length; s++) {
      const i = e[s];
      if (i.id === t)
        return i;
    }
  }
  static resolve(e, t) {
    return fi.buildAbsoluteURL(t, e, {
      alwaysNormalize: !0
    });
  }
  static isMediaPlaylist(e) {
    return Al.test(e);
  }
  static parseMasterPlaylist(e, t) {
    const s = gr(e), i = {
      contentSteering: null,
      levels: [],
      playlistParsingError: null,
      sessionData: null,
      sessionKeys: null,
      startTimeOffset: null,
      variableList: null,
      hasVariableRefs: s
    }, r = [];
    Er.lastIndex = 0;
    let n;
    for (; (n = Er.exec(e)) != null; )
      if (n[1]) {
        var o;
        const l = new oe(n[1], i), h = Js(i, n[2]), u = {
          attrs: l,
          bitrate: l.decimalInteger("BANDWIDTH") || l.decimalInteger("AVERAGE-BANDWIDTH"),
          name: l.NAME,
          url: Oe.resolve(h, t)
        }, d = l.decimalResolution("RESOLUTION");
        d && (u.width = d.width, u.height = d.height), vr(l.CODECS, u);
        const f = l["SUPPLEMENTAL-CODECS"];
        f && (u.supplemental = {}, vr(f, u.supplemental)), (o = u.unknownCodecs) != null && o.length || r.push(u), i.levels.push(u);
      } else if (n[3]) {
        const l = n[3], h = n[4];
        switch (l) {
          case "SESSION-DATA": {
            const u = new oe(h, i), d = u["DATA-ID"];
            d && (i.sessionData === null && (i.sessionData = {}), i.sessionData[d] = u);
            break;
          }
          case "SESSION-KEY": {
            const u = Tr(h, t, i);
            u.encrypted && u.isSupported() ? (i.sessionKeys === null && (i.sessionKeys = []), i.sessionKeys.push(u)) : Q.warn(`[Keys] Ignoring invalid EXT-X-SESSION-KEY tag: "${h}"`);
            break;
          }
          case "DEFINE": {
            {
              const u = new oe(h, i);
              mr(i, u, t);
            }
            break;
          }
          case "CONTENT-STEERING": {
            const u = new oe(h, i);
            i.contentSteering = {
              uri: Oe.resolve(u["SERVER-URI"], t),
              pathwayId: u["PATHWAY-ID"] || "."
            };
            break;
          }
          case "START": {
            i.startTimeOffset = Sr(h);
            break;
          }
        }
      }
    const c = r.length > 0 && r.length < i.levels.length;
    return i.levels = c ? r : i.levels, i.levels.length === 0 && (i.playlistParsingError = new Error("no levels found in manifest")), i;
  }
  static parseMasterPlaylistMedia(e, t, s) {
    let i;
    const r = {}, n = s.levels, o = {
      AUDIO: n.map((l) => ({
        id: l.attrs.AUDIO,
        audioCodec: l.audioCodec
      })),
      SUBTITLES: n.map((l) => ({
        id: l.attrs.SUBTITLES,
        textCodec: l.textCodec
      })),
      "CLOSED-CAPTIONS": []
    };
    let c = 0;
    for (yr.lastIndex = 0; (i = yr.exec(e)) !== null; ) {
      const l = new oe(i[1], s), h = l.TYPE;
      if (h) {
        const u = o[h], d = r[h] || [];
        r[h] = d;
        const f = l.LANGUAGE, g = l["ASSOC-LANGUAGE"], p = l.CHANNELS, E = l.CHARACTERISTICS, y = l["INSTREAM-ID"], S = {
          attrs: l,
          bitrate: 0,
          id: c++,
          groupId: l["GROUP-ID"] || "",
          name: l.NAME || f || "",
          type: h,
          default: l.bool("DEFAULT"),
          autoselect: l.bool("AUTOSELECT"),
          forced: l.bool("FORCED"),
          lang: f,
          url: l.URI ? Oe.resolve(l.URI, t) : ""
        };
        if (g && (S.assocLang = g), p && (S.channels = p), E && (S.characteristics = E), y && (S.instreamId = y), u != null && u.length) {
          const T = Oe.findGroup(u, S.groupId) || u[0];
          xr(S, T, "audioCodec"), xr(S, T, "textCodec");
        }
        d.push(S);
      }
    }
    return r;
  }
  static parseLevelPlaylist(e, t, s, i, r, n) {
    var o;
    const c = {
      url: t
    }, l = new ml(t), h = l.fragments, u = [];
    let d = null, f = 0, g = 0, p = 0, E = 0, y = 0, S = null, T = new Ls(i, c), v, x, _, A = -1, b = !1, D = null, L;
    if (Ps.lastIndex = 0, l.m3u8 = e, l.hasVariableRefs = gr(e), ((o = Ps.exec(e)) == null ? void 0 : o[0]) !== "#EXTM3U")
      return l.playlistParsingError = new Error("Missing format identifier #EXTM3U"), l;
    for (; (v = Ps.exec(e)) !== null; ) {
      b && (b = !1, T = new Ls(i, c), T.playlistOffset = p, T.start = p, T.sn = f, T.cc = E, y && (T.bitrate = y), T.level = s, d && (T.initSegment = d, d.rawProgramDateTime && (T.rawProgramDateTime = d.rawProgramDateTime, d.rawProgramDateTime = null), D && (T.setByteRange(D), D = null)));
      const w = v[1];
      if (w) {
        T.duration = parseFloat(w);
        const U = (" " + v[2]).slice(1);
        T.title = U || null, T.tagList.push(U ? ["INF", w, U] : ["INF", w]);
      } else if (v[3]) {
        if (M(T.duration)) {
          T.playlistOffset = p, T.start = p, _ && Lr(T, _, l), T.sn = f, T.level = s, T.cc = E, h.push(T);
          const U = (" " + v[3]).slice(1);
          T.relurl = Js(l, U), ti(T, S, u), S = T, p += T.duration, f++, g = 0, b = !0;
        }
      } else {
        if (v = v[0].match(Ll), !v) {
          Q.warn("No matches on slow regex match for level playlist!");
          continue;
        }
        for (x = 1; x < v.length && v[x] === void 0; x++)
          ;
        const U = (" " + v[x]).slice(1), N = (" " + v[x + 1]).slice(1), B = v[x + 2] ? (" " + v[x + 2]).slice(1) : null;
        switch (U) {
          case "BYTERANGE":
            S ? T.setByteRange(N, S) : T.setByteRange(N);
            break;
          case "PROGRAM-DATE-TIME":
            T.rawProgramDateTime = N, T.tagList.push(["PROGRAM-DATE-TIME", N]), A === -1 && (A = h.length);
            break;
          case "PLAYLIST-TYPE":
            l.type && Ne(l, U, v), l.type = N.toUpperCase();
            break;
          case "MEDIA-SEQUENCE":
            l.startSN !== 0 ? Ne(l, U, v) : h.length > 0 && Ir(l, U, v), f = l.startSN = parseInt(N);
            break;
          case "SKIP": {
            l.skippedSegments && Ne(l, U, v);
            const $ = new oe(N, l), P = $.decimalInteger("SKIPPED-SEGMENTS");
            if (M(P)) {
              l.skippedSegments += P;
              for (let W = P; W--; )
                h.push(null);
              f += P;
            }
            const O = $.enumeratedString("RECENTLY-REMOVED-DATERANGES");
            O && (l.recentlyRemovedDateranges = (l.recentlyRemovedDateranges || []).concat(O.split("	")));
            break;
          }
          case "TARGETDURATION":
            l.targetduration !== 0 && Ne(l, U, v), l.targetduration = Math.max(parseInt(N), 1);
            break;
          case "VERSION":
            l.version !== null && Ne(l, U, v), l.version = parseInt(N);
            break;
          case "INDEPENDENT-SEGMENTS":
            break;
          case "ENDLIST":
            l.live || Ne(l, U, v), l.live = !1;
            break;
          case "#":
            (N || B) && T.tagList.push(B ? [N, B] : [N]);
            break;
          case "DISCONTINUITY":
            E++, T.tagList.push(["DIS"]);
            break;
          case "GAP":
            T.gap = !0, T.tagList.push([U]);
            break;
          case "BITRATE":
            T.tagList.push([U, N]), y = parseInt(N) * 1e3, M(y) ? T.bitrate = y : y = 0;
            break;
          case "DATERANGE": {
            const $ = new oe(N, l), P = new Nn($, l.dateRanges[$.ID], l.dateRangeTagCount);
            l.dateRangeTagCount++, P.isValid || l.skippedSegments ? l.dateRanges[P.id] = P : Q.warn(`Ignoring invalid DATERANGE tag: "${N}"`), T.tagList.push(["EXT-X-DATERANGE", N]);
            break;
          }
          case "DEFINE": {
            {
              const $ = new oe(N, l);
              "IMPORT" in $ ? cl(l, $, n) : mr(l, $, t);
            }
            break;
          }
          case "DISCONTINUITY-SEQUENCE":
            l.startCC !== 0 ? Ne(l, U, v) : h.length > 0 && Ir(l, U, v), l.startCC = E = parseInt(N);
            break;
          case "KEY": {
            const $ = Tr(N, t, l);
            if ($.isSupported()) {
              if ($.method === "NONE") {
                _ = void 0;
                break;
              }
              _ || (_ = {}), _[$.keyFormat] && (_ = re({}, _)), _[$.keyFormat] = $;
            } else
              Q.warn(`[Keys] Ignoring invalid EXT-X-KEY tag: "${N}"`);
            break;
          }
          case "START":
            l.startTimeOffset = Sr(N);
            break;
          case "MAP": {
            const $ = new oe(N, l);
            if (T.duration) {
              const P = new Ls(i, c);
              Ar(P, $, s, _), d = P, T.initSegment = d, d.rawProgramDateTime && !T.rawProgramDateTime && (T.rawProgramDateTime = d.rawProgramDateTime);
            } else {
              const P = T.byteRangeEndOffset;
              if (P) {
                const O = T.byteRangeStartOffset;
                D = `${P - O}@${O}`;
              } else
                D = null;
              Ar(T, $, s, _), d = T, b = !0;
            }
            d.cc = E;
            break;
          }
          case "SERVER-CONTROL": {
            L && Ne(l, U, v), L = new oe(N), l.canBlockReload = L.bool("CAN-BLOCK-RELOAD"), l.canSkipUntil = L.optionalFloat("CAN-SKIP-UNTIL", 0), l.canSkipDateRanges = l.canSkipUntil > 0 && L.bool("CAN-SKIP-DATERANGES"), l.partHoldBack = L.optionalFloat("PART-HOLD-BACK", 0), l.holdBack = L.optionalFloat("HOLD-BACK", 0);
            break;
          }
          case "PART-INF": {
            l.partTarget && Ne(l, U, v);
            const $ = new oe(N);
            l.partTarget = $.decimalFloatingPoint("PART-TARGET");
            break;
          }
          case "PART": {
            let $ = l.partList;
            $ || ($ = l.partList = []);
            const P = g > 0 ? $[$.length - 1] : void 0, O = g++, W = new oe(N, l), H = new uo(W, T, c, O, P);
            $.push(H), T.duration += H.duration;
            break;
          }
          case "PRELOAD-HINT": {
            const $ = new oe(N, l);
            l.preloadHint = $;
            break;
          }
          case "RENDITION-REPORT": {
            const $ = new oe(N, l);
            l.renditionReports = l.renditionReports || [], l.renditionReports.push($);
            break;
          }
          default:
            Q.warn(`line parsed but not handled: ${v}`);
            break;
        }
      }
    }
    S && !S.relurl ? (h.pop(), p -= S.duration, l.partList && (l.fragmentHint = S)) : l.partList && (ti(T, S, u), T.cc = E, l.fragmentHint = T, _ && Lr(T, _, l)), l.targetduration || (l.playlistParsingError = new Error("#EXT-X-TARGETDURATION is required"));
    const k = h.length, F = h[0], j = h[k - 1];
    if (p += l.skippedSegments * l.targetduration, p > 0 && k && j) {
      l.averagetargetduration = p / k;
      const w = j.sn;
      l.endSN = w !== "initSegment" ? w : 0, l.live || (j.endList = !0), F && l.startCC === void 0 && (l.startCC = F.cc), A > 0 && (Rl(h, A), F && u.unshift(F));
    } else
      l.endSN = 0, l.startCC = 0;
    return l.fragmentHint && (p += l.fragmentHint.duration), l.totalduration = p, u.length && l.dateRangeTagCount && F && $n(u, l), l.endCC = E, l;
  }
}
function $n(a, e) {
  const t = a.length, s = a[t - 1], i = e.live ? 1 / 0 : e.totalduration, r = Object.keys(e.dateRanges);
  for (let n = r.length; n--; ) {
    const o = e.dateRanges[r[n]], c = o.startDate.getTime();
    o.tagAnchor = s.ref;
    for (let l = t; l--; ) {
      const h = Il(e, c, a, l, i);
      if (h !== -1) {
        o.tagAnchor = e.fragments[h].ref;
        break;
      }
    }
  }
}
function Il(a, e, t, s, i) {
  const r = t[s];
  if (r) {
    const o = r.programDateTime;
    if (e >= o || s === 0) {
      var n;
      const c = (((n = t[s + 1]) == null ? void 0 : n.start) || i) - r.start;
      if (e <= o + c * 1e3) {
        const l = t[s].sn - a.startSN, h = a.fragments;
        if (h.length > t.length) {
          const d = (t[s + 1] || h[h.length - 1]).sn - a.startSN;
          for (let f = d; f > l; f--) {
            const g = h[f].programDateTime;
            if (e >= g && e < g + h[f].duration * 1e3)
              return f;
          }
        }
        return l;
      }
    }
  }
  return -1;
}
function Tr(a, e, t) {
  var s, i;
  const r = new oe(a, t), n = (s = r.METHOD) != null ? s : "", o = r.URI, c = r.hexadecimalInteger("IV"), l = r.KEYFORMATVERSIONS, h = (i = r.KEYFORMAT) != null ? i : "identity";
  o && r.IV && !c && Q.error(`Invalid IV: ${r.IV}`);
  const u = o ? Oe.resolve(o, e) : "", d = (l || "1").split("/").map(Number).filter(Number.isFinite);
  return new Ct(n, u, h, d, c);
}
function Sr(a) {
  const t = new oe(a).decimalFloatingPoint("TIME-OFFSET");
  return M(t) ? t : null;
}
function vr(a, e) {
  let t = (a || "").split(/[ ,]+/).filter((s) => s);
  ["video", "audio", "text"].forEach((s) => {
    const i = t.filter((r) => bn(r, s));
    i.length && (e[`${s}Codec`] = i.map((r) => r.split("/")[0]).join(","), t = t.filter((r) => i.indexOf(r) === -1));
  }), e.unknownCodecs = t;
}
function xr(a, e, t) {
  const s = e[t];
  s && (a[t] = s);
}
function Rl(a, e) {
  let t = a[e];
  for (let s = e; s--; ) {
    const i = a[s];
    if (!i)
      return;
    i.programDateTime = t.programDateTime - i.duration * 1e3, t = i;
  }
}
function ti(a, e, t) {
  a.rawProgramDateTime ? t.push(a) : e != null && e.programDateTime && (a.programDateTime = e.endProgramDateTime);
}
function Ar(a, e, t, s) {
  a.relurl = e.URI, e.BYTERANGE && a.setByteRange(e.BYTERANGE), a.level = t, a.sn = "initSegment", s && (a.levelkeys = s), a.initSegment = null;
}
function Lr(a, e, t) {
  a.levelkeys = e;
  const {
    encryptedFragments: s
  } = t;
  (!s.length || s[s.length - 1].levelkeys !== e) && Object.keys(e).some((i) => e[i].isCommonEncryption) && s.push(a);
}
function Ne(a, e, t) {
  a.playlistParsingError = new Error(`#EXT-X-${e} must not appear more than once (${t[0]})`);
}
function Ir(a, e, t) {
  a.playlistParsingError = new Error(`#EXT-X-${e} must appear before the first Media Segment (${t[0]})`);
}
function ks(a, e) {
  const t = e.startPTS;
  if (M(t)) {
    let s = 0, i;
    e.sn > a.sn ? (s = t - a.start, i = a) : (s = a.start - t, i = e), i.duration !== s && i.setDuration(s);
  } else e.sn > a.sn ? a.cc === e.cc && a.minEndPTS ? e.setStart(a.start + (a.minEndPTS - a.start)) : e.setStart(a.start + a.duration) : e.setStart(Math.max(a.start - e.duration, 0));
}
function Gn(a, e, t, s, i, r) {
  s - t <= 0 && (Q.warn("Fragment should have a positive duration", e), s = t + e.duration, r = i + e.duration);
  let o = t, c = s;
  const l = e.startPTS, h = e.endPTS;
  if (M(l)) {
    const E = Math.abs(l - t);
    M(e.deltaPTS) ? e.deltaPTS = Math.max(E, e.deltaPTS) : e.deltaPTS = E, o = Math.max(t, l), t = Math.min(t, l), i = Math.min(i, e.startDTS), c = Math.min(s, h), s = Math.max(s, h), r = Math.max(r, e.endDTS);
  }
  const u = t - e.start;
  e.start !== 0 && e.setStart(t), e.setDuration(s - e.start), e.startPTS = t, e.maxStartPTS = o, e.startDTS = i, e.endPTS = s, e.minEndPTS = c, e.endDTS = r;
  const d = e.sn;
  if (!a || d < a.startSN || d > a.endSN)
    return 0;
  let f;
  const g = d - a.startSN, p = a.fragments;
  for (p[g] = e, f = g; f > 0; f--)
    ks(p[f], p[f - 1]);
  for (f = g; f < p.length - 1; f++)
    ks(p[f], p[f + 1]);
  return a.fragmentHint && ks(p[p.length - 1], a.fragmentHint), a.PTSKnown = a.alignedSliding = !0, u;
}
function bl(a, e) {
  if (a === e)
    return;
  let t = null;
  const s = a.fragments;
  for (let c = s.length - 1; c >= 0; c--) {
    const l = s[c].initSegment;
    if (l) {
      t = l;
      break;
    }
  }
  a.fragmentHint && delete a.fragmentHint.endPTS;
  let i;
  Cl(a, e, (c, l, h, u) => {
    if (!e.startCC && l.cc !== c.cc) {
      var d, f;
      const g = c.cc - l.cc;
      for (let p = h; p < u.length; p++)
        u[p].cc += g;
      e.startCC = (d = (f = Hn(a, e.startSN - 1)) == null ? void 0 : f.cc) != null ? d : u[0].cc, e.endCC = u[u.length - 1].cc;
    }
    M(c.startPTS) && M(c.endPTS) && (l.setStart(l.startPTS = c.startPTS), l.startDTS = c.startDTS, l.maxStartPTS = c.maxStartPTS, l.endPTS = c.endPTS, l.endDTS = c.endDTS, l.minEndPTS = c.minEndPTS, l.setDuration(c.endPTS - c.startPTS), l.duration && (i = l), e.PTSKnown = e.alignedSliding = !0), c.hasStreams && (l.elementaryStreams = c.elementaryStreams), l.loader = c.loader, c.hasStats && (l.stats = c.stats), c.initSegment && (l.initSegment = c.initSegment, t = c.initSegment);
  });
  const r = e.fragments, n = e.fragmentHint ? r.concat(e.fragmentHint) : r;
  if (t && n.forEach((c) => {
    var l;
    c && (!c.initSegment || c.initSegment.relurl === ((l = t) == null ? void 0 : l.relurl)) && (c.initSegment = t);
  }), e.skippedSegments)
    if (e.deltaUpdateFailed = r.some((c) => !c), e.deltaUpdateFailed) {
      Q.warn("[level-helper] Previous playlist missing segments skipped in delta playlist");
      for (let c = e.skippedSegments; c--; )
        r.shift();
      e.startSN = r[0].sn;
    } else {
      e.endCC = r[r.length - 1].cc, e.canSkipDateRanges && (e.dateRanges = _l(a.dateRanges, e));
      const c = a.fragments.filter((l) => l.rawProgramDateTime);
      if (a.hasProgramDateTime && !e.hasProgramDateTime)
        for (let l = 1; l < n.length; l++)
          n[l].programDateTime === null && ti(n[l], n[l - 1], c);
      $n(c, e);
    }
  Dl(a.partList, e.partList, (c, l) => {
    l.elementaryStreams = c.elementaryStreams, l.stats = c.stats;
  }), i ? Gn(e, i, i.startPTS, i.endPTS, i.startDTS, i.endDTS) : Kn(a, e), r.length && (e.totalduration = e.edge - r[0].start), e.driftStartTime = a.driftStartTime, e.driftStart = a.driftStart;
  const o = e.advancedDateTime;
  if (e.advanced && o) {
    const c = e.edge;
    e.driftStart || (e.driftStartTime = o, e.driftStart = c), e.driftEndTime = o, e.driftEnd = c;
  } else
    e.driftEndTime = a.driftEndTime, e.driftEnd = a.driftEnd, e.advancedDateTime = a.advancedDateTime;
  e.requestScheduled === -1 && (e.requestScheduled = a.requestScheduled);
}
function _l(a, e) {
  const {
    dateRanges: t,
    recentlyRemovedDateranges: s
  } = e, i = re({}, a);
  s && s.forEach((o) => {
    delete i[o];
  });
  const n = Object.keys(i).length;
  return n && Object.keys(t).forEach((o) => {
    const c = i[o], l = new Nn(t[o].attr, c);
    l.isValid ? (i[o] = l, c || (l.tagOrder += n)) : Q.warn(`Ignoring invalid Playlist Delta Update DATERANGE tag: "${ae(t[o].attr)}"`);
  }), i;
}
function Dl(a, e, t) {
  if (a && e) {
    let s = 0;
    for (let i = 0, r = a.length; i <= r; i++) {
      const n = a[i], o = e[i + s];
      n && o && n.index === o.index && n.fragment.sn === o.fragment.sn ? t(n, o) : s--;
    }
  }
}
function Cl(a, e, t) {
  const s = e.skippedSegments, i = Math.max(a.startSN, e.startSN) - e.startSN, r = (a.fragmentHint ? 1 : 0) + (s ? e.endSN : Math.min(a.endSN, e.endSN)) - e.startSN, n = e.startSN - a.startSN, o = e.fragmentHint ? e.fragments.concat(e.fragmentHint) : e.fragments, c = a.fragmentHint ? a.fragments.concat(a.fragmentHint) : a.fragments;
  for (let l = i; l <= r; l++) {
    const h = c[n + l];
    let u = o[l];
    if (s && !u && h && (u = e.fragments[l] = h), h && u) {
      if (t(h, u, l, o), h.url && h.url !== u.url) {
        e.playlistParsingError = Rr(`media sequence mismatch ${u.sn}:`, a, e, h, u);
        return;
      } else if (h.cc !== u.cc) {
        e.playlistParsingError = Rr(`discontinuity sequence mismatch (${h.cc}!=${u.cc})`, a, e, h, u);
        return;
      }
    }
  }
}
function Rr(a, e, t, s, i) {
  return new Error(`${a} ${i.url}
Playlist starting @${e.startSN}
${e.m3u8}

Playlist starting @${t.startSN}
${t.m3u8}`);
}
function Kn(a, e, t = !0) {
  const s = e.startSN + e.skippedSegments - a.startSN, i = a.fragments, r = s >= 0;
  let n = 0;
  if (r && s < i.length)
    n = i[s].start;
  else if (r && e.startSN === a.endSN + 1)
    n = a.fragmentEnd;
  else if (r && t)
    n = a.fragmentStart + s * e.levelTargetDuration;
  else if (!e.skippedSegments && e.fragmentStart === 0)
    n = a.fragmentStart;
  else
    return;
  si(e, n);
}
function si(a, e) {
  if (e) {
    const t = a.fragments;
    for (let s = a.skippedSegments; s < t.length; s++)
      t[s].addStart(e);
    a.fragmentHint && a.fragmentHint.addStart(e);
  }
}
function Vn(a, e = 1 / 0) {
  let t = 1e3 * a.targetduration;
  if (a.updated) {
    const s = a.fragments;
    if (s.length && t * 4 > e) {
      const r = s[s.length - 1].duration * 1e3;
      r < t && (t = r);
    }
  } else
    t /= 2;
  return Math.round(t);
}
function Hn(a, e, t) {
  if (!a)
    return null;
  let s = a.fragments[e - a.startSN];
  return s || (s = a.fragmentHint, s && s.sn === e) ? s : e < a.startSN && t && t.sn === e ? t : null;
}
function br(a, e, t) {
  return a ? Wn(a.partList, e, t) : null;
}
function Wn(a, e, t) {
  if (a)
    for (let s = a.length; s--; ) {
      const i = a[s];
      if (i.index === t && i.fragment.sn === e)
        return i;
    }
  return null;
}
function Yn(a) {
  a.forEach((e, t) => {
    var s;
    (s = e.details) == null || s.fragments.forEach((i) => {
      i.level = t, i.initSegment && (i.initSegment.level = t);
    });
  });
}
function At(a, e) {
  for (let s = 0, i = a.length; s < i; s++) {
    var t;
    if (((t = a[s]) == null ? void 0 : t.cc) === e)
      return a[s];
  }
  return null;
}
function Pl(a, e) {
  return !!(a && e.startCC < a.endCC && e.endCC > a.startCC);
}
function _r(a, e) {
  if (a) {
    const t = a.start + e;
    a.start = a.startPTS = t, a.endPTS = t + a.duration;
  }
}
function qn(a, e) {
  const t = e.fragments;
  for (let s = 0, i = t.length; s < i; s++)
    _r(t[s], a);
  e.fragmentHint && _r(e.fragmentHint, a), e.alignedSliding = !0;
}
function kl(a, e) {
  a && (jn(e, a), !e.alignedSliding && a && fs(e, a), !e.alignedSliding && a && !e.skippedSegments && Kn(a, e, !1));
}
function jn(a, e) {
  if (!Pl(e, a))
    return;
  const t = Math.min(e.endCC, a.endCC), s = At(e.fragments, t), i = At(a.fragments, t);
  if (!s || !i)
    return;
  Q.log(`Aligning playlist at start of dicontinuity sequence ${t}`);
  const r = s.start - i.start;
  qn(r, a);
}
function fs(a, e) {
  if (!a.hasProgramDateTime || !e.hasProgramDateTime)
    return;
  const t = a.fragments, s = e.fragments;
  if (!t.length || !s.length)
    return;
  let i, r;
  const n = Math.min(e.endCC, a.endCC);
  e.startCC < n && a.startCC < n && (i = At(s, n), r = At(t, n)), (!i || !r) && (i = s[Math.floor(s.length / 2)], r = At(t, i.cc) || t[Math.floor(t.length / 2)]);
  const o = i.programDateTime, c = r.programDateTime;
  if (!o || !c)
    return;
  const l = (c - o) / 1e3 - (r.start - i.start);
  qn(l, a);
}
const wl = {
  toString: function(a) {
    let e = "";
    const t = a.length;
    for (let s = 0; s < t; s++)
      e += `[${a.start(s).toFixed(3)}-${a.end(s).toFixed(3)}]`;
    return e;
  }
}, C = {
  STOPPED: "STOPPED",
  IDLE: "IDLE",
  KEY_LOADING: "KEY_LOADING",
  FRAG_LOADING: "FRAG_LOADING",
  FRAG_LOADING_WAITING_RETRY: "FRAG_LOADING_WAITING_RETRY",
  WAITING_TRACK: "WAITING_TRACK",
  PARSING: "PARSING",
  PARSED: "PARSED",
  ENDED: "ENDED",
  ERROR: "ERROR",
  WAITING_INIT_PTS: "WAITING_INIT_PTS",
  WAITING_LEVEL: "WAITING_LEVEL"
};
class xi extends Fn {
  constructor(e, t, s, i, r) {
    super(i, e.logger), this.hls = void 0, this.fragPrevious = null, this.fragCurrent = null, this.fragmentTracker = void 0, this.transmuxer = null, this._state = C.STOPPED, this.playlistType = void 0, this.media = null, this.mediaBuffer = null, this.config = void 0, this.bitrateTest = !1, this.lastCurrentTime = 0, this.nextLoadPosition = 0, this.startPosition = 0, this.startTimeOffset = null, this.retryDate = 0, this.levels = null, this.fragmentLoader = void 0, this.keyLoader = void 0, this.levelLastLoaded = null, this.startFragRequested = !1, this.decrypter = void 0, this.initPTS = [], this.buffering = !0, this.loadingParts = !1, this.loopSn = void 0, this.onMediaSeeking = () => {
      const {
        config: n,
        fragCurrent: o,
        media: c,
        mediaBuffer: l,
        state: h
      } = this, u = c ? c.currentTime : 0, d = q.bufferInfo(l || c, u, n.maxBufferHole);
      if (this.log(`media seeking to ${M(u) ? u.toFixed(3) : u}, state: ${h}`), this.state === C.ENDED)
        this.resetLoadingState();
      else if (o) {
        const f = n.maxFragLookUpTolerance, g = o.start - f, p = o.start + o.duration + f;
        if (!d.len || p < d.start || g > d.end) {
          const E = u > p;
          (u < g || E) && (E && o.loader && (this.log("seeking outside of buffer while fragment load in progress, cancel fragment load"), o.abortRequests(), this.resetLoadingState()), this.fragPrevious = null);
        }
      }
      if (c) {
        this.fragmentTracker.removeFragmentsInRange(u, 1 / 0, this.playlistType, !0);
        const f = this.lastCurrentTime;
        if (u > f && (this.lastCurrentTime = u), !this.loadingParts) {
          const g = Math.max(d.end, u), p = this.shouldLoadParts(this.getLevelDetails(), g);
          p && (this.log(`LL-Part loading ON after seeking to ${u.toFixed(2)} with buffer @${g.toFixed(2)}`), this.loadingParts = p);
        }
      }
      !this.hls.hasEnoughToStart && !d.len && (this.log(`setting startPosition to ${u} because of seek before start`), this.nextLoadPosition = this.startPosition = u), this.tickImmediate();
    }, this.onMediaEnded = () => {
      this.log("setting startPosition to 0 because media ended"), this.startPosition = this.lastCurrentTime = 0;
    }, this.playlistType = r, this.hls = e, this.fragmentLoader = new ol(e.config), this.keyLoader = s, this.fragmentTracker = t, this.config = e.config, this.decrypter = new yi(e.config);
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.MANIFEST_LOADED, this.onManifestLoaded, this), e.on(m.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.MANIFEST_LOADED, this.onManifestLoaded, this), e.off(m.ERROR, this.onError, this);
  }
  doTick() {
    this.onTickEnd();
  }
  onTickEnd() {
  }
  startLoad(e) {
  }
  stopLoad() {
    if (this.state === C.STOPPED)
      return;
    this.fragmentLoader.abort(), this.keyLoader.abort(this.playlistType);
    const e = this.fragCurrent;
    e != null && e.loader && (e.abortRequests(), this.fragmentTracker.removeFragment(e)), this.resetTransmuxer(), this.fragCurrent = null, this.fragPrevious = null, this.clearInterval(), this.clearNextTick(), this.state = C.STOPPED;
  }
  get startPositionValue() {
    const {
      nextLoadPosition: e,
      startPosition: t
    } = this;
    return t === -1 && e ? e : t;
  }
  get bufferingEnabled() {
    return this.buffering;
  }
  pauseBuffering() {
    this.buffering = !1;
  }
  resumeBuffering() {
    this.buffering = !0;
  }
  get inFlightFrag() {
    return {
      frag: this.fragCurrent,
      state: this.state
    };
  }
  _streamEnded(e, t) {
    if (t.live || !this.media)
      return !1;
    const s = e.end || 0, i = this.config.timelineOffset || 0;
    if (s <= i)
      return !1;
    const r = e.nextStart;
    if (r && r > i && r < t.edge || this.media.currentTime < e.start)
      return !1;
    const o = t.partList;
    if (o != null && o.length) {
      const l = o[o.length - 1];
      return q.isBuffered(this.media, l.start + l.duration / 2);
    }
    const c = t.fragments[t.fragments.length - 1].type;
    return this.fragmentTracker.isEndListAppended(c);
  }
  getLevelDetails() {
    if (this.levels && this.levelLastLoaded !== null) {
      var e;
      return (e = this.levelLastLoaded) == null ? void 0 : e.details;
    }
  }
  get timelineOffset() {
    const e = this.config.timelineOffset;
    if (e) {
      var t;
      return ((t = this.getLevelDetails()) == null ? void 0 : t.appliedTimelineOffset) || e;
    }
    return 0;
  }
  onMediaAttached(e, t) {
    const s = this.media = this.mediaBuffer = t.media;
    s.removeEventListener("seeking", this.onMediaSeeking), s.removeEventListener("ended", this.onMediaEnded), s.addEventListener("seeking", this.onMediaSeeking), s.addEventListener("ended", this.onMediaEnded);
    const i = this.config;
    this.levels && i.autoStartLoad && this.state === C.STOPPED && this.startLoad(i.startPosition);
  }
  onMediaDetaching(e, t) {
    const s = !!t.transferMedia, i = this.media;
    if (i !== null) {
      if (i.ended && (this.log("MSE detaching and video ended, reset startPosition"), this.startPosition = this.lastCurrentTime = 0), i.removeEventListener("seeking", this.onMediaSeeking), i.removeEventListener("ended", this.onMediaEnded), this.keyLoader && !s && this.keyLoader.detach(), this.media = this.mediaBuffer = null, this.loopSn = void 0, s) {
        this.resetLoadingState(), this.resetTransmuxer();
        return;
      }
      this.loadingParts = !1, this.fragmentTracker.removeAllFragments(), this.stopLoad();
    }
  }
  onManifestLoading() {
    this.initPTS = [], this.levels = this.levelLastLoaded = this.fragCurrent = null, this.lastCurrentTime = this.startPosition = 0, this.startFragRequested = !1;
  }
  onError(e, t) {
  }
  onManifestLoaded(e, t) {
    this.startTimeOffset = t.startTimeOffset;
  }
  onHandlerDestroying() {
    this.stopLoad(), this.transmuxer && (this.transmuxer.destroy(), this.transmuxer = null), super.onHandlerDestroying(), this.hls = this.onMediaSeeking = this.onMediaEnded = null;
  }
  onHandlerDestroyed() {
    this.state = C.STOPPED, this.fragmentLoader && this.fragmentLoader.destroy(), this.keyLoader && this.keyLoader.destroy(), this.decrypter && this.decrypter.destroy(), this.hls = this.log = this.warn = this.decrypter = this.keyLoader = this.fragmentLoader = this.fragmentTracker = null, super.onHandlerDestroyed();
  }
  loadFragment(e, t, s) {
    this.startFragRequested = !0, this._loadFragForPlayback(e, t, s);
  }
  _loadFragForPlayback(e, t, s) {
    const i = (r) => {
      const n = r.frag;
      if (this.fragContextChanged(n)) {
        this.warn(`${n.type} sn: ${n.sn}${r.part ? " part: " + r.part.index : ""} of ${this.fragInfo(n, !1, r.part)}) was dropped during download.`), this.fragmentTracker.removeFragment(n);
        return;
      }
      n.stats.chunkCount++, this._handleFragmentLoadProgress(r);
    };
    this._doFragLoad(e, t, s, i).then((r) => {
      if (!r)
        return;
      const n = this.state, o = r.frag;
      if (this.fragContextChanged(o)) {
        (n === C.FRAG_LOADING || !this.fragCurrent && n === C.PARSING) && (this.fragmentTracker.removeFragment(o), this.state = C.IDLE);
        return;
      }
      "payload" in r && (this.log(`Loaded ${o.type} sn: ${o.sn} of ${this.playlistLabel()} ${o.level}`), this.hls.trigger(m.FRAG_LOADED, r)), this._handleFragmentLoadComplete(r);
    }).catch((r) => {
      this.state === C.STOPPED || this.state === C.ERROR || (this.warn(`Frag error: ${(r == null ? void 0 : r.message) || r}`), this.resetFragmentLoading(e));
    });
  }
  clearTrackerIfNeeded(e) {
    var t;
    const {
      fragmentTracker: s
    } = this;
    if (s.getState(e) === ce.APPENDING) {
      const r = e.type, n = this.getFwdBufferInfo(this.mediaBuffer, r), o = Math.max(e.duration, n ? n.len : this.config.maxBufferLength), c = this.backtrackFragment;
      ((c ? e.sn - c.sn : 0) === 1 || this.reduceMaxBufferLength(o, e.duration)) && s.removeFragment(e);
    } else ((t = this.mediaBuffer) == null ? void 0 : t.buffered.length) === 0 ? s.removeAllFragments() : s.hasParts(e.type) && (s.detectPartialFragments({
      frag: e,
      part: null,
      stats: e.stats,
      id: e.type
    }), s.getState(e) === ce.PARTIAL && s.removeFragment(e));
  }
  checkLiveUpdate(e) {
    if (e.updated && !e.live) {
      const t = e.fragments[e.fragments.length - 1];
      this.fragmentTracker.detectPartialFragments({
        frag: t,
        part: null,
        stats: t.stats,
        id: t.type
      });
    }
    e.fragments[0] || (e.deltaUpdateFailed = !0);
  }
  waitForLive(e) {
    const t = e.details;
    return (t == null ? void 0 : t.live) && t.type !== "EVENT" && (this.levelLastLoaded !== e || t.expired);
  }
  flushMainBuffer(e, t, s = null) {
    if (!(e - t))
      return;
    const i = {
      startOffset: e,
      endOffset: t,
      type: s
    };
    this.hls.trigger(m.BUFFER_FLUSHING, i);
  }
  _loadInitSegment(e, t) {
    this._doFragLoad(e, t).then((s) => {
      const i = s == null ? void 0 : s.frag;
      if (!i || this.fragContextChanged(i) || !this.levels)
        throw new Error("init load aborted");
      return s;
    }).then((s) => {
      const {
        hls: i
      } = this, {
        frag: r,
        payload: n
      } = s, o = r.decryptdata;
      if (n && n.byteLength > 0 && o != null && o.key && o.iv && dt(o.method)) {
        const c = self.performance.now();
        return this.decrypter.decrypt(new Uint8Array(n), o.key.buffer, o.iv.buffer, Si(o.method)).catch((l) => {
          throw i.trigger(m.ERROR, {
            type: K.MEDIA_ERROR,
            details: R.FRAG_DECRYPT_ERROR,
            fatal: !1,
            error: l,
            reason: l.message,
            frag: r
          }), l;
        }).then((l) => {
          const h = self.performance.now();
          return i.trigger(m.FRAG_DECRYPTED, {
            frag: r,
            payload: l,
            stats: {
              tstart: c,
              tdecrypt: h
            }
          }), s.payload = l, this.completeInitSegmentLoad(s);
        });
      }
      return this.completeInitSegmentLoad(s);
    }).catch((s) => {
      this.state === C.STOPPED || this.state === C.ERROR || (this.warn(s), this.resetFragmentLoading(e));
    });
  }
  completeInitSegmentLoad(e) {
    const {
      levels: t
    } = this;
    if (!t)
      throw new Error("init load aborted, missing levels");
    const s = e.frag.stats;
    this.state !== C.STOPPED && (this.state = C.IDLE), e.frag.data = new Uint8Array(e.payload), s.parsing.start = s.buffering.start = self.performance.now(), s.parsing.end = s.buffering.end = self.performance.now(), this.tick();
  }
  fragContextChanged(e) {
    const {
      fragCurrent: t
    } = this;
    return !e || !t || e.sn !== t.sn || e.level !== t.level;
  }
  fragBufferedComplete(e, t) {
    const s = this.mediaBuffer ? this.mediaBuffer : this.media;
    if (this.log(`Buffered ${e.type} sn: ${e.sn}${t ? " part: " + t.index : ""} of ${this.fragInfo(e, !1, t)} > buffer:${s ? wl.toString(q.getBuffered(s)) : "(detached)"})`), ue(e)) {
      var i;
      if (e.type !== G.SUBTITLE) {
        const n = e.elementaryStreams;
        if (!Object.keys(n).some((o) => !!n[o])) {
          this.state = C.IDLE;
          return;
        }
      }
      const r = (i = this.levels) == null ? void 0 : i[e.level];
      r != null && r.fragmentError && (this.log(`Resetting level fragment error count of ${r.fragmentError} on frag buffered`), r.fragmentError = 0);
    }
    this.state = C.IDLE;
  }
  _handleFragmentLoadComplete(e) {
    const {
      transmuxer: t
    } = this;
    if (!t)
      return;
    const {
      frag: s,
      part: i,
      partsLoaded: r
    } = e, n = !r || r.length === 0 || r.some((c) => !c), o = new Ti(s.level, s.sn, s.stats.chunkCount + 1, 0, i ? i.index : -1, !n);
    t.flush(o);
  }
  _handleFragmentLoadProgress(e) {
  }
  _doFragLoad(e, t, s = null, i) {
    var r;
    this.fragCurrent = e;
    const n = t == null ? void 0 : t.details;
    if (!this.levels || !n)
      throw new Error(`frag load aborted, missing level${n ? "" : " detail"}s`);
    let o = null;
    e.encrypted && !((r = e.decryptdata) != null && r.key) ? (this.log(`Loading key for ${e.sn} of [${n.startSN}-${n.endSN}], ${this.playlistLabel()} ${e.level}`), this.state = C.KEY_LOADING, this.fragCurrent = e, o = this.keyLoader.load(e).then((u) => {
      if (!this.fragContextChanged(u.frag))
        return this.hls.trigger(m.KEY_LOADED, u), this.state === C.KEY_LOADING && (this.state = C.IDLE), u;
    }), this.hls.trigger(m.KEY_LOADING, {
      frag: e
    }), this.fragCurrent === null && (o = Promise.reject(new Error("frag load aborted, context changed in KEY_LOADING")))) : !e.encrypted && n.encryptedFragments.length && this.keyLoader.loadClear(e, n.encryptedFragments);
    const c = this.fragPrevious;
    if (ue(e) && (!c || e.sn !== c.sn)) {
      const u = this.shouldLoadParts(t.details, e.end);
      u !== this.loadingParts && (this.log(`LL-Part loading ${u ? "ON" : "OFF"} loading sn ${c == null ? void 0 : c.sn}->${e.sn}`), this.loadingParts = u);
    }
    if (s = Math.max(e.start, s || 0), this.loadingParts && ue(e)) {
      const u = n.partList;
      if (u && i) {
        s > e.end && n.fragmentHint && (e = n.fragmentHint);
        const d = this.getNextPart(u, e, s);
        if (d > -1) {
          const f = u[d];
          e = this.fragCurrent = f.fragment, this.log(`Loading ${e.type} sn: ${e.sn} part: ${f.index} (${d}/${u.length - 1}) of ${this.fragInfo(e, !1, f)}) cc: ${e.cc} [${n.startSN}-${n.endSN}], target: ${parseFloat(s.toFixed(3))}`), this.nextLoadPosition = f.start + f.duration, this.state = C.FRAG_LOADING;
          let g;
          return o ? g = o.then((p) => !p || this.fragContextChanged(p.frag) ? null : this.doFragPartsLoad(e, f, t, i)).catch((p) => this.handleFragLoadError(p)) : g = this.doFragPartsLoad(e, f, t, i).catch((p) => this.handleFragLoadError(p)), this.hls.trigger(m.FRAG_LOADING, {
            frag: e,
            part: f,
            targetBufferTime: s
          }), this.fragCurrent === null ? Promise.reject(new Error("frag load aborted, context changed in FRAG_LOADING parts")) : g;
        } else if (!e.url || this.loadedEndOfParts(u, s))
          return Promise.resolve(null);
      }
    }
    if (ue(e) && this.loadingParts)
      this.log(`LL-Part loading OFF after next part miss @${s.toFixed(2)}`), this.loadingParts = !1;
    else if (!e.url)
      return Promise.resolve(null);
    this.log(`Loading ${e.type} sn: ${e.sn} of ${this.fragInfo(e, !1)}) cc: ${e.cc} ${n ? "[" + n.startSN + "-" + n.endSN + "]" : ""}, target: ${parseFloat(s.toFixed(3))}`), M(e.sn) && !this.bitrateTest && (this.nextLoadPosition = e.start + e.duration), this.state = C.FRAG_LOADING;
    const l = this.config.progressive;
    let h;
    return l && o ? h = o.then((u) => !u || this.fragContextChanged(u == null ? void 0 : u.frag) ? null : this.fragmentLoader.load(e, i)).catch((u) => this.handleFragLoadError(u)) : h = Promise.all([this.fragmentLoader.load(e, l ? i : void 0), o]).then(([u]) => (!l && u && i && i(u), u)).catch((u) => this.handleFragLoadError(u)), this.hls.trigger(m.FRAG_LOADING, {
      frag: e,
      targetBufferTime: s
    }), this.fragCurrent === null ? Promise.reject(new Error("frag load aborted, context changed in FRAG_LOADING")) : h;
  }
  doFragPartsLoad(e, t, s, i) {
    return new Promise((r, n) => {
      var o;
      const c = [], l = (o = s.details) == null ? void 0 : o.partList, h = (u) => {
        this.fragmentLoader.loadPart(e, u, i).then((d) => {
          c[u.index] = d;
          const f = d.part;
          this.hls.trigger(m.FRAG_LOADED, d);
          const g = br(s.details, e.sn, u.index + 1) || Wn(l, e.sn, u.index + 1);
          if (g)
            h(g);
          else
            return r({
              frag: e,
              part: f,
              partsLoaded: c
            });
        }).catch(n);
      };
      h(t);
    });
  }
  handleFragLoadError(e) {
    if ("data" in e) {
      const t = e.data;
      e.data && t.details === R.INTERNAL_ABORTED ? this.handleFragLoadAborted(t.frag, t.part) : this.hls.trigger(m.ERROR, t);
    } else
      this.hls.trigger(m.ERROR, {
        type: K.OTHER_ERROR,
        details: R.INTERNAL_EXCEPTION,
        err: e,
        error: e,
        fatal: !0
      });
    return null;
  }
  _handleTransmuxerFlush(e) {
    const t = this.getCurrentContext(e);
    if (!t || this.state !== C.PARSING) {
      !this.fragCurrent && this.state !== C.STOPPED && this.state !== C.ERROR && (this.state = C.IDLE);
      return;
    }
    const {
      frag: s,
      part: i,
      level: r
    } = t, n = self.performance.now();
    s.stats.parsing.end = n, i && (i.stats.parsing.end = n);
    const o = this.getLevelDetails(), l = o && s.sn > o.endSN || this.shouldLoadParts(o, s.end);
    l !== this.loadingParts && (this.log(`LL-Part loading ${l ? "ON" : "OFF"} after parsing segment ending @${s.end.toFixed(2)}`), this.loadingParts = l), this.updateLevelTiming(s, i, r, e.partial);
  }
  shouldLoadParts(e, t) {
    if (this.config.lowLatencyMode) {
      if (!e)
        return this.loadingParts;
      if (e != null && e.partList) {
        var s;
        const r = e.partList[0], n = r.end + (((s = e.fragmentHint) == null ? void 0 : s.duration) || 0);
        if (t >= n) {
          var i;
          if ((this.hls.hasEnoughToStart ? ((i = this.media) == null ? void 0 : i.currentTime) || this.lastCurrentTime : this.getLoadPosition()) > r.start - r.fragment.duration)
            return !0;
        }
      }
    }
    return !1;
  }
  getCurrentContext(e) {
    const {
      levels: t,
      fragCurrent: s
    } = this, {
      level: i,
      sn: r,
      part: n
    } = e;
    if (!(t != null && t[i]))
      return this.warn(`Levels object was unset while buffering fragment ${r} of ${this.playlistLabel()} ${i}. The current chunk will not be buffered.`), null;
    const o = t[i], c = o.details, l = n > -1 ? br(c, r, n) : null, h = l ? l.fragment : Hn(c, r, s);
    return h ? (s && s !== h && (h.stats = s.stats), {
      frag: h,
      part: l,
      level: o
    }) : null;
  }
  bufferFragmentData(e, t, s, i, r) {
    var n;
    if (!e || this.state !== C.PARSING)
      return;
    const {
      data1: o,
      data2: c
    } = e;
    let l = o;
    if (o && c && (l = Ie(o, c)), !((n = l) != null && n.length))
      return;
    const h = {
      type: e.type,
      frag: t,
      part: s,
      chunkMeta: i,
      parent: t.type,
      data: l
    };
    if (this.hls.trigger(m.BUFFER_APPENDING, h), e.dropped && e.independent && !s) {
      if (r)
        return;
      this.flushBufferGap(t);
    }
  }
  flushBufferGap(e) {
    const t = this.media;
    if (!t)
      return;
    if (!q.isBuffered(t, t.currentTime)) {
      this.flushMainBuffer(0, e.start);
      return;
    }
    const s = t.currentTime, i = q.bufferInfo(t, s, 0), r = e.duration, n = Math.min(this.config.maxFragLookUpTolerance * 2, r * 0.25), o = Math.max(Math.min(e.start - n, i.end - n), s + n);
    e.start - o > n && this.flushMainBuffer(o, e.start);
  }
  getFwdBufferInfo(e, t) {
    var s;
    const i = this.getLoadPosition();
    if (!M(i))
      return null;
    const n = this.lastCurrentTime > i || (s = this.media) != null && s.paused ? 0 : this.config.maxBufferHole;
    return this.getFwdBufferInfoAtPos(e, i, t, n);
  }
  getFwdBufferInfoAtPos(e, t, s, i) {
    const r = q.bufferInfo(e, t, i);
    if (r.len === 0 && r.nextStart !== void 0) {
      const n = this.fragmentTracker.getBufferedFrag(t, s);
      if (n && (r.nextStart <= n.end || n.gap)) {
        const o = Math.max(Math.min(r.nextStart, n.end) - t, i);
        return q.bufferInfo(e, t, o);
      }
    }
    return r;
  }
  getMaxBufferLength(e) {
    const {
      config: t
    } = this;
    let s;
    return e ? s = Math.max(8 * t.maxBufferSize / e, t.maxBufferLength) : s = t.maxBufferLength, Math.min(s, t.maxMaxBufferLength);
  }
  reduceMaxBufferLength(e, t) {
    const s = this.config, i = Math.max(Math.min(e - t, s.maxBufferLength), t), r = Math.max(e - t * 3, s.maxMaxBufferLength / 2, i);
    return r >= i ? (s.maxMaxBufferLength = r, this.warn(`Reduce max buffer length to ${r}s`), !0) : !1;
  }
  getAppendedFrag(e, t = G.MAIN) {
    var s;
    const i = (s = this.fragmentTracker) == null ? void 0 : s.getAppendedFrag(e, t);
    return i && "fragment" in i ? i.fragment : i;
  }
  getNextFragment(e, t) {
    const s = t.fragments, i = s.length;
    if (!i)
      return null;
    const {
      config: r
    } = this, n = s[0].start, o = r.lowLatencyMode && !!t.partList;
    let c = null;
    if (t.live) {
      const u = r.initialLiveManifestSize;
      if (i < u)
        return this.warn(`Not enough fragments to start playback (have: ${i}, need: ${u})`), null;
      if (!t.PTSKnown && !this.startFragRequested && this.startPosition === -1 || e < n) {
        var l;
        o && !this.loadingParts && (this.log("LL-Part loading ON for initial live fragment"), this.loadingParts = !0), c = this.getInitialLiveFragment(t, s);
        const d = this.hls.startPosition, f = this.hls.liveSyncPosition, g = c ? (d !== -1 && d >= n ? d : f) || c.start : e;
        this.log(`Setting startPosition to ${g} to match start frag at live edge. mainStart: ${d} liveSyncPosition: ${f} frag.start: ${(l = c) == null ? void 0 : l.start}`), this.startPosition = this.nextLoadPosition = g;
      }
    } else e <= n && (c = s[0]);
    if (!c) {
      const u = this.loadingParts ? t.partEnd : t.fragmentEnd;
      c = this.getFragmentAtPosition(e, u, t);
    }
    let h = this.filterReplacedPrimary(c, t);
    if (!h && c) {
      const u = c.sn - t.startSN;
      h = this.filterReplacedPrimary(s[u + 1] || null, t);
    }
    return this.mapToInitFragWhenRequired(h);
  }
  isLoopLoading(e, t) {
    const s = this.fragmentTracker.getState(e);
    return (s === ce.OK || s === ce.PARTIAL && !!e.gap) && this.nextLoadPosition > t;
  }
  getNextFragmentLoopLoading(e, t, s, i, r) {
    let n = null;
    if (e.gap && (n = this.getNextFragment(this.nextLoadPosition, t), n && !n.gap && s.nextStart)) {
      const o = this.getFwdBufferInfoAtPos(this.mediaBuffer ? this.mediaBuffer : this.media, s.nextStart, i, 0);
      if (o !== null && s.len + o.len >= r) {
        const c = n.sn;
        return this.loopSn !== c && (this.log(`buffer full after gaps in "${i}" playlist starting at sn: ${c}`), this.loopSn = c), null;
      }
    }
    return this.loopSn = void 0, n;
  }
  get primaryPrefetch() {
    if (Dr(this.hls.config)) {
      var e, t;
      if ((e = this.hls.interstitialsManager) == null || (t = e.playingItem) == null ? void 0 : t.event)
        return !0;
    }
    return !1;
  }
  filterReplacedPrimary(e, t) {
    if (!e)
      return e;
    if (Dr(this.hls.config) && e.type !== G.SUBTITLE) {
      const s = this.hls.interstitialsManager, i = s == null ? void 0 : s.bufferingItem;
      if (i) {
        const n = i.event;
        if (n) {
          if (n.appendInPlace || Math.abs(e.start - i.start) > 1 || i.start === 0)
            return null;
        } else if (e.end <= i.start && (t == null ? void 0 : t.live) === !1 || e.start > i.end && i.nextEvent && (i.nextEvent.appendInPlace || e.start - i.end > 1))
          return null;
      }
      const r = s == null ? void 0 : s.playerQueue;
      if (r)
        for (let n = r.length; n--; ) {
          const o = r[n].interstitial;
          if (o.appendInPlace && e.start >= o.startTime && e.end <= o.resumeTime)
            return null;
        }
    }
    return e;
  }
  mapToInitFragWhenRequired(e) {
    return e != null && e.initSegment && !(e != null && e.initSegment.data) && !this.bitrateTest ? e.initSegment : e;
  }
  getNextPart(e, t, s) {
    let i = -1, r = !1, n = !0;
    for (let o = 0, c = e.length; o < c; o++) {
      const l = e[o];
      if (n = n && !l.independent, i > -1 && s < l.start)
        break;
      const h = l.loaded;
      h ? i = -1 : (r || l.independent || n) && l.fragment === t && (i = o), r = h;
    }
    return i;
  }
  loadedEndOfParts(e, t) {
    const s = e[e.length - 1];
    return s && t > s.start && s.loaded;
  }
  /*
   This method is used find the best matching first fragment for a live playlist. This fragment is used to calculate the
   "sliding" of the playlist, which is its offset from the start of playback. After sliding we can compute the real
   start and end times for each fragment in the playlist (after which this method will not need to be called).
  */
  getInitialLiveFragment(e, t) {
    const s = this.fragPrevious;
    let i = null;
    if (s) {
      if (e.hasProgramDateTime && (this.log(`Live playlist, switching playlist, load frag with same PDT: ${s.programDateTime}`), i = jo(t, s.endProgramDateTime, this.config.maxFragLookUpTolerance)), !i) {
        const r = s.sn + 1;
        if (r >= e.startSN && r <= e.endSN) {
          const n = t[r - e.startSN];
          s.cc === n.cc && (i = n, this.log(`Live playlist, switching playlist, load frag with next SN: ${i.sn}`));
        }
        i || (i = On(t, s.cc), i && this.log(`Live playlist, switching playlist, load frag with same CC: ${i.sn}`));
      }
    } else {
      const r = this.hls.liveSyncPosition;
      r !== null && (i = this.getFragmentAtPosition(r, this.bitrateTest ? e.fragmentEnd : e.edge, e));
    }
    return i;
  }
  /*
  This method finds the best matching fragment given the provided position.
   */
  getFragmentAtPosition(e, t, s) {
    const {
      config: i
    } = this;
    let {
      fragPrevious: r
    } = this, {
      fragments: n,
      endSN: o
    } = s;
    const {
      fragmentHint: c
    } = s, {
      maxFragLookUpTolerance: l
    } = i, h = s.partList, u = !!(this.loadingParts && h != null && h.length && c);
    u && c && !this.bitrateTest && h[h.length - 1].fragment.sn === c.sn && (n = n.concat(c), o = c.sn);
    let d;
    if (e < t) {
      var f;
      const p = e < this.lastCurrentTime || e > t - l || (f = this.media) != null && f.paused || !this.startFragRequested ? 0 : l;
      d = it(r, n, e, p);
    } else
      d = n[n.length - 1];
    if (d) {
      const g = d.sn - s.startSN, p = this.fragmentTracker.getState(d);
      if ((p === ce.OK || p === ce.PARTIAL && d.gap) && (r = d), r && d.sn === r.sn && (!u || h[0].fragment.sn > d.sn || !s.live && !u) && r && d.level === r.level) {
        const y = n[g + 1];
        d.sn < o && this.fragmentTracker.getState(y) !== ce.OK ? d = y : d = null;
      }
    }
    return d;
  }
  alignPlaylists(e, t, s) {
    const i = e.fragments.length;
    if (!i)
      return this.warn("No fragments in live playlist"), 0;
    const r = e.fragmentStart, n = !t, o = e.alignedSliding && M(r);
    if (n || !o && !r) {
      kl(s, e);
      const c = e.fragmentStart;
      return this.log(`Live playlist sliding: ${c.toFixed(2)} start-sn: ${t ? t.startSN : "na"}->${e.startSN} fragments: ${i}`), c;
    }
    return r;
  }
  waitForCdnTuneIn(e) {
    return e.live && e.canBlockReload && e.partTarget && e.tuneInGoal > Math.max(e.partHoldBack, e.partTarget * 3);
  }
  setStartPosition(e, t) {
    let s = this.startPosition;
    s < t && (s = -1);
    const i = this.timelineOffset;
    if (s === -1) {
      const r = this.startTimeOffset !== null, n = r ? this.startTimeOffset : e.startTimeOffset;
      n !== null && M(n) ? (s = t + n, n < 0 && (s += e.edge), s = Math.min(Math.max(t, s), t + e.totalduration), this.log(`Setting startPosition to ${s} for start time offset ${n} found in ${r ? "multivariant" : "media"} playlist`), this.startPosition = s) : e.live ? (s = this.hls.liveSyncPosition || t, this.log(`Setting startPosition to -1 to start at live edge ${s}`), this.startPosition = -1) : (this.log("setting startPosition to 0 by default"), this.startPosition = s = 0), this.lastCurrentTime = s + i;
    }
    this.nextLoadPosition = s + i;
  }
  getLoadPosition() {
    var e;
    const {
      media: t
    } = this;
    let s = 0;
    return (e = this.hls) != null && e.hasEnoughToStart && t ? s = t.currentTime : this.nextLoadPosition >= 0 && (s = this.nextLoadPosition), s;
  }
  handleFragLoadAborted(e, t) {
    this.transmuxer && e.type === this.playlistType && ue(e) && e.stats.aborted && (this.warn(`Fragment ${e.sn}${t ? " part " + t.index : ""} of ${this.playlistLabel()} ${e.level} was aborted`), this.resetFragmentLoading(e));
  }
  resetFragmentLoading(e) {
    (!this.fragCurrent || !this.fragContextChanged(e) && this.state !== C.FRAG_LOADING_WAITING_RETRY) && (this.state = C.IDLE);
  }
  onFragmentOrKeyLoadError(e, t) {
    if (t.chunkMeta && !t.frag) {
      const g = this.getCurrentContext(t.chunkMeta);
      g && (t.frag = g.frag);
    }
    const s = t.frag;
    if (!s || s.type !== e || !this.levels)
      return;
    if (this.fragContextChanged(s)) {
      var i;
      this.warn(`Frag load error must match current frag to retry ${s.url} > ${(i = this.fragCurrent) == null ? void 0 : i.url}`);
      return;
    }
    const r = t.details === R.FRAG_GAP;
    r && this.fragmentTracker.fragBuffered(s, !0);
    const n = t.errorAction, {
      action: o,
      flags: c,
      retryCount: l = 0,
      retryConfig: h
    } = n || {}, u = !!n && !!h, d = u && o === ge.RetryRequest, f = u && !n.resolved && c === _e.MoveAllAlternatesMatchingHost;
    if (!d && f && ue(s) && !s.endList)
      this.resetFragmentErrors(e), this.treatAsGap(s), n.resolved = !0;
    else if ((d || f) && l < h.maxNumRetry) {
      this.resetStartWhenNotLoaded(this.levelLastLoaded);
      const g = Ei(h, l);
      this.warn(`Fragment ${s.sn} of ${e} ${s.level} errored with ${t.details}, retrying loading ${l + 1}/${h.maxNumRetry} in ${g}ms`), n.resolved = !0, this.retryDate = self.performance.now() + g, this.state = C.FRAG_LOADING_WAITING_RETRY;
    } else if (h && n)
      if (this.resetFragmentErrors(e), l < h.maxNumRetry)
        !r && o !== ge.RemoveAlternatePermanently && (n.resolved = !0);
      else {
        this.warn(`${t.details} reached or exceeded max retry (${l})`);
        return;
      }
    else o === ge.SendAlternateToPenaltyBox ? this.state = C.WAITING_LEVEL : this.state = C.ERROR;
    this.tickImmediate();
  }
  reduceLengthAndFlushBuffer(e) {
    if (this.state === C.PARSING || this.state === C.PARSED) {
      const t = e.frag, s = e.parent, i = this.getFwdBufferInfo(this.mediaBuffer, s), r = i && i.len > 0.5;
      r && this.reduceMaxBufferLength(i.len, (t == null ? void 0 : t.duration) || 10);
      const n = !r;
      return n && this.warn(`Buffer full error while media.currentTime is not buffered, flush ${s} buffer`), t && (this.fragmentTracker.removeFragment(t), this.nextLoadPosition = t.start), this.resetLoadingState(), n;
    }
    return !1;
  }
  resetFragmentErrors(e) {
    e === G.AUDIO && (this.fragCurrent = null), this.hls.hasEnoughToStart || (this.startFragRequested = !1), this.state !== C.STOPPED && (this.state = C.IDLE);
  }
  afterBufferFlushed(e, t, s) {
    if (!e)
      return;
    const i = q.getBuffered(e);
    this.fragmentTracker.detectEvictedFragments(t, i, s), this.state === C.ENDED && this.resetLoadingState();
  }
  resetLoadingState() {
    this.log("Reset loading state"), this.fragCurrent = null, this.fragPrevious = null, this.state !== C.STOPPED && (this.state = C.IDLE);
  }
  resetStartWhenNotLoaded(e) {
    if (!this.hls.hasEnoughToStart) {
      this.startFragRequested = !1;
      const t = e ? e.details : null;
      t != null && t.live ? (this.log("resetting startPosition for live start"), this.startPosition = -1, this.setStartPosition(t, t.fragmentStart), this.resetLoadingState()) : this.nextLoadPosition = this.startPosition;
    }
  }
  resetWhenMissingContext(e) {
    this.warn(`The loading context changed while buffering fragment ${e.sn} of ${this.playlistLabel()} ${e.level}. This chunk will not be buffered.`), this.removeUnbufferedFrags(), this.resetStartWhenNotLoaded(this.levelLastLoaded), this.resetLoadingState();
  }
  removeUnbufferedFrags(e = 0) {
    this.fragmentTracker.removeFragmentsInRange(e, 1 / 0, this.playlistType, !1, !0);
  }
  updateLevelTiming(e, t, s, i) {
    const r = s.details;
    if (!r) {
      this.warn("level.details undefined");
      return;
    }
    if (!Object.keys(e.elementaryStreams).reduce((c, l) => {
      const h = e.elementaryStreams[l];
      if (h) {
        const u = h.endPTS - h.startPTS;
        if (u <= 0)
          return this.warn(`Could not parse fragment ${e.sn} ${l} duration reliably (${u})`), c || !1;
        const d = i ? 0 : Gn(r, e, h.startPTS, h.endPTS, h.startDTS, h.endDTS);
        return this.hls.trigger(m.LEVEL_PTS_UPDATED, {
          details: r,
          level: s,
          drift: d,
          type: l,
          frag: e,
          start: h.startPTS,
          end: h.endPTS
        }), !0;
      }
      return c;
    }, !1)) {
      var o;
      if (s.fragmentError === 0 && this.treatAsGap(e, s), ((o = this.transmuxer) == null ? void 0 : o.error) === null) {
        const c = new Error(`Found no media in fragment ${e.sn} of ${this.playlistLabel()} ${e.level} resetting transmuxer to fallback to playlist timing`);
        if (this.warn(c.message), this.hls.trigger(m.ERROR, {
          type: K.MEDIA_ERROR,
          details: R.FRAG_PARSING_ERROR,
          fatal: !1,
          error: c,
          frag: e,
          reason: `Found no media in msn ${e.sn} of ${this.playlistLabel()} "${s.url}"`
        }), !this.hls)
          return;
        this.resetTransmuxer();
      }
    }
    this.state = C.PARSED, this.log(`Parsed ${e.type} sn: ${e.sn}${t ? " part: " + t.index : ""} of ${this.fragInfo(e, !1, t)})`), this.hls.trigger(m.FRAG_PARSED, {
      frag: e,
      part: t
    });
  }
  playlistLabel() {
    return this.playlistType === G.MAIN ? "level" : "track";
  }
  fragInfo(e, t = !0, s) {
    var i, r;
    return `${this.playlistLabel()} ${e.level} (${s ? "part" : "frag"}:[${((i = t && !s ? e.startPTS : (s || e).start) != null ? i : NaN).toFixed(3)}-${((r = t && !s ? e.endPTS : (s || e).end) != null ? r : NaN).toFixed(3)}]${s && e.type === "main" ? "INDEPENDENT=" + (s.independent ? "YES" : "NO") : ""}`;
  }
  treatAsGap(e, t) {
    t && t.fragmentError++, e.gap = !0, this.fragmentTracker.removeFragment(e), this.fragmentTracker.fragBuffered(e, !0);
  }
  resetTransmuxer() {
    var e;
    (e = this.transmuxer) == null || e.reset();
  }
  recoverWorkerError(e) {
    e.event === "demuxerWorker" && (this.fragmentTracker.removeAllFragments(), this.transmuxer && (this.transmuxer.destroy(), this.transmuxer = null), this.resetStartWhenNotLoaded(this.levelLastLoaded), this.resetLoadingState());
  }
  set state(e) {
    const t = this._state;
    t !== e && (this._state = e, this.log(`${t}->${e}`));
  }
  get state() {
    return this._state;
  }
}
function Dr(a) {
  return !!a.interstitialsController && a.enableInterstitialPlayback !== !1;
}
class Xn {
  constructor() {
    this.chunks = [], this.dataLength = 0;
  }
  push(e) {
    this.chunks.push(e), this.dataLength += e.length;
  }
  flush() {
    const {
      chunks: e,
      dataLength: t
    } = this;
    let s;
    if (e.length)
      e.length === 1 ? s = e[0] : s = Ol(e, t);
    else return new Uint8Array(0);
    return this.reset(), s;
  }
  reset() {
    this.chunks.length = 0, this.dataLength = 0;
  }
}
function Ol(a, e) {
  const t = new Uint8Array(e);
  let s = 0;
  for (let i = 0; i < a.length; i++) {
    const r = a[i];
    t.set(r, s), s += r.length;
  }
  return t;
}
var ws = { exports: {} }, Cr;
function Fl() {
  return Cr || (Cr = 1, function(a) {
    var e = Object.prototype.hasOwnProperty, t = "~";
    function s() {
    }
    Object.create && (s.prototype = /* @__PURE__ */ Object.create(null), new s().__proto__ || (t = !1));
    function i(c, l, h) {
      this.fn = c, this.context = l, this.once = h || !1;
    }
    function r(c, l, h, u, d) {
      if (typeof h != "function")
        throw new TypeError("The listener must be a function");
      var f = new i(h, u || c, d), g = t ? t + l : l;
      return c._events[g] ? c._events[g].fn ? c._events[g] = [c._events[g], f] : c._events[g].push(f) : (c._events[g] = f, c._eventsCount++), c;
    }
    function n(c, l) {
      --c._eventsCount === 0 ? c._events = new s() : delete c._events[l];
    }
    function o() {
      this._events = new s(), this._eventsCount = 0;
    }
    o.prototype.eventNames = function() {
      var l = [], h, u;
      if (this._eventsCount === 0) return l;
      for (u in h = this._events)
        e.call(h, u) && l.push(t ? u.slice(1) : u);
      return Object.getOwnPropertySymbols ? l.concat(Object.getOwnPropertySymbols(h)) : l;
    }, o.prototype.listeners = function(l) {
      var h = t ? t + l : l, u = this._events[h];
      if (!u) return [];
      if (u.fn) return [u.fn];
      for (var d = 0, f = u.length, g = new Array(f); d < f; d++)
        g[d] = u[d].fn;
      return g;
    }, o.prototype.listenerCount = function(l) {
      var h = t ? t + l : l, u = this._events[h];
      return u ? u.fn ? 1 : u.length : 0;
    }, o.prototype.emit = function(l, h, u, d, f, g) {
      var p = t ? t + l : l;
      if (!this._events[p]) return !1;
      var E = this._events[p], y = arguments.length, S, T;
      if (E.fn) {
        switch (E.once && this.removeListener(l, E.fn, void 0, !0), y) {
          case 1:
            return E.fn.call(E.context), !0;
          case 2:
            return E.fn.call(E.context, h), !0;
          case 3:
            return E.fn.call(E.context, h, u), !0;
          case 4:
            return E.fn.call(E.context, h, u, d), !0;
          case 5:
            return E.fn.call(E.context, h, u, d, f), !0;
          case 6:
            return E.fn.call(E.context, h, u, d, f, g), !0;
        }
        for (T = 1, S = new Array(y - 1); T < y; T++)
          S[T - 1] = arguments[T];
        E.fn.apply(E.context, S);
      } else {
        var v = E.length, x;
        for (T = 0; T < v; T++)
          switch (E[T].once && this.removeListener(l, E[T].fn, void 0, !0), y) {
            case 1:
              E[T].fn.call(E[T].context);
              break;
            case 2:
              E[T].fn.call(E[T].context, h);
              break;
            case 3:
              E[T].fn.call(E[T].context, h, u);
              break;
            case 4:
              E[T].fn.call(E[T].context, h, u, d);
              break;
            default:
              if (!S) for (x = 1, S = new Array(y - 1); x < y; x++)
                S[x - 1] = arguments[x];
              E[T].fn.apply(E[T].context, S);
          }
      }
      return !0;
    }, o.prototype.on = function(l, h, u) {
      return r(this, l, h, u, !1);
    }, o.prototype.once = function(l, h, u) {
      return r(this, l, h, u, !0);
    }, o.prototype.removeListener = function(l, h, u, d) {
      var f = t ? t + l : l;
      if (!this._events[f]) return this;
      if (!h)
        return n(this, f), this;
      var g = this._events[f];
      if (g.fn)
        g.fn === h && (!d || g.once) && (!u || g.context === u) && n(this, f);
      else {
        for (var p = 0, E = [], y = g.length; p < y; p++)
          (g[p].fn !== h || d && !g[p].once || u && g[p].context !== u) && E.push(g[p]);
        E.length ? this._events[f] = E.length === 1 ? E[0] : E : n(this, f);
      }
      return this;
    }, o.prototype.removeAllListeners = function(l) {
      var h;
      return l ? (h = t ? t + l : l, this._events[h] && n(this, h)) : (this._events = new s(), this._eventsCount = 0), this;
    }, o.prototype.off = o.prototype.removeListener, o.prototype.addListener = o.prototype.on, o.prefixed = t, o.EventEmitter = o, a.exports = o;
  }(ws)), ws.exports;
}
var Ml = Fl(), Ai = /* @__PURE__ */ co(Ml);
const Pt = "1.6.2", pt = {};
function Nl() {
  return typeof __HLS_WORKER_BUNDLE__ == "function";
}
function Bl() {
  const a = pt[Pt];
  if (a)
    return a.clientCount++, a;
  const e = new self.Blob([`var exports={};var module={exports:exports};function define(f){f()};define.amd=true;(${__HLS_WORKER_BUNDLE__.toString()})(true);`], {
    type: "text/javascript"
  }), t = self.URL.createObjectURL(e), i = {
    worker: new self.Worker(t),
    objectURL: t,
    clientCount: 1
  };
  return pt[Pt] = i, i;
}
function Ul(a) {
  const e = pt[a];
  if (e)
    return e.clientCount++, e;
  const t = new self.URL(a, self.location.href).href, i = {
    worker: new self.Worker(t),
    scriptURL: t,
    clientCount: 1
  };
  return pt[a] = i, i;
}
function $l(a) {
  const e = pt[a || Pt];
  if (e && e.clientCount-- === 1) {
    const {
      worker: s,
      objectURL: i
    } = e;
    delete pt[a || Pt], i && self.URL.revokeObjectURL(i), s.terminate();
  }
}
function zn(a, e) {
  return e + 10 <= a.length && a[e] === 51 && a[e + 1] === 68 && a[e + 2] === 73 && a[e + 3] < 255 && a[e + 4] < 255 && a[e + 6] < 128 && a[e + 7] < 128 && a[e + 8] < 128 && a[e + 9] < 128;
}
function Li(a, e) {
  return e + 10 <= a.length && a[e] === 73 && a[e + 1] === 68 && a[e + 2] === 51 && a[e + 3] < 255 && a[e + 4] < 255 && a[e + 6] < 128 && a[e + 7] < 128 && a[e + 8] < 128 && a[e + 9] < 128;
}
function Ts(a, e) {
  let t = 0;
  return t = (a[e] & 127) << 21, t |= (a[e + 1] & 127) << 14, t |= (a[e + 2] & 127) << 7, t |= a[e + 3] & 127, t;
}
function kt(a, e) {
  const t = e;
  let s = 0;
  for (; Li(a, e); ) {
    s += 10;
    const i = Ts(a, e + 6);
    s += i, zn(a, e + 10) && (s += 10), e += s;
  }
  if (s > 0)
    return a.subarray(t, t + s);
}
function Gl(a, e, t, s) {
  const i = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350], r = e[t + 2], n = r >> 2 & 15;
  if (n > 12) {
    const f = new Error(`invalid ADTS sampling index:${n}`);
    a.emit(m.ERROR, m.ERROR, {
      type: K.MEDIA_ERROR,
      details: R.FRAG_PARSING_ERROR,
      fatal: !0,
      error: f,
      reason: f.message
    });
    return;
  }
  const o = (r >> 6 & 3) + 1, c = e[t + 3] >> 6 & 3 | (r & 1) << 2, l = "mp4a.40." + o, h = i[n];
  let u = n;
  (o === 5 || o === 29) && (u -= 3);
  const d = [o << 3 | (u & 14) >> 1, (u & 1) << 7 | c << 3];
  return Q.log(`manifest codec:${s}, parsed codec:${l}, channels:${c}, rate:${h} (ADTS object type:${o} sampling index:${n})`), {
    config: d,
    samplerate: h,
    channelCount: c,
    codec: l,
    parsedCodec: l,
    manifestCodec: s
  };
}
function Qn(a, e) {
  return a[e] === 255 && (a[e + 1] & 246) === 240;
}
function Zn(a, e) {
  return a[e + 1] & 1 ? 7 : 9;
}
function Ii(a, e) {
  return (a[e + 3] & 3) << 11 | a[e + 4] << 3 | (a[e + 5] & 224) >>> 5;
}
function Kl(a, e) {
  return e + 5 < a.length;
}
function gs(a, e) {
  return e + 1 < a.length && Qn(a, e);
}
function Vl(a, e) {
  return Kl(a, e) && Qn(a, e) && Ii(a, e) <= a.length - e;
}
function Hl(a, e) {
  if (gs(a, e)) {
    const t = Zn(a, e);
    if (e + t >= a.length)
      return !1;
    const s = Ii(a, e);
    if (s <= t)
      return !1;
    const i = e + s;
    return i === a.length || gs(a, i);
  }
  return !1;
}
function Jn(a, e, t, s, i) {
  if (!a.samplerate) {
    const r = Gl(e, t, s, i);
    if (!r)
      return;
    re(a, r);
  }
}
function ea(a) {
  return 1024 * 9e4 / a;
}
function Wl(a, e) {
  const t = Zn(a, e);
  if (e + t <= a.length) {
    const s = Ii(a, e) - t;
    if (s > 0)
      return {
        headerLength: t,
        frameLength: s
      };
  }
}
function ta(a, e, t, s, i) {
  const r = ea(a.samplerate), n = s + i * r, o = Wl(e, t);
  let c;
  if (o) {
    const {
      frameLength: u,
      headerLength: d
    } = o, f = d + u, g = Math.max(0, t + f - e.length);
    g ? (c = new Uint8Array(f - d), c.set(e.subarray(t + d, e.length), 0)) : c = e.subarray(t + d, t + f);
    const p = {
      unit: c,
      pts: n
    };
    return g || a.samples.push(p), {
      sample: p,
      length: f,
      missing: g
    };
  }
  const l = e.length - t;
  return c = new Uint8Array(l), c.set(e.subarray(t, e.length), 0), {
    sample: {
      unit: c,
      pts: n
    },
    length: l,
    missing: -1
  };
}
function Yl(a, e) {
  return Li(a, e) && Ts(a, e + 6) + 10 <= a.length - e;
}
function ql(a) {
  if (a.size < 2)
    return;
  const e = ve(a.data, !0), t = new Uint8Array(a.data.subarray(e.length + 1));
  return {
    key: a.type,
    info: e,
    data: t.buffer
  };
}
function jl(a) {
  if (a.size < 2)
    return;
  if (a.type === "TXXX") {
    let t = 1;
    const s = ve(a.data.subarray(t), !0);
    t += s.length + 1;
    const i = ve(a.data.subarray(t));
    return {
      key: a.type,
      info: s,
      data: i
    };
  }
  const e = ve(a.data.subarray(1));
  return {
    key: a.type,
    info: "",
    data: e
  };
}
function Xl(a) {
  if (a.type === "WXXX") {
    if (a.size < 2)
      return;
    let t = 1;
    const s = ve(a.data.subarray(t), !0);
    t += s.length + 1;
    const i = ve(a.data.subarray(t));
    return {
      key: a.type,
      info: s,
      data: i
    };
  }
  const e = ve(a.data);
  return {
    key: a.type,
    info: "",
    data: e
  };
}
function zl(a) {
  return btoa(String.fromCharCode(...a));
}
function sa(a, e) {
  if (a < 0)
    return -sa(-a, e);
  const t = Math.pow(10, e);
  if (Math.abs(a * t % 1 - 0.5) < Number.EPSILON) {
    const i = Math.floor(a * t);
    return (i % 2 === 0 ? i : i + 1) / t;
  } else
    return Math.round(a * t) / t;
}
function Ql(a, e) {
  const t = new URL(a), s = new URL(e);
  if (t.origin !== s.origin)
    return a;
  const i = t.pathname.split("/").slice(1), r = s.pathname.split("/").slice(1, -1);
  for (; i[0] === r[0]; )
    i.shift(), r.shift();
  for (; r.length; )
    r.shift(), i.unshift("..");
  return i.join("/");
}
function Zl() {
  try {
    return crypto.randomUUID();
  } catch {
    try {
      const e = URL.createObjectURL(new Blob()), t = e.toString();
      return URL.revokeObjectURL(e), t.slice(t.lastIndexOf("/") + 1);
    } catch {
      let t = (/* @__PURE__ */ new Date()).getTime();
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (i) => {
        const r = (t + Math.random() * 16) % 16 | 0;
        return t = Math.floor(t / 16), (i == "x" ? r : r & 3 | 8).toString(16);
      });
    }
  }
}
function Jl(a) {
  return a instanceof ArrayBuffer ? a : a.byteOffset == 0 && a.byteLength == a.buffer.byteLength ? a.buffer : new Uint8Array(a).buffer;
}
function Os(a, e = 0, t = 1 / 0) {
  return ec(a, e, t, Uint8Array);
}
function ec(a, e, t, s) {
  const i = tc(a);
  let r = 1;
  "BYTES_PER_ELEMENT" in s && (r = s.BYTES_PER_ELEMENT);
  const n = sc(a) ? a.byteOffset : 0, o = (n + a.byteLength) / r, c = (n + e) / r, l = Math.floor(Math.max(0, Math.min(c, o))), h = Math.floor(Math.min(l + Math.max(t, 0), o));
  return new s(i, l, h - l);
}
function tc(a) {
  return a instanceof ArrayBuffer ? a : a.buffer;
}
function sc(a) {
  return a && a.buffer instanceof ArrayBuffer && a.byteLength !== void 0 && a.byteOffset !== void 0;
}
function ic(a) {
  const e = {
    key: a.type,
    description: "",
    data: "",
    mimeType: null,
    pictureType: null
  }, t = 3;
  if (a.size < 2)
    return;
  if (a.data[0] !== t) {
    console.log("Ignore frame with unrecognized character encoding");
    return;
  }
  const s = a.data.subarray(1).indexOf(0);
  if (s === -1)
    return;
  const i = ve(Os(a.data, 1, s)), r = a.data[2 + s], n = a.data.subarray(3 + s).indexOf(0);
  if (n === -1)
    return;
  const o = ve(Os(a.data, 3 + s, n));
  let c;
  return i === "-->" ? c = ve(Os(a.data, 4 + s + n)) : c = Jl(a.data.subarray(4 + s + n)), e.mimeType = i, e.pictureType = r, e.description = o, e.data = c, e;
}
function rc(a) {
  return a.type === "PRIV" ? ql(a) : a.type[0] === "W" ? Xl(a) : a.type === "APIC" ? ic(a) : jl(a);
}
function nc(a) {
  const e = String.fromCharCode(a[0], a[1], a[2], a[3]), t = Ts(a, 4), s = 10;
  return {
    type: e,
    size: t,
    data: a.subarray(s, s + t)
  };
}
const Ht = 10, ac = 10;
function ia(a) {
  let e = 0;
  const t = [];
  for (; Li(a, e); ) {
    const s = Ts(a, e + 6);
    a[e + 5] >> 6 & 1 && (e += Ht), e += Ht;
    const i = e + s;
    for (; e + ac < i; ) {
      const r = nc(a.subarray(e)), n = rc(r);
      n && t.push(n), e += r.size + Ht;
    }
    zn(a, e) && (e += Ht);
  }
  return t;
}
function ra(a) {
  return a && a.key === "PRIV" && a.info === "com.apple.streaming.transportStreamTimestamp";
}
function oc(a) {
  if (a.data.byteLength === 8) {
    const e = new Uint8Array(a.data), t = e[3] & 1;
    let s = (e[4] << 23) + (e[5] << 15) + (e[6] << 7) + e[7];
    return s /= 45, t && (s += 4772185884e-2), Math.round(s);
  }
}
function Ri(a) {
  const e = ia(a);
  for (let t = 0; t < e.length; t++) {
    const s = e[t];
    if (ra(s))
      return oc(s);
  }
}
let Te = /* @__PURE__ */ function(a) {
  return a.audioId3 = "org.id3", a.dateRange = "com.apple.quicktime.HLS", a.emsg = "https://aomedia.org/emsg/ID3", a.misbklv = "urn:misb:KLV:bin:1910.1", a;
}({});
function ke(a = "", e = 9e4) {
  return {
    type: a,
    id: -1,
    pid: -1,
    inputTimeScale: e,
    sequenceNumber: -1,
    samples: [],
    dropped: 0
  };
}
class bi {
  constructor() {
    this._audioTrack = void 0, this._id3Track = void 0, this.frameIndex = 0, this.cachedData = null, this.basePTS = null, this.initPTS = null, this.lastPTS = null;
  }
  resetInitSegment(e, t, s, i) {
    this._id3Track = {
      type: "id3",
      id: 3,
      pid: -1,
      inputTimeScale: 9e4,
      sequenceNumber: 0,
      samples: [],
      dropped: 0
    };
  }
  resetTimeStamp(e) {
    this.initPTS = e, this.resetContiguity();
  }
  resetContiguity() {
    this.basePTS = null, this.lastPTS = null, this.frameIndex = 0;
  }
  canParse(e, t) {
    return !1;
  }
  appendFrame(e, t, s) {
  }
  // feed incoming data to the front of the parsing pipeline
  demux(e, t) {
    this.cachedData && (e = Ie(this.cachedData, e), this.cachedData = null);
    let s = kt(e, 0), i = s ? s.length : 0, r;
    const n = this._audioTrack, o = this._id3Track, c = s ? Ri(s) : void 0, l = e.length;
    for ((this.basePTS === null || this.frameIndex === 0 && M(c)) && (this.basePTS = lc(c, t, this.initPTS), this.lastPTS = this.basePTS), this.lastPTS === null && (this.lastPTS = this.basePTS), s && s.length > 0 && o.samples.push({
      pts: this.lastPTS,
      dts: this.lastPTS,
      data: s,
      type: Te.audioId3,
      duration: Number.POSITIVE_INFINITY
    }); i < l; ) {
      if (this.canParse(e, i)) {
        const h = this.appendFrame(n, e, i);
        h ? (this.frameIndex++, this.lastPTS = h.sample.pts, i += h.length, r = i) : i = l;
      } else Yl(e, i) ? (s = kt(e, i), o.samples.push({
        pts: this.lastPTS,
        dts: this.lastPTS,
        data: s,
        type: Te.audioId3,
        duration: Number.POSITIVE_INFINITY
      }), i += s.length, r = i) : i++;
      if (i === l && r !== l) {
        const h = e.slice(r);
        this.cachedData ? this.cachedData = Ie(this.cachedData, h) : this.cachedData = h;
      }
    }
    return {
      audioTrack: n,
      videoTrack: ke(),
      id3Track: o,
      textTrack: ke()
    };
  }
  demuxSampleAes(e, t, s) {
    return Promise.reject(new Error(`[${this}] This demuxer does not support Sample-AES decryption`));
  }
  flush(e) {
    const t = this.cachedData;
    return t && (this.cachedData = null, this.demux(t, 0)), {
      audioTrack: this._audioTrack,
      videoTrack: ke(),
      id3Track: this._id3Track,
      textTrack: ke()
    };
  }
  destroy() {
    this.cachedData = null, this._audioTrack = this._id3Track = void 0;
  }
}
const lc = (a, e, t) => {
  if (M(a))
    return a * 90;
  const s = t ? t.baseTime * 9e4 / t.timescale : 0;
  return e * 9e4 + s;
};
let Wt = null;
const cc = [32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160], hc = [44100, 48e3, 32e3, 22050, 24e3, 16e3, 11025, 12e3, 8e3], uc = [
  // MPEG 2.5
  [
    0,
    // Reserved
    72,
    // Layer3
    144,
    // Layer2
    12
    // Layer1
  ],
  // Reserved
  [
    0,
    // Reserved
    0,
    // Layer3
    0,
    // Layer2
    0
    // Layer1
  ],
  // MPEG 2
  [
    0,
    // Reserved
    72,
    // Layer3
    144,
    // Layer2
    12
    // Layer1
  ],
  // MPEG 1
  [
    0,
    // Reserved
    144,
    // Layer3
    144,
    // Layer2
    12
    // Layer1
  ]
], dc = [
  0,
  // Reserved
  1,
  // Layer3
  1,
  // Layer2
  4
  // Layer1
];
function na(a, e, t, s, i) {
  if (t + 24 > e.length)
    return;
  const r = aa(e, t);
  if (r && t + r.frameLength <= e.length) {
    const n = r.samplesPerFrame * 9e4 / r.sampleRate, o = s + i * n, c = {
      unit: e.subarray(t, t + r.frameLength),
      pts: o,
      dts: o
    };
    return a.config = [], a.channelCount = r.channelCount, a.samplerate = r.sampleRate, a.samples.push(c), {
      sample: c,
      length: r.frameLength,
      missing: 0
    };
  }
}
function aa(a, e) {
  const t = a[e + 1] >> 3 & 3, s = a[e + 1] >> 1 & 3, i = a[e + 2] >> 4 & 15, r = a[e + 2] >> 2 & 3;
  if (t !== 1 && i !== 0 && i !== 15 && r !== 3) {
    const n = a[e + 2] >> 1 & 1, o = a[e + 3] >> 6, c = t === 3 ? 3 - s : s === 3 ? 3 : 4, l = cc[c * 14 + i - 1] * 1e3, u = hc[(t === 3 ? 0 : t === 2 ? 1 : 2) * 3 + r], d = o === 3 ? 1 : 2, f = uc[t][s], g = dc[s], p = f * 8 * g, E = Math.floor(f * l / u + n) * g;
    if (Wt === null) {
      const T = (navigator.userAgent || "").match(/Chrome\/(\d+)/i);
      Wt = T ? parseInt(T[1]) : 0;
    }
    return !!Wt && Wt <= 87 && s === 2 && l >= 224e3 && o === 0 && (a[e + 3] = a[e + 3] | 128), {
      sampleRate: u,
      channelCount: d,
      frameLength: E,
      samplesPerFrame: p
    };
  }
}
function _i(a, e) {
  return a[e] === 255 && (a[e + 1] & 224) === 224 && (a[e + 1] & 6) !== 0;
}
function oa(a, e) {
  return e + 1 < a.length && _i(a, e);
}
function fc(a, e) {
  return _i(a, e) && 4 <= a.length - e;
}
function la(a, e) {
  if (e + 1 < a.length && _i(a, e)) {
    const s = aa(a, e);
    let i = 4;
    s != null && s.frameLength && (i = s.frameLength);
    const r = e + i;
    return r === a.length || oa(a, r);
  }
  return !1;
}
class gc extends bi {
  constructor(e, t) {
    super(), this.observer = void 0, this.config = void 0, this.observer = e, this.config = t;
  }
  resetInitSegment(e, t, s, i) {
    super.resetInitSegment(e, t, s, i), this._audioTrack = {
      container: "audio/adts",
      type: "audio",
      id: 2,
      pid: -1,
      sequenceNumber: 0,
      segmentCodec: "aac",
      samples: [],
      manifestCodec: t,
      duration: i,
      inputTimeScale: 9e4,
      dropped: 0
    };
  }
  // Source for probe info - https://wiki.multimedia.cx/index.php?title=ADTS
  static probe(e, t) {
    if (!e)
      return !1;
    const s = kt(e, 0);
    let i = (s == null ? void 0 : s.length) || 0;
    if (la(e, i))
      return !1;
    for (let r = e.length; i < r; i++)
      if (Hl(e, i))
        return t.log("ADTS sync word found !"), !0;
    return !1;
  }
  canParse(e, t) {
    return Vl(e, t);
  }
  appendFrame(e, t, s) {
    Jn(e, this.observer, t, s, e.manifestCodec);
    const i = ta(e, t, s, this.basePTS, this.frameIndex);
    if (i && i.missing === 0)
      return i;
  }
}
const ca = (a, e) => {
  let t = 0, s = 5;
  e += s;
  const i = new Uint32Array(1), r = new Uint32Array(1), n = new Uint8Array(1);
  for (; s > 0; ) {
    n[0] = a[e];
    const o = Math.min(s, 8), c = 8 - o;
    r[0] = 4278190080 >>> 24 + c << c, i[0] = (n[0] & r[0]) >> c, t = t ? t << o | i[0] : i[0], e += 1, s -= o;
  }
  return t;
};
class mc extends bi {
  constructor(e) {
    super(), this.observer = void 0, this.observer = e;
  }
  resetInitSegment(e, t, s, i) {
    super.resetInitSegment(e, t, s, i), this._audioTrack = {
      container: "audio/ac-3",
      type: "audio",
      id: 2,
      pid: -1,
      sequenceNumber: 0,
      segmentCodec: "ac3",
      samples: [],
      manifestCodec: t,
      duration: i,
      inputTimeScale: 9e4,
      dropped: 0
    };
  }
  canParse(e, t) {
    return t + 64 < e.length;
  }
  appendFrame(e, t, s) {
    const i = ha(e, t, s, this.basePTS, this.frameIndex);
    if (i !== -1)
      return {
        sample: e.samples[e.samples.length - 1],
        length: i,
        missing: 0
      };
  }
  static probe(e) {
    if (!e)
      return !1;
    const t = kt(e, 0);
    if (!t)
      return !1;
    const s = t.length;
    return e[s] === 11 && e[s + 1] === 119 && Ri(t) !== void 0 && // check the bsid to confirm ac-3
    ca(e, s) < 16;
  }
}
function ha(a, e, t, s, i) {
  if (t + 8 > e.length || e[t] !== 11 || e[t + 1] !== 119)
    return -1;
  const r = e[t + 4] >> 6;
  if (r >= 3)
    return -1;
  const o = [48e3, 44100, 32e3][r], c = e[t + 4] & 63, h = [64, 69, 96, 64, 70, 96, 80, 87, 120, 80, 88, 120, 96, 104, 144, 96, 105, 144, 112, 121, 168, 112, 122, 168, 128, 139, 192, 128, 140, 192, 160, 174, 240, 160, 175, 240, 192, 208, 288, 192, 209, 288, 224, 243, 336, 224, 244, 336, 256, 278, 384, 256, 279, 384, 320, 348, 480, 320, 349, 480, 384, 417, 576, 384, 418, 576, 448, 487, 672, 448, 488, 672, 512, 557, 768, 512, 558, 768, 640, 696, 960, 640, 697, 960, 768, 835, 1152, 768, 836, 1152, 896, 975, 1344, 896, 976, 1344, 1024, 1114, 1536, 1024, 1115, 1536, 1152, 1253, 1728, 1152, 1254, 1728, 1280, 1393, 1920, 1280, 1394, 1920][c * 3 + r] * 2;
  if (t + h > e.length)
    return -1;
  const u = e[t + 6] >> 5;
  let d = 0;
  u === 2 ? d += 2 : (u & 1 && u !== 1 && (d += 2), u & 4 && (d += 2));
  const f = (e[t + 6] << 8 | e[t + 7]) >> 12 - d & 1, p = [2, 1, 2, 3, 3, 4, 4, 5][u] + f, E = e[t + 5] >> 3, y = e[t + 5] & 7, S = new Uint8Array([r << 6 | E << 1 | y >> 2, (y & 3) << 6 | u << 3 | f << 2 | c >> 4, c << 4 & 224]), T = 1536 / o * 9e4, v = s + i * T, x = e.subarray(t, t + h);
  return a.config = S, a.channelCount = p, a.samplerate = o, a.samples.push({
    unit: x,
    pts: v
  }), h;
}
class pc extends bi {
  resetInitSegment(e, t, s, i) {
    super.resetInitSegment(e, t, s, i), this._audioTrack = {
      container: "audio/mpeg",
      type: "audio",
      id: 2,
      pid: -1,
      sequenceNumber: 0,
      segmentCodec: "mp3",
      samples: [],
      manifestCodec: t,
      duration: i,
      inputTimeScale: 9e4,
      dropped: 0
    };
  }
  static probe(e) {
    if (!e)
      return !1;
    const t = kt(e, 0);
    let s = (t == null ? void 0 : t.length) || 0;
    if (t && e[s] === 11 && e[s + 1] === 119 && Ri(t) !== void 0 && // check the bsid to confirm ac-3 or ec-3 (not mp3)
    ca(e, s) <= 16)
      return !1;
    for (let i = e.length; s < i; s++)
      if (la(e, s))
        return Q.log("MPEG Audio sync word found !"), !0;
    return !1;
  }
  canParse(e, t) {
    return fc(e, t);
  }
  appendFrame(e, t, s) {
    if (this.basePTS !== null)
      return na(e, t, s, this.basePTS, this.frameIndex);
  }
}
const Ec = /\/emsg[-/]ID3/i;
class yc {
  constructor(e, t) {
    this.remainderData = null, this.timeOffset = 0, this.config = void 0, this.videoTrack = void 0, this.audioTrack = void 0, this.id3Track = void 0, this.txtTrack = void 0, this.config = t;
  }
  resetTimeStamp() {
  }
  resetInitSegment(e, t, s, i) {
    const r = this.videoTrack = ke("video", 1), n = this.audioTrack = ke("audio", 1), o = this.txtTrack = ke("text", 1);
    if (this.id3Track = ke("id3", 1), this.timeOffset = 0, !(e != null && e.byteLength))
      return;
    const c = An(e);
    if (c.video) {
      const {
        id: l,
        timescale: h,
        codec: u,
        supplemental: d
      } = c.video;
      r.id = l, r.timescale = o.timescale = h, r.codec = u, r.supplemental = d;
    }
    if (c.audio) {
      const {
        id: l,
        timescale: h,
        codec: u
      } = c.audio;
      n.id = l, n.timescale = h, n.codec = u;
    }
    o.id = Sn.text, r.sampleDuration = 0, r.duration = n.duration = i;
  }
  resetContiguity() {
    this.remainderData = null;
  }
  static probe(e) {
    return mo(e);
  }
  demux(e, t) {
    this.timeOffset = t;
    let s = e;
    const i = this.videoTrack, r = this.txtTrack;
    if (this.config.progressive) {
      this.remainderData && (s = Ie(this.remainderData, e));
      const o = Ao(s);
      this.remainderData = o.remainder, i.samples = o.valid || new Uint8Array();
    } else
      i.samples = s;
    const n = this.extractID3Track(i, t);
    return r.samples = Qi(t, i), {
      videoTrack: i,
      audioTrack: this.audioTrack,
      id3Track: n,
      textTrack: this.txtTrack
    };
  }
  flush() {
    const e = this.timeOffset, t = this.videoTrack, s = this.txtTrack;
    t.samples = this.remainderData || new Uint8Array(), this.remainderData = null;
    const i = this.extractID3Track(t, this.timeOffset);
    return s.samples = Qi(e, t), {
      videoTrack: t,
      audioTrack: ke(),
      id3Track: i,
      textTrack: ke()
    };
  }
  extractID3Track(e, t) {
    const s = this.id3Track;
    if (e.samples.length) {
      const i = Y(e.samples, ["emsg"]);
      i && i.forEach((r) => {
        const n = Io(r);
        if (Ec.test(n.schemeIdUri)) {
          const o = Pr(n, t);
          let c = n.eventDuration === 4294967295 ? Number.POSITIVE_INFINITY : n.eventDuration / n.timeScale;
          c <= 1e-3 && (c = Number.POSITIVE_INFINITY);
          const l = n.payload;
          s.samples.push({
            data: l,
            len: l.byteLength,
            dts: o,
            pts: o,
            type: Te.emsg,
            duration: c
          });
        } else if (this.config.enableEmsgKLVMetadata && n.schemeIdUri.startsWith("urn:misb:KLV:bin:1910.1")) {
          const o = Pr(n, t);
          s.samples.push({
            data: n.payload,
            len: n.payload.byteLength,
            dts: o,
            pts: o,
            type: Te.misbklv,
            duration: Number.POSITIVE_INFINITY
          });
        }
      });
    }
    return s;
  }
  demuxSampleAes(e, t, s) {
    return Promise.reject(new Error("The MP4 demuxer does not support SAMPLE-AES decryption"));
  }
  destroy() {
    this.config = null, this.remainderData = null, this.videoTrack = this.audioTrack = this.id3Track = this.txtTrack = void 0;
  }
}
function Pr(a, e) {
  return M(a.presentationTime) ? a.presentationTime / a.timeScale : e + a.presentationTimeDelta / a.timeScale;
}
class Tc {
  constructor(e, t, s) {
    this.keyData = void 0, this.decrypter = void 0, this.keyData = s, this.decrypter = new yi(t, {
      removePKCS7Padding: !1
    });
  }
  decryptBuffer(e) {
    return this.decrypter.decrypt(e, this.keyData.key.buffer, this.keyData.iv.buffer, Qe.cbc);
  }
  // AAC - encrypt all full 16 bytes blocks starting from offset 16
  decryptAacSample(e, t, s) {
    const i = e[t].unit;
    if (i.length <= 16)
      return;
    const r = i.subarray(16, i.length - i.length % 16), n = r.buffer.slice(r.byteOffset, r.byteOffset + r.length);
    this.decryptBuffer(n).then((o) => {
      const c = new Uint8Array(o);
      i.set(c, 16), this.decrypter.isSync() || this.decryptAacSamples(e, t + 1, s);
    });
  }
  decryptAacSamples(e, t, s) {
    for (; ; t++) {
      if (t >= e.length) {
        s();
        return;
      }
      if (!(e[t].unit.length < 32) && (this.decryptAacSample(e, t, s), !this.decrypter.isSync()))
        return;
    }
  }
  // AVC - encrypt one 16 bytes block out of ten, starting from offset 32
  getAvcEncryptedData(e) {
    const t = Math.floor((e.length - 48) / 160) * 16 + 16, s = new Int8Array(t);
    let i = 0;
    for (let r = 32; r < e.length - 16; r += 160, i += 16)
      s.set(e.subarray(r, r + 16), i);
    return s;
  }
  getAvcDecryptedUnit(e, t) {
    const s = new Uint8Array(t);
    let i = 0;
    for (let r = 32; r < e.length - 16; r += 160, i += 16)
      e.set(s.subarray(i, i + 16), r);
    return e;
  }
  decryptAvcSample(e, t, s, i, r) {
    const n = In(r.data), o = this.getAvcEncryptedData(n);
    this.decryptBuffer(o.buffer).then((c) => {
      r.data = this.getAvcDecryptedUnit(n, c), this.decrypter.isSync() || this.decryptAvcSamples(e, t, s + 1, i);
    });
  }
  decryptAvcSamples(e, t, s, i) {
    if (e instanceof Uint8Array)
      throw new Error("Cannot decrypt samples of type Uint8Array");
    for (; ; t++, s = 0) {
      if (t >= e.length) {
        i();
        return;
      }
      const r = e[t].units;
      for (; !(s >= r.length); s++) {
        const n = r[s];
        if (!(n.data.length <= 48 || n.type !== 1 && n.type !== 5) && (this.decryptAvcSample(e, t, s, i, n), !this.decrypter.isSync()))
          return;
      }
    }
  }
}
class ua {
  constructor() {
    this.VideoSample = null;
  }
  createVideoSample(e, t, s) {
    return {
      key: e,
      frame: !1,
      pts: t,
      dts: s,
      units: [],
      length: 0
    };
  }
  getLastNalUnit(e) {
    var t;
    let s = this.VideoSample, i;
    if ((!s || s.units.length === 0) && (s = e[e.length - 1]), (t = s) != null && t.units) {
      const r = s.units;
      i = r[r.length - 1];
    }
    return i;
  }
  pushAccessUnit(e, t) {
    if (e.units.length && e.frame) {
      if (e.pts === void 0) {
        const s = t.samples, i = s.length;
        if (i) {
          const r = s[i - 1];
          e.pts = r.pts, e.dts = r.dts;
        } else {
          t.dropped++;
          return;
        }
      }
      t.samples.push(e);
    }
  }
  parseNALu(e, t, s) {
    const i = t.byteLength;
    let r = e.naluState || 0;
    const n = r, o = [];
    let c = 0, l, h, u, d = -1, f = 0;
    for (r === -1 && (d = 0, f = this.getNALuType(t, 0), r = 0, c = 1); c < i; ) {
      if (l = t[c++], !r) {
        r = l ? 0 : 1;
        continue;
      }
      if (r === 1) {
        r = l ? 0 : 2;
        continue;
      }
      if (!l)
        r = 3;
      else if (l === 1) {
        if (h = c - r - 1, d >= 0) {
          const g = {
            data: t.subarray(d, h),
            type: f
          };
          o.push(g);
        } else {
          const g = this.getLastNalUnit(e.samples);
          g && (n && c <= 4 - n && g.state && (g.data = g.data.subarray(0, g.data.byteLength - n)), h > 0 && (g.data = Ie(g.data, t.subarray(0, h)), g.state = 0));
        }
        c < i ? (u = this.getNALuType(t, c), d = c, f = u, r = 0) : r = -1;
      } else
        r = 0;
    }
    if (d >= 0 && r >= 0) {
      const g = {
        data: t.subarray(d, i),
        type: f,
        state: r
      };
      o.push(g);
    }
    if (o.length === 0) {
      const g = this.getLastNalUnit(e.samples);
      g && (g.data = Ie(g.data, t));
    }
    return e.naluState = r, o;
  }
}
class Lt {
  constructor(e) {
    this.data = void 0, this.bytesAvailable = void 0, this.word = void 0, this.bitsAvailable = void 0, this.data = e, this.bytesAvailable = e.byteLength, this.word = 0, this.bitsAvailable = 0;
  }
  // ():void
  loadWord() {
    const e = this.data, t = this.bytesAvailable, s = e.byteLength - t, i = new Uint8Array(4), r = Math.min(4, t);
    if (r === 0)
      throw new Error("no bytes available");
    i.set(e.subarray(s, s + r)), this.word = new DataView(i.buffer).getUint32(0), this.bitsAvailable = r * 8, this.bytesAvailable -= r;
  }
  // (count:int):void
  skipBits(e) {
    let t;
    e = Math.min(e, this.bytesAvailable * 8 + this.bitsAvailable), this.bitsAvailable > e ? (this.word <<= e, this.bitsAvailable -= e) : (e -= this.bitsAvailable, t = e >> 3, e -= t << 3, this.bytesAvailable -= t, this.loadWord(), this.word <<= e, this.bitsAvailable -= e);
  }
  // (size:int):uint
  readBits(e) {
    let t = Math.min(this.bitsAvailable, e);
    const s = this.word >>> 32 - t;
    if (e > 32 && Q.error("Cannot read more than 32 bits at a time"), this.bitsAvailable -= t, this.bitsAvailable > 0)
      this.word <<= t;
    else if (this.bytesAvailable > 0)
      this.loadWord();
    else
      throw new Error("no bits available");
    return t = e - t, t > 0 && this.bitsAvailable ? s << t | this.readBits(t) : s;
  }
  // ():uint
  skipLZ() {
    let e;
    for (e = 0; e < this.bitsAvailable; ++e)
      if (this.word & 2147483648 >>> e)
        return this.word <<= e, this.bitsAvailable -= e, e;
    return this.loadWord(), e + this.skipLZ();
  }
  // ():void
  skipUEG() {
    this.skipBits(1 + this.skipLZ());
  }
  // ():void
  skipEG() {
    this.skipBits(1 + this.skipLZ());
  }
  // ():uint
  readUEG() {
    const e = this.skipLZ();
    return this.readBits(e + 1) - 1;
  }
  // ():int
  readEG() {
    const e = this.readUEG();
    return 1 & e ? 1 + e >>> 1 : -1 * (e >>> 1);
  }
  // Some convenience functions
  // :Boolean
  readBoolean() {
    return this.readBits(1) === 1;
  }
  // ():int
  readUByte() {
    return this.readBits(8);
  }
  // ():int
  readUShort() {
    return this.readBits(16);
  }
  // ():int
  readUInt() {
    return this.readBits(32);
  }
}
class kr extends ua {
  parsePES(e, t, s, i) {
    const r = this.parseNALu(e, s.data, i);
    let n = this.VideoSample, o, c = !1;
    s.data = null, n && r.length && !e.audFound && (this.pushAccessUnit(n, e), n = this.VideoSample = this.createVideoSample(!1, s.pts, s.dts)), r.forEach((l) => {
      var h, u;
      switch (l.type) {
        case 1: {
          let p = !1;
          o = !0;
          const E = l.data;
          if (c && E.length > 4) {
            const y = this.readSliceType(E);
            (y === 2 || y === 4 || y === 7 || y === 9) && (p = !0);
          }
          if (p) {
            var d;
            (d = n) != null && d.frame && !n.key && (this.pushAccessUnit(n, e), n = this.VideoSample = null);
          }
          n || (n = this.VideoSample = this.createVideoSample(!0, s.pts, s.dts)), n.frame = !0, n.key = p;
          break;
        }
        case 5:
          o = !0, (h = n) != null && h.frame && !n.key && (this.pushAccessUnit(n, e), n = this.VideoSample = null), n || (n = this.VideoSample = this.createVideoSample(!0, s.pts, s.dts)), n.key = !0, n.frame = !0;
          break;
        case 6: {
          o = !0, mi(l.data, 1, s.pts, t.samples);
          break;
        }
        case 7: {
          var f, g;
          o = !0, c = !0;
          const p = l.data, E = this.readSPS(p);
          if (!e.sps || e.width !== E.width || e.height !== E.height || ((f = e.pixelRatio) == null ? void 0 : f[0]) !== E.pixelRatio[0] || ((g = e.pixelRatio) == null ? void 0 : g[1]) !== E.pixelRatio[1]) {
            e.width = E.width, e.height = E.height, e.pixelRatio = E.pixelRatio, e.sps = [p];
            const y = p.subarray(1, 4);
            let S = "avc1.";
            for (let T = 0; T < 3; T++) {
              let v = y[T].toString(16);
              v.length < 2 && (v = "0" + v), S += v;
            }
            e.codec = S;
          }
          break;
        }
        case 8:
          o = !0, e.pps = [l.data];
          break;
        case 9:
          o = !0, e.audFound = !0, (u = n) != null && u.frame && (this.pushAccessUnit(n, e), n = null), n || (n = this.VideoSample = this.createVideoSample(!1, s.pts, s.dts));
          break;
        case 12:
          o = !0;
          break;
        default:
          o = !1;
          break;
      }
      n && o && n.units.push(l);
    }), i && n && (this.pushAccessUnit(n, e), this.VideoSample = null);
  }
  getNALuType(e, t) {
    return e[t] & 31;
  }
  readSliceType(e) {
    const t = new Lt(e);
    return t.readUByte(), t.readUEG(), t.readUEG();
  }
  /**
   * The scaling list is optionally transmitted as part of a sequence parameter
   * set and is not relevant to transmuxing.
   * @param count the number of entries in this scaling list
   * @see Recommendation ITU-T H.264, Section 7.3.2.1.1.1
   */
  skipScalingList(e, t) {
    let s = 8, i = 8, r;
    for (let n = 0; n < e; n++)
      i !== 0 && (r = t.readEG(), i = (s + r + 256) % 256), s = i === 0 ? s : i;
  }
  /**
   * Read a sequence parameter set and return some interesting video
   * properties. A sequence parameter set is the H264 metadata that
   * describes the properties of upcoming video frames.
   * @returns an object with configuration parsed from the
   * sequence parameter set, including the dimensions of the
   * associated video frames.
   */
  readSPS(e) {
    const t = new Lt(e);
    let s = 0, i = 0, r = 0, n = 0, o, c, l;
    const h = t.readUByte.bind(t), u = t.readBits.bind(t), d = t.readUEG.bind(t), f = t.readBoolean.bind(t), g = t.skipBits.bind(t), p = t.skipEG.bind(t), E = t.skipUEG.bind(t), y = this.skipScalingList.bind(this);
    h();
    const S = h();
    if (u(5), g(3), h(), E(), S === 100 || S === 110 || S === 122 || S === 244 || S === 44 || S === 83 || S === 86 || S === 118 || S === 128) {
      const b = d();
      if (b === 3 && g(1), E(), E(), g(1), f())
        for (c = b !== 3 ? 8 : 12, l = 0; l < c; l++)
          f() && (l < 6 ? y(16, t) : y(64, t));
    }
    E();
    const T = d();
    if (T === 0)
      d();
    else if (T === 1)
      for (g(1), p(), p(), o = d(), l = 0; l < o; l++)
        p();
    E(), g(1);
    const v = d(), x = d(), _ = u(1);
    _ === 0 && g(1), g(1), f() && (s = d(), i = d(), r = d(), n = d());
    let A = [1, 1];
    if (f() && f())
      switch (h()) {
        case 1:
          A = [1, 1];
          break;
        case 2:
          A = [12, 11];
          break;
        case 3:
          A = [10, 11];
          break;
        case 4:
          A = [16, 11];
          break;
        case 5:
          A = [40, 33];
          break;
        case 6:
          A = [24, 11];
          break;
        case 7:
          A = [20, 11];
          break;
        case 8:
          A = [32, 11];
          break;
        case 9:
          A = [80, 33];
          break;
        case 10:
          A = [18, 11];
          break;
        case 11:
          A = [15, 11];
          break;
        case 12:
          A = [64, 33];
          break;
        case 13:
          A = [160, 99];
          break;
        case 14:
          A = [4, 3];
          break;
        case 15:
          A = [3, 2];
          break;
        case 16:
          A = [2, 1];
          break;
        case 255: {
          A = [h() << 8 | h(), h() << 8 | h()];
          break;
        }
      }
    return {
      width: Math.ceil((v + 1) * 16 - s * 2 - i * 2),
      height: (2 - _) * (x + 1) * 16 - (_ ? 2 : 4) * (r + n),
      pixelRatio: A
    };
  }
}
class wr extends ua {
  constructor(...e) {
    super(...e), this.initVPS = null;
  }
  parsePES(e, t, s, i) {
    const r = this.parseNALu(e, s.data, i);
    let n = this.VideoSample, o, c = !1;
    s.data = null, n && r.length && !e.audFound && (this.pushAccessUnit(n, e), n = this.VideoSample = this.createVideoSample(!1, s.pts, s.dts)), r.forEach((l) => {
      var h, u;
      switch (l.type) {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
          n || (n = this.VideoSample = this.createVideoSample(!1, s.pts, s.dts)), n.frame = !0, o = !0;
          break;
        case 16:
        case 17:
        case 18:
        case 21:
          if (o = !0, c) {
            var d;
            (d = n) != null && d.frame && !n.key && (this.pushAccessUnit(n, e), n = this.VideoSample = null);
          }
          n || (n = this.VideoSample = this.createVideoSample(!0, s.pts, s.dts)), n.key = !0, n.frame = !0;
          break;
        case 19:
        case 20:
          o = !0, (h = n) != null && h.frame && !n.key && (this.pushAccessUnit(n, e), n = this.VideoSample = null), n || (n = this.VideoSample = this.createVideoSample(!0, s.pts, s.dts)), n.key = !0, n.frame = !0;
          break;
        case 39:
          o = !0, mi(
            l.data,
            2,
            // NALu header size
            s.pts,
            t.samples
          );
          break;
        case 32:
          o = !0, e.vps || (typeof e.params != "object" && (e.params = {}), e.params = re(e.params, this.readVPS(l.data)), this.initVPS = l.data), e.vps = [l.data];
          break;
        case 33:
          if (o = !0, c = !0, e.vps !== void 0 && e.vps[0] !== this.initVPS && e.sps !== void 0 && !this.matchSPS(e.sps[0], l.data) && (this.initVPS = e.vps[0], e.sps = e.pps = void 0), !e.sps) {
            const f = this.readSPS(l.data);
            e.width = f.width, e.height = f.height, e.pixelRatio = f.pixelRatio, e.codec = f.codecString, e.sps = [], typeof e.params != "object" && (e.params = {});
            for (const g in f.params)
              e.params[g] = f.params[g];
          }
          this.pushParameterSet(e.sps, l.data, e.vps), n || (n = this.VideoSample = this.createVideoSample(!0, s.pts, s.dts)), n.key = !0;
          break;
        case 34:
          if (o = !0, typeof e.params == "object") {
            if (!e.pps) {
              e.pps = [];
              const f = this.readPPS(l.data);
              for (const g in f)
                e.params[g] = f[g];
            }
            this.pushParameterSet(e.pps, l.data, e.vps);
          }
          break;
        case 35:
          o = !0, e.audFound = !0, (u = n) != null && u.frame && (this.pushAccessUnit(n, e), n = null), n || (n = this.VideoSample = this.createVideoSample(!1, s.pts, s.dts));
          break;
        default:
          o = !1;
          break;
      }
      n && o && n.units.push(l);
    }), i && n && (this.pushAccessUnit(n, e), this.VideoSample = null);
  }
  pushParameterSet(e, t, s) {
    (s && s[0] === this.initVPS || !s && !e.length) && e.push(t);
  }
  getNALuType(e, t) {
    return (e[t] & 126) >>> 1;
  }
  ebsp2rbsp(e) {
    const t = new Uint8Array(e.byteLength);
    let s = 0;
    for (let i = 0; i < e.byteLength; i++)
      i >= 2 && e[i] === 3 && e[i - 1] === 0 && e[i - 2] === 0 || (t[s] = e[i], s++);
    return new Uint8Array(t.buffer, 0, s);
  }
  pushAccessUnit(e, t) {
    super.pushAccessUnit(e, t), this.initVPS && (this.initVPS = null);
  }
  readVPS(e) {
    const t = new Lt(e);
    t.readUByte(), t.readUByte(), t.readBits(4), t.skipBits(2), t.readBits(6);
    const s = t.readBits(3), i = t.readBoolean();
    return {
      numTemporalLayers: s + 1,
      temporalIdNested: i
    };
  }
  readSPS(e) {
    const t = new Lt(this.ebsp2rbsp(e));
    t.readUByte(), t.readUByte(), t.readBits(4);
    const s = t.readBits(3);
    t.readBoolean();
    const i = t.readBits(2), r = t.readBoolean(), n = t.readBits(5), o = t.readUByte(), c = t.readUByte(), l = t.readUByte(), h = t.readUByte(), u = t.readUByte(), d = t.readUByte(), f = t.readUByte(), g = t.readUByte(), p = t.readUByte(), E = t.readUByte(), y = t.readUByte(), S = [], T = [];
    for (let J = 0; J < s; J++)
      S.push(t.readBoolean()), T.push(t.readBoolean());
    if (s > 0)
      for (let J = s; J < 8; J++)
        t.readBits(2);
    for (let J = 0; J < s; J++)
      S[J] && (t.readUByte(), t.readUByte(), t.readUByte(), t.readUByte(), t.readUByte(), t.readUByte(), t.readUByte(), t.readUByte(), t.readUByte(), t.readUByte(), t.readUByte()), T[J] && t.readUByte();
    t.readUEG();
    const v = t.readUEG();
    v == 3 && t.skipBits(1);
    const x = t.readUEG(), _ = t.readUEG(), A = t.readBoolean();
    let b = 0, D = 0, L = 0, k = 0;
    A && (b += t.readUEG(), D += t.readUEG(), L += t.readUEG(), k += t.readUEG());
    const F = t.readUEG(), j = t.readUEG(), w = t.readUEG(), U = t.readBoolean();
    for (let J = U ? 0 : s; J <= s; J++)
      t.skipUEG(), t.skipUEG(), t.skipUEG();
    if (t.skipUEG(), t.skipUEG(), t.skipUEG(), t.skipUEG(), t.skipUEG(), t.skipUEG(), t.readBoolean() && t.readBoolean())
      for (let de = 0; de < 4; de++)
        for (let xe = 0; xe < (de === 3 ? 2 : 6); xe++)
          if (!t.readBoolean())
            t.readUEG();
          else {
            const Re = Math.min(64, 1 << 4 + (de << 1));
            de > 1 && t.readEG();
            for (let rt = 0; rt < Re; rt++)
              t.readEG();
          }
    t.readBoolean(), t.readBoolean(), t.readBoolean() && (t.readUByte(), t.skipUEG(), t.skipUEG(), t.readBoolean());
    const $ = t.readUEG();
    let P = 0;
    for (let J = 0; J < $; J++) {
      let de = !1;
      if (J !== 0 && (de = t.readBoolean()), de) {
        J === $ && t.readUEG(), t.readBoolean(), t.readUEG();
        let xe = 0;
        for (let Ze = 0; Ze <= P; Ze++) {
          const Re = t.readBoolean();
          let rt = !1;
          Re || (rt = t.readBoolean()), (Re || rt) && xe++;
        }
        P = xe;
      } else {
        const xe = t.readUEG(), Ze = t.readUEG();
        P = xe + Ze;
        for (let Re = 0; Re < xe; Re++)
          t.readUEG(), t.readBoolean();
        for (let Re = 0; Re < Ze; Re++)
          t.readUEG(), t.readBoolean();
      }
    }
    if (t.readBoolean()) {
      const J = t.readUEG();
      for (let de = 0; de < J; de++) {
        for (let xe = 0; xe < w + 4; xe++)
          t.readBits(1);
        t.readBits(1);
      }
    }
    let W = 0, H = 1, X = 1, Z = !0, ee = 1, ne = 0;
    t.readBoolean(), t.readBoolean();
    let me = !1;
    if (t.readBoolean()) {
      if (t.readBoolean()) {
        const Je = t.readUByte(), Mi = [1, 12, 10, 16, 40, 24, 20, 32, 80, 18, 15, 64, 160, 4, 3, 2], Ft = [1, 11, 11, 11, 33, 11, 11, 11, 33, 11, 11, 33, 99, 3, 2, 1];
        Je > 0 && Je < 16 ? (H = Mi[Je - 1], X = Ft[Je - 1]) : Je === 255 && (H = t.readBits(16), X = t.readBits(16));
      }
      if (t.readBoolean() && t.readBoolean(), t.readBoolean() && (t.readBits(3), t.readBoolean(), t.readBoolean() && (t.readUByte(), t.readUByte(), t.readUByte())), t.readBoolean() && (t.readUEG(), t.readUEG()), t.readBoolean(), t.readBoolean(), t.readBoolean(), me = t.readBoolean(), me && (b += t.readUEG(), D += t.readUEG(), L += t.readUEG(), k += t.readUEG()), t.readBoolean() && (ee = t.readBits(32), ne = t.readBits(32), t.readBoolean() && t.readUEG(), t.readBoolean())) {
        const Ft = t.readBoolean(), Ni = t.readBoolean();
        let Tt = !1;
        (Ft || Ni) && (Tt = t.readBoolean(), Tt && (t.readUByte(), t.readBits(5), t.readBoolean(), t.readBits(5)), t.readBits(4), t.readBits(4), Tt && t.readBits(4), t.readBits(5), t.readBits(5), t.readBits(5));
        for (let Bi = 0; Bi <= s; Bi++) {
          Z = t.readBoolean();
          const Va = Z || t.readBoolean();
          let Ui = !1;
          Va ? t.readEG() : Ui = t.readBoolean();
          const $i = Ui ? 1 : t.readUEG() + 1;
          if (Ft)
            for (let St = 0; St < $i; St++)
              t.readUEG(), t.readUEG(), Tt && (t.readUEG(), t.readUEG()), t.skipBits(1);
          if (Ni)
            for (let St = 0; St < $i; St++)
              t.readUEG(), t.readUEG(), Tt && (t.readUEG(), t.readUEG()), t.skipBits(1);
        }
      }
      t.readBoolean() && (t.readBoolean(), t.readBoolean(), t.readBoolean(), W = t.readUEG());
    }
    let He = x, Fi = _;
    if (A || me) {
      let J = 1, de = 1;
      v === 1 ? J = de = 2 : v == 2 && (J = 2), He = x - J * D - J * b, Fi = _ - de * k - de * L;
    }
    const Ga = i ? ["A", "B", "C"][i] : "", Ka = o << 24 | c << 16 | l << 8 | h;
    let vs = 0;
    for (let J = 0; J < 32; J++)
      vs = (vs | (Ka >> J & 1) << 31 - J) >>> 0;
    let xs = vs.toString(16);
    return n === 1 && xs === "2" && (xs = "6"), {
      codecString: `hvc1.${Ga}${n}.${xs}.${r ? "H" : "L"}${y}.B0`,
      params: {
        general_tier_flag: r,
        general_profile_idc: n,
        general_profile_space: i,
        general_profile_compatibility_flags: [o, c, l, h],
        general_constraint_indicator_flags: [u, d, f, g, p, E],
        general_level_idc: y,
        bit_depth: F + 8,
        bit_depth_luma_minus8: F,
        bit_depth_chroma_minus8: j,
        min_spatial_segmentation_idc: W,
        chroma_format_idc: v,
        frame_rate: {
          fixed: Z,
          fps: ne / ee
        }
      },
      width: He,
      height: Fi,
      pixelRatio: [H, X]
    };
  }
  readPPS(e) {
    const t = new Lt(this.ebsp2rbsp(e));
    t.readUByte(), t.readUByte(), t.skipUEG(), t.skipUEG(), t.skipBits(2), t.skipBits(3), t.skipBits(2), t.skipUEG(), t.skipUEG(), t.skipEG(), t.skipBits(2), t.readBoolean() && t.skipUEG(), t.skipEG(), t.skipEG(), t.skipBits(4);
    const i = t.readBoolean(), r = t.readBoolean();
    let n = 1;
    return r && i ? n = 0 : r ? n = 3 : i && (n = 2), {
      parallelismType: n
    };
  }
  matchSPS(e, t) {
    return String.fromCharCode.apply(null, e).substr(3) === String.fromCharCode.apply(null, t).substr(3);
  }
}
const he = 188;
class Xe {
  constructor(e, t, s, i) {
    this.logger = void 0, this.observer = void 0, this.config = void 0, this.typeSupported = void 0, this.sampleAes = null, this.pmtParsed = !1, this.audioCodec = void 0, this.videoCodec = void 0, this._pmtId = -1, this._videoTrack = void 0, this._audioTrack = void 0, this._id3Track = void 0, this._txtTrack = void 0, this.aacOverFlow = null, this.remainderData = null, this.videoParser = void 0, this.observer = e, this.config = t, this.typeSupported = s, this.logger = i, this.videoParser = null;
  }
  static probe(e, t) {
    const s = Xe.syncOffset(e);
    return s > 0 && t.warn(`MPEG2-TS detected but first sync word found @ offset ${s}`), s !== -1;
  }
  static syncOffset(e) {
    const t = e.length;
    let s = Math.min(he * 5, t - he) + 1, i = 0;
    for (; i < s; ) {
      let r = !1, n = -1, o = 0;
      for (let c = i; c < t; c += he)
        if (e[c] === 71 && (t - c === he || e[c + he] === 71)) {
          if (o++, n === -1 && (n = c, n !== 0 && (s = Math.min(n + he * 99, e.length - he) + 1)), r || (r = ii(e, c) === 0), r && o > 1 && (n === 0 && o > 2 || c + he > s))
            return n;
        } else {
          if (o)
            return -1;
          break;
        }
      i++;
    }
    return -1;
  }
  /**
   * Creates a track model internal to demuxer used to drive remuxing input
   */
  static createTrack(e, t) {
    return {
      container: e === "video" || e === "audio" ? "video/mp2t" : void 0,
      type: e,
      id: Sn[e],
      pid: -1,
      inputTimeScale: 9e4,
      sequenceNumber: 0,
      samples: [],
      dropped: 0,
      duration: e === "audio" ? t : void 0
    };
  }
  /**
   * Initializes a new init segment on the demuxer/remuxer interface. Needed for discontinuities/track-switches (or at stream start)
   * Resets all internal track instances of the demuxer.
   */
  resetInitSegment(e, t, s, i) {
    this.pmtParsed = !1, this._pmtId = -1, this._videoTrack = Xe.createTrack("video"), this._videoTrack.duration = i, this._audioTrack = Xe.createTrack("audio", i), this._id3Track = Xe.createTrack("id3"), this._txtTrack = Xe.createTrack("text"), this._audioTrack.segmentCodec = "aac", this.aacOverFlow = null, this.remainderData = null, this.audioCodec = t, this.videoCodec = s;
  }
  resetTimeStamp() {
  }
  resetContiguity() {
    const {
      _audioTrack: e,
      _videoTrack: t,
      _id3Track: s
    } = this;
    e && (e.pesData = null), t && (t.pesData = null), s && (s.pesData = null), this.aacOverFlow = null, this.remainderData = null;
  }
  demux(e, t, s = !1, i = !1) {
    s || (this.sampleAes = null);
    let r;
    const n = this._videoTrack, o = this._audioTrack, c = this._id3Track, l = this._txtTrack;
    let h = n.pid, u = n.pesData, d = o.pid, f = c.pid, g = o.pesData, p = c.pesData, E = null, y = this.pmtParsed, S = this._pmtId, T = e.length;
    if (this.remainderData && (e = Ie(this.remainderData, e), T = e.length, this.remainderData = null), T < he && !i)
      return this.remainderData = e, {
        audioTrack: o,
        videoTrack: n,
        id3Track: c,
        textTrack: l
      };
    const v = Math.max(0, Xe.syncOffset(e));
    T -= (T - v) % he, T < e.byteLength && !i && (this.remainderData = new Uint8Array(e.buffer, T, e.buffer.byteLength - T));
    let x = 0;
    for (let A = v; A < T; A += he)
      if (e[A] === 71) {
        const b = !!(e[A + 1] & 64), D = ii(e, A), L = (e[A + 3] & 48) >> 4;
        let k;
        if (L > 1) {
          if (k = A + 5 + e[A + 4], k === A + he)
            continue;
        } else
          k = A + 4;
        switch (D) {
          case h:
            if (b) {
              if (u && (r = lt(u, this.logger))) {
                if (this.videoParser === null)
                  switch (n.segmentCodec) {
                    case "avc":
                      this.videoParser = new kr();
                      break;
                    case "hevc":
                      this.videoParser = new wr();
                      break;
                  }
                this.videoParser !== null && this.videoParser.parsePES(n, l, r, !1);
              }
              u = {
                data: [],
                size: 0
              };
            }
            u && (u.data.push(e.subarray(k, A + he)), u.size += A + he - k);
            break;
          case d:
            if (b) {
              if (g && (r = lt(g, this.logger)))
                switch (o.segmentCodec) {
                  case "aac":
                    this.parseAACPES(o, r);
                    break;
                  case "mp3":
                    this.parseMPEGPES(o, r);
                    break;
                  case "ac3":
                    this.parseAC3PES(o, r);
                    break;
                }
              g = {
                data: [],
                size: 0
              };
            }
            g && (g.data.push(e.subarray(k, A + he)), g.size += A + he - k);
            break;
          case f:
            b && (p && (r = lt(p, this.logger)) && this.parseID3PES(c, r), p = {
              data: [],
              size: 0
            }), p && (p.data.push(e.subarray(k, A + he)), p.size += A + he - k);
            break;
          case 0:
            b && (k += e[k] + 1), S = this._pmtId = Sc(e, k);
            break;
          case S: {
            b && (k += e[k] + 1);
            const F = vc(e, k, this.typeSupported, s, this.observer, this.logger);
            h = F.videoPid, h > 0 && (n.pid = h, n.segmentCodec = F.segmentVideoCodec), d = F.audioPid, d > 0 && (o.pid = d, o.segmentCodec = F.segmentAudioCodec), f = F.id3Pid, f > 0 && (c.pid = f), E !== null && !y && (this.logger.warn(`MPEG-TS PMT found at ${A} after unknown PID '${E}'. Backtracking to sync byte @${v} to parse all TS packets.`), E = null, A = v - 188), y = this.pmtParsed = !0;
            break;
          }
          case 17:
          case 8191:
            break;
          default:
            E = D;
            break;
        }
      } else
        x++;
    x > 0 && ri(this.observer, new Error(`Found ${x} TS packet/s that do not start with 0x47`), void 0, this.logger), n.pesData = u, o.pesData = g, c.pesData = p;
    const _ = {
      audioTrack: o,
      videoTrack: n,
      id3Track: c,
      textTrack: l
    };
    return i && this.extractRemainingSamples(_), _;
  }
  flush() {
    const {
      remainderData: e
    } = this;
    this.remainderData = null;
    let t;
    return e ? t = this.demux(e, -1, !1, !0) : t = {
      videoTrack: this._videoTrack,
      audioTrack: this._audioTrack,
      id3Track: this._id3Track,
      textTrack: this._txtTrack
    }, this.extractRemainingSamples(t), this.sampleAes ? this.decrypt(t, this.sampleAes) : t;
  }
  extractRemainingSamples(e) {
    const {
      audioTrack: t,
      videoTrack: s,
      id3Track: i,
      textTrack: r
    } = e, n = s.pesData, o = t.pesData, c = i.pesData;
    let l;
    if (n && (l = lt(n, this.logger))) {
      if (this.videoParser === null)
        switch (s.segmentCodec) {
          case "avc":
            this.videoParser = new kr();
            break;
          case "hevc":
            this.videoParser = new wr();
            break;
        }
      this.videoParser !== null && (this.videoParser.parsePES(s, r, l, !0), s.pesData = null);
    } else
      s.pesData = n;
    if (o && (l = lt(o, this.logger))) {
      switch (t.segmentCodec) {
        case "aac":
          this.parseAACPES(t, l);
          break;
        case "mp3":
          this.parseMPEGPES(t, l);
          break;
        case "ac3":
          this.parseAC3PES(t, l);
          break;
      }
      t.pesData = null;
    } else
      o != null && o.size && this.logger.log("last AAC PES packet truncated,might overlap between fragments"), t.pesData = o;
    c && (l = lt(c, this.logger)) ? (this.parseID3PES(i, l), i.pesData = null) : i.pesData = c;
  }
  demuxSampleAes(e, t, s) {
    const i = this.demux(e, s, !0, !this.config.progressive), r = this.sampleAes = new Tc(this.observer, this.config, t);
    return this.decrypt(i, r);
  }
  decrypt(e, t) {
    return new Promise((s) => {
      const {
        audioTrack: i,
        videoTrack: r
      } = e;
      i.samples && i.segmentCodec === "aac" ? t.decryptAacSamples(i.samples, 0, () => {
        r.samples ? t.decryptAvcSamples(r.samples, 0, 0, () => {
          s(e);
        }) : s(e);
      }) : r.samples && t.decryptAvcSamples(r.samples, 0, 0, () => {
        s(e);
      });
    });
  }
  destroy() {
    this.observer && this.observer.removeAllListeners(), this.config = this.logger = this.observer = null, this.aacOverFlow = this.videoParser = this.remainderData = this.sampleAes = null, this._videoTrack = this._audioTrack = this._id3Track = this._txtTrack = void 0;
  }
  parseAACPES(e, t) {
    let s = 0;
    const i = this.aacOverFlow;
    let r = t.data;
    if (i) {
      this.aacOverFlow = null;
      const u = i.missing, d = i.sample.unit.byteLength;
      if (u === -1)
        r = Ie(i.sample.unit, r);
      else {
        const f = d - u;
        i.sample.unit.set(r.subarray(0, u), f), e.samples.push(i.sample), s = i.missing;
      }
    }
    let n, o;
    for (n = s, o = r.length; n < o - 1 && !gs(r, n); n++)
      ;
    if (n !== s) {
      let u;
      const d = n < o - 1;
      if (d ? u = `AAC PES did not start with ADTS header,offset:${n}` : u = "No ADTS header found in AAC PES", ri(this.observer, new Error(u), d, this.logger), !d)
        return;
    }
    Jn(e, this.observer, r, n, this.audioCodec);
    let c;
    if (t.pts !== void 0)
      c = t.pts;
    else if (i) {
      const u = ea(e.samplerate);
      c = i.sample.pts + u;
    } else {
      this.logger.warn("[tsdemuxer]: AAC PES unknown PTS");
      return;
    }
    let l = 0, h;
    for (; n < o; )
      if (h = ta(e, r, n, c, l), n += h.length, h.missing) {
        this.aacOverFlow = h;
        break;
      } else
        for (l++; n < o - 1 && !gs(r, n); n++)
          ;
  }
  parseMPEGPES(e, t) {
    const s = t.data, i = s.length;
    let r = 0, n = 0;
    const o = t.pts;
    if (o === void 0) {
      this.logger.warn("[tsdemuxer]: MPEG PES unknown PTS");
      return;
    }
    for (; n < i; )
      if (oa(s, n)) {
        const c = na(e, s, n, o, r);
        if (c)
          n += c.length, r++;
        else
          break;
      } else
        n++;
  }
  parseAC3PES(e, t) {
    {
      const s = t.data, i = t.pts;
      if (i === void 0) {
        this.logger.warn("[tsdemuxer]: AC3 PES unknown PTS");
        return;
      }
      const r = s.length;
      let n = 0, o = 0, c;
      for (; o < r && (c = ha(e, s, o, i, n++)) > 0; )
        o += c;
    }
  }
  parseID3PES(e, t) {
    if (t.pts === void 0) {
      this.logger.warn("[tsdemuxer]: ID3 PES unknown PTS");
      return;
    }
    const s = re({}, t, {
      type: this._videoTrack ? Te.emsg : Te.audioId3,
      duration: Number.POSITIVE_INFINITY
    });
    e.samples.push(s);
  }
}
function ii(a, e) {
  return ((a[e + 1] & 31) << 8) + a[e + 2];
}
function Sc(a, e) {
  return (a[e + 10] & 31) << 8 | a[e + 11];
}
function vc(a, e, t, s, i, r) {
  const n = {
    audioPid: -1,
    videoPid: -1,
    id3Pid: -1,
    segmentVideoCodec: "avc",
    segmentAudioCodec: "aac"
  }, o = (a[e + 1] & 15) << 8 | a[e + 2], c = e + 3 + o - 4, l = (a[e + 10] & 15) << 8 | a[e + 11];
  for (e += 12 + l; e < c; ) {
    const h = ii(a, e), u = (a[e + 3] & 15) << 8 | a[e + 4];
    switch (a[e]) {
      case 207:
        if (!s) {
          Fs("ADTS AAC", r);
          break;
        }
      case 15:
        n.audioPid === -1 && (n.audioPid = h);
        break;
      case 21:
        n.id3Pid === -1 && (n.id3Pid = h);
        break;
      case 219:
        if (!s) {
          Fs("H.264", r);
          break;
        }
      case 27:
        n.videoPid === -1 && (n.videoPid = h);
        break;
      case 3:
      case 4:
        !t.mpeg && !t.mp3 ? r.log("MPEG audio found, not supported in this browser") : n.audioPid === -1 && (n.audioPid = h, n.segmentAudioCodec = "mp3");
        break;
      case 193:
        if (!s) {
          Fs("AC-3", r);
          break;
        }
      case 129:
        t.ac3 ? n.audioPid === -1 && (n.audioPid = h, n.segmentAudioCodec = "ac3") : r.log("AC-3 audio found, not supported in this browser");
        break;
      case 6:
        if (n.audioPid === -1 && u > 0) {
          let d = e + 5, f = u;
          for (; f > 2; ) {
            switch (a[d]) {
              case 106:
                t.ac3 !== !0 ? r.log("AC-3 audio found, not supported in this browser for now") : (n.audioPid = h, n.segmentAudioCodec = "ac3");
                break;
            }
            const p = a[d + 1] + 2;
            d += p, f -= p;
          }
        }
        break;
      case 194:
      case 135:
        return ri(i, new Error("Unsupported EC-3 in M2TS found"), void 0, r), n;
      case 36:
        n.videoPid === -1 && (n.videoPid = h, n.segmentVideoCodec = "hevc", r.log("HEVC in M2TS found"));
        break;
    }
    e += u + 5;
  }
  return n;
}
function ri(a, e, t, s) {
  s.warn(`parsing error: ${e.message}`), a.emit(m.ERROR, m.ERROR, {
    type: K.MEDIA_ERROR,
    details: R.FRAG_PARSING_ERROR,
    fatal: !1,
    levelRetry: t,
    error: e,
    reason: e.message
  });
}
function Fs(a, e) {
  e.log(`${a} with AES-128-CBC encryption found in unencrypted stream`);
}
function lt(a, e) {
  let t = 0, s, i, r, n, o;
  const c = a.data;
  if (!a || a.size === 0)
    return null;
  for (; c[0].length < 19 && c.length > 1; )
    c[0] = Ie(c[0], c[1]), c.splice(1, 1);
  if (s = c[0], (s[0] << 16) + (s[1] << 8) + s[2] === 1) {
    if (i = (s[4] << 8) + s[5], i && i > a.size - 6)
      return null;
    const h = s[7];
    h & 192 && (n = (s[9] & 14) * 536870912 + // 1 << 29
    (s[10] & 255) * 4194304 + // 1 << 22
    (s[11] & 254) * 16384 + // 1 << 14
    (s[12] & 255) * 128 + // 1 << 7
    (s[13] & 254) / 2, h & 64 ? (o = (s[14] & 14) * 536870912 + // 1 << 29
    (s[15] & 255) * 4194304 + // 1 << 22
    (s[16] & 254) * 16384 + // 1 << 14
    (s[17] & 255) * 128 + // 1 << 7
    (s[18] & 254) / 2, n - o > 60 * 9e4 && (e.warn(`${Math.round((n - o) / 9e4)}s delta between PTS and DTS, align them`), n = o)) : o = n), r = s[8];
    let u = r + 9;
    if (a.size <= u)
      return null;
    a.size -= u;
    const d = new Uint8Array(a.size);
    for (let f = 0, g = c.length; f < g; f++) {
      s = c[f];
      let p = s.byteLength;
      if (u)
        if (u > p) {
          u -= p;
          continue;
        } else
          s = s.subarray(u), p -= u, u = 0;
      d.set(s, t), t += p;
    }
    return i && (i -= r + 3), {
      data: d,
      pts: n,
      dts: o,
      len: i
    };
  }
  return null;
}
class xc {
  static getSilentFrame(e, t) {
    switch (e) {
      case "mp4a.40.2":
        if (t === 1)
          return new Uint8Array([0, 200, 0, 128, 35, 128]);
        if (t === 2)
          return new Uint8Array([33, 0, 73, 144, 2, 25, 0, 35, 128]);
        if (t === 3)
          return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 142]);
        if (t === 4)
          return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 128, 44, 128, 8, 2, 56]);
        if (t === 5)
          return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 56]);
        if (t === 6)
          return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 0, 178, 0, 32, 8, 224]);
        break;
      default:
        if (t === 1)
          return new Uint8Array([1, 64, 34, 128, 163, 78, 230, 128, 186, 8, 0, 0, 0, 28, 6, 241, 193, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
        if (t === 2)
          return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
        if (t === 3)
          return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
        break;
    }
  }
}
const We = Math.pow(2, 32) - 1;
class I {
  static init() {
    I.types = {
      avc1: [],
      // codingname
      avcC: [],
      hvc1: [],
      hvcC: [],
      btrt: [],
      dinf: [],
      dref: [],
      esds: [],
      ftyp: [],
      hdlr: [],
      mdat: [],
      mdhd: [],
      mdia: [],
      mfhd: [],
      minf: [],
      moof: [],
      moov: [],
      mp4a: [],
      ".mp3": [],
      dac3: [],
      "ac-3": [],
      mvex: [],
      mvhd: [],
      pasp: [],
      sdtp: [],
      stbl: [],
      stco: [],
      stsc: [],
      stsd: [],
      stsz: [],
      stts: [],
      tfdt: [],
      tfhd: [],
      traf: [],
      trak: [],
      trun: [],
      trex: [],
      tkhd: [],
      vmhd: [],
      smhd: []
    };
    let e;
    for (e in I.types)
      I.types.hasOwnProperty(e) && (I.types[e] = [e.charCodeAt(0), e.charCodeAt(1), e.charCodeAt(2), e.charCodeAt(3)]);
    const t = new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      // pre_defined
      118,
      105,
      100,
      101,
      // handler_type: 'vide'
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      86,
      105,
      100,
      101,
      111,
      72,
      97,
      110,
      100,
      108,
      101,
      114,
      0
      // name: 'VideoHandler'
    ]), s = new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      // pre_defined
      115,
      111,
      117,
      110,
      // handler_type: 'soun'
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      83,
      111,
      117,
      110,
      100,
      72,
      97,
      110,
      100,
      108,
      101,
      114,
      0
      // name: 'SoundHandler'
    ]);
    I.HDLR_TYPES = {
      video: t,
      audio: s
    };
    const i = new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      1,
      // entry_count
      0,
      0,
      0,
      12,
      // entry_size
      117,
      114,
      108,
      32,
      // 'url' type
      0,
      // version 0
      0,
      0,
      1
      // entry_flags
    ]), r = new Uint8Array([
      0,
      // version
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0
      // entry_count
    ]);
    I.STTS = I.STSC = I.STCO = r, I.STSZ = new Uint8Array([
      0,
      // version
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      // sample_size
      0,
      0,
      0,
      0
      // sample_count
    ]), I.VMHD = new Uint8Array([
      0,
      // version
      0,
      0,
      1,
      // flags
      0,
      0,
      // graphicsmode
      0,
      0,
      0,
      0,
      0,
      0
      // opcolor
    ]), I.SMHD = new Uint8Array([
      0,
      // version
      0,
      0,
      0,
      // flags
      0,
      0,
      // balance
      0,
      0
      // reserved
    ]), I.STSD = new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      1
    ]);
    const n = new Uint8Array([105, 115, 111, 109]), o = new Uint8Array([97, 118, 99, 49]), c = new Uint8Array([0, 0, 0, 1]);
    I.FTYP = I.box(I.types.ftyp, n, c, n, o), I.DINF = I.box(I.types.dinf, I.box(I.types.dref, i));
  }
  static box(e, ...t) {
    let s = 8, i = t.length;
    const r = i;
    for (; i--; )
      s += t[i].byteLength;
    const n = new Uint8Array(s);
    for (n[0] = s >> 24 & 255, n[1] = s >> 16 & 255, n[2] = s >> 8 & 255, n[3] = s & 255, n.set(e, 4), i = 0, s = 8; i < r; i++)
      n.set(t[i], s), s += t[i].byteLength;
    return n;
  }
  static hdlr(e) {
    return I.box(I.types.hdlr, I.HDLR_TYPES[e]);
  }
  static mdat(e) {
    return I.box(I.types.mdat, e);
  }
  static mdhd(e, t) {
    t *= e;
    const s = Math.floor(t / (We + 1)), i = Math.floor(t % (We + 1));
    return I.box(I.types.mdhd, new Uint8Array([
      1,
      // version 1
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      // creation_time
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      // modification_time
      e >> 24 & 255,
      e >> 16 & 255,
      e >> 8 & 255,
      e & 255,
      // timescale
      s >> 24,
      s >> 16 & 255,
      s >> 8 & 255,
      s & 255,
      i >> 24,
      i >> 16 & 255,
      i >> 8 & 255,
      i & 255,
      85,
      196,
      // 'und' language (undetermined)
      0,
      0
    ]));
  }
  static mdia(e) {
    return I.box(I.types.mdia, I.mdhd(e.timescale || 0, e.duration || 0), I.hdlr(e.type), I.minf(e));
  }
  static mfhd(e) {
    return I.box(I.types.mfhd, new Uint8Array([
      0,
      0,
      0,
      0,
      // flags
      e >> 24,
      e >> 16 & 255,
      e >> 8 & 255,
      e & 255
      // sequence_number
    ]));
  }
  static minf(e) {
    return e.type === "audio" ? I.box(I.types.minf, I.box(I.types.smhd, I.SMHD), I.DINF, I.stbl(e)) : I.box(I.types.minf, I.box(I.types.vmhd, I.VMHD), I.DINF, I.stbl(e));
  }
  static moof(e, t, s) {
    return I.box(I.types.moof, I.mfhd(e), I.traf(s, t));
  }
  static moov(e) {
    let t = e.length;
    const s = [];
    for (; t--; )
      s[t] = I.trak(e[t]);
    return I.box.apply(null, [I.types.moov, I.mvhd(e[0].timescale || 0, e[0].duration || 0)].concat(s).concat(I.mvex(e)));
  }
  static mvex(e) {
    let t = e.length;
    const s = [];
    for (; t--; )
      s[t] = I.trex(e[t]);
    return I.box.apply(null, [I.types.mvex, ...s]);
  }
  static mvhd(e, t) {
    t *= e;
    const s = Math.floor(t / (We + 1)), i = Math.floor(t % (We + 1)), r = new Uint8Array([
      1,
      // version 1
      0,
      0,
      0,
      // flags
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      // creation_time
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      // modification_time
      e >> 24 & 255,
      e >> 16 & 255,
      e >> 8 & 255,
      e & 255,
      // timescale
      s >> 24,
      s >> 16 & 255,
      s >> 8 & 255,
      s & 255,
      i >> 24,
      i >> 16 & 255,
      i >> 8 & 255,
      i & 255,
      0,
      1,
      0,
      0,
      // 1.0 rate
      1,
      0,
      // 1.0 volume
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      0,
      // reserved
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      64,
      0,
      0,
      0,
      // transformation: unity matrix
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // pre_defined
      255,
      255,
      255,
      255
      // next_track_ID
    ]);
    return I.box(I.types.mvhd, r);
  }
  static sdtp(e) {
    const t = e.samples || [], s = new Uint8Array(4 + t.length);
    let i, r;
    for (i = 0; i < t.length; i++)
      r = t[i].flags, s[i + 4] = r.dependsOn << 4 | r.isDependedOn << 2 | r.hasRedundancy;
    return I.box(I.types.sdtp, s);
  }
  static stbl(e) {
    return I.box(I.types.stbl, I.stsd(e), I.box(I.types.stts, I.STTS), I.box(I.types.stsc, I.STSC), I.box(I.types.stsz, I.STSZ), I.box(I.types.stco, I.STCO));
  }
  static avc1(e) {
    let t = [], s = [], i, r, n;
    for (i = 0; i < e.sps.length; i++)
      r = e.sps[i], n = r.byteLength, t.push(n >>> 8 & 255), t.push(n & 255), t = t.concat(Array.prototype.slice.call(r));
    for (i = 0; i < e.pps.length; i++)
      r = e.pps[i], n = r.byteLength, s.push(n >>> 8 & 255), s.push(n & 255), s = s.concat(Array.prototype.slice.call(r));
    const o = I.box(I.types.avcC, new Uint8Array([
      1,
      // version
      t[3],
      // profile
      t[4],
      // profile compat
      t[5],
      // level
      255,
      // lengthSizeMinusOne, hard-coded to 4 bytes
      224 | e.sps.length
      // 3bit reserved (111) + numOfSequenceParameterSets
    ].concat(t).concat([
      e.pps.length
      // numOfPictureParameterSets
    ]).concat(s))), c = e.width, l = e.height, h = e.pixelRatio[0], u = e.pixelRatio[1];
    return I.box(
      I.types.avc1,
      new Uint8Array([
        0,
        0,
        0,
        // reserved
        0,
        0,
        0,
        // reserved
        0,
        1,
        // data_reference_index
        0,
        0,
        // pre_defined
        0,
        0,
        // reserved
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        // pre_defined
        c >> 8 & 255,
        c & 255,
        // width
        l >> 8 & 255,
        l & 255,
        // height
        0,
        72,
        0,
        0,
        // horizresolution
        0,
        72,
        0,
        0,
        // vertresolution
        0,
        0,
        0,
        0,
        // reserved
        0,
        1,
        // frame_count
        18,
        100,
        97,
        105,
        108,
        // dailymotion/hls.js
        121,
        109,
        111,
        116,
        105,
        111,
        110,
        47,
        104,
        108,
        115,
        46,
        106,
        115,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        // compressorname
        0,
        24,
        // depth = 24
        17,
        17
      ]),
      // pre_defined = -1
      o,
      I.box(I.types.btrt, new Uint8Array([
        0,
        28,
        156,
        128,
        // bufferSizeDB
        0,
        45,
        198,
        192,
        // maxBitrate
        0,
        45,
        198,
        192
      ])),
      // avgBitrate
      I.box(I.types.pasp, new Uint8Array([
        h >> 24,
        // hSpacing
        h >> 16 & 255,
        h >> 8 & 255,
        h & 255,
        u >> 24,
        // vSpacing
        u >> 16 & 255,
        u >> 8 & 255,
        u & 255
      ]))
    );
  }
  static esds(e) {
    const t = e.config;
    return new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      3,
      // descriptor_type
      25,
      // length
      0,
      1,
      // es_id
      0,
      // stream_priority
      4,
      // descriptor_type
      17,
      // length
      64,
      // codec : mpeg4_audio
      21,
      // stream_type
      0,
      0,
      0,
      // buffer_size
      0,
      0,
      0,
      0,
      // maxBitrate
      0,
      0,
      0,
      0,
      // avgBitrate
      5,
      // descriptor_type
      2,
      // length
      ...t,
      6,
      1,
      2
      // GASpecificConfig)); // length + audio config descriptor
    ]);
  }
  static audioStsd(e) {
    const t = e.samplerate || 0;
    return new Uint8Array([
      0,
      0,
      0,
      // reserved
      0,
      0,
      0,
      // reserved
      0,
      1,
      // data_reference_index
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // reserved
      0,
      e.channelCount || 0,
      // channelcount
      0,
      16,
      // sampleSize:16bits
      0,
      0,
      0,
      0,
      // reserved2
      t >> 8 & 255,
      t & 255,
      //
      0,
      0
    ]);
  }
  static mp4a(e) {
    return I.box(I.types.mp4a, I.audioStsd(e), I.box(I.types.esds, I.esds(e)));
  }
  static mp3(e) {
    return I.box(I.types[".mp3"], I.audioStsd(e));
  }
  static ac3(e) {
    return I.box(I.types["ac-3"], I.audioStsd(e), I.box(I.types.dac3, e.config));
  }
  static stsd(e) {
    const {
      segmentCodec: t
    } = e;
    if (e.type === "audio") {
      if (t === "aac")
        return I.box(I.types.stsd, I.STSD, I.mp4a(e));
      if (t === "ac3" && e.config)
        return I.box(I.types.stsd, I.STSD, I.ac3(e));
      if (t === "mp3" && e.codec === "mp3")
        return I.box(I.types.stsd, I.STSD, I.mp3(e));
    } else if (e.pps && e.sps) {
      if (t === "avc")
        return I.box(I.types.stsd, I.STSD, I.avc1(e));
      if (t === "hevc" && e.vps)
        return I.box(I.types.stsd, I.STSD, I.hvc1(e));
    } else
      throw new Error("video track missing pps or sps");
    throw new Error(`unsupported ${e.type} segment codec (${t}/${e.codec})`);
  }
  static tkhd(e) {
    const t = e.id, s = (e.duration || 0) * (e.timescale || 0), i = e.width || 0, r = e.height || 0, n = Math.floor(s / (We + 1)), o = Math.floor(s % (We + 1));
    return I.box(I.types.tkhd, new Uint8Array([
      1,
      // version 1
      0,
      0,
      7,
      // flags
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      2,
      // creation_time
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      3,
      // modification_time
      t >> 24 & 255,
      t >> 16 & 255,
      t >> 8 & 255,
      t & 255,
      // track_ID
      0,
      0,
      0,
      0,
      // reserved
      n >> 24,
      n >> 16 & 255,
      n >> 8 & 255,
      n & 255,
      o >> 24,
      o >> 16 & 255,
      o >> 8 & 255,
      o & 255,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // reserved
      0,
      0,
      // layer
      0,
      0,
      // alternate_group
      0,
      0,
      // non-audio track volume
      0,
      0,
      // reserved
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      64,
      0,
      0,
      0,
      // transformation: unity matrix
      i >> 8 & 255,
      i & 255,
      0,
      0,
      // width
      r >> 8 & 255,
      r & 255,
      0,
      0
      // height
    ]));
  }
  static traf(e, t) {
    const s = I.sdtp(e), i = e.id, r = Math.floor(t / (We + 1)), n = Math.floor(t % (We + 1));
    return I.box(
      I.types.traf,
      I.box(I.types.tfhd, new Uint8Array([
        0,
        // version 0
        0,
        0,
        0,
        // flags
        i >> 24,
        i >> 16 & 255,
        i >> 8 & 255,
        i & 255
        // track_ID
      ])),
      I.box(I.types.tfdt, new Uint8Array([
        1,
        // version 1
        0,
        0,
        0,
        // flags
        r >> 24,
        r >> 16 & 255,
        r >> 8 & 255,
        r & 255,
        n >> 24,
        n >> 16 & 255,
        n >> 8 & 255,
        n & 255
      ])),
      I.trun(e, s.length + 16 + // tfhd
      20 + // tfdt
      8 + // traf header
      16 + // mfhd
      8 + // moof header
      8),
      // mdat header
      s
    );
  }
  /**
   * Generate a track box.
   * @param track a track definition
   */
  static trak(e) {
    return e.duration = e.duration || 4294967295, I.box(I.types.trak, I.tkhd(e), I.mdia(e));
  }
  static trex(e) {
    const t = e.id;
    return I.box(I.types.trex, new Uint8Array([
      0,
      // version 0
      0,
      0,
      0,
      // flags
      t >> 24,
      t >> 16 & 255,
      t >> 8 & 255,
      t & 255,
      // track_ID
      0,
      0,
      0,
      1,
      // default_sample_description_index
      0,
      0,
      0,
      0,
      // default_sample_duration
      0,
      0,
      0,
      0,
      // default_sample_size
      0,
      1,
      0,
      1
      // default_sample_flags
    ]));
  }
  static trun(e, t) {
    const s = e.samples || [], i = s.length, r = 12 + 16 * i, n = new Uint8Array(r);
    let o, c, l, h, u, d;
    for (t += 8 + r, n.set([
      e.type === "video" ? 1 : 0,
      // version 1 for video with signed-int sample_composition_time_offset
      0,
      15,
      1,
      // flags
      i >>> 24 & 255,
      i >>> 16 & 255,
      i >>> 8 & 255,
      i & 255,
      // sample_count
      t >>> 24 & 255,
      t >>> 16 & 255,
      t >>> 8 & 255,
      t & 255
      // data_offset
    ], 0), o = 0; o < i; o++)
      c = s[o], l = c.duration, h = c.size, u = c.flags, d = c.cts, n.set([
        l >>> 24 & 255,
        l >>> 16 & 255,
        l >>> 8 & 255,
        l & 255,
        // sample_duration
        h >>> 24 & 255,
        h >>> 16 & 255,
        h >>> 8 & 255,
        h & 255,
        // sample_size
        u.isLeading << 2 | u.dependsOn,
        u.isDependedOn << 6 | u.hasRedundancy << 4 | u.paddingValue << 1 | u.isNonSync,
        u.degradPrio & 61440,
        u.degradPrio & 15,
        // sample_flags
        d >>> 24 & 255,
        d >>> 16 & 255,
        d >>> 8 & 255,
        d & 255
        // sample_composition_time_offset
      ], 12 + 16 * o);
    return I.box(I.types.trun, n);
  }
  static initSegment(e) {
    I.types || I.init();
    const t = I.moov(e);
    return Ie(I.FTYP, t);
  }
  static hvc1(e) {
    const t = e.params, s = [e.vps, e.sps, e.pps], i = 4, r = new Uint8Array([1, t.general_profile_space << 6 | (t.general_tier_flag ? 32 : 0) | t.general_profile_idc, t.general_profile_compatibility_flags[0], t.general_profile_compatibility_flags[1], t.general_profile_compatibility_flags[2], t.general_profile_compatibility_flags[3], t.general_constraint_indicator_flags[0], t.general_constraint_indicator_flags[1], t.general_constraint_indicator_flags[2], t.general_constraint_indicator_flags[3], t.general_constraint_indicator_flags[4], t.general_constraint_indicator_flags[5], t.general_level_idc, 240 | t.min_spatial_segmentation_idc >> 8, 255 & t.min_spatial_segmentation_idc, 252 | t.parallelismType, 252 | t.chroma_format_idc, 248 | t.bit_depth_luma_minus8, 248 | t.bit_depth_chroma_minus8, 0, parseInt(t.frame_rate.fps), i - 1 | t.temporal_id_nested << 2 | t.num_temporal_layers << 3 | (t.frame_rate.fixed ? 64 : 0), s.length]);
    let n = r.length;
    for (let g = 0; g < s.length; g += 1) {
      n += 3;
      for (let p = 0; p < s[g].length; p += 1)
        n += 2 + s[g][p].length;
    }
    const o = new Uint8Array(n);
    o.set(r, 0), n = r.length;
    const c = s.length - 1;
    for (let g = 0; g < s.length; g += 1) {
      o.set(new Uint8Array([32 + g | (g === c ? 128 : 0), 0, s[g].length]), n), n += 3;
      for (let p = 0; p < s[g].length; p += 1)
        o.set(new Uint8Array([s[g][p].length >> 8, s[g][p].length & 255]), n), n += 2, o.set(s[g][p], n), n += s[g][p].length;
    }
    const l = I.box(I.types.hvcC, o), h = e.width, u = e.height, d = e.pixelRatio[0], f = e.pixelRatio[1];
    return I.box(
      I.types.hvc1,
      new Uint8Array([
        0,
        0,
        0,
        // reserved
        0,
        0,
        0,
        // reserved
        0,
        1,
        // data_reference_index
        0,
        0,
        // pre_defined
        0,
        0,
        // reserved
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        // pre_defined
        h >> 8 & 255,
        h & 255,
        // width
        u >> 8 & 255,
        u & 255,
        // height
        0,
        72,
        0,
        0,
        // horizresolution
        0,
        72,
        0,
        0,
        // vertresolution
        0,
        0,
        0,
        0,
        // reserved
        0,
        1,
        // frame_count
        18,
        100,
        97,
        105,
        108,
        // dailymotion/hls.js
        121,
        109,
        111,
        116,
        105,
        111,
        110,
        47,
        104,
        108,
        115,
        46,
        106,
        115,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        // compressorname
        0,
        24,
        // depth = 24
        17,
        17
      ]),
      // pre_defined = -1
      l,
      I.box(I.types.btrt, new Uint8Array([
        0,
        28,
        156,
        128,
        // bufferSizeDB
        0,
        45,
        198,
        192,
        // maxBitrate
        0,
        45,
        198,
        192
      ])),
      // avgBitrate
      I.box(I.types.pasp, new Uint8Array([
        d >> 24,
        // hSpacing
        d >> 16 & 255,
        d >> 8 & 255,
        d & 255,
        f >> 24,
        // vSpacing
        f >> 16 & 255,
        f >> 8 & 255,
        f & 255
      ]))
    );
  }
}
I.types = void 0;
I.HDLR_TYPES = void 0;
I.STTS = void 0;
I.STSC = void 0;
I.STCO = void 0;
I.STSZ = void 0;
I.VMHD = void 0;
I.SMHD = void 0;
I.STSD = void 0;
I.FTYP = void 0;
I.DINF = void 0;
const da = 9e4;
function Di(a, e, t = 1, s = !1) {
  const i = a * e * t;
  return s ? Math.round(i) : i;
}
function Ac(a, e, t = 1, s = !1) {
  return Di(a, e, 1 / t, s);
}
function vt(a, e = !1) {
  return Di(a, 1e3, 1 / da, e);
}
function Lc(a, e = 1) {
  return Di(a, da, 1 / e);
}
const Ic = 10 * 1e3, Rc = 1024, bc = 1152, _c = 1536;
let ct = null, Ms = null;
function Or(a, e, t, s) {
  return {
    duration: e,
    size: t,
    cts: s,
    flags: {
      isLeading: 0,
      isDependedOn: 0,
      hasRedundancy: 0,
      degradPrio: 0,
      dependsOn: a ? 2 : 1,
      isNonSync: a ? 0 : 1
    }
  };
}
class es {
  constructor(e, t, s, i) {
    if (this.logger = void 0, this.observer = void 0, this.config = void 0, this.typeSupported = void 0, this.ISGenerated = !1, this._initPTS = null, this._initDTS = null, this.nextAvcDts = null, this.nextAudioPts = null, this.videoSampleDuration = null, this.isAudioContiguous = !1, this.isVideoContiguous = !1, this.videoTrackConfig = void 0, this.observer = e, this.config = t, this.typeSupported = s, this.logger = i, this.ISGenerated = !1, ct === null) {
      const n = (navigator.userAgent || "").match(/Chrome\/(\d+)/i);
      ct = n ? parseInt(n[1]) : 0;
    }
    if (Ms === null) {
      const r = navigator.userAgent.match(/Safari\/(\d+)/i);
      Ms = r ? parseInt(r[1]) : 0;
    }
  }
  destroy() {
    this.config = this.videoTrackConfig = this._initPTS = this._initDTS = null;
  }
  resetTimeStamp(e) {
    this.logger.log("[mp4-remuxer]: initPTS & initDTS reset"), this._initPTS = this._initDTS = e;
  }
  resetNextTimestamp() {
    this.logger.log("[mp4-remuxer]: reset next timestamp"), this.isVideoContiguous = !1, this.isAudioContiguous = !1;
  }
  resetInitSegment() {
    this.logger.log("[mp4-remuxer]: ISGenerated flag reset"), this.ISGenerated = !1, this.videoTrackConfig = void 0;
  }
  getVideoStartPts(e) {
    let t = !1;
    const s = e[0].pts, i = e.reduce((r, n) => {
      let o = n.pts, c = o - r;
      return c < -4294967296 && (t = !0, o = Le(o, s), c = o - r), c > 0 ? r : o;
    }, s);
    return t && this.logger.debug("PTS rollover detected"), i;
  }
  remux(e, t, s, i, r, n, o, c) {
    let l, h, u, d, f, g, p = r, E = r;
    const y = e.pid > -1, S = t.pid > -1, T = t.samples.length, v = e.samples.length > 0, x = o && T > 0 || T > 1;
    if ((!y || v) && (!S || x) || this.ISGenerated || o) {
      if (this.ISGenerated) {
        var A, b, D, L;
        const w = this.videoTrackConfig;
        (w && (t.width !== w.width || t.height !== w.height || ((A = t.pixelRatio) == null ? void 0 : A[0]) !== ((b = w.pixelRatio) == null ? void 0 : b[0]) || ((D = t.pixelRatio) == null ? void 0 : D[1]) !== ((L = w.pixelRatio) == null ? void 0 : L[1])) || !w && x || this.nextAudioPts === null && v) && this.resetInitSegment();
      }
      this.ISGenerated || (u = this.generateIS(e, t, r, n));
      const k = this.isVideoContiguous;
      let F = -1, j;
      if (x && (F = Dc(t.samples), !k && this.config.forceKeyFrameOnDiscontinuity))
        if (g = !0, F > 0) {
          this.logger.warn(`[mp4-remuxer]: Dropped ${F} out of ${T} video samples due to a missing keyframe`);
          const w = this.getVideoStartPts(t.samples);
          t.samples = t.samples.slice(F), t.dropped += F, E += (t.samples[0].pts - w) / t.inputTimeScale, j = E;
        } else F === -1 && (this.logger.warn(`[mp4-remuxer]: No keyframe found out of ${T} video samples`), g = !1);
      if (this.ISGenerated) {
        if (v && x) {
          const w = this.getVideoStartPts(t.samples), N = (Le(e.samples[0].pts, w) - w) / t.inputTimeScale;
          p += Math.max(0, N), E += Math.max(0, -N);
        }
        if (v) {
          if (e.samplerate || (this.logger.warn("[mp4-remuxer]: regenerate InitSegment as audio detected"), u = this.generateIS(e, t, r, n)), h = this.remuxAudio(e, p, this.isAudioContiguous, n, S || x || c === G.AUDIO ? E : void 0), x) {
            const w = h ? h.endPTS - h.startPTS : 0;
            t.inputTimeScale || (this.logger.warn("[mp4-remuxer]: regenerate InitSegment as video detected"), u = this.generateIS(e, t, r, n)), l = this.remuxVideo(t, E, k, w);
          }
        } else x && (l = this.remuxVideo(t, E, k, 0));
        l && (l.firstKeyFrame = F, l.independent = F !== -1, l.firstKeyFramePTS = j);
      }
    }
    return this.ISGenerated && this._initPTS && this._initDTS && (s.samples.length && (f = fa(s, r, this._initPTS, this._initDTS)), i.samples.length && (d = ga(i, r, this._initPTS))), {
      audio: h,
      video: l,
      initSegment: u,
      independent: g,
      text: d,
      id3: f
    };
  }
  generateIS(e, t, s, i) {
    const r = e.samples, n = t.samples, o = this.typeSupported, c = {}, l = this._initPTS;
    let h = !l || i, u = "audio/mp4", d, f, g;
    if (h && (d = f = 1 / 0), e.config && r.length) {
      switch (e.timescale = e.samplerate, e.segmentCodec) {
        case "mp3":
          o.mpeg ? (u = "audio/mpeg", e.codec = "") : o.mp3 && (e.codec = "mp3");
          break;
        case "ac3":
          e.codec = "ac-3";
          break;
      }
      c.audio = {
        id: "audio",
        container: u,
        codec: e.codec,
        initSegment: e.segmentCodec === "mp3" && o.mpeg ? new Uint8Array(0) : I.initSegment([e]),
        metadata: {
          channelCount: e.channelCount
        }
      }, h && (g = e.inputTimeScale, !l || g !== l.timescale ? d = f = r[0].pts - Math.round(g * s) : h = !1);
    }
    if (t.sps && t.pps && n.length) {
      if (t.timescale = t.inputTimeScale, c.video = {
        id: "main",
        container: "video/mp4",
        codec: t.codec,
        initSegment: I.initSegment([t]),
        metadata: {
          width: t.width,
          height: t.height
        }
      }, h)
        if (g = t.inputTimeScale, !l || g !== l.timescale) {
          const p = this.getVideoStartPts(n), E = Math.round(g * s);
          f = Math.min(f, Le(n[0].dts, p) - E), d = Math.min(d, p - E);
        } else
          h = !1;
      this.videoTrackConfig = {
        width: t.width,
        height: t.height,
        pixelRatio: t.pixelRatio
      };
    }
    if (Object.keys(c).length)
      return this.ISGenerated = !0, h ? (this._initPTS = {
        baseTime: d,
        timescale: g
      }, this._initDTS = {
        baseTime: f,
        timescale: g
      }) : d = g = void 0, {
        tracks: c,
        initPTS: d,
        timescale: g
      };
  }
  remuxVideo(e, t, s, i) {
    const r = e.inputTimeScale, n = e.samples, o = [], c = n.length, l = this._initPTS;
    let h = this.nextAvcDts, u = 8, d = this.videoSampleDuration, f, g, p = Number.POSITIVE_INFINITY, E = Number.NEGATIVE_INFINITY, y = !1;
    if (!s || h === null) {
      const P = t * r, O = n[0].pts - Le(n[0].dts, n[0].pts);
      ct && h !== null && Math.abs(P - O - h) < 15e3 ? s = !0 : h = P - O;
    }
    const S = l.baseTime * r / l.timescale;
    for (let P = 0; P < c; P++) {
      const O = n[P];
      O.pts = Le(O.pts - S, h), O.dts = Le(O.dts - S, h), O.dts < n[P > 0 ? P - 1 : P].dts && (y = !0);
    }
    y && n.sort(function(P, O) {
      const W = P.dts - O.dts, H = P.pts - O.pts;
      return W || H;
    }), f = n[0].dts, g = n[n.length - 1].dts;
    const T = g - f, v = T ? Math.round(T / (c - 1)) : d || e.inputTimeScale / 30;
    if (s) {
      const P = f - h, O = P > v, W = P < -1;
      if ((O || W) && (O ? this.logger.warn(`${(e.segmentCodec || "").toUpperCase()}: ${vt(P, !0)} ms (${P}dts) hole between fragments detected at ${t.toFixed(3)}`) : this.logger.warn(`${(e.segmentCodec || "").toUpperCase()}: ${vt(-P, !0)} ms (${P}dts) overlapping between fragments detected at ${t.toFixed(3)}`), !W || h >= n[0].pts || ct)) {
        f = h;
        const H = n[0].pts - P;
        if (O)
          n[0].dts = f, n[0].pts = H;
        else {
          let X = !0;
          for (let Z = 0; Z < n.length && !(n[Z].dts > H && X); Z++) {
            const ee = n[Z].pts;
            if (n[Z].dts -= P, n[Z].pts -= P, Z < n.length - 1) {
              const ne = n[Z + 1].pts, me = n[Z].pts, pe = ne <= me, He = ne <= ee;
              X = pe == He;
            }
          }
        }
        this.logger.log(`Video: Initial PTS/DTS adjusted: ${vt(H, !0)}/${vt(f, !0)}, delta: ${vt(P, !0)} ms`);
      }
    }
    f = Math.max(0, f);
    let x = 0, _ = 0, A = f;
    for (let P = 0; P < c; P++) {
      const O = n[P], W = O.units, H = W.length;
      let X = 0;
      for (let Z = 0; Z < H; Z++)
        X += W[Z].data.length;
      _ += X, x += H, O.length = X, O.dts < A ? (O.dts = A, A += v / 4 | 0 || 1) : A = O.dts, p = Math.min(O.pts, p), E = Math.max(O.pts, E);
    }
    g = n[c - 1].dts;
    const b = _ + 4 * x + 8;
    let D;
    try {
      D = new Uint8Array(b);
    } catch (P) {
      this.observer.emit(m.ERROR, m.ERROR, {
        type: K.MUX_ERROR,
        details: R.REMUX_ALLOC_ERROR,
        fatal: !1,
        error: P,
        bytes: b,
        reason: `fail allocating video mdat ${b}`
      });
      return;
    }
    const L = new DataView(D.buffer);
    L.setUint32(0, b), D.set(I.types.mdat, 4);
    let k = !1, F = Number.POSITIVE_INFINITY, j = Number.POSITIVE_INFINITY, w = Number.NEGATIVE_INFINITY, U = Number.NEGATIVE_INFINITY;
    for (let P = 0; P < c; P++) {
      const O = n[P], W = O.units;
      let H = 0;
      for (let ee = 0, ne = W.length; ee < ne; ee++) {
        const me = W[ee], pe = me.data, He = me.data.byteLength;
        L.setUint32(u, He), u += 4, D.set(pe, u), u += He, H += 4 + He;
      }
      let X;
      if (P < c - 1)
        d = n[P + 1].dts - O.dts, X = n[P + 1].pts - O.pts;
      else {
        const ee = this.config, ne = P > 0 ? O.dts - n[P - 1].dts : v;
        if (X = P > 0 ? O.pts - n[P - 1].pts : v, ee.stretchShortVideoTrack && this.nextAudioPts !== null) {
          const me = Math.floor(ee.maxBufferHole * r), pe = (i ? p + i * r : this.nextAudioPts) - O.pts;
          pe > me ? (d = pe - ne, d < 0 ? d = ne : k = !0, this.logger.log(`[mp4-remuxer]: It is approximately ${pe / 90} ms to the next segment; using duration ${d / 90} ms for the last video frame.`)) : d = ne;
        } else
          d = ne;
      }
      const Z = Math.round(O.pts - O.dts);
      F = Math.min(F, d), w = Math.max(w, d), j = Math.min(j, X), U = Math.max(U, X), o.push(Or(O.key, d, H, Z));
    }
    if (o.length) {
      if (ct) {
        if (ct < 70) {
          const P = o[0].flags;
          P.dependsOn = 2, P.isNonSync = 0;
        }
      } else if (Ms && U - j < w - F && v / w < 0.025 && o[0].cts === 0) {
        this.logger.warn("Found irregular gaps in sample duration. Using PTS instead of DTS to determine MP4 sample duration.");
        let P = f;
        for (let O = 0, W = o.length; O < W; O++) {
          const H = P + o[O].duration, X = P + o[O].cts;
          if (O < W - 1) {
            const Z = H + o[O + 1].cts;
            o[O].duration = Z - X;
          } else
            o[O].duration = O ? o[O - 1].duration : v;
          o[O].cts = 0, P = H;
        }
      }
    }
    d = k || !d ? v : d, this.nextAvcDts = h = g + d, this.videoSampleDuration = d, this.isVideoContiguous = !0;
    const $ = {
      data1: I.moof(e.sequenceNumber++, f, re(e, {
        samples: o
      })),
      data2: D,
      startPTS: p / r,
      endPTS: (E + d) / r,
      startDTS: f / r,
      endDTS: h / r,
      type: "video",
      hasAudio: !1,
      hasVideo: !0,
      nb: o.length,
      dropped: e.dropped
    };
    return e.samples = [], e.dropped = 0, $;
  }
  getSamplesPerFrame(e) {
    switch (e.segmentCodec) {
      case "mp3":
        return bc;
      case "ac3":
        return _c;
      default:
        return Rc;
    }
  }
  remuxAudio(e, t, s, i, r) {
    const n = e.inputTimeScale, o = e.samplerate ? e.samplerate : n, c = n / o, l = this.getSamplesPerFrame(e), h = l * c, u = this._initPTS, d = e.segmentCodec === "mp3" && this.typeSupported.mpeg, f = [], g = r !== void 0;
    let p = e.samples, E = d ? 0 : 8, y = this.nextAudioPts || -1;
    const S = t * n, T = u.baseTime * n / u.timescale;
    if (this.isAudioContiguous = s = s || p.length && y > 0 && (i && Math.abs(S - y) < 9e3 || Math.abs(Le(p[0].pts - T, S) - y) < 20 * h), p.forEach(function(N) {
      N.pts = Le(N.pts - T, S);
    }), !s || y < 0) {
      if (p = p.filter((N) => N.pts >= 0), !p.length)
        return;
      r === 0 ? y = 0 : i && !g ? y = Math.max(0, S) : y = p[0].pts;
    }
    if (e.segmentCodec === "aac") {
      const N = this.config.maxAudioFramesDrift;
      for (let B = 0, $ = y; B < p.length; B++) {
        const P = p[B], O = P.pts, W = O - $, H = Math.abs(1e3 * W / n);
        if (W <= -N * h && g)
          B === 0 && (this.logger.warn(`Audio frame @ ${(O / n).toFixed(3)}s overlaps nextAudioPts by ${Math.round(1e3 * W / n)} ms.`), this.nextAudioPts = y = $ = O);
        else if (W >= N * h && H < Ic && g) {
          let X = Math.round(W / h);
          $ = O - X * h, $ < 0 && (X--, $ += h), B === 0 && (this.nextAudioPts = y = $), this.logger.warn(`[mp4-remuxer]: Injecting ${X} audio frame @ ${($ / n).toFixed(3)}s due to ${Math.round(1e3 * W / n)} ms gap.`);
          for (let Z = 0; Z < X; Z++) {
            const ee = Math.max($, 0);
            let ne = xc.getSilentFrame(e.parsedCodec || e.manifestCodec || e.codec, e.channelCount);
            ne || (this.logger.log("[mp4-remuxer]: Unable to get silent frame for given audio codec; duplicating last frame instead."), ne = P.unit.subarray()), p.splice(B, 0, {
              unit: ne,
              pts: ee
            }), $ += h, B++;
          }
        }
        P.pts = $, $ += h;
      }
    }
    let v = null, x = null, _, A = 0, b = p.length;
    for (; b--; )
      A += p[b].unit.byteLength;
    for (let N = 0, B = p.length; N < B; N++) {
      const $ = p[N], P = $.unit;
      let O = $.pts;
      if (x !== null) {
        const H = f[N - 1];
        H.duration = Math.round((O - x) / c);
      } else if (s && e.segmentCodec === "aac" && (O = y), v = O, A > 0) {
        A += E;
        try {
          _ = new Uint8Array(A);
        } catch (H) {
          this.observer.emit(m.ERROR, m.ERROR, {
            type: K.MUX_ERROR,
            details: R.REMUX_ALLOC_ERROR,
            fatal: !1,
            error: H,
            bytes: A,
            reason: `fail allocating audio mdat ${A}`
          });
          return;
        }
        d || (new DataView(_.buffer).setUint32(0, A), _.set(I.types.mdat, 4));
      } else
        return;
      _.set(P, E);
      const W = P.byteLength;
      E += W, f.push(Or(!0, l, W, 0)), x = O;
    }
    const D = f.length;
    if (!D)
      return;
    const L = f[f.length - 1];
    this.nextAudioPts = y = x + c * L.duration;
    const k = d ? new Uint8Array(0) : I.moof(e.sequenceNumber++, v / c, re({}, e, {
      samples: f
    }));
    e.samples = [];
    const F = v / n, j = y / n, U = {
      data1: k,
      data2: _,
      startPTS: F,
      endPTS: j,
      startDTS: F,
      endDTS: j,
      type: "audio",
      hasAudio: !0,
      hasVideo: !1,
      nb: D
    };
    return this.isAudioContiguous = !0, U;
  }
}
function Le(a, e) {
  let t;
  if (e === null)
    return a;
  for (e < a ? t = -8589934592 : t = 8589934592; Math.abs(a - e) > 4294967296; )
    a += t;
  return a;
}
function Dc(a) {
  for (let e = 0; e < a.length; e++)
    if (a[e].key)
      return e;
  return -1;
}
function fa(a, e, t, s) {
  const i = a.samples.length;
  if (!i)
    return;
  const r = a.inputTimeScale;
  for (let o = 0; o < i; o++) {
    const c = a.samples[o];
    c.pts = Le(c.pts - t.baseTime * r / t.timescale, e * r) / r, c.dts = Le(c.dts - s.baseTime * r / s.timescale, e * r) / r;
  }
  const n = a.samples;
  return a.samples = [], {
    samples: n
  };
}
function ga(a, e, t) {
  const s = a.samples.length;
  if (!s)
    return;
  const i = a.inputTimeScale;
  for (let n = 0; n < s; n++) {
    const o = a.samples[n];
    o.pts = Le(o.pts - t.baseTime * i / t.timescale, e * i) / i;
  }
  a.samples.sort((n, o) => n.pts - o.pts);
  const r = a.samples;
  return a.samples = [], {
    samples: r
  };
}
class Cc {
  constructor(e, t, s, i) {
    this.logger = void 0, this.emitInitSegment = !1, this.audioCodec = void 0, this.videoCodec = void 0, this.initData = void 0, this.initPTS = null, this.initTracks = void 0, this.lastEndTime = null, this.logger = i;
  }
  destroy() {
  }
  resetTimeStamp(e) {
    this.initPTS = e, this.lastEndTime = null;
  }
  resetNextTimestamp() {
    this.lastEndTime = null;
  }
  resetInitSegment(e, t, s, i) {
    this.audioCodec = t, this.videoCodec = s, this.generateInitSegment(yo(e, i)), this.emitInitSegment = !0;
  }
  generateInitSegment(e) {
    let {
      audioCodec: t,
      videoCodec: s
    } = this;
    if (!(e != null && e.byteLength)) {
      this.initTracks = void 0, this.initData = void 0;
      return;
    }
    const i = this.initData = An(e);
    i.audio && (t = Fr(i.audio, ie.AUDIO)), i.video && (s = Fr(i.video, ie.VIDEO));
    const r = {};
    i.audio && i.video ? r.audiovideo = {
      container: "video/mp4",
      codec: t + "," + s,
      supplemental: i.video.supplemental,
      initSegment: e,
      id: "main"
    } : i.audio ? r.audio = {
      container: "audio/mp4",
      codec: t,
      initSegment: e,
      id: "audio"
    } : i.video ? r.video = {
      container: "video/mp4",
      codec: s,
      supplemental: i.video.supplemental,
      initSegment: e,
      id: "main"
    } : this.logger.warn("[passthrough-remuxer.ts]: initSegment does not contain moov or trak boxes."), this.initTracks = r;
  }
  remux(e, t, s, i, r, n) {
    var o, c;
    let {
      initPTS: l,
      lastEndTime: h
    } = this;
    const u = {
      audio: void 0,
      video: void 0,
      text: i,
      id3: s,
      initSegment: void 0
    };
    M(h) || (h = this.lastEndTime = r || 0);
    const d = t.samples;
    if (!(d != null && d.length))
      return u;
    const f = {
      initPTS: void 0,
      timescale: 1
    };
    let g = this.initData;
    if ((o = g) != null && o.length || (this.generateInitSegment(d), g = this.initData), !((c = g) != null && c.length))
      return this.logger.warn("[passthrough-remuxer.ts]: Failed to generate initSegment."), u;
    this.emitInitSegment && (f.tracks = this.initTracks, this.emitInitSegment = !1);
    const p = So(d, g), E = To(g, d), y = E === null ? r : E;
    (n || !l) && (Pc(l, y, r, p) || f.timescale !== l.timescale) && (f.initPTS = y - r, l && l.timescale === 1 && this.logger.warn(`Adjusting initPTS @${r} from ${l.baseTime / l.timescale} to ${f.initPTS}`), this.initPTS = l = {
      baseTime: f.initPTS,
      timescale: 1
    });
    const S = e ? y - l.baseTime / l.timescale : h, T = S + p;
    xo(g, d, l.baseTime / l.timescale), p > 0 ? this.lastEndTime = T : (this.logger.warn("Duration parsed from mp4 should be greater than zero"), this.resetNextTimestamp());
    const v = !!g.audio, x = !!g.video;
    let _ = "";
    v && (_ += "audio"), x && (_ += "video");
    const A = {
      data1: d,
      startPTS: S,
      startDTS: S,
      endPTS: T,
      endDTS: T,
      type: _,
      hasAudio: v,
      hasVideo: x,
      nb: 1,
      dropped: 0
    };
    return u.audio = A.type === "audio" ? A : void 0, u.video = A.type !== "audio" ? A : void 0, u.initSegment = f, u.id3 = fa(s, r, l, l), i.samples.length && (u.text = ga(i, r, l)), u;
  }
}
function Pc(a, e, t, s) {
  if (a === null)
    return !0;
  const i = Math.max(s, 1), r = e - a.baseTime / a.timescale;
  return Math.abs(r - t) > i;
}
function Fr(a, e) {
  const t = a == null ? void 0 : a.codec;
  return t && t.length > 4 ? t : e === ie.AUDIO ? t === "ec-3" || t === "ac-3" || t === "alac" ? t : t === "fLaC" || t === "Opus" ? os(t, !1) : (Q.warn(`Unhandled audio codec "${t}" in mp4 MAP`), t || "mp4a") : (Q.warn(`Unhandled video codec "${t}" in mp4 MAP`), t || "avc1");
}
let $e;
try {
  $e = self.performance.now.bind(self.performance);
} catch {
  $e = Date.now;
}
const ts = [{
  demux: yc,
  remux: Cc
}, {
  demux: Xe,
  remux: es
}, {
  demux: gc,
  remux: es
}, {
  demux: pc,
  remux: es
}];
ts.splice(2, 0, {
  demux: mc,
  remux: es
});
class Mr {
  constructor(e, t, s, i, r, n) {
    this.asyncResult = !1, this.logger = void 0, this.observer = void 0, this.typeSupported = void 0, this.config = void 0, this.id = void 0, this.demuxer = void 0, this.remuxer = void 0, this.decrypter = void 0, this.probe = void 0, this.decryptionPromise = null, this.transmuxConfig = void 0, this.currentTransmuxState = void 0, this.observer = e, this.typeSupported = t, this.config = s, this.id = r, this.logger = n;
  }
  configure(e) {
    this.transmuxConfig = e, this.decrypter && this.decrypter.reset();
  }
  push(e, t, s, i) {
    const r = s.transmuxing;
    r.executeStart = $e();
    let n = new Uint8Array(e);
    const {
      currentTransmuxState: o,
      transmuxConfig: c
    } = this;
    i && (this.currentTransmuxState = i);
    const {
      contiguous: l,
      discontinuity: h,
      trackSwitch: u,
      accurateTimeOffset: d,
      timeOffset: f,
      initSegmentChange: g
    } = i || o, {
      audioCodec: p,
      videoCodec: E,
      defaultInitPts: y,
      duration: S,
      initSegmentData: T
    } = c, v = kc(n, t);
    if (v && dt(v.method)) {
      const b = this.getDecrypter(), D = Si(v.method);
      if (b.isSync()) {
        let L = b.softwareDecrypt(n, v.key.buffer, v.iv.buffer, D);
        if (s.part > -1) {
          const F = b.flush();
          L = F && F.buffer;
        }
        if (!L)
          return r.executeEnd = $e(), Ns(s);
        n = new Uint8Array(L);
      } else
        return this.asyncResult = !0, this.decryptionPromise = b.webCryptoDecrypt(n, v.key.buffer, v.iv.buffer, D).then((L) => {
          const k = this.push(L, null, s);
          return this.decryptionPromise = null, k;
        }), this.decryptionPromise;
    }
    const x = this.needsProbing(h, u);
    if (x) {
      const b = this.configureTransmuxer(n);
      if (b)
        return this.logger.warn(`[transmuxer] ${b.message}`), this.observer.emit(m.ERROR, m.ERROR, {
          type: K.MEDIA_ERROR,
          details: R.FRAG_PARSING_ERROR,
          fatal: !1,
          error: b,
          reason: b.message
        }), r.executeEnd = $e(), Ns(s);
    }
    (h || u || g || x) && this.resetInitSegment(T, p, E, S, t), (h || g || x) && this.resetInitialTimestamp(y), l || this.resetContiguity();
    const _ = this.transmux(n, v, f, d, s);
    this.asyncResult = wt(_);
    const A = this.currentTransmuxState;
    return A.contiguous = !0, A.discontinuity = !1, A.trackSwitch = !1, r.executeEnd = $e(), _;
  }
  // Due to data caching, flush calls can produce more than one TransmuxerResult (hence the Array type)
  flush(e) {
    const t = e.transmuxing;
    t.executeStart = $e();
    const {
      decrypter: s,
      currentTransmuxState: i,
      decryptionPromise: r
    } = this;
    if (r)
      return this.asyncResult = !0, r.then(() => this.flush(e));
    const n = [], {
      timeOffset: o
    } = i;
    if (s) {
      const u = s.flush();
      u && n.push(this.push(u.buffer, null, e));
    }
    const {
      demuxer: c,
      remuxer: l
    } = this;
    if (!c || !l) {
      t.executeEnd = $e();
      const u = [Ns(e)];
      return this.asyncResult ? Promise.resolve(u) : u;
    }
    const h = c.flush(o);
    return wt(h) ? (this.asyncResult = !0, h.then((u) => (this.flushRemux(n, u, e), n))) : (this.flushRemux(n, h, e), this.asyncResult ? Promise.resolve(n) : n);
  }
  flushRemux(e, t, s) {
    const {
      audioTrack: i,
      videoTrack: r,
      id3Track: n,
      textTrack: o
    } = t, {
      accurateTimeOffset: c,
      timeOffset: l
    } = this.currentTransmuxState;
    this.logger.log(`[transmuxer.ts]: Flushed ${this.id} sn: ${s.sn}${s.part > -1 ? " part: " + s.part : ""} of ${this.id === G.MAIN ? "level" : "track"} ${s.level}`);
    const h = this.remuxer.remux(i, r, n, o, l, c, !0, this.id);
    e.push({
      remuxResult: h,
      chunkMeta: s
    }), s.transmuxing.executeEnd = $e();
  }
  resetInitialTimestamp(e) {
    const {
      demuxer: t,
      remuxer: s
    } = this;
    !t || !s || (t.resetTimeStamp(e), s.resetTimeStamp(e));
  }
  resetContiguity() {
    const {
      demuxer: e,
      remuxer: t
    } = this;
    !e || !t || (e.resetContiguity(), t.resetNextTimestamp());
  }
  resetInitSegment(e, t, s, i, r) {
    const {
      demuxer: n,
      remuxer: o
    } = this;
    !n || !o || (n.resetInitSegment(e, t, s, i), o.resetInitSegment(e, t, s, r));
  }
  destroy() {
    this.demuxer && (this.demuxer.destroy(), this.demuxer = void 0), this.remuxer && (this.remuxer.destroy(), this.remuxer = void 0);
  }
  transmux(e, t, s, i, r) {
    let n;
    return t && t.method === "SAMPLE-AES" ? n = this.transmuxSampleAes(e, t, s, i, r) : n = this.transmuxUnencrypted(e, s, i, r), n;
  }
  transmuxUnencrypted(e, t, s, i) {
    const {
      audioTrack: r,
      videoTrack: n,
      id3Track: o,
      textTrack: c
    } = this.demuxer.demux(e, t, !1, !this.config.progressive);
    return {
      remuxResult: this.remuxer.remux(r, n, o, c, t, s, !1, this.id),
      chunkMeta: i
    };
  }
  transmuxSampleAes(e, t, s, i, r) {
    return this.demuxer.demuxSampleAes(e, t, s).then((n) => ({
      remuxResult: this.remuxer.remux(n.audioTrack, n.videoTrack, n.id3Track, n.textTrack, s, i, !1, this.id),
      chunkMeta: r
    }));
  }
  configureTransmuxer(e) {
    const {
      config: t,
      observer: s,
      typeSupported: i
    } = this;
    let r;
    for (let u = 0, d = ts.length; u < d; u++) {
      var n;
      if ((n = ts[u].demux) != null && n.probe(e, this.logger)) {
        r = ts[u];
        break;
      }
    }
    if (!r)
      return new Error("Failed to find demuxer by probing fragment data");
    const o = this.demuxer, c = this.remuxer, l = r.remux, h = r.demux;
    (!c || !(c instanceof l)) && (this.remuxer = new l(s, t, i, this.logger)), (!o || !(o instanceof h)) && (this.demuxer = new h(s, t, i, this.logger), this.probe = h.probe);
  }
  needsProbing(e, t) {
    return !this.demuxer || !this.remuxer || e || t;
  }
  getDecrypter() {
    let e = this.decrypter;
    return e || (e = this.decrypter = new yi(this.config)), e;
  }
}
function kc(a, e) {
  let t = null;
  return a.byteLength > 0 && (e == null ? void 0 : e.key) != null && e.iv !== null && e.method != null && (t = e), t;
}
const Ns = (a) => ({
  remuxResult: {},
  chunkMeta: a
});
function wt(a) {
  return "then" in a && a.then instanceof Function;
}
class wc {
  constructor(e, t, s, i, r) {
    this.audioCodec = void 0, this.videoCodec = void 0, this.initSegmentData = void 0, this.duration = void 0, this.defaultInitPts = void 0, this.audioCodec = e, this.videoCodec = t, this.initSegmentData = s, this.duration = i, this.defaultInitPts = r || null;
  }
}
class Oc {
  constructor(e, t, s, i, r, n) {
    this.discontinuity = void 0, this.contiguous = void 0, this.accurateTimeOffset = void 0, this.trackSwitch = void 0, this.timeOffset = void 0, this.initSegmentChange = void 0, this.discontinuity = e, this.contiguous = t, this.accurateTimeOffset = s, this.trackSwitch = i, this.timeOffset = r, this.initSegmentChange = n;
  }
}
let Nr = 0;
class ma {
  constructor(e, t, s, i) {
    this.error = null, this.hls = void 0, this.id = void 0, this.instanceNo = Nr++, this.observer = void 0, this.frag = null, this.part = null, this.useWorker = void 0, this.workerContext = null, this.transmuxer = null, this.onTransmuxComplete = void 0, this.onFlush = void 0, this.onWorkerMessage = (c) => {
      const l = c.data, h = this.hls;
      if (!(!h || !(l != null && l.event) || l.instanceNo !== this.instanceNo))
        switch (l.event) {
          case "init": {
            var u;
            const d = (u = this.workerContext) == null ? void 0 : u.objectURL;
            d && self.URL.revokeObjectURL(d);
            break;
          }
          case "transmuxComplete": {
            this.handleTransmuxComplete(l.data);
            break;
          }
          case "flush": {
            this.onFlush(l.data);
            break;
          }
          case "workerLog": {
            h.logger[l.data.logType] && h.logger[l.data.logType](l.data.message);
            break;
          }
          default: {
            l.data = l.data || {}, l.data.frag = this.frag, l.data.part = this.part, l.data.id = this.id, h.trigger(l.event, l.data);
            break;
          }
        }
    }, this.onWorkerError = (c) => {
      if (!this.hls)
        return;
      const l = new Error(`${c.message}  (${c.filename}:${c.lineno})`);
      this.hls.config.enableWorker = !1, this.hls.logger.warn(`Error in "${this.id}" Web Worker, fallback to inline`), this.hls.trigger(m.ERROR, {
        type: K.OTHER_ERROR,
        details: R.INTERNAL_EXCEPTION,
        fatal: !1,
        event: "demuxerWorker",
        error: l
      });
    };
    const r = e.config;
    this.hls = e, this.id = t, this.useWorker = !!r.enableWorker, this.onTransmuxComplete = s, this.onFlush = i;
    const n = (c, l) => {
      l = l || {}, l.frag = this.frag || void 0, c === m.ERROR && (l = l, l.parent = this.id, l.part = this.part, this.error = l.error), this.hls.trigger(c, l);
    };
    this.observer = new Ai(), this.observer.on(m.FRAG_DECRYPTED, n), this.observer.on(m.ERROR, n);
    const o = Ji(r.preferManagedMediaSource);
    if (this.useWorker && typeof Worker < "u") {
      const c = this.hls.logger;
      if (r.workerPath || Nl()) {
        try {
          r.workerPath ? (c.log(`loading Web Worker ${r.workerPath} for "${t}"`), this.workerContext = Ul(r.workerPath)) : (c.log(`injecting Web Worker for "${t}"`), this.workerContext = Bl());
          const {
            worker: h
          } = this.workerContext;
          h.addEventListener("message", this.onWorkerMessage), h.addEventListener("error", this.onWorkerError), h.postMessage({
            instanceNo: this.instanceNo,
            cmd: "init",
            typeSupported: o,
            id: t,
            config: ae(r)
          });
        } catch (h) {
          c.warn(`Error setting up "${t}" Web Worker, fallback to inline`, h), this.terminateWorker(), this.error = null, this.transmuxer = new Mr(this.observer, o, r, "", t, e.logger);
        }
        return;
      }
    }
    this.transmuxer = new Mr(this.observer, o, r, "", t, e.logger);
  }
  reset() {
    if (this.frag = null, this.part = null, this.workerContext) {
      const e = this.instanceNo;
      this.instanceNo = Nr++;
      const t = this.hls.config, s = Ji(t.preferManagedMediaSource);
      this.workerContext.worker.postMessage({
        instanceNo: this.instanceNo,
        cmd: "reset",
        resetNo: e,
        typeSupported: s,
        id: this.id,
        config: ae(t)
      });
    }
  }
  terminateWorker() {
    if (this.workerContext) {
      const {
        worker: e
      } = this.workerContext;
      this.workerContext = null, e.removeEventListener("message", this.onWorkerMessage), e.removeEventListener("error", this.onWorkerError), $l(this.hls.config.workerPath);
    }
  }
  destroy() {
    if (this.workerContext)
      this.terminateWorker(), this.onWorkerMessage = this.onWorkerError = null;
    else {
      const t = this.transmuxer;
      t && (t.destroy(), this.transmuxer = null);
    }
    const e = this.observer;
    e && e.removeAllListeners(), this.frag = null, this.part = null, this.observer = null, this.hls = null;
  }
  push(e, t, s, i, r, n, o, c, l, h) {
    var u, d;
    l.transmuxing.start = self.performance.now();
    const {
      instanceNo: f,
      transmuxer: g
    } = this, p = n ? n.start : r.start, E = r.decryptdata, y = this.frag, S = !(y && r.cc === y.cc), T = !(y && l.level === y.level), v = y ? l.sn - y.sn : -1, x = this.part ? l.part - this.part.index : -1, _ = v === 0 && l.id > 1 && l.id === (y == null ? void 0 : y.stats.chunkCount), A = !T && (v === 1 || v === 0 && (x === 1 || _ && x <= 0)), b = self.performance.now();
    (T || v || r.stats.parsing.start === 0) && (r.stats.parsing.start = b), n && (x || !A) && (n.stats.parsing.start = b);
    const D = !(y && ((u = r.initSegment) == null ? void 0 : u.url) === ((d = y.initSegment) == null ? void 0 : d.url)), L = new Oc(S, A, c, T, p, D);
    if (!A || S || D) {
      this.hls.logger.log(`[transmuxer-interface]: Starting new transmux session for ${r.type} sn: ${l.sn}${l.part > -1 ? " part: " + l.part : ""} ${this.id === G.MAIN ? "level" : "track"}: ${l.level} id: ${l.id}
        discontinuity: ${S}
        trackSwitch: ${T}
        contiguous: ${A}
        accurateTimeOffset: ${c}
        timeOffset: ${p}
        initSegmentChange: ${D}`);
      const k = new wc(s, i, t, o, h);
      this.configureTransmuxer(k);
    }
    if (this.frag = r, this.part = n, this.workerContext)
      this.workerContext.worker.postMessage({
        instanceNo: f,
        cmd: "demux",
        data: e,
        decryptdata: E,
        chunkMeta: l,
        state: L
      }, e instanceof ArrayBuffer ? [e] : []);
    else if (g) {
      const k = g.push(e, E, l, L);
      wt(k) ? k.then((F) => {
        this.handleTransmuxComplete(F);
      }).catch((F) => {
        this.transmuxerError(F, l, "transmuxer-interface push error");
      }) : this.handleTransmuxComplete(k);
    }
  }
  flush(e) {
    e.transmuxing.start = self.performance.now();
    const {
      instanceNo: t,
      transmuxer: s
    } = this;
    if (this.workerContext)
      this.workerContext.worker.postMessage({
        instanceNo: t,
        cmd: "flush",
        chunkMeta: e
      });
    else if (s) {
      const i = s.flush(e);
      wt(i) ? i.then((r) => {
        this.handleFlushResult(r, e);
      }).catch((r) => {
        this.transmuxerError(r, e, "transmuxer-interface flush error");
      }) : this.handleFlushResult(i, e);
    }
  }
  transmuxerError(e, t, s) {
    this.hls && (this.error = e, this.hls.trigger(m.ERROR, {
      type: K.MEDIA_ERROR,
      details: R.FRAG_PARSING_ERROR,
      chunkMeta: t,
      frag: this.frag || void 0,
      part: this.part || void 0,
      fatal: !1,
      error: e,
      err: e,
      reason: s
    }));
  }
  handleFlushResult(e, t) {
    e.forEach((s) => {
      this.handleTransmuxComplete(s);
    }), this.onFlush(t);
  }
  configureTransmuxer(e) {
    const {
      instanceNo: t,
      transmuxer: s
    } = this;
    this.workerContext ? this.workerContext.worker.postMessage({
      instanceNo: t,
      cmd: "configure",
      config: e
    }) : s && s.configure(e);
  }
  handleTransmuxComplete(e) {
    e.chunkMeta.transmuxing.end = self.performance.now(), this.onTransmuxComplete(e);
  }
}
const Br = 100;
class Fc extends xi {
  constructor(e, t, s) {
    super(e, t, s, "audio-stream-controller", G.AUDIO), this.mainAnchor = null, this.mainFragLoading = null, this.audioOnly = !1, this.bufferedTrack = null, this.switchingTrack = null, this.trackId = -1, this.waitingData = null, this.mainDetails = null, this.flushing = !1, this.bufferFlushed = !1, this.cachedTrackLoadedData = null, this.registerListeners();
  }
  onHandlerDestroying() {
    this.unregisterListeners(), super.onHandlerDestroying(), this.resetItem();
  }
  resetItem() {
    this.mainDetails = this.mainAnchor = this.mainFragLoading = this.bufferedTrack = this.switchingTrack = this.waitingData = this.cachedTrackLoadedData = null;
  }
  registerListeners() {
    super.registerListeners();
    const {
      hls: e
    } = this;
    e.on(m.LEVEL_LOADED, this.onLevelLoaded, this), e.on(m.AUDIO_TRACKS_UPDATED, this.onAudioTracksUpdated, this), e.on(m.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.on(m.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), e.on(m.BUFFER_RESET, this.onBufferReset, this), e.on(m.BUFFER_CREATED, this.onBufferCreated, this), e.on(m.BUFFER_FLUSHING, this.onBufferFlushing, this), e.on(m.BUFFER_FLUSHED, this.onBufferFlushed, this), e.on(m.INIT_PTS_FOUND, this.onInitPtsFound, this), e.on(m.FRAG_LOADING, this.onFragLoading, this), e.on(m.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e && (super.unregisterListeners(), e.off(m.LEVEL_LOADED, this.onLevelLoaded, this), e.off(m.AUDIO_TRACKS_UPDATED, this.onAudioTracksUpdated, this), e.off(m.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.off(m.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), e.off(m.BUFFER_RESET, this.onBufferReset, this), e.off(m.BUFFER_CREATED, this.onBufferCreated, this), e.off(m.BUFFER_FLUSHING, this.onBufferFlushing, this), e.off(m.BUFFER_FLUSHED, this.onBufferFlushed, this), e.off(m.INIT_PTS_FOUND, this.onInitPtsFound, this), e.off(m.FRAG_LOADING, this.onFragLoading, this), e.off(m.FRAG_BUFFERED, this.onFragBuffered, this));
  }
  // INIT_PTS_FOUND is triggered when the video track parsed in the stream-controller has a new PTS value
  onInitPtsFound(e, {
    frag: t,
    id: s,
    initPTS: i,
    timescale: r
  }) {
    if (s === G.MAIN) {
      const n = t.cc, o = this.fragCurrent;
      if (this.initPTS[n] = {
        baseTime: i,
        timescale: r
      }, this.log(`InitPTS for cc: ${n} found from main: ${i}/${r}`), this.mainAnchor = t, this.state === C.WAITING_INIT_PTS) {
        const c = this.waitingData;
        (!c && !this.loadingParts || c && c.frag.cc !== n) && (this.nextLoadPosition = this.findSyncFrag(t).start), this.tick();
      } else !this.hls.hasEnoughToStart && o && o.cc !== n ? (this.startFragRequested = !1, this.nextLoadPosition = this.findSyncFrag(t).start, o.abortRequests(), this.resetLoadingState()) : this.state === C.IDLE && this.tick();
    }
  }
  findSyncFrag(e) {
    const t = this.getLevelDetails(), s = e.cc;
    return Qo(t, s, e) || t && On(t.fragments, s) || e;
  }
  startLoad(e, t) {
    if (!this.levels) {
      this.startPosition = e, this.state = C.STOPPED;
      return;
    }
    const s = this.lastCurrentTime;
    this.stopLoad(), this.setInterval(Br), s > 0 && e === -1 ? (this.log(`Override startPosition with lastCurrentTime @${s.toFixed(3)}`), e = s, this.state = C.IDLE) : this.state = C.WAITING_TRACK, this.nextLoadPosition = this.lastCurrentTime = e + this.timelineOffset, this.startPosition = t ? -1 : e, this.tick();
  }
  doTick() {
    switch (this.state) {
      case C.IDLE:
        this.doTickIdle();
        break;
      case C.WAITING_TRACK: {
        const {
          levels: t,
          trackId: s
        } = this, i = t == null ? void 0 : t[s], r = i == null ? void 0 : i.details;
        if (r && !this.waitForLive(i)) {
          if (this.waitForCdnTuneIn(r))
            break;
          this.state = C.WAITING_INIT_PTS;
        }
        break;
      }
      case C.FRAG_LOADING_WAITING_RETRY: {
        var e;
        const t = performance.now(), s = this.retryDate;
        if (!s || t >= s || (e = this.media) != null && e.seeking) {
          const {
            levels: i,
            trackId: r
          } = this;
          this.log("RetryDate reached, switch back to IDLE state"), this.resetStartWhenNotLoaded((i == null ? void 0 : i[r]) || null), this.state = C.IDLE;
        }
        break;
      }
      case C.WAITING_INIT_PTS: {
        const t = this.waitingData;
        if (t) {
          const {
            frag: s,
            part: i,
            cache: r,
            complete: n
          } = t, o = this.mainAnchor;
          if (this.initPTS[s.cc] !== void 0) {
            this.waitingData = null, this.state = C.FRAG_LOADING;
            const c = r.flush().buffer, l = {
              frag: s,
              part: i,
              payload: c,
              networkDetails: null
            };
            this._handleFragmentLoadProgress(l), n && super._handleFragmentLoadComplete(l);
          } else o && o.cc !== t.frag.cc && (this.log(`Waiting fragment cc (${s.cc}) cancelled because video is at cc ${o.cc}`), this.nextLoadPosition = this.findSyncFrag(o).start, this.clearWaitingFragment());
        } else
          this.state = C.IDLE;
      }
    }
    this.onTickEnd();
  }
  clearWaitingFragment() {
    const e = this.waitingData;
    e && (this.hls.hasEnoughToStart || (this.startFragRequested = !1), this.fragmentTracker.removeFragment(e.frag), this.waitingData = null, this.state !== C.STOPPED && (this.state = C.IDLE));
  }
  resetLoadingState() {
    this.clearWaitingFragment(), super.resetLoadingState();
  }
  onTickEnd() {
    const {
      media: e
    } = this;
    e != null && e.readyState && (this.lastCurrentTime = e.currentTime);
  }
  doTickIdle() {
    var e;
    const {
      hls: t,
      levels: s,
      media: i,
      trackId: r
    } = this, n = t.config;
    if (!this.buffering || !i && !this.primaryPrefetch && (this.startFragRequested || !n.startFragPrefetch) || !(s != null && s[r]))
      return;
    const o = s[r], c = o.details;
    if (!c || this.waitForLive(o) || this.waitForCdnTuneIn(c)) {
      this.state = C.WAITING_TRACK, this.startFragRequested = !1;
      return;
    }
    const l = this.mediaBuffer ? this.mediaBuffer : this.media;
    this.bufferFlushed && l && (this.bufferFlushed = !1, this.afterBufferFlushed(l, ie.AUDIO, G.AUDIO));
    const h = this.getFwdBufferInfo(l, G.AUDIO);
    if (h === null)
      return;
    if (!this.switchingTrack && this._streamEnded(h, c)) {
      t.trigger(m.BUFFER_EOS, {
        type: "audio"
      }), this.state = C.ENDED;
      return;
    }
    const u = h.len, d = t.maxBufferLength, f = c.fragments, g = f[0].start, p = this.getLoadPosition(), E = this.flushing ? p : h.end;
    if (this.switchingTrack && i) {
      const T = p;
      c.PTSKnown && T < g && (h.end > g || h.nextStart) && (this.log("Alt audio track ahead of main track, seek to start of alt audio track"), i.currentTime = g + 0.05);
    }
    if (u >= d && !this.switchingTrack && E < f[f.length - 1].start)
      return;
    let y = this.getNextFragment(E, c);
    if (y && this.isLoopLoading(y, E) && (y = this.getNextFragmentLoopLoading(y, c, h, G.MAIN, d)), !y) {
      this.bufferFlushed = !0;
      return;
    }
    let S = ((e = this.mainFragLoading) == null ? void 0 : e.frag) || null;
    if (!this.audioOnly && this.startFragRequested && S && ue(y) && !y.endList && (!c.live || !this.loadingParts && E < this.hls.liveSyncPosition) && (this.fragmentTracker.getState(S) === ce.OK && (this.mainFragLoading = S = null), S && ue(S))) {
      if (y.start > S.end) {
        const v = this.fragmentTracker.getFragAtPos(E, G.MAIN);
        v && v.end > S.end && (S = v, this.mainFragLoading = {
          frag: v,
          targetBufferTime: null
        });
      }
      if (y.start > S.end)
        return;
    }
    this.loadFragment(y, o, E);
  }
  onMediaDetaching(e, t) {
    this.bufferFlushed = this.flushing = !1, super.onMediaDetaching(e, t);
  }
  onAudioTracksUpdated(e, {
    audioTracks: t
  }) {
    this.resetTransmuxer(), this.levels = t.map((s) => new _t(s));
  }
  onAudioTrackSwitching(e, t) {
    const s = !!t.url;
    this.trackId = t.id;
    const {
      fragCurrent: i
    } = this;
    i && (i.abortRequests(), this.removeUnbufferedFrags(i.start)), this.resetLoadingState(), s ? (this.switchingTrack = t, this.flushAudioIfNeeded(t), this.state !== C.STOPPED && (this.setInterval(Br), this.state = C.IDLE, this.tick())) : (this.resetTransmuxer(), this.switchingTrack = null, this.bufferedTrack = t, this.clearInterval());
  }
  onManifestLoading() {
    super.onManifestLoading(), this.bufferFlushed = this.flushing = this.audioOnly = !1, this.resetItem(), this.trackId = -1;
  }
  onLevelLoaded(e, t) {
    this.mainDetails = t.details;
    const s = this.cachedTrackLoadedData;
    s && (this.cachedTrackLoadedData = null, this.onAudioTrackLoaded(m.AUDIO_TRACK_LOADED, s));
  }
  onAudioTrackLoaded(e, t) {
    var s;
    const {
      levels: i
    } = this, {
      details: r,
      id: n,
      groupId: o,
      track: c
    } = t;
    if (!i) {
      this.warn(`Audio tracks reset while loading track ${n} "${c.name}" of "${o}"`);
      return;
    }
    const l = this.mainDetails;
    if (!l || r.endCC > l.endCC || l.expired) {
      this.cachedTrackLoadedData = t, this.state !== C.STOPPED && (this.state = C.WAITING_TRACK);
      return;
    }
    this.cachedTrackLoadedData = null, this.log(`Audio track ${n} "${c.name}" of "${o}" loaded [${r.startSN},${r.endSN}]${r.lastPartSn ? `[part-${r.lastPartSn}-${r.lastPartIndex}]` : ""},duration:${r.totalduration}`);
    const h = i[n];
    let u = 0;
    if (r.live || (s = h.details) != null && s.live) {
      if (this.checkLiveUpdate(r), r.deltaUpdateFailed)
        return;
      if (h.details) {
        var d;
        u = this.alignPlaylists(r, h.details, (d = this.levelLastLoaded) == null ? void 0 : d.details);
      }
      r.alignedSliding || (jn(r, l), r.alignedSliding || fs(r, l), u = r.fragmentStart);
    }
    h.details = r, this.levelLastLoaded = h, this.startFragRequested || this.setStartPosition(l, u), this.hls.trigger(m.AUDIO_TRACK_UPDATED, {
      details: r,
      id: n,
      groupId: t.groupId
    }), this.state === C.WAITING_TRACK && !this.waitForCdnTuneIn(r) && (this.state = C.IDLE), this.tick();
  }
  _handleFragmentLoadProgress(e) {
    var t;
    const s = e.frag, {
      part: i,
      payload: r
    } = e, {
      config: n,
      trackId: o,
      levels: c
    } = this;
    if (!c) {
      this.warn(`Audio tracks were reset while fragment load was in progress. Fragment ${s.sn} of level ${s.level} will not be buffered`);
      return;
    }
    const l = c[o];
    if (!l) {
      this.warn("Audio track is undefined on fragment load progress");
      return;
    }
    const h = l.details;
    if (!h) {
      this.warn("Audio track details undefined on fragment load progress"), this.removeUnbufferedFrags(s.start);
      return;
    }
    const u = n.defaultAudioCodec || l.audioCodec || "mp4a.40.2";
    let d = this.transmuxer;
    d || (d = this.transmuxer = new ma(this.hls, G.AUDIO, this._handleTransmuxComplete.bind(this), this._handleTransmuxerFlush.bind(this)));
    const f = this.initPTS[s.cc], g = (t = s.initSegment) == null ? void 0 : t.data;
    if (f !== void 0) {
      const E = i ? i.index : -1, y = E !== -1, S = new Ti(s.level, s.sn, s.stats.chunkCount, r.byteLength, E, y);
      d.push(r, g, u, "", s, i, h.totalduration, !1, S, f);
    } else {
      this.log(`Unknown video PTS for cc ${s.cc}, waiting for video PTS before demuxing audio frag ${s.sn} of [${h.startSN} ,${h.endSN}],track ${o}`);
      const {
        cache: p
      } = this.waitingData = this.waitingData || {
        frag: s,
        part: i,
        cache: new Xn(),
        complete: !1
      };
      p.push(new Uint8Array(r)), this.state !== C.STOPPED && (this.state = C.WAITING_INIT_PTS);
    }
  }
  _handleFragmentLoadComplete(e) {
    if (this.waitingData) {
      this.waitingData.complete = !0;
      return;
    }
    super._handleFragmentLoadComplete(e);
  }
  onBufferReset() {
    this.mediaBuffer = null;
  }
  onBufferCreated(e, t) {
    this.bufferFlushed = this.flushing = !1;
    const s = t.tracks.audio;
    s && (this.mediaBuffer = s.buffer || null);
  }
  onFragLoading(e, t) {
    !this.audioOnly && t.frag.type === G.MAIN && ue(t.frag) && (this.mainFragLoading = t, this.state === C.IDLE && this.tick());
  }
  onFragBuffered(e, t) {
    const {
      frag: s,
      part: i
    } = t;
    if (s.type !== G.AUDIO) {
      !this.audioOnly && s.type === G.MAIN && !s.elementaryStreams.video && !s.elementaryStreams.audiovideo && (this.audioOnly = !0, this.mainFragLoading = null);
      return;
    }
    if (this.fragContextChanged(s)) {
      this.warn(`Fragment ${s.sn}${i ? " p: " + i.index : ""} of level ${s.level} finished buffering, but was aborted. state: ${this.state}, audioSwitch: ${this.switchingTrack ? this.switchingTrack.name : "false"}`);
      return;
    }
    if (ue(s)) {
      this.fragPrevious = s;
      const r = this.switchingTrack;
      r && (this.bufferedTrack = r, this.switchingTrack = null, this.hls.trigger(m.AUDIO_TRACK_SWITCHED, te({}, r)));
    }
    this.fragBufferedComplete(s, i), this.media && this.tick();
  }
  onError(e, t) {
    var s;
    if (t.fatal) {
      this.state = C.ERROR;
      return;
    }
    switch (t.details) {
      case R.FRAG_GAP:
      case R.FRAG_PARSING_ERROR:
      case R.FRAG_DECRYPT_ERROR:
      case R.FRAG_LOAD_ERROR:
      case R.FRAG_LOAD_TIMEOUT:
      case R.KEY_LOAD_ERROR:
      case R.KEY_LOAD_TIMEOUT:
        this.onFragmentOrKeyLoadError(G.AUDIO, t);
        break;
      case R.AUDIO_TRACK_LOAD_ERROR:
      case R.AUDIO_TRACK_LOAD_TIMEOUT:
      case R.LEVEL_PARSING_ERROR:
        !t.levelRetry && this.state === C.WAITING_TRACK && ((s = t.context) == null ? void 0 : s.type) === z.AUDIO_TRACK && (this.state = C.IDLE);
        break;
      case R.BUFFER_ADD_CODEC_ERROR:
      case R.BUFFER_APPEND_ERROR:
        if (t.parent !== "audio")
          return;
        this.resetLoadingState();
        break;
      case R.BUFFER_FULL_ERROR:
        if (t.parent !== "audio")
          return;
        this.reduceLengthAndFlushBuffer(t) && (this.bufferedTrack = null, super.flushMainBuffer(0, Number.POSITIVE_INFINITY, "audio"));
        break;
      case R.INTERNAL_EXCEPTION:
        this.recoverWorkerError(t);
        break;
    }
  }
  onBufferFlushing(e, {
    type: t
  }) {
    t !== ie.VIDEO && (this.flushing = !0);
  }
  onBufferFlushed(e, {
    type: t
  }) {
    if (t !== ie.VIDEO) {
      this.flushing = !1, this.bufferFlushed = !0, this.state === C.ENDED && (this.state = C.IDLE);
      const s = this.mediaBuffer || this.media;
      s && (this.afterBufferFlushed(s, t, G.AUDIO), this.tick());
    }
  }
  _handleTransmuxComplete(e) {
    var t;
    const s = "audio", {
      hls: i
    } = this, {
      remuxResult: r,
      chunkMeta: n
    } = e, o = this.getCurrentContext(n);
    if (!o) {
      this.resetWhenMissingContext(n);
      return;
    }
    const {
      frag: c,
      part: l,
      level: h
    } = o, {
      details: u
    } = h, {
      audio: d,
      text: f,
      id3: g,
      initSegment: p
    } = r;
    if (this.fragContextChanged(c) || !u) {
      this.fragmentTracker.removeFragment(c);
      return;
    }
    if (this.state = C.PARSING, this.switchingTrack && d && this.completeAudioSwitch(this.switchingTrack), p != null && p.tracks) {
      const E = c.initSegment || c;
      this._bufferInitSegment(h, p.tracks, E, n), i.trigger(m.FRAG_PARSING_INIT_SEGMENT, {
        frag: E,
        id: s,
        tracks: p.tracks
      });
    }
    if (d) {
      const {
        startPTS: E,
        endPTS: y,
        startDTS: S,
        endDTS: T
      } = d;
      l && (l.elementaryStreams[ie.AUDIO] = {
        startPTS: E,
        endPTS: y,
        startDTS: S,
        endDTS: T
      }), c.setElementaryStreamInfo(ie.AUDIO, E, y, S, T), this.bufferFragmentData(d, c, l, n);
    }
    if (g != null && (t = g.samples) != null && t.length) {
      const E = re({
        id: s,
        frag: c,
        details: u
      }, g);
      i.trigger(m.FRAG_PARSING_METADATA, E);
    }
    if (f) {
      const E = re({
        id: s,
        frag: c,
        details: u
      }, f);
      i.trigger(m.FRAG_PARSING_USERDATA, E);
    }
  }
  _bufferInitSegment(e, t, s, i) {
    if (this.state !== C.PARSING || (t.video && delete t.video, t.audiovideo && delete t.audiovideo, !t.audio))
      return;
    const r = t.audio;
    r.id = G.AUDIO;
    const n = e.audioCodec;
    this.log(`Init audio buffer, container:${r.container}, codecs[level/parsed]=[${n}/${r.codec}]`), n && n.split(",").length === 1 && (r.levelCodec = n), this.hls.trigger(m.BUFFER_CODECS, t);
    const o = r.initSegment;
    if (o != null && o.byteLength) {
      const c = {
        type: "audio",
        frag: s,
        part: null,
        chunkMeta: i,
        parent: s.type,
        data: o
      };
      this.hls.trigger(m.BUFFER_APPENDING, c);
    }
    this.tickImmediate();
  }
  loadFragment(e, t, s) {
    const i = this.fragmentTracker.getState(e);
    if (this.switchingTrack || i === ce.NOT_LOADED || i === ce.PARTIAL) {
      var r;
      if (!ue(e))
        this._loadInitSegment(e, t);
      else if ((r = t.details) != null && r.live && !this.initPTS[e.cc]) {
        this.log(`Waiting for video PTS in continuity counter ${e.cc} of live stream before loading audio fragment ${e.sn} of level ${this.trackId}`), this.state = C.WAITING_INIT_PTS;
        const n = this.mainDetails;
        n && n.fragmentStart !== t.details.fragmentStart && fs(t.details, n);
      } else
        super.loadFragment(e, t, s);
    } else
      this.clearTrackerIfNeeded(e);
  }
  flushAudioIfNeeded(e) {
    if (this.media && this.bufferedTrack) {
      const {
        name: t,
        lang: s,
        assocLang: i,
        characteristics: r,
        audioCodec: n,
        channels: o
      } = this.bufferedTrack;
      st({
        name: t,
        lang: s,
        assocLang: i,
        characteristics: r,
        audioCodec: n,
        channels: o
      }, e, tt) || (cs(e.url, this.hls) ? (this.log("Switching audio track : flushing all audio"), super.flushMainBuffer(0, Number.POSITIVE_INFINITY, "audio"), this.bufferedTrack = null) : this.bufferedTrack = e);
    }
  }
  completeAudioSwitch(e) {
    const {
      hls: t
    } = this;
    this.flushAudioIfNeeded(e), this.bufferedTrack = e, this.switchingTrack = null, t.trigger(m.AUDIO_TRACK_SWITCHED, te({}, e));
  }
}
class Ci extends Ve {
  constructor(e, t) {
    super(t, e.logger), this.hls = void 0, this.canLoad = !1, this.timer = -1, this.hls = e;
  }
  destroy() {
    this.clearTimer(), this.hls = this.log = this.warn = null;
  }
  clearTimer() {
    this.timer !== -1 && (self.clearTimeout(this.timer), this.timer = -1);
  }
  startLoad() {
    this.canLoad = !0, this.loadPlaylist();
  }
  stopLoad() {
    this.canLoad = !1, this.clearTimer();
  }
  switchParams(e, t, s) {
    const i = t == null ? void 0 : t.renditionReports;
    if (i) {
      let r = -1;
      for (let n = 0; n < i.length; n++) {
        const o = i[n];
        let c;
        try {
          c = new self.URL(o.URI, t.url).href;
        } catch (l) {
          this.warn(`Could not construct new URL for Rendition Report: ${l}`), c = o.URI || "";
        }
        if (c === e) {
          r = n;
          break;
        } else c === e.substring(0, c.length) && (r = n);
      }
      if (r !== -1) {
        const n = i[r], o = parseInt(n["LAST-MSN"]) || (t == null ? void 0 : t.lastPartSn);
        let c = parseInt(n["LAST-PART"]) || (t == null ? void 0 : t.lastPartIndex);
        if (this.hls.config.lowLatencyMode) {
          const h = Math.min(t.age - t.partTarget, t.targetduration);
          c >= 0 && h > t.partTarget && (c += 1);
        }
        const l = s && tr(s);
        return new sr(o, c >= 0 ? c : void 0, l);
      }
    }
  }
  loadPlaylist(e) {
    this.clearTimer();
  }
  loadingPlaylist(e, t) {
    this.clearTimer();
  }
  shouldLoadPlaylist(e) {
    return this.canLoad && !!e && !!e.url && (!e.details || e.details.live);
  }
  getUrlWithDirectives(e, t) {
    if (t)
      try {
        return t.addDirectives(e);
      } catch (s) {
        this.warn(`Could not construct new URL with HLS Delivery Directives: ${s}`);
      }
    return e;
  }
  playlistLoaded(e, t, s) {
    const {
      details: i,
      stats: r
    } = t, n = self.performance.now(), o = r.loading.first ? Math.max(0, n - r.loading.first) : 0;
    i.advancedDateTime = Date.now() - o;
    const c = this.hls.config.timelineOffset;
    if (c !== i.appliedTimelineOffset) {
      const h = Math.max(c || 0, 0);
      i.appliedTimelineOffset = h, i.fragments.forEach((u) => {
        u.start = u.playlistOffset + h;
      });
    }
    if (i.live || s != null && s.live) {
      const h = "levelInfo" in t ? t.levelInfo : t.track;
      if (i.reloaded(s), s && i.fragments.length > 0) {
        bl(s, i);
        const S = i.playlistParsingError;
        if (S) {
          this.warn(S);
          const T = this.hls;
          if (!T.config.ignorePlaylistParsingErrors) {
            var l;
            const {
              networkDetails: v
            } = t;
            T.trigger(m.ERROR, {
              type: K.NETWORK_ERROR,
              details: R.LEVEL_PARSING_ERROR,
              fatal: !1,
              url: i.url,
              error: S,
              reason: S.message,
              level: t.level || void 0,
              parent: (l = i.fragments[0]) == null ? void 0 : l.type,
              networkDetails: v,
              stats: r
            });
            return;
          }
          i.playlistParsingError = null;
        }
      }
      i.requestScheduled === -1 && (i.requestScheduled = r.loading.start);
      const u = this.hls.mainForwardBufferInfo, d = u ? u.end - u.len : 0, f = (i.edge - d) * 1e3, g = Vn(i, f);
      if (i.requestScheduled + g < n ? i.requestScheduled = n : i.requestScheduled += g, this.log(`live playlist ${e} ${i.advanced ? "REFRESHED " + i.lastPartSn + "-" + i.lastPartIndex : i.updated ? "UPDATED" : "MISSED"}`), !this.canLoad || !i.live)
        return;
      let p, E, y;
      if (i.canBlockReload && i.endSN && i.advanced) {
        const S = this.hls.config.lowLatencyMode, T = i.lastPartSn, v = i.endSN, x = i.lastPartIndex, _ = x !== -1, A = T === v;
        _ ? A ? (E = v + 1, y = S ? 0 : x) : (E = T, y = S ? x + 1 : i.maxPartIndex) : E = v + 1;
        const b = i.age, D = b + i.ageHeader;
        let L = Math.min(D - i.partTarget, i.targetduration * 1.5);
        if (L > 0) {
          if (D > i.targetduration * 3)
            this.log(`Playlist last advanced ${b.toFixed(2)}s ago. Omitting segment and part directives.`), E = void 0, y = void 0;
          else if (s != null && s.tuneInGoal && D - i.partTarget > s.tuneInGoal)
            this.warn(`CDN Tune-in goal increased from: ${s.tuneInGoal} to: ${L} with playlist age: ${i.age}`), L = 0;
          else {
            const k = Math.floor(L / i.targetduration);
            if (E += k, y !== void 0) {
              const F = Math.round(L % i.targetduration / i.partTarget);
              y += F;
            }
            this.log(`CDN Tune-in age: ${i.ageHeader}s last advanced ${b.toFixed(2)}s goal: ${L} skip sn ${k} to part ${y}`);
          }
          i.tuneInGoal = L;
        }
        if (p = this.getDeliveryDirectives(i, t.deliveryDirectives, E, y), S || !A) {
          i.requestScheduled = n, this.loadingPlaylist(h, p);
          return;
        }
      } else (i.canBlockReload || i.canSkipUntil) && (p = this.getDeliveryDirectives(i, t.deliveryDirectives, E, y));
      p && E !== void 0 && i.canBlockReload && (i.requestScheduled = r.loading.first + Math.max(g - o * 2, g / 2)), this.scheduleLoading(h, p, i);
    } else
      this.clearTimer();
  }
  scheduleLoading(e, t, s) {
    const i = s || e.details;
    if (!i) {
      this.loadingPlaylist(e, t);
      return;
    }
    const r = self.performance.now(), n = i.requestScheduled;
    if (r >= n) {
      this.loadingPlaylist(e, t);
      return;
    }
    const o = n - r;
    this.log(`reload live playlist ${e.name || e.bitrate + "bps"} in ${Math.round(o)} ms`), this.clearTimer(), this.timer = self.setTimeout(() => this.loadingPlaylist(e, t), o);
  }
  getDeliveryDirectives(e, t, s, i) {
    let r = tr(e);
    return t != null && t.skip && e.deltaUpdateFailed && (s = t.msn, i = t.part, r = Jt.No), new sr(s, i, r);
  }
  checkRetry(e) {
    const t = e.details, s = hs(e), i = e.errorAction, {
      action: r,
      retryCount: n = 0,
      retryConfig: o
    } = i || {}, c = !!i && !!o && (r === ge.RetryRequest || !i.resolved && r === ge.SendAlternateToPenaltyBox);
    if (c) {
      var l;
      if (n >= o.maxNumRetry)
        return !1;
      if (s && (l = e.context) != null && l.deliveryDirectives)
        this.warn(`Retrying playlist loading ${n + 1}/${o.maxNumRetry} after "${t}" without delivery-directives`), this.loadPlaylist();
      else {
        const h = Ei(o, n);
        this.clearTimer(), this.timer = self.setTimeout(() => this.loadPlaylist(), h), this.warn(`Retrying playlist loading ${n + 1}/${o.maxNumRetry} after "${t}" in ${h}ms`);
      }
      e.levelRetry = !0, i.resolved = !0;
    }
    return c;
  }
}
function pa(a, e) {
  if (a.length !== e.length)
    return !1;
  for (let t = 0; t < a.length; t++)
    if (!Ot(a[t].attrs, e[t].attrs))
      return !1;
  return !0;
}
function Ot(a, e, t) {
  const s = a["STABLE-RENDITION-ID"];
  return s && !t ? s === e["STABLE-RENDITION-ID"] : !(t || ["LANGUAGE", "NAME", "CHARACTERISTICS", "AUTOSELECT", "DEFAULT", "FORCED", "ASSOC-LANGUAGE"]).some((i) => a[i] !== e[i]);
}
function ni(a, e) {
  return e.label.toLowerCase() === a.name.toLowerCase() && (!e.language || e.language.toLowerCase() === (a.lang || "").toLowerCase());
}
class Mc extends Ci {
  constructor(e) {
    super(e, "audio-track-controller"), this.tracks = [], this.groupIds = null, this.tracksInGroup = [], this.trackId = -1, this.currentTrack = null, this.selectDefaultTrack = !0, this.registerListeners();
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.MANIFEST_PARSED, this.onManifestParsed, this), e.on(m.LEVEL_LOADING, this.onLevelLoading, this), e.on(m.LEVEL_SWITCHING, this.onLevelSwitching, this), e.on(m.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), e.on(m.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.MANIFEST_PARSED, this.onManifestParsed, this), e.off(m.LEVEL_LOADING, this.onLevelLoading, this), e.off(m.LEVEL_SWITCHING, this.onLevelSwitching, this), e.off(m.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), e.off(m.ERROR, this.onError, this);
  }
  destroy() {
    this.unregisterListeners(), this.tracks.length = 0, this.tracksInGroup.length = 0, this.currentTrack = null, super.destroy();
  }
  onManifestLoading() {
    this.tracks = [], this.tracksInGroup = [], this.groupIds = null, this.currentTrack = null, this.trackId = -1, this.selectDefaultTrack = !0;
  }
  onManifestParsed(e, t) {
    this.tracks = t.audioTracks || [];
  }
  onAudioTrackLoaded(e, t) {
    const {
      id: s,
      groupId: i,
      details: r
    } = t, n = this.tracksInGroup[s];
    if (!n || n.groupId !== i) {
      this.warn(`Audio track with id:${s} and group:${i} not found in active group ${n == null ? void 0 : n.groupId}`);
      return;
    }
    const o = n.details;
    n.details = t.details, this.log(`Audio track ${s} "${n.name}" lang:${n.lang} group:${i} loaded [${r.startSN}-${r.endSN}]`), s === this.trackId && this.playlistLoaded(s, t, o);
  }
  onLevelLoading(e, t) {
    this.switchLevel(t.level);
  }
  onLevelSwitching(e, t) {
    this.switchLevel(t.level);
  }
  switchLevel(e) {
    const t = this.hls.levels[e];
    if (!t)
      return;
    const s = t.audioGroups || null, i = this.groupIds;
    let r = this.currentTrack;
    if (!s || (i == null ? void 0 : i.length) !== (s == null ? void 0 : s.length) || s != null && s.some((o) => (i == null ? void 0 : i.indexOf(o)) === -1)) {
      this.groupIds = s, this.trackId = -1, this.currentTrack = null;
      const o = this.tracks.filter((d) => !s || s.indexOf(d.groupId) !== -1);
      if (o.length)
        this.selectDefaultTrack && !o.some((d) => d.default) && (this.selectDefaultTrack = !1), o.forEach((d, f) => {
          d.id = f;
        });
      else if (!r && !this.tracksInGroup.length)
        return;
      this.tracksInGroup = o;
      const c = this.hls.config.audioPreference;
      if (!r && c) {
        const d = we(c, o, tt);
        if (d > -1)
          r = o[d];
        else {
          const f = we(c, this.tracks);
          r = this.tracks[f];
        }
      }
      let l = this.findTrackId(r);
      l === -1 && r && (l = this.findTrackId(null));
      const h = {
        audioTracks: o
      };
      this.log(`Updating audio tracks, ${o.length} track(s) found in group(s): ${s == null ? void 0 : s.join(",")}`), this.hls.trigger(m.AUDIO_TRACKS_UPDATED, h);
      const u = this.trackId;
      if (l !== -1 && u === -1)
        this.setAudioTrack(l);
      else if (o.length && u === -1) {
        var n;
        const d = new Error(`No audio track selected for current audio group-ID(s): ${(n = this.groupIds) == null ? void 0 : n.join(",")} track count: ${o.length}`);
        this.warn(d.message), this.hls.trigger(m.ERROR, {
          type: K.MEDIA_ERROR,
          details: R.AUDIO_TRACK_LOAD_ERROR,
          fatal: !0,
          error: d
        });
      }
    }
  }
  onError(e, t) {
    t.fatal || !t.context || t.context.type === z.AUDIO_TRACK && t.context.id === this.trackId && (!this.groupIds || this.groupIds.indexOf(t.context.groupId) !== -1) && this.checkRetry(t);
  }
  get allAudioTracks() {
    return this.tracks;
  }
  get audioTracks() {
    return this.tracksInGroup;
  }
  get audioTrack() {
    return this.trackId;
  }
  set audioTrack(e) {
    this.selectDefaultTrack = !1, this.setAudioTrack(e);
  }
  setAudioOption(e) {
    const t = this.hls;
    if (t.config.audioPreference = e, e) {
      const s = this.allAudioTracks;
      if (this.selectDefaultTrack = !1, s.length) {
        const i = this.currentTrack;
        if (i && st(e, i, tt))
          return i;
        const r = we(e, this.tracksInGroup, tt);
        if (r > -1) {
          const n = this.tracksInGroup[r];
          return this.setAudioTrack(r), n;
        } else if (i) {
          let n = t.loadLevel;
          n === -1 && (n = t.firstAutoLevel);
          const o = Yo(e, t.levels, s, n, tt);
          if (o === -1)
            return null;
          t.nextLoadLevel = o;
        }
        if (e.channels || e.audioCodec) {
          const n = we(e, s);
          if (n > -1)
            return s[n];
        }
      }
    }
    return null;
  }
  setAudioTrack(e) {
    const t = this.tracksInGroup;
    if (e < 0 || e >= t.length) {
      this.warn(`Invalid audio track id: ${e}`);
      return;
    }
    this.selectDefaultTrack = !1;
    const s = this.currentTrack, i = t[e], r = i.details && !i.details.live;
    if (e === this.trackId && i === s && r || (this.log(`Switching to audio-track ${e} "${i.name}" lang:${i.lang} group:${i.groupId} channels:${i.channels}`), this.trackId = e, this.currentTrack = i, this.hls.trigger(m.AUDIO_TRACK_SWITCHING, te({}, i)), r))
      return;
    const n = this.switchParams(i.url, s == null ? void 0 : s.details, i.details);
    this.loadPlaylist(n);
  }
  findTrackId(e) {
    const t = this.tracksInGroup;
    for (let s = 0; s < t.length; s++) {
      const i = t[s];
      if (!(this.selectDefaultTrack && !i.default) && (!e || st(e, i, tt)))
        return s;
    }
    if (e) {
      const {
        name: s,
        lang: i,
        assocLang: r,
        characteristics: n,
        audioCodec: o,
        channels: c
      } = e;
      for (let l = 0; l < t.length; l++) {
        const h = t[l];
        if (st({
          name: s,
          lang: i,
          assocLang: r,
          characteristics: n,
          audioCodec: o,
          channels: c
        }, h, tt))
          return l;
      }
      for (let l = 0; l < t.length; l++) {
        const h = t[l];
        if (Ot(e.attrs, h.attrs, ["LANGUAGE", "ASSOC-LANGUAGE", "CHARACTERISTICS"]))
          return l;
      }
      for (let l = 0; l < t.length; l++) {
        const h = t[l];
        if (Ot(e.attrs, h.attrs, ["LANGUAGE"]))
          return l;
      }
    }
    return -1;
  }
  loadPlaylist(e) {
    super.loadPlaylist();
    const t = this.currentTrack;
    this.shouldLoadPlaylist(t) && cs(t.url, this.hls) && this.scheduleLoading(t, e);
  }
  loadingPlaylist(e, t) {
    super.loadingPlaylist(e, t);
    const s = e.id, i = e.groupId, r = this.getUrlWithDirectives(e.url, t), n = e.details, o = n == null ? void 0 : n.age;
    this.log(`Loading audio-track ${s} "${e.name}" lang:${e.lang} group:${i}${(t == null ? void 0 : t.msn) !== void 0 ? " at sn " + t.msn + " part " + t.part : ""}${o && n.live ? " age " + o.toFixed(1) + (n.type && " " + n.type || "") : ""} ${r}`), this.hls.trigger(m.AUDIO_TRACK_LOADING, {
      url: r,
      id: s,
      groupId: i,
      deliveryDirectives: t || null,
      track: e
    });
  }
}
class Nc {
  constructor(e) {
    this.tracks = void 0, this.queues = {
      video: [],
      audio: [],
      audiovideo: []
    }, this.tracks = e;
  }
  destroy() {
    this.tracks = this.queues = null;
  }
  append(e, t, s) {
    if (this.queues === null || this.tracks === null)
      return;
    const i = this.queues[t];
    i.push(e), i.length === 1 && !s && this.executeNext(t);
  }
  appendBlocker(e) {
    return new Promise((t) => {
      const s = {
        label: "async-blocker",
        execute: t,
        onStart: () => {
        },
        onComplete: () => {
        },
        onError: () => {
        }
      };
      this.append(s, e);
    });
  }
  prependBlocker(e) {
    return new Promise((t) => {
      if (this.queues) {
        const s = {
          label: "async-blocker-prepend",
          execute: t,
          onStart: () => {
          },
          onComplete: () => {
          },
          onError: () => {
          }
        };
        this.queues[e].unshift(s);
      }
    });
  }
  removeBlockers() {
    this.queues !== null && [this.queues.video, this.queues.audio, this.queues.audiovideo].forEach((e) => {
      var t;
      const s = (t = e[0]) == null ? void 0 : t.label;
      (s === "async-blocker" || s === "async-blocker-prepend") && (e[0].execute(), e.splice(0, 1));
    });
  }
  unblockAudio(e) {
    if (this.queues === null)
      return;
    this.queues.audio[0] === e && this.shiftAndExecuteNext("audio");
  }
  executeNext(e) {
    if (this.queues === null || this.tracks === null)
      return;
    const t = this.queues[e];
    if (t.length) {
      const i = t[0];
      try {
        i.execute();
      } catch (r) {
        var s;
        if (i.onError(r), this.queues === null || this.tracks === null)
          return;
        const n = (s = this.tracks[e]) == null ? void 0 : s.buffer;
        n != null && n.updating || this.shiftAndExecuteNext(e);
      }
    }
  }
  shiftAndExecuteNext(e) {
    this.queues !== null && (this.queues[e].shift(), this.executeNext(e));
  }
  current(e) {
    var t;
    return ((t = this.queues) == null ? void 0 : t[e][0]) || null;
  }
  toString() {
    const {
      queues: e,
      tracks: t
    } = this;
    return e === null || t === null ? "<destroyed>" : `
${this.list("video")}
${this.list("audio")}
${this.list("audiovideo")}}`;
  }
  list(e) {
    var t, s;
    return (t = this.queues) != null && t[e] || (s = this.tracks) != null && s[e] ? `${e}: (${this.listSbInfo(e)}) ${this.listOps(e)}` : "";
  }
  listSbInfo(e) {
    var t;
    const s = (t = this.tracks) == null ? void 0 : t[e], i = s == null ? void 0 : s.buffer;
    return i ? `SourceBuffer${i.updating ? " updating" : ""}${s.ended ? " ended" : ""}${s.ending ? " ending" : ""}` : "none";
  }
  listOps(e) {
    var t;
    return ((t = this.queues) == null ? void 0 : t[e].map((s) => s.label).join(", ")) || "";
  }
}
const Ur = /(avc[1234]|hvc1|hev1|dvh[1e]|vp09|av01)(?:\.[^.,]+)+/, Ea = "HlsJsTrackRemovedError";
class Bc extends Error {
  constructor(e) {
    super(e), this.name = Ea;
  }
}
class Uc extends Ve {
  constructor(e, t) {
    super("buffer-controller", e.logger), this.hls = void 0, this.fragmentTracker = void 0, this.details = null, this._objectUrl = null, this.operationQueue = null, this.bufferCodecEventsTotal = 0, this.media = null, this.mediaSource = null, this.lastMpegAudioChunk = null, this.blockedAudioAppend = null, this.lastVideoAppendEnd = 0, this.appendSource = void 0, this.transferData = void 0, this.overrides = void 0, this.appendErrors = {
      audio: 0,
      video: 0,
      audiovideo: 0
    }, this.tracks = {}, this.sourceBuffers = [[null, null], [null, null]], this._onEndStreaming = (s) => {
      var i;
      this.hls && ((i = this.mediaSource) == null ? void 0 : i.readyState) === "open" && this.hls.pauseBuffering();
    }, this._onStartStreaming = (s) => {
      this.hls && this.hls.resumeBuffering();
    }, this._onMediaSourceOpen = (s) => {
      const {
        media: i,
        mediaSource: r
      } = this;
      s && this.log("Media source opened"), !(!i || !r) && (r.removeEventListener("sourceopen", this._onMediaSourceOpen), i.removeEventListener("emptied", this._onMediaEmptied), this.updateDuration(), this.hls.trigger(m.MEDIA_ATTACHED, {
        media: i,
        mediaSource: r
      }), this.mediaSource !== null && this.checkPendingTracks());
    }, this._onMediaSourceClose = () => {
      this.log("Media source closed");
    }, this._onMediaSourceEnded = () => {
      this.log("Media source ended");
    }, this._onMediaEmptied = () => {
      const {
        mediaSrc: s,
        _objectUrl: i
      } = this;
      s !== i && this.error(`Media element src was set while attaching MediaSource (${i} > ${s})`);
    }, this.hls = e, this.fragmentTracker = t, this.appendSource = lo(ze(e.config.preferManagedMediaSource)), this.initTracks(), this.registerListeners();
  }
  hasSourceTypes() {
    return Object.keys(this.tracks).length > 0;
  }
  destroy() {
    this.unregisterListeners(), this.details = null, this.lastMpegAudioChunk = this.blockedAudioAppend = null, this.transferData = this.overrides = void 0, this.operationQueue && (this.operationQueue.destroy(), this.operationQueue = null), this.hls = this.fragmentTracker = null, this._onMediaSourceOpen = this._onMediaSourceClose = null, this._onMediaSourceEnded = null, this._onStartStreaming = this._onEndStreaming = null;
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.MANIFEST_PARSED, this.onManifestParsed, this), e.on(m.BUFFER_RESET, this.onBufferReset, this), e.on(m.BUFFER_APPENDING, this.onBufferAppending, this), e.on(m.BUFFER_CODECS, this.onBufferCodecs, this), e.on(m.BUFFER_EOS, this.onBufferEos, this), e.on(m.BUFFER_FLUSHING, this.onBufferFlushing, this), e.on(m.LEVEL_UPDATED, this.onLevelUpdated, this), e.on(m.FRAG_PARSED, this.onFragParsed, this), e.on(m.FRAG_CHANGED, this.onFragChanged, this), e.on(m.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.MANIFEST_PARSED, this.onManifestParsed, this), e.off(m.BUFFER_RESET, this.onBufferReset, this), e.off(m.BUFFER_APPENDING, this.onBufferAppending, this), e.off(m.BUFFER_CODECS, this.onBufferCodecs, this), e.off(m.BUFFER_EOS, this.onBufferEos, this), e.off(m.BUFFER_FLUSHING, this.onBufferFlushing, this), e.off(m.LEVEL_UPDATED, this.onLevelUpdated, this), e.off(m.FRAG_PARSED, this.onFragParsed, this), e.off(m.FRAG_CHANGED, this.onFragChanged, this), e.off(m.ERROR, this.onError, this);
  }
  transferMedia() {
    const {
      media: e,
      mediaSource: t
    } = this;
    if (!e)
      return null;
    const s = {};
    if (this.operationQueue) {
      const r = this.isUpdating();
      r || this.operationQueue.removeBlockers();
      const n = this.isQueued();
      (r || n) && this.warn(`Transfering MediaSource with${n ? " operations in queue" : ""}${r ? " updating SourceBuffer(s)" : ""} ${this.operationQueue}`), this.operationQueue.destroy();
    }
    const i = this.transferData;
    return !this.sourceBufferCount && i && i.mediaSource === t ? re(s, i.tracks) : this.sourceBuffers.forEach((r) => {
      const [n] = r;
      n && (s[n] = re({}, this.tracks[n]), this.removeBuffer(n)), r[0] = r[1] = null;
    }), {
      media: e,
      mediaSource: t,
      tracks: s
    };
  }
  initTracks() {
    const e = {};
    this.sourceBuffers = [[null, null], [null, null]], this.tracks = e, this.resetQueue(), this.resetAppendErrors(), this.lastMpegAudioChunk = this.blockedAudioAppend = null, this.lastVideoAppendEnd = 0;
  }
  onManifestLoading() {
    this.bufferCodecEventsTotal = 0, this.details = null;
  }
  onManifestParsed(e, t) {
    var s;
    let i = 2;
    (t.audio && !t.video || !t.altAudio) && (i = 1), this.bufferCodecEventsTotal = i, this.log(`${i} bufferCodec event(s) expected.`), (s = this.transferData) != null && s.mediaSource && this.sourceBufferCount && i && this.bufferCreated();
  }
  onMediaAttaching(e, t) {
    const s = this.media = t.media, i = ze(this.appendSource);
    if (this.transferData = this.overrides = void 0, s && i) {
      const r = !!t.mediaSource;
      (r || t.overrides) && (this.transferData = t, this.overrides = t.overrides);
      const n = this.mediaSource = t.mediaSource || new i();
      if (this.assignMediaSource(n), r)
        this._objectUrl = s.src, this.attachTransferred();
      else {
        const o = this._objectUrl = self.URL.createObjectURL(n);
        if (this.appendSource)
          try {
            s.removeAttribute("src");
            const c = self.ManagedMediaSource;
            s.disableRemotePlayback = s.disableRemotePlayback || c && n instanceof c, $r(s), $c(s, o), s.load();
          } catch {
            s.src = o;
          }
        else
          s.src = o;
      }
      s.addEventListener("emptied", this._onMediaEmptied);
    }
  }
  assignMediaSource(e) {
    var t, s;
    this.log(`${((t = this.transferData) == null ? void 0 : t.mediaSource) === e ? "transferred" : "created"} media source: ${(s = e.constructor) == null ? void 0 : s.name}`), e.addEventListener("sourceopen", this._onMediaSourceOpen), e.addEventListener("sourceended", this._onMediaSourceEnded), e.addEventListener("sourceclose", this._onMediaSourceClose), this.appendSource && (e.addEventListener("startstreaming", this._onStartStreaming), e.addEventListener("endstreaming", this._onEndStreaming));
  }
  attachTransferred() {
    const e = this.media, t = this.transferData;
    if (!t || !e)
      return;
    const s = this.tracks, i = t.tracks, r = i ? Object.keys(i) : null, n = r ? r.length : 0, o = () => {
      this.media && this.mediaSourceOpenOrEnded && this._onMediaSourceOpen();
    };
    if (i && r && n) {
      if (!this.tracksReady) {
        this.hls.config.startFragPrefetch = !0, this.log("attachTransferred: waiting for SourceBuffer track info");
        return;
      }
      if (this.log(`attachTransferred: (bufferCodecEventsTotal ${this.bufferCodecEventsTotal})
required tracks: ${ae(s, (c, l) => c === "initSegment" ? void 0 : l)};
transfer tracks: ${ae(i, (c, l) => c === "initSegment" ? void 0 : l)}}`), !En(i, s)) {
        t.mediaSource = null, t.tracks = void 0;
        const c = e.currentTime, l = this.details, h = Math.max(c, (l == null ? void 0 : l.fragments[0].start) || 0);
        if (h - c > 1) {
          this.log(`attachTransferred: waiting for playback to reach new tracks start time ${c} -> ${h}`);
          return;
        }
        this.warn(`attachTransferred: resetting MediaSource for incompatible tracks ("${Object.keys(i)}"->"${Object.keys(s)}") start time: ${h} currentTime: ${c}`), this.onMediaDetaching(m.MEDIA_DETACHING, {}), this.onMediaAttaching(m.MEDIA_ATTACHING, t), e.currentTime = h;
        return;
      }
      this.transferData = void 0, r.forEach((c) => {
        const l = c, h = i[l];
        if (h) {
          const u = h.buffer;
          if (u) {
            const d = this.fragmentTracker, f = h.id;
            if (d.hasFragments(f) || d.hasParts(f)) {
              const E = q.getBuffered(u);
              d.detectEvictedFragments(l, E, f, null, !0);
            }
            const g = Bs(l), p = [l, u];
            this.sourceBuffers[g] = p, u.updating && this.operationQueue && this.operationQueue.prependBlocker(l), this.trackSourceBuffer(l, h);
          }
        }
      }), o(), this.bufferCreated();
    } else
      this.log("attachTransferred: MediaSource w/o SourceBuffers"), o();
  }
  get mediaSourceOpenOrEnded() {
    var e;
    const t = (e = this.mediaSource) == null ? void 0 : e.readyState;
    return t === "open" || t === "ended";
  }
  onMediaDetaching(e, t) {
    const s = !!t.transferMedia;
    this.transferData = this.overrides = void 0;
    const {
      media: i,
      mediaSource: r,
      _objectUrl: n
    } = this;
    if (r) {
      if (this.log(`media source ${s ? "transferring" : "detaching"}`), s)
        this.sourceBuffers.forEach(([o]) => {
          o && this.removeBuffer(o);
        }), this.resetQueue();
      else {
        if (this.mediaSourceOpenOrEnded) {
          const o = r.readyState === "open";
          try {
            const c = r.sourceBuffers;
            for (let l = c.length; l--; )
              o && c[l].abort(), r.removeSourceBuffer(c[l]);
            o && r.endOfStream();
          } catch (c) {
            this.warn(`onMediaDetaching: ${c.message} while calling endOfStream`);
          }
        }
        this.sourceBufferCount && this.onBufferReset();
      }
      r.removeEventListener("sourceopen", this._onMediaSourceOpen), r.removeEventListener("sourceended", this._onMediaSourceEnded), r.removeEventListener("sourceclose", this._onMediaSourceClose), this.appendSource && (r.removeEventListener("startstreaming", this._onStartStreaming), r.removeEventListener("endstreaming", this._onEndStreaming)), this.mediaSource = null, this._objectUrl = null;
    }
    i && (i.removeEventListener("emptied", this._onMediaEmptied), s || (n && self.URL.revokeObjectURL(n), this.mediaSrc === n ? (i.removeAttribute("src"), this.appendSource && $r(i), i.load()) : this.warn("media|source.src was changed by a third party - skip cleanup")), this.media = null), this.hls.trigger(m.MEDIA_DETACHED, t);
  }
  onBufferReset() {
    this.sourceBuffers.forEach(([e]) => {
      e && this.resetBuffer(e);
    }), this.initTracks();
  }
  resetBuffer(e) {
    var t;
    const s = (t = this.tracks[e]) == null ? void 0 : t.buffer;
    if (this.removeBuffer(e), s)
      try {
        var i;
        (i = this.mediaSource) != null && i.sourceBuffers.length && this.mediaSource.removeSourceBuffer(s);
      } catch (r) {
        this.warn(`onBufferReset ${e}`, r);
      }
    delete this.tracks[e];
  }
  removeBuffer(e) {
    this.removeBufferListeners(e), this.sourceBuffers[Bs(e)] = [null, null];
    const t = this.tracks[e];
    t && (t.buffer = void 0);
  }
  resetQueue() {
    this.operationQueue && this.operationQueue.destroy(), this.operationQueue = new Nc(this.tracks);
  }
  onBufferCodecs(e, t) {
    const s = this.tracks, i = Object.keys(t);
    this.log(`BUFFER_CODECS: "${i}" (current SB count ${this.sourceBufferCount})`);
    const r = "audiovideo" in t && (s.audio || s.video) || s.audiovideo && ("audio" in t || "video" in t), n = !r && this.sourceBufferCount && this.media && i.some((o) => !s[o]);
    if (r || n) {
      this.warn(`Unsupported transition between "${Object.keys(s)}" and "${i}" SourceBuffers`);
      return;
    }
    i.forEach((o) => {
      var c, l, h;
      const u = t[o], {
        id: d,
        codec: f,
        levelCodec: g,
        container: p,
        metadata: E,
        supplemental: y
      } = u;
      let S = s[o];
      const T = (c = this.transferData) == null || (l = c.tracks) == null ? void 0 : l[o], v = T != null && T.buffer ? T : S, x = (v == null ? void 0 : v.pendingCodec) || (v == null ? void 0 : v.codec), _ = v == null ? void 0 : v.levelCodec;
      S || (S = s[o] = {
        buffer: void 0,
        listeners: [],
        codec: f,
        supplemental: y,
        container: p,
        levelCodec: g,
        metadata: E,
        id: d
      });
      const A = Zt(x, _), b = A == null ? void 0 : A.replace(Ur, "$1");
      let D = Zt(f, g);
      const L = (h = D) == null ? void 0 : h.replace(Ur, "$1");
      D && A && b !== L && (o.slice(0, 5) === "audio" && (D = os(D, this.appendSource)), this.log(`switching codec ${x} to ${D}`), D !== (S.pendingCodec || S.codec) && (S.pendingCodec = D), S.container = p, this.appendChangeType(o, p, D));
    }), (this.tracksReady || this.sourceBufferCount) && (t.tracks = this.sourceBufferTracks), !this.sourceBufferCount && this.mediaSourceOpenOrEnded && this.checkPendingTracks();
  }
  get sourceBufferTracks() {
    return Object.keys(this.tracks).reduce((e, t) => {
      const s = this.tracks[t];
      return e[t] = {
        id: s.id,
        container: s.container,
        codec: s.codec,
        levelCodec: s.levelCodec
      }, e;
    }, {});
  }
  appendChangeType(e, t, s) {
    const i = `${t};codecs=${s}`, r = {
      label: `change-type=${i}`,
      execute: () => {
        const n = this.tracks[e];
        if (n) {
          const o = n.buffer;
          o != null && o.changeType && (this.log(`changing ${e} sourceBuffer type to ${i}`), o.changeType(i), n.codec = s, n.container = t);
        }
        this.shiftAndExecuteNext(e);
      },
      onStart: () => {
      },
      onComplete: () => {
      },
      onError: (n) => {
        this.warn(`Failed to change ${e} SourceBuffer type`, n);
      }
    };
    this.append(r, e, this.isPending(this.tracks[e]));
  }
  blockAudio(e) {
    var t;
    const s = e.start, i = s + e.duration * 0.05;
    if (((t = this.fragmentTracker.getAppendedFrag(s, G.MAIN)) == null ? void 0 : t.gap) === !0)
      return;
    const n = {
      label: "block-audio",
      execute: () => {
        var o;
        const c = this.tracks.video;
        (this.lastVideoAppendEnd > i || c != null && c.buffer && q.isBuffered(c.buffer, i) || ((o = this.fragmentTracker.getAppendedFrag(i, G.MAIN)) == null ? void 0 : o.gap) === !0) && (this.blockedAudioAppend = null, this.shiftAndExecuteNext("audio"));
      },
      onStart: () => {
      },
      onComplete: () => {
      },
      onError: (o) => {
        this.warn("Error executing block-audio operation", o);
      }
    };
    this.blockedAudioAppend = {
      op: n,
      frag: e
    }, this.append(n, "audio", !0);
  }
  unblockAudio() {
    const {
      blockedAudioAppend: e,
      operationQueue: t
    } = this;
    e && t && (this.blockedAudioAppend = null, t.unblockAudio(e.op));
  }
  onBufferAppending(e, t) {
    const {
      tracks: s
    } = this, {
      data: i,
      type: r,
      parent: n,
      frag: o,
      part: c,
      chunkMeta: l
    } = t, h = l.buffering[r], u = o.sn, d = self.performance.now();
    h.start = d;
    const f = o.stats.buffering, g = c ? c.stats.buffering : null;
    f.start === 0 && (f.start = d), g && g.start === 0 && (g.start = d);
    const p = s.audio;
    let E = !1;
    r === "audio" && (p == null ? void 0 : p.container) === "audio/mpeg" && (E = !this.lastMpegAudioChunk || l.id === 1 || this.lastMpegAudioChunk.sn !== l.sn, this.lastMpegAudioChunk = l);
    const y = this.tracks.video, S = y == null ? void 0 : y.buffer;
    if (S && u !== "initSegment") {
      const x = c || o, _ = this.blockedAudioAppend;
      if (r === "audio" && n !== "main" && !this.blockedAudioAppend) {
        const b = x.start + x.duration * 0.05, D = S.buffered, L = this.currentOp("video");
        !D.length && !L ? this.blockAudio(x) : !L && !q.isBuffered(S, b) && this.lastVideoAppendEnd < b && this.blockAudio(x);
      } else if (r === "video") {
        const A = x.end;
        if (_) {
          const b = _.frag.start;
          (A > b || A < this.lastVideoAppendEnd || q.isBuffered(S, b)) && this.unblockAudio();
        }
        this.lastVideoAppendEnd = A;
      }
    }
    const T = (c || o).start, v = {
      label: `append-${r}`,
      execute: () => {
        if (h.executeStart = self.performance.now(), E) {
          const x = this.tracks[r];
          if (x) {
            const _ = x.buffer;
            if (_) {
              const A = T - _.timestampOffset;
              Math.abs(A) >= 0.1 && (this.log(`Updating audio SourceBuffer timestampOffset to ${T} (delta: ${A}) sn: ${u})`), _.timestampOffset = T);
            }
          }
        }
        this.appendExecutor(i, r);
      },
      onStart: () => {
      },
      onComplete: () => {
        const x = self.performance.now();
        h.executeEnd = h.end = x, f.first === 0 && (f.first = x), g && g.first === 0 && (g.first = x);
        const _ = {};
        this.sourceBuffers.forEach(([A, b]) => {
          A && (_[A] = q.getBuffered(b));
        }), this.appendErrors[r] = 0, r === "audio" || r === "video" ? this.appendErrors.audiovideo = 0 : (this.appendErrors.audio = 0, this.appendErrors.video = 0), this.hls.trigger(m.BUFFER_APPENDED, {
          type: r,
          frag: o,
          part: c,
          chunkMeta: l,
          parent: o.type,
          timeRanges: _
        });
      },
      onError: (x) => {
        var _;
        const A = {
          type: K.MEDIA_ERROR,
          parent: o.type,
          details: R.BUFFER_APPEND_ERROR,
          sourceBufferName: r,
          frag: o,
          part: c,
          chunkMeta: l,
          error: x,
          err: x,
          fatal: !1
        }, b = (_ = this.media) == null ? void 0 : _.error;
        if (x.code === DOMException.QUOTA_EXCEEDED_ERR)
          A.details = R.BUFFER_FULL_ERROR;
        else if (x.code === DOMException.INVALID_STATE_ERR && this.mediaSourceOpenOrEnded && !b)
          A.errorAction = Dt(!0);
        else if (x.name === Ea && this.sourceBufferCount === 0)
          A.errorAction = Dt(!0);
        else {
          const D = ++this.appendErrors[r];
          this.warn(`Failed ${D}/${this.hls.config.appendErrorMaxRetry} times to append segment in "${r}" sourceBuffer (${b || "no media error"})`), (D >= this.hls.config.appendErrorMaxRetry || b) && (A.fatal = !0);
        }
        this.hls.trigger(m.ERROR, A);
      }
    };
    this.append(v, r, this.isPending(this.tracks[r]));
  }
  getFlushOp(e, t, s) {
    return this.log(`queuing "${e}" remove ${t}-${s}`), {
      label: "remove",
      execute: () => {
        this.removeExecutor(e, t, s);
      },
      onStart: () => {
      },
      onComplete: () => {
        this.hls.trigger(m.BUFFER_FLUSHED, {
          type: e
        });
      },
      onError: (i) => {
        this.warn(`Failed to remove ${t}-${s} from "${e}" SourceBuffer`, i);
      }
    };
  }
  onBufferFlushing(e, t) {
    const {
      type: s,
      startOffset: i,
      endOffset: r
    } = t;
    s ? this.append(this.getFlushOp(s, i, r), s) : this.sourceBuffers.forEach(([n]) => {
      n && this.append(this.getFlushOp(n, i, r), n);
    });
  }
  onFragParsed(e, t) {
    const {
      frag: s,
      part: i
    } = t, r = [], n = i ? i.elementaryStreams : s.elementaryStreams;
    n[ie.AUDIOVIDEO] ? r.push("audiovideo") : (n[ie.AUDIO] && r.push("audio"), n[ie.VIDEO] && r.push("video"));
    const o = () => {
      const c = self.performance.now();
      s.stats.buffering.end = c, i && (i.stats.buffering.end = c);
      const l = i ? i.stats : s.stats;
      this.hls.trigger(m.FRAG_BUFFERED, {
        frag: s,
        part: i,
        stats: l,
        id: s.type
      });
    };
    r.length === 0 && this.warn(`Fragments must have at least one ElementaryStreamType set. type: ${s.type} level: ${s.level} sn: ${s.sn}`), this.blockBuffers(o, r).catch((c) => {
      this.warn(`Fragment buffered callback ${c}`), this.stepOperationQueue(this.sourceBufferTypes);
    });
  }
  onFragChanged(e, t) {
    this.trimBuffers();
  }
  get bufferedToEnd() {
    return this.sourceBufferCount > 0 && !this.sourceBuffers.some(([e]) => {
      var t, s;
      return e && (!((t = this.tracks[e]) != null && t.ended) || ((s = this.tracks[e]) == null ? void 0 : s.ending));
    });
  }
  // on BUFFER_EOS mark matching sourcebuffer(s) as "ending" and "ended" and queue endOfStream after remaining operations(s)
  // an undefined data.type will mark all buffers as EOS.
  onBufferEos(e, t) {
    var s;
    this.sourceBuffers.forEach(([n]) => {
      if (n) {
        const o = this.tracks[n];
        (!t.type || t.type === n) && (o.ending = !0, o.ended || (o.ended = !0, this.log(`${n} buffer reached EOS`)));
      }
    });
    const i = ((s = this.overrides) == null ? void 0 : s.endOfStream) !== !1;
    this.sourceBufferCount > 0 && !this.sourceBuffers.some(([n]) => {
      var o;
      return n && !((o = this.tracks[n]) != null && o.ended);
    }) && (i ? (this.log("Queueing EOS"), this.blockUntilOpen(() => {
      this.tracksEnded();
      const {
        mediaSource: n
      } = this;
      if (!n || n.readyState !== "open") {
        n && this.log(`Could not call mediaSource.endOfStream(). mediaSource.readyState: ${n.readyState}`);
        return;
      }
      this.log("Calling mediaSource.endOfStream()"), n.endOfStream(), this.hls.trigger(m.BUFFERED_TO_END, void 0);
    })) : (this.tracksEnded(), this.hls.trigger(m.BUFFERED_TO_END, void 0)));
  }
  tracksEnded() {
    this.sourceBuffers.forEach(([e]) => {
      if (e !== null) {
        const t = this.tracks[e];
        t && (t.ending = !1);
      }
    });
  }
  onLevelUpdated(e, {
    details: t
  }) {
    t.fragments.length && (this.details = t, this.updateDuration());
  }
  updateDuration() {
    const e = this.getDurationAndRange();
    e && this.blockUntilOpen(() => this.updateMediaSource(e));
  }
  onError(e, t) {
    if (t.details === R.BUFFER_APPEND_ERROR && t.frag) {
      var s;
      const i = (s = t.errorAction) == null ? void 0 : s.nextAutoLevel;
      M(i) && i !== t.frag.level && this.resetAppendErrors();
    }
  }
  resetAppendErrors() {
    this.appendErrors = {
      audio: 0,
      video: 0,
      audiovideo: 0
    };
  }
  trimBuffers() {
    const {
      hls: e,
      details: t,
      media: s
    } = this;
    if (!s || t === null || !this.sourceBufferCount)
      return;
    const i = e.config, r = s.currentTime, n = t.levelTargetDuration, o = t.live && i.liveBackBufferLength !== null ? i.liveBackBufferLength : i.backBufferLength;
    if (M(o) && o >= 0) {
      const c = Math.max(o, n), l = Math.floor(r / n) * n - c;
      this.flushBackBuffer(r, n, l);
    }
    if (M(i.frontBufferFlushThreshold) && i.frontBufferFlushThreshold > 0) {
      const c = Math.max(i.maxBufferLength, i.frontBufferFlushThreshold), l = Math.max(c, n), h = Math.floor(r / n) * n + l;
      this.flushFrontBuffer(r, n, h);
    }
  }
  flushBackBuffer(e, t, s) {
    this.sourceBuffers.forEach(([i, r]) => {
      if (r) {
        const o = q.getBuffered(r);
        if (o.length > 0 && s > o.start(0)) {
          var n;
          this.hls.trigger(m.BACK_BUFFER_REACHED, {
            bufferEnd: s
          });
          const c = this.tracks[i];
          if ((n = this.details) != null && n.live)
            this.hls.trigger(m.LIVE_BACK_BUFFER_REACHED, {
              bufferEnd: s
            });
          else if (c != null && c.ended) {
            this.log(`Cannot flush ${i} back buffer while SourceBuffer is in ended state`);
            return;
          }
          this.hls.trigger(m.BUFFER_FLUSHING, {
            startOffset: 0,
            endOffset: s,
            type: i
          });
        }
      }
    });
  }
  flushFrontBuffer(e, t, s) {
    this.sourceBuffers.forEach(([i, r]) => {
      if (r) {
        const n = q.getBuffered(r), o = n.length;
        if (o < 2)
          return;
        const c = n.start(o - 1), l = n.end(o - 1);
        if (s > c || e >= c && e <= l)
          return;
        this.hls.trigger(m.BUFFER_FLUSHING, {
          startOffset: c,
          endOffset: 1 / 0,
          type: i
        });
      }
    });
  }
  /**
   * Update Media Source duration to current level duration or override to Infinity if configuration parameter
   * 'liveDurationInfinity` is set to `true`
   * More details: https://github.com/video-dev/hls.js/issues/355
   */
  getDurationAndRange() {
    var e;
    const {
      details: t,
      mediaSource: s
    } = this;
    if (!t || !this.media || (s == null ? void 0 : s.readyState) !== "open")
      return null;
    const i = t.edge;
    if (t.live && this.hls.config.liveDurationInfinity) {
      if (t.fragments.length && t.live && s.setLiveSeekableRange) {
        const l = Math.max(0, t.fragmentStart), h = Math.max(l, i);
        return {
          duration: 1 / 0,
          start: l,
          end: h
        };
      }
      return {
        duration: 1 / 0
      };
    }
    const r = (e = this.overrides) == null ? void 0 : e.duration;
    if (r)
      return M(r) ? {
        duration: r
      } : null;
    const n = this.media.duration, o = M(s.duration) ? s.duration : 0;
    return i > o && i > n || !M(n) ? {
      duration: i
    } : null;
  }
  updateMediaSource({
    duration: e,
    start: t,
    end: s
  }) {
    const i = this.mediaSource;
    !this.media || !i || i.readyState !== "open" || (i.duration !== e && (M(e) && this.log(`Updating MediaSource duration to ${e.toFixed(3)}`), i.duration = e), t !== void 0 && s !== void 0 && (this.log(`MediaSource duration is set to ${i.duration}. Setting seekable range to ${t}-${s}.`), i.setLiveSeekableRange(t, s)));
  }
  get tracksReady() {
    const e = this.pendingTrackCount;
    return e > 0 && (e >= this.bufferCodecEventsTotal || this.isPending(this.tracks.audiovideo));
  }
  checkPendingTracks() {
    const {
      bufferCodecEventsTotal: e,
      pendingTrackCount: t,
      tracks: s
    } = this;
    if (this.log(`checkPendingTracks (pending: ${t} codec events expected: ${e}) ${ae(s)}`), this.tracksReady) {
      var i;
      const r = (i = this.transferData) == null ? void 0 : i.tracks;
      r && Object.keys(r).length ? this.attachTransferred() : this.createSourceBuffers();
    }
  }
  bufferCreated() {
    if (this.sourceBufferCount) {
      const e = {};
      this.sourceBuffers.forEach(([t, s]) => {
        if (t) {
          const i = this.tracks[t];
          e[t] = {
            buffer: s,
            container: i.container,
            codec: i.codec,
            supplemental: i.supplemental,
            levelCodec: i.levelCodec,
            id: i.id,
            metadata: i.metadata
          };
        }
      }), this.hls.trigger(m.BUFFER_CREATED, {
        tracks: e
      }), this.log(`SourceBuffers created. Running queue: ${this.operationQueue}`), this.sourceBuffers.forEach(([t]) => {
        this.executeNext(t);
      });
    } else {
      const e = new Error("could not create source buffer for media codec(s)");
      this.hls.trigger(m.ERROR, {
        type: K.MEDIA_ERROR,
        details: R.BUFFER_INCOMPATIBLE_CODECS_ERROR,
        fatal: !0,
        error: e,
        reason: e.message
      });
    }
  }
  createSourceBuffers() {
    const {
      tracks: e,
      sourceBuffers: t,
      mediaSource: s
    } = this;
    if (!s)
      throw new Error("createSourceBuffers called when mediaSource was null");
    for (const r in e) {
      const n = r, o = e[n];
      if (this.isPending(o)) {
        const c = this.getTrackCodec(o, n), l = `${o.container};codecs=${c}`;
        o.codec = c, this.log(`creating sourceBuffer(${l})${this.currentOp(n) ? " Queued" : ""} ${ae(o)}`);
        try {
          const h = s.addSourceBuffer(l), u = Bs(n), d = [n, h];
          t[u] = d, o.buffer = h;
        } catch (h) {
          var i;
          this.error(`error while trying to add sourceBuffer: ${h.message}`), this.shiftAndExecuteNext(n), (i = this.operationQueue) == null || i.removeBlockers(), delete this.tracks[n], this.hls.trigger(m.ERROR, {
            type: K.MEDIA_ERROR,
            details: R.BUFFER_ADD_CODEC_ERROR,
            fatal: !1,
            error: h,
            sourceBufferName: n,
            mimeType: l,
            parent: o.id
          });
          return;
        }
        this.trackSourceBuffer(n, o);
      }
    }
    this.bufferCreated();
  }
  getTrackCodec(e, t) {
    const s = e.supplemental;
    let i = e.codec;
    s && (t === "video" || t === "audiovideo") && Qs(s, "video") && (i = ko(i, s));
    const r = Zt(i, e.levelCodec);
    return r ? t.slice(0, 5) === "audio" ? os(r, this.appendSource) : r : "";
  }
  trackSourceBuffer(e, t) {
    const s = t.buffer;
    if (!s)
      return;
    const i = this.getTrackCodec(t, e);
    this.tracks[e] = {
      buffer: s,
      codec: i,
      container: t.container,
      levelCodec: t.levelCodec,
      supplemental: t.supplemental,
      metadata: t.metadata,
      id: t.id,
      listeners: []
    }, this.removeBufferListeners(e), this.addBufferListener(e, "updatestart", this.onSBUpdateStart), this.addBufferListener(e, "updateend", this.onSBUpdateEnd), this.addBufferListener(e, "error", this.onSBUpdateError), this.appendSource && this.addBufferListener(e, "bufferedchange", (r, n) => {
      const o = n.removedRanges;
      o != null && o.length && this.hls.trigger(m.BUFFER_FLUSHED, {
        type: r
      });
    });
  }
  get mediaSrc() {
    var e, t;
    const s = ((e = this.media) == null || (t = e.querySelector) == null ? void 0 : t.call(e, "source")) || this.media;
    return s == null ? void 0 : s.src;
  }
  onSBUpdateStart(e) {
    const t = this.currentOp(e);
    t && t.onStart();
  }
  onSBUpdateEnd(e) {
    var t;
    if (((t = this.mediaSource) == null ? void 0 : t.readyState) === "closed") {
      this.resetBuffer(e);
      return;
    }
    const s = this.currentOp(e);
    s && (s.onComplete(), this.shiftAndExecuteNext(e));
  }
  onSBUpdateError(e, t) {
    var s;
    const i = new Error(`${e} SourceBuffer error. MediaSource readyState: ${(s = this.mediaSource) == null ? void 0 : s.readyState}`);
    this.error(`${i}`, t), this.hls.trigger(m.ERROR, {
      type: K.MEDIA_ERROR,
      details: R.BUFFER_APPENDING_ERROR,
      sourceBufferName: e,
      error: i,
      fatal: !1
    });
    const r = this.currentOp(e);
    r && r.onError(i);
  }
  // This method must result in an updateend event; if remove is not called, onSBUpdateEnd must be called manually
  removeExecutor(e, t, s) {
    const {
      media: i,
      mediaSource: r
    } = this, n = this.tracks[e], o = n == null ? void 0 : n.buffer;
    if (!i || !r || !o) {
      this.warn(`Attempting to remove from the ${e} SourceBuffer, but it does not exist`), this.shiftAndExecuteNext(e);
      return;
    }
    const c = M(i.duration) ? i.duration : 1 / 0, l = M(r.duration) ? r.duration : 1 / 0, h = Math.max(0, t), u = Math.min(s, c, l);
    u > h && (!n.ending || n.ended) ? (n.ended = !1, this.log(`Removing [${h},${u}] from the ${e} SourceBuffer`), o.remove(h, u)) : this.shiftAndExecuteNext(e);
  }
  // This method must result in an updateend event; if append is not called, onSBUpdateEnd must be called manually
  appendExecutor(e, t) {
    const s = this.tracks[t], i = s == null ? void 0 : s.buffer;
    if (!i)
      throw new Bc(`Attempting to append to the ${t} SourceBuffer, but it does not exist`);
    s.ending = !1, s.ended = !1, i.appendBuffer(e);
  }
  blockUntilOpen(e) {
    if (this.isUpdating() || this.isQueued())
      this.blockBuffers(e).catch((t) => {
        this.warn(`SourceBuffer blocked callback ${t}`), this.stepOperationQueue(this.sourceBufferTypes);
      });
    else
      try {
        e();
      } catch (t) {
        this.warn(`Callback run without blocking ${this.operationQueue} ${t}`);
      }
  }
  isUpdating() {
    return this.sourceBuffers.some(([e, t]) => e && t.updating);
  }
  isQueued() {
    return this.sourceBuffers.some(([e]) => e && !!this.currentOp(e));
  }
  isPending(e) {
    return !!e && !e.buffer;
  }
  // Enqueues an operation to each SourceBuffer queue which, upon execution, resolves a promise. When all promises
  // resolve, the onUnblocked function is executed. Functions calling this method do not need to unblock the queue
  // upon completion, since we already do it here
  blockBuffers(e, t = this.sourceBufferTypes) {
    if (!t.length)
      return this.log("Blocking operation requested, but no SourceBuffers exist"), Promise.resolve().then(e);
    const {
      operationQueue: s
    } = this, i = t.map((n) => this.appendBlocker(n));
    return t.length > 1 && !!this.blockedAudioAppend && this.unblockAudio(), Promise.all(i).then((n) => {
      s === this.operationQueue && (e(), this.stepOperationQueue(this.sourceBufferTypes));
    });
  }
  stepOperationQueue(e) {
    e.forEach((t) => {
      var s;
      const i = (s = this.tracks[t]) == null ? void 0 : s.buffer;
      !i || i.updating || this.shiftAndExecuteNext(t);
    });
  }
  append(e, t, s) {
    this.operationQueue && this.operationQueue.append(e, t, s);
  }
  appendBlocker(e) {
    if (this.operationQueue)
      return this.operationQueue.appendBlocker(e);
  }
  currentOp(e) {
    return this.operationQueue ? this.operationQueue.current(e) : null;
  }
  executeNext(e) {
    e && this.operationQueue && this.operationQueue.executeNext(e);
  }
  shiftAndExecuteNext(e) {
    this.operationQueue && this.operationQueue.shiftAndExecuteNext(e);
  }
  get pendingTrackCount() {
    return Object.keys(this.tracks).reduce((e, t) => e + (this.isPending(this.tracks[t]) ? 1 : 0), 0);
  }
  get sourceBufferCount() {
    return this.sourceBuffers.reduce((e, [t]) => e + (t ? 1 : 0), 0);
  }
  get sourceBufferTypes() {
    return this.sourceBuffers.map(([e]) => e).filter((e) => !!e);
  }
  addBufferListener(e, t, s) {
    const i = this.tracks[e];
    if (!i)
      return;
    const r = i.buffer;
    if (!r)
      return;
    const n = s.bind(this, e);
    i.listeners.push({
      event: t,
      listener: n
    }), r.addEventListener(t, n);
  }
  removeBufferListeners(e) {
    const t = this.tracks[e];
    if (!t)
      return;
    const s = t.buffer;
    s && (t.listeners.forEach((i) => {
      s.removeEventListener(i.event, i.listener);
    }), t.listeners.length = 0);
  }
}
function $r(a) {
  const e = a.querySelectorAll("source");
  [].slice.call(e).forEach((t) => {
    a.removeChild(t);
  });
}
function $c(a, e) {
  const t = self.document.createElement("source");
  t.type = "video/mp4", t.src = e, a.appendChild(t);
}
function Bs(a) {
  return a === "audio" ? 1 : 0;
}
class Pi {
  constructor(e) {
    this.hls = void 0, this.autoLevelCapping = void 0, this.firstLevel = void 0, this.media = void 0, this.restrictedLevels = void 0, this.timer = void 0, this.clientRect = void 0, this.streamController = void 0, this.hls = e, this.autoLevelCapping = Number.POSITIVE_INFINITY, this.firstLevel = -1, this.media = null, this.restrictedLevels = [], this.timer = void 0, this.clientRect = null, this.registerListeners();
  }
  setStreamController(e) {
    this.streamController = e;
  }
  destroy() {
    this.hls && this.unregisterListener(), this.timer && this.stopCapping(), this.media = null, this.clientRect = null, this.hls = this.streamController = null;
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.FPS_DROP_LEVEL_CAPPING, this.onFpsDropLevelCapping, this), e.on(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.on(m.MANIFEST_PARSED, this.onManifestParsed, this), e.on(m.LEVELS_UPDATED, this.onLevelsUpdated, this), e.on(m.BUFFER_CODECS, this.onBufferCodecs, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this);
  }
  unregisterListener() {
    const {
      hls: e
    } = this;
    e.off(m.FPS_DROP_LEVEL_CAPPING, this.onFpsDropLevelCapping, this), e.off(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.off(m.MANIFEST_PARSED, this.onManifestParsed, this), e.off(m.LEVELS_UPDATED, this.onLevelsUpdated, this), e.off(m.BUFFER_CODECS, this.onBufferCodecs, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this);
  }
  onFpsDropLevelCapping(e, t) {
    const s = this.hls.levels[t.droppedLevel];
    this.isLevelAllowed(s) && this.restrictedLevels.push({
      bitrate: s.bitrate,
      height: s.height,
      width: s.width
    });
  }
  onMediaAttaching(e, t) {
    this.media = t.media instanceof HTMLVideoElement ? t.media : null, this.clientRect = null, this.timer && this.hls.levels.length && this.detectPlayerSize();
  }
  onManifestParsed(e, t) {
    const s = this.hls;
    this.restrictedLevels = [], this.firstLevel = t.firstLevel, s.config.capLevelToPlayerSize && t.video && this.startCapping();
  }
  onLevelsUpdated(e, t) {
    this.timer && M(this.autoLevelCapping) && this.detectPlayerSize();
  }
  // Only activate capping when playing a video stream; otherwise, multi-bitrate audio-only streams will be restricted
  // to the first level
  onBufferCodecs(e, t) {
    this.hls.config.capLevelToPlayerSize && t.video && this.startCapping();
  }
  onMediaDetaching() {
    this.stopCapping(), this.media = null;
  }
  detectPlayerSize() {
    if (this.media) {
      if (this.mediaHeight <= 0 || this.mediaWidth <= 0) {
        this.clientRect = null;
        return;
      }
      const e = this.hls.levels;
      if (e.length) {
        const t = this.hls, s = this.getMaxLevel(e.length - 1);
        s !== this.autoLevelCapping && t.logger.log(`Setting autoLevelCapping to ${s}: ${e[s].height}p@${e[s].bitrate} for media ${this.mediaWidth}x${this.mediaHeight}`), t.autoLevelCapping = s, t.autoLevelEnabled && t.autoLevelCapping > this.autoLevelCapping && this.streamController && this.streamController.nextLevelSwitch(), this.autoLevelCapping = t.autoLevelCapping;
      }
    }
  }
  /*
   * returns level should be the one with the dimensions equal or greater than the media (player) dimensions (so the video will be downscaled)
   */
  getMaxLevel(e) {
    const t = this.hls.levels;
    if (!t.length)
      return -1;
    const s = t.filter((i, r) => this.isLevelAllowed(i) && r <= e);
    return this.clientRect = null, Pi.getMaxLevelByMediaSize(s, this.mediaWidth, this.mediaHeight);
  }
  startCapping() {
    this.timer || (this.autoLevelCapping = Number.POSITIVE_INFINITY, self.clearInterval(this.timer), this.timer = self.setInterval(this.detectPlayerSize.bind(this), 1e3), this.detectPlayerSize());
  }
  stopCapping() {
    this.restrictedLevels = [], this.firstLevel = -1, this.autoLevelCapping = Number.POSITIVE_INFINITY, this.timer && (self.clearInterval(this.timer), this.timer = void 0);
  }
  getDimensions() {
    if (this.clientRect)
      return this.clientRect;
    const e = this.media, t = {
      width: 0,
      height: 0
    };
    if (e) {
      const s = e.getBoundingClientRect();
      t.width = s.width, t.height = s.height, !t.width && !t.height && (t.width = s.right - s.left || e.width || 0, t.height = s.bottom - s.top || e.height || 0);
    }
    return this.clientRect = t, t;
  }
  get mediaWidth() {
    return this.getDimensions().width * this.contentScaleFactor;
  }
  get mediaHeight() {
    return this.getDimensions().height * this.contentScaleFactor;
  }
  get contentScaleFactor() {
    let e = 1;
    if (!this.hls.config.ignoreDevicePixelRatio)
      try {
        e = self.devicePixelRatio;
      } catch {
      }
    return Math.min(e, this.hls.config.maxDevicePixelRatio);
  }
  isLevelAllowed(e) {
    return !this.restrictedLevels.some((s) => e.bitrate === s.bitrate && e.width === s.width && e.height === s.height);
  }
  static getMaxLevelByMediaSize(e, t, s) {
    if (!(e != null && e.length))
      return -1;
    const i = (o, c) => c ? o.width !== c.width || o.height !== c.height : !0;
    let r = e.length - 1;
    const n = Math.max(t, s);
    for (let o = 0; o < e.length; o += 1) {
      const c = e[o];
      if ((c.width >= n || c.height >= n) && i(c, e[o + 1])) {
        r = o;
        break;
      }
    }
    return r;
  }
}
const Gc = {
  /**
   * text file, such as a manifest or playlist
   */
  MANIFEST: "m",
  /**
   * audio only
   */
  AUDIO: "a",
  /**
   * video only
   */
  VIDEO: "v",
  /**
   * muxed audio and video
   */
  MUXED: "av",
  /**
   * init segment
   */
  INIT: "i",
  /**
   * caption or subtitle
   */
  CAPTION: "c",
  /**
   * ISOBMFF timed text track
   */
  TIMED_TEXT: "tt",
  /**
   * cryptographic key, license or certificate.
   */
  KEY: "k",
  /**
   * other
   */
  OTHER: "o"
}, Ee = Gc, Kc = {
  /**
   * HTTP Live Streaming (HLS)
   */
  HLS: "h"
}, Vc = Kc, Hc = "CMCD-Object", Wc = "CMCD-Request", Yc = "CMCD-Session", qc = "CMCD-Status", xt = {
  /**
   * keys whose values vary with the object being requested.
   */
  OBJECT: Hc,
  /**
   * keys whose values vary with each request.
   */
  REQUEST: Wc,
  /**
   * keys whose values are expected to be invariant over the life of the session.
   */
  SESSION: Yc,
  /**
   * keys whose values do not vary with every request or object.
   */
  STATUS: qc
}, jc = {
  [xt.OBJECT]: ["br", "d", "ot", "tb"],
  [xt.REQUEST]: ["bl", "dl", "mtp", "nor", "nrr", "su"],
  [xt.SESSION]: ["cid", "pr", "sf", "sid", "st", "v"],
  [xt.STATUS]: ["bs", "rtp"]
};
class Et {
  constructor(e, t) {
    Array.isArray(e) && (e = e.map((s) => s instanceof Et ? s : new Et(s))), this.value = e, this.params = t;
  }
}
const Xc = "Dict";
function zc(a) {
  return Array.isArray(a) ? JSON.stringify(a) : a instanceof Map ? "Map{}" : a instanceof Set ? "Set{}" : typeof a == "object" ? JSON.stringify(a) : String(a);
}
function Qc(a, e, t, s) {
  return new Error(`failed to ${a} "${zc(e)}" as ${t}`, {
    cause: s
  });
}
function Me(a, e, t) {
  return Qc("serialize", a, e, t);
}
class ya {
  constructor(e) {
    this.description = e;
  }
}
const Gr = "Bare Item", Zc = "Boolean";
function Jc(a) {
  if (typeof a != "boolean")
    throw Me(a, Zc);
  return a ? "?1" : "?0";
}
const eh = "Byte Sequence";
function th(a) {
  if (ArrayBuffer.isView(a) === !1)
    throw Me(a, eh);
  return `:${zl(a)}:`;
}
const sh = "Integer";
function ih(a) {
  return a < -999999999999999 || 999999999999999 < a;
}
function Ta(a) {
  if (ih(a))
    throw Me(a, sh);
  return a.toString();
}
function rh(a) {
  return `@${Ta(a.getTime() / 1e3)}`;
}
const nh = "Decimal";
function ah(a) {
  const e = sa(a, 3);
  if (Math.floor(Math.abs(e)).toString().length > 12)
    throw Me(a, nh);
  const t = e.toString();
  return t.includes(".") ? t : `${t}.0`;
}
const oh = "String", lh = /[\x00-\x1f\x7f]+/;
function ch(a) {
  if (lh.test(a))
    throw Me(a, oh);
  return `"${a.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}
function hh(a) {
  return a.description || a.toString().slice(7, -1);
}
const uh = "Token";
function Kr(a) {
  const e = hh(a);
  if (/^([a-zA-Z*])([!#$%&'*+\-.^_`|~\w:/]*)$/.test(e) === !1)
    throw Me(e, uh);
  return e;
}
function ai(a) {
  switch (typeof a) {
    case "number":
      if (!M(a))
        throw Me(a, Gr);
      return Number.isInteger(a) ? Ta(a) : ah(a);
    case "string":
      return ch(a);
    case "symbol":
      return Kr(a);
    case "boolean":
      return Jc(a);
    case "object":
      if (a instanceof Date)
        return rh(a);
      if (a instanceof Uint8Array)
        return th(a);
      if (a instanceof ya)
        return Kr(a);
    default:
      throw Me(a, Gr);
  }
}
const dh = "Key";
function oi(a) {
  if (/^[a-z*][a-z0-9\-_.*]*$/.test(a) === !1)
    throw Me(a, dh);
  return a;
}
function ki(a) {
  return a == null ? "" : Object.entries(a).map(([e, t]) => t === !0 ? `;${oi(e)}` : `;${oi(e)}=${ai(t)}`).join("");
}
function Sa(a) {
  return a instanceof Et ? `${ai(a.value)}${ki(a.params)}` : ai(a);
}
function fh(a) {
  return `(${a.value.map(Sa).join(" ")})${ki(a.params)}`;
}
function gh(a, e = {
  whitespace: !0
}) {
  if (typeof a != "object")
    throw Me(a, Xc);
  const t = a instanceof Map ? a.entries() : Object.entries(a), s = e != null && e.whitespace ? " " : "";
  return Array.from(t).map(([i, r]) => {
    r instanceof Et || (r = new Et(r));
    let n = oi(i);
    return r.value === !0 ? n += ki(r.params) : (n += "=", Array.isArray(r.value) ? n += fh(r) : n += Sa(r)), n;
  }).join(`,${s}`);
}
function mh(a, e) {
  return gh(a, e);
}
function ph(a) {
  return a === "ot" || a === "sf" || a === "st";
}
function Eh(a) {
  return typeof a == "number" ? M(a) : a != null && a !== "" && a !== !1;
}
const ss = (a) => Math.round(a), yh = (a, e) => (e != null && e.baseUrl && (a = Ql(a, e.baseUrl)), encodeURIComponent(a)), Yt = (a) => ss(a / 100) * 100, Th = {
  /**
   * Bitrate (kbps) rounded integer
   */
  br: ss,
  /**
   * Duration (milliseconds) rounded integer
   */
  d: ss,
  /**
   * Buffer Length (milliseconds) rounded nearest 100ms
   */
  bl: Yt,
  /**
   * Deadline (milliseconds) rounded nearest 100ms
   */
  dl: Yt,
  /**
   * Measured Throughput (kbps) rounded nearest 100kbps
   */
  mtp: Yt,
  /**
   * Next Object Request URL encoded
   */
  nor: yh,
  /**
   * Requested maximum throughput (kbps) rounded nearest 100kbps
   */
  rtp: Yt,
  /**
   * Top Bitrate (kbps) rounded integer
   */
  tb: ss
};
function Sh(a, e) {
  const t = {};
  if (a == null || typeof a != "object")
    return t;
  const s = Object.keys(a).sort(), i = re({}, Th, e == null ? void 0 : e.formatters), r = e == null ? void 0 : e.filter;
  return s.forEach((n) => {
    if (r != null && r(n))
      return;
    let o = a[n];
    const c = i[n];
    c && (o = c(o, e)), !(n === "v" && o === 1) && (n == "pr" && o === 1 || Eh(o) && (ph(n) && typeof o == "string" && (o = new ya(o)), t[n] = o));
  }), t;
}
function va(a, e = {}) {
  return a ? mh(Sh(a, e), re({
    whitespace: !1
  }, e)) : "";
}
function vh(a, e = {}) {
  const t = {};
  if (!a)
    return t;
  const s = Object.entries(a), i = Object.entries(jc).concat(Object.entries((e == null ? void 0 : e.customHeaderMap) || {})), r = s.reduce((n, o) => {
    var c, l;
    const [h, u] = o, d = ((c = i.find((f) => f[1].includes(h))) === null || c === void 0 ? void 0 : c[0]) || xt.REQUEST;
    return (l = n[d]) !== null && l !== void 0 || (n[d] = {}), n[d][h] = u, n;
  }, {});
  return Object.entries(r).reduce((n, [o, c]) => (n[o] = va(c, e), n), t);
}
function xh(a, e, t) {
  return re(a, vh(e, t));
}
const Ah = "CMCD";
function Lh(a, e = {}) {
  if (!a)
    return "";
  const t = va(a, e);
  return `${Ah}=${encodeURIComponent(t)}`;
}
const Vr = /CMCD=[^&#]+/;
function Ih(a, e, t) {
  const s = Lh(e, t);
  if (!s)
    return a;
  if (Vr.test(a))
    return a.replace(Vr, s);
  const i = a.includes("?") ? "&" : "?";
  return `${a}${i}${s}`;
}
class Rh {
  constructor(e) {
    this.hls = void 0, this.config = void 0, this.media = void 0, this.sid = void 0, this.cid = void 0, this.useHeaders = !1, this.includeKeys = void 0, this.initialized = !1, this.starved = !1, this.buffering = !0, this.audioBuffer = void 0, this.videoBuffer = void 0, this.onWaiting = () => {
      this.initialized && (this.starved = !0), this.buffering = !0;
    }, this.onPlaying = () => {
      this.initialized || (this.initialized = !0), this.buffering = !1;
    }, this.applyPlaylistData = (i) => {
      try {
        this.apply(i, {
          ot: Ee.MANIFEST,
          su: !this.initialized
        });
      } catch (r) {
        this.hls.logger.warn("Could not generate manifest CMCD data.", r);
      }
    }, this.applyFragmentData = (i) => {
      try {
        const {
          frag: r,
          part: n
        } = i, o = this.hls.levels[r.level], c = this.getObjectType(r), l = {
          d: (n || r).duration * 1e3,
          ot: c
        };
        (c === Ee.VIDEO || c === Ee.AUDIO || c == Ee.MUXED) && (l.br = o.bitrate / 1e3, l.tb = this.getTopBandwidth(c) / 1e3, l.bl = this.getBufferLength(c));
        const h = n ? this.getNextPart(n) : this.getNextFrag(r);
        h != null && h.url && h.url !== r.url && (l.nor = h.url), this.apply(i, l);
      } catch (r) {
        this.hls.logger.warn("Could not generate segment CMCD data.", r);
      }
    }, this.hls = e;
    const t = this.config = e.config, {
      cmcd: s
    } = t;
    s != null && (t.pLoader = this.createPlaylistLoader(), t.fLoader = this.createFragmentLoader(), this.sid = s.sessionId || e.sessionId, this.cid = s.contentId, this.useHeaders = s.useHeaders === !0, this.includeKeys = s.includeKeys, this.registerListeners());
  }
  registerListeners() {
    const e = this.hls;
    e.on(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(m.MEDIA_DETACHED, this.onMediaDetached, this), e.on(m.BUFFER_CREATED, this.onBufferCreated, this);
  }
  unregisterListeners() {
    const e = this.hls;
    e.off(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(m.MEDIA_DETACHED, this.onMediaDetached, this), e.off(m.BUFFER_CREATED, this.onBufferCreated, this);
  }
  destroy() {
    this.unregisterListeners(), this.onMediaDetached(), this.hls = this.config = this.audioBuffer = this.videoBuffer = null, this.onWaiting = this.onPlaying = this.media = null;
  }
  onMediaAttached(e, t) {
    this.media = t.media, this.media.addEventListener("waiting", this.onWaiting), this.media.addEventListener("playing", this.onPlaying);
  }
  onMediaDetached() {
    this.media && (this.media.removeEventListener("waiting", this.onWaiting), this.media.removeEventListener("playing", this.onPlaying), this.media = null);
  }
  onBufferCreated(e, t) {
    var s, i;
    this.audioBuffer = (s = t.tracks.audio) == null ? void 0 : s.buffer, this.videoBuffer = (i = t.tracks.video) == null ? void 0 : i.buffer;
  }
  /**
   * Create baseline CMCD data
   */
  createData() {
    var e;
    return {
      v: 1,
      sf: Vc.HLS,
      sid: this.sid,
      cid: this.cid,
      pr: (e = this.media) == null ? void 0 : e.playbackRate,
      mtp: this.hls.bandwidthEstimate / 1e3
    };
  }
  /**
   * Apply CMCD data to a request.
   */
  apply(e, t = {}) {
    re(t, this.createData());
    const s = t.ot === Ee.INIT || t.ot === Ee.VIDEO || t.ot === Ee.MUXED;
    this.starved && s && (t.bs = !0, t.su = !0, this.starved = !1), t.su == null && (t.su = this.buffering);
    const {
      includeKeys: i
    } = this;
    i && (t = Object.keys(t).reduce((n, o) => (i.includes(o) && (n[o] = t[o]), n), {}));
    const r = {
      baseUrl: e.url
    };
    this.useHeaders ? (e.headers || (e.headers = {}), xh(e.headers, t, r)) : e.url = Ih(e.url, t, r);
  }
  getNextFrag(e) {
    var t;
    const s = (t = this.hls.levels[e.level]) == null ? void 0 : t.details;
    if (s) {
      const i = e.sn - s.startSN;
      return s.fragments[i + 1];
    }
  }
  getNextPart(e) {
    var t, s;
    const {
      index: i,
      fragment: r
    } = e, n = (t = this.hls.levels[r.level]) == null || (s = t.details) == null ? void 0 : s.partList;
    if (n) {
      const {
        sn: o
      } = r;
      for (let c = n.length - 1; c >= 0; c--) {
        const l = n[c];
        if (l.index === i && l.fragment.sn === o)
          return n[c + 1];
      }
    }
  }
  /**
   * The CMCD object type.
   */
  getObjectType(e) {
    const {
      type: t
    } = e;
    if (t === "subtitle")
      return Ee.TIMED_TEXT;
    if (e.sn === "initSegment")
      return Ee.INIT;
    if (t === "audio")
      return Ee.AUDIO;
    if (t === "main")
      return this.hls.audioTracks.length ? Ee.VIDEO : Ee.MUXED;
  }
  /**
   * Get the highest bitrate.
   */
  getTopBandwidth(e) {
    let t = 0, s;
    const i = this.hls;
    if (e === Ee.AUDIO)
      s = i.audioTracks;
    else {
      const r = i.maxAutoLevel, n = r > -1 ? r + 1 : i.levels.length;
      s = i.levels.slice(0, n);
    }
    for (const r of s)
      r.bitrate > t && (t = r.bitrate);
    return t > 0 ? t : NaN;
  }
  /**
   * Get the buffer length for a media type in milliseconds
   */
  getBufferLength(e) {
    const t = this.media, s = e === Ee.AUDIO ? this.audioBuffer : this.videoBuffer;
    return !s || !t ? NaN : q.bufferInfo(s, t.currentTime, this.config.maxBufferHole).len * 1e3;
  }
  /**
   * Create a playlist loader
   */
  createPlaylistLoader() {
    const {
      pLoader: e
    } = this.config, t = this.applyPlaylistData, s = e || this.config.loader;
    return class {
      constructor(r) {
        this.loader = void 0, this.loader = new s(r);
      }
      get stats() {
        return this.loader.stats;
      }
      get context() {
        return this.loader.context;
      }
      destroy() {
        this.loader.destroy();
      }
      abort() {
        this.loader.abort();
      }
      load(r, n, o) {
        t(r), this.loader.load(r, n, o);
      }
    };
  }
  /**
   * Create a playlist loader
   */
  createFragmentLoader() {
    const {
      fLoader: e
    } = this.config, t = this.applyFragmentData, s = e || this.config.loader;
    return class {
      constructor(r) {
        this.loader = void 0, this.loader = new s(r);
      }
      get stats() {
        return this.loader.stats;
      }
      get context() {
        return this.loader.context;
      }
      destroy() {
        this.loader.destroy();
      }
      abort() {
        this.loader.abort();
      }
      load(r, n, o) {
        t(r), this.loader.load(r, n, o);
      }
    };
  }
}
const bh = 3e5;
class _h extends Ve {
  constructor(e) {
    super("content-steering", e.logger), this.hls = void 0, this.loader = null, this.uri = null, this.pathwayId = ".", this._pathwayPriority = null, this.timeToLoad = 300, this.reloadTimer = -1, this.updated = 0, this.started = !1, this.enabled = !0, this.levels = null, this.audioTracks = null, this.subtitleTracks = null, this.penalizedPathways = {}, this.hls = e, this.registerListeners();
  }
  registerListeners() {
    const e = this.hls;
    e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.MANIFEST_LOADED, this.onManifestLoaded, this), e.on(m.MANIFEST_PARSED, this.onManifestParsed, this), e.on(m.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const e = this.hls;
    e && (e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.MANIFEST_LOADED, this.onManifestLoaded, this), e.off(m.MANIFEST_PARSED, this.onManifestParsed, this), e.off(m.ERROR, this.onError, this));
  }
  pathways() {
    return (this.levels || []).reduce((e, t) => (e.indexOf(t.pathwayId) === -1 && e.push(t.pathwayId), e), []);
  }
  get pathwayPriority() {
    return this._pathwayPriority;
  }
  set pathwayPriority(e) {
    this.updatePathwayPriority(e);
  }
  startLoad() {
    if (this.started = !0, this.clearTimeout(), this.enabled && this.uri) {
      if (this.updated) {
        const e = this.timeToLoad * 1e3 - (performance.now() - this.updated);
        if (e > 0) {
          this.scheduleRefresh(this.uri, e);
          return;
        }
      }
      this.loadSteeringManifest(this.uri);
    }
  }
  stopLoad() {
    this.started = !1, this.loader && (this.loader.destroy(), this.loader = null), this.clearTimeout();
  }
  clearTimeout() {
    this.reloadTimer !== -1 && (self.clearTimeout(this.reloadTimer), this.reloadTimer = -1);
  }
  destroy() {
    this.unregisterListeners(), this.stopLoad(), this.hls = null, this.levels = this.audioTracks = this.subtitleTracks = null;
  }
  removeLevel(e) {
    const t = this.levels;
    t && (this.levels = t.filter((s) => s !== e));
  }
  onManifestLoading() {
    this.stopLoad(), this.enabled = !0, this.timeToLoad = 300, this.updated = 0, this.uri = null, this.pathwayId = ".", this.levels = this.audioTracks = this.subtitleTracks = null;
  }
  onManifestLoaded(e, t) {
    const {
      contentSteering: s
    } = t;
    s !== null && (this.pathwayId = s.pathwayId, this.uri = s.uri, this.started && this.startLoad());
  }
  onManifestParsed(e, t) {
    this.audioTracks = t.audioTracks, this.subtitleTracks = t.subtitleTracks;
  }
  onError(e, t) {
    const {
      errorAction: s
    } = t;
    if ((s == null ? void 0 : s.action) === ge.SendAlternateToPenaltyBox && s.flags === _e.MoveAllAlternatesMatchingHost) {
      const i = this.levels;
      let r = this._pathwayPriority, n = this.pathwayId;
      if (t.context) {
        const {
          groupId: o,
          pathwayId: c,
          type: l
        } = t.context;
        o && i ? n = this.getPathwayForGroupId(o, l, n) : c && (n = c);
      }
      n in this.penalizedPathways || (this.penalizedPathways[n] = performance.now()), !r && i && (r = this.pathways()), r && r.length > 1 && (this.updatePathwayPriority(r), s.resolved = this.pathwayId !== n), s.resolved || this.warn(`Could not resolve ${t.details} ("${t.error.message}") with content-steering for Pathway: ${n} levels: ${i && i.length} priorities: ${ae(r)} penalized: ${ae(this.penalizedPathways)}`);
    }
  }
  filterParsedLevels(e) {
    this.levels = e;
    let t = this.getLevelsForPathway(this.pathwayId);
    if (t.length === 0) {
      const s = e[0].pathwayId;
      this.log(`No levels found in Pathway ${this.pathwayId}. Setting initial Pathway to "${s}"`), t = this.getLevelsForPathway(s), this.pathwayId = s;
    }
    return t.length !== e.length && this.log(`Found ${t.length}/${e.length} levels in Pathway "${this.pathwayId}"`), t;
  }
  getLevelsForPathway(e) {
    return this.levels === null ? [] : this.levels.filter((t) => e === t.pathwayId);
  }
  updatePathwayPriority(e) {
    this._pathwayPriority = e;
    let t;
    const s = this.penalizedPathways, i = performance.now();
    Object.keys(s).forEach((r) => {
      i - s[r] > bh && delete s[r];
    });
    for (let r = 0; r < e.length; r++) {
      const n = e[r];
      if (n in s)
        continue;
      if (n === this.pathwayId)
        return;
      const o = this.hls.nextLoadLevel, c = this.hls.levels[o];
      if (t = this.getLevelsForPathway(n), t.length > 0) {
        this.log(`Setting Pathway to "${n}"`), this.pathwayId = n, Yn(t), this.hls.trigger(m.LEVELS_UPDATED, {
          levels: t
        });
        const l = this.hls.levels[o];
        c && l && this.levels && (l.attrs["STABLE-VARIANT-ID"] !== c.attrs["STABLE-VARIANT-ID"] && l.bitrate !== c.bitrate && this.log(`Unstable Pathways change from bitrate ${c.bitrate} to ${l.bitrate}`), this.hls.nextLoadLevel = o);
        break;
      }
    }
  }
  getPathwayForGroupId(e, t, s) {
    const i = this.getLevelsForPathway(s).concat(this.levels || []);
    for (let r = 0; r < i.length; r++)
      if (t === z.AUDIO_TRACK && i[r].hasAudioGroup(e) || t === z.SUBTITLE_TRACK && i[r].hasSubtitleGroup(e))
        return i[r].pathwayId;
    return s;
  }
  clonePathways(e) {
    const t = this.levels;
    if (!t)
      return;
    const s = {}, i = {};
    e.forEach((r) => {
      const {
        ID: n,
        "BASE-ID": o,
        "URI-REPLACEMENT": c
      } = r;
      if (t.some((h) => h.pathwayId === n))
        return;
      const l = this.getLevelsForPathway(o).map((h) => {
        const u = new oe(h.attrs);
        u["PATHWAY-ID"] = n;
        const d = u.AUDIO && `${u.AUDIO}_clone_${n}`, f = u.SUBTITLES && `${u.SUBTITLES}_clone_${n}`;
        d && (s[u.AUDIO] = d, u.AUDIO = d), f && (i[u.SUBTITLES] = f, u.SUBTITLES = f);
        const g = xa(h.uri, u["STABLE-VARIANT-ID"], "PER-VARIANT-URIS", c), p = new _t({
          attrs: u,
          audioCodec: h.audioCodec,
          bitrate: h.bitrate,
          height: h.height,
          name: h.name,
          url: g,
          videoCodec: h.videoCodec,
          width: h.width
        });
        if (h.audioGroups)
          for (let E = 1; E < h.audioGroups.length; E++)
            p.addGroupId("audio", `${h.audioGroups[E]}_clone_${n}`);
        if (h.subtitleGroups)
          for (let E = 1; E < h.subtitleGroups.length; E++)
            p.addGroupId("text", `${h.subtitleGroups[E]}_clone_${n}`);
        return p;
      });
      t.push(...l), Hr(this.audioTracks, s, c, n), Hr(this.subtitleTracks, i, c, n);
    });
  }
  loadSteeringManifest(e) {
    const t = this.hls.config, s = t.loader;
    this.loader && this.loader.destroy(), this.loader = new s(t);
    let i;
    try {
      i = new self.URL(e);
    } catch {
      this.enabled = !1, this.log(`Failed to parse Steering Manifest URI: ${e}`);
      return;
    }
    if (i.protocol !== "data:") {
      const h = (this.hls.bandwidthEstimate || t.abrEwmaDefaultEstimate) | 0;
      i.searchParams.set("_HLS_pathway", this.pathwayId), i.searchParams.set("_HLS_throughput", "" + h);
    }
    const r = {
      responseType: "json",
      url: i.href
    }, n = t.steeringManifestLoadPolicy.default, o = n.errorRetry || n.timeoutRetry || {}, c = {
      loadPolicy: n,
      timeout: n.maxLoadTimeMs,
      maxRetry: o.maxNumRetry || 0,
      retryDelay: o.retryDelayMs || 0,
      maxRetryDelay: o.maxRetryDelayMs || 0
    }, l = {
      onSuccess: (h, u, d, f) => {
        this.log(`Loaded steering manifest: "${i}"`);
        const g = h.data;
        if ((g == null ? void 0 : g.VERSION) !== 1) {
          this.log(`Steering VERSION ${g.VERSION} not supported!`);
          return;
        }
        this.updated = performance.now(), this.timeToLoad = g.TTL;
        const {
          "RELOAD-URI": p,
          "PATHWAY-CLONES": E,
          "PATHWAY-PRIORITY": y
        } = g;
        if (p)
          try {
            this.uri = new self.URL(p, i).href;
          } catch {
            this.enabled = !1, this.log(`Failed to parse Steering Manifest RELOAD-URI: ${p}`);
            return;
          }
        this.scheduleRefresh(this.uri || d.url), E && this.clonePathways(E);
        const S = {
          steeringManifest: g,
          url: i.toString()
        };
        this.hls.trigger(m.STEERING_MANIFEST_LOADED, S), y && this.updatePathwayPriority(y);
      },
      onError: (h, u, d, f) => {
        if (this.log(`Error loading steering manifest: ${h.code} ${h.text} (${u.url})`), this.stopLoad(), h.code === 410) {
          this.enabled = !1, this.log(`Steering manifest ${u.url} no longer available`);
          return;
        }
        let g = this.timeToLoad * 1e3;
        if (h.code === 429) {
          const p = this.loader;
          if (typeof (p == null ? void 0 : p.getResponseHeader) == "function") {
            const E = p.getResponseHeader("Retry-After");
            E && (g = parseFloat(E) * 1e3);
          }
          this.log(`Steering manifest ${u.url} rate limited`);
          return;
        }
        this.scheduleRefresh(this.uri || u.url, g);
      },
      onTimeout: (h, u, d) => {
        this.log(`Timeout loading steering manifest (${u.url})`), this.scheduleRefresh(this.uri || u.url);
      }
    };
    this.log(`Requesting steering manifest: ${i}`), this.loader.load(r, c, l);
  }
  scheduleRefresh(e, t = this.timeToLoad * 1e3) {
    this.clearTimeout(), this.reloadTimer = self.setTimeout(() => {
      var s;
      const i = (s = this.hls) == null ? void 0 : s.media;
      if (i && !i.ended) {
        this.loadSteeringManifest(e);
        return;
      }
      this.scheduleRefresh(e, this.timeToLoad * 1e3);
    }, t);
  }
}
function Hr(a, e, t, s) {
  a && Object.keys(e).forEach((i) => {
    const r = a.filter((n) => n.groupId === i).map((n) => {
      const o = re({}, n);
      return o.details = void 0, o.attrs = new oe(o.attrs), o.url = o.attrs.URI = xa(n.url, n.attrs["STABLE-RENDITION-ID"], "PER-RENDITION-URIS", t), o.groupId = o.attrs["GROUP-ID"] = e[i], o.attrs["PATHWAY-ID"] = s, o;
    });
    a.push(...r);
  });
}
function xa(a, e, t, s) {
  const {
    HOST: i,
    PARAMS: r,
    [t]: n
  } = s;
  let o;
  e && (o = n == null ? void 0 : n[e], o && (a = o));
  const c = new self.URL(a);
  return i && !o && (c.host = i), r && Object.keys(r).sort().forEach((l) => {
    l && c.searchParams.set(l, r[l]);
  }), c.href;
}
class ft extends Ve {
  constructor(e) {
    super("eme", e.logger), this.hls = void 0, this.config = void 0, this.media = null, this.keyFormatPromise = null, this.keySystemAccessPromises = {}, this._requestLicenseFailureCount = 0, this.mediaKeySessions = [], this.keyIdToKeySessionPromise = {}, this.setMediaKeysQueue = ft.CDMCleanupPromise ? [ft.CDMCleanupPromise] : [], this.onMediaEncrypted = (t) => {
      const {
        initDataType: s,
        initData: i
      } = t, r = `"${t.type}" event: init data type: "${s}"`;
      if (this.debug(r), i !== null) {
        if (!this.keyFormatPromise) {
          let n = Object.keys(this.keySystemAccessPromises);
          n.length || (n = Kt(this.config));
          const o = n.map(Cs).filter((c) => !!c);
          this.keyFormatPromise = this.getKeyFormatPromise(o);
        }
        this.keyFormatPromise.then((n) => {
          const o = _s(n);
          let c, l;
          if (s === "sinf") {
            if (o !== se.FAIRPLAY) {
              this.warn(`Ignoring unexpected "${t.type}" event with init data type: "${s}" for selected key-system ${o}`);
              return;
            }
            const g = le(new Uint8Array(i));
            try {
              const p = vi(JSON.parse(g).sinf), E = Ln(p);
              if (!E)
                throw new Error("'schm' box missing or not cbcs/cenc with schi > tenc");
              c = new Uint8Array(E.subarray(8, 24)), l = se.FAIRPLAY;
            } catch (p) {
              this.warn(`${r} Failed to parse sinf: ${p}`);
              return;
            }
          } else {
            if (o !== se.WIDEVINE && o !== se.PLAYREADY) {
              this.warn(`Ignoring unexpected "${t.type}" event with init data type: "${s}" for selected key-system ${o}`);
              return;
            }
            const g = _o(i), p = g.filter((y) => !!y.systemId && Ds(y.systemId) === o);
            p.length > 1 && this.warn(`${r} Using first of ${p.length} pssh found for selected key-system ${o}`);
            const E = p[0];
            if (!E) {
              g.length === 0 || g.some((y) => !y.systemId) ? this.warn(`${r} contains incomplete or invalid pssh data`) : this.log(`ignoring ${r} for ${g.map((y) => Ds(y.systemId)).join(",")} pssh data in favor of playlist keys`);
              return;
            }
            if (l = Ds(E.systemId), E.version === 0 && E.data)
              if (l === se.WIDEVINE) {
                const y = E.data.length - 22;
                c = new Uint8Array(E.data.subarray(y, y + 16));
              } else l === se.PLAYREADY && (c = Un(E.data));
          }
          if (!l || !c)
            return;
          const h = Pe.hexDump(c), {
            keyIdToKeySessionPromise: u,
            mediaKeySessions: d
          } = this;
          let f = u[h];
          for (let g = 0; g < d.length; g++) {
            const p = d[g], E = p.decryptdata;
            if (!E.keyId)
              continue;
            const y = Pe.hexDump(E.keyId);
            if (h === y || E.uri.replace(/-/g, "").indexOf(h) !== -1) {
              if (f = u[y], E.pssh)
                break;
              delete u[y], E.pssh = new Uint8Array(i), E.keyId = c, f = u[h] = f.then(() => this.generateRequestWithPreferredKeySession(p, s, i, "encrypted-event-key-match")), f.catch((S) => this.handleError(S));
              break;
            }
          }
          if (!f) {
            if (l !== o) {
              this.log(`Ignoring "${t.type}" event with ${l} init data for selected key-system ${o}`);
              return;
            }
            f = u[h] = this.getKeySystemSelectionPromise([l]).then(({
              keySystem: g,
              mediaKeys: p
            }) => {
              var E;
              this.throwIfDestroyed();
              const y = new Ct("ISO-23001-7", h, (E = Cs(g)) != null ? E : "");
              return y.pssh = new Uint8Array(i), y.keyId = c, this.attemptSetMediaKeys(g, p).then(() => {
                this.throwIfDestroyed();
                const S = this.createMediaKeySessionContext({
                  decryptdata: y,
                  keySystem: g,
                  mediaKeys: p
                });
                return this.generateRequestWithPreferredKeySession(S, s, i, "encrypted-event-no-match");
              });
            }), f.catch((g) => this.handleError(g));
          }
        });
      }
    }, this.onWaitingForKey = (t) => {
      this.log(`"${t.type}" event`);
    }, this.hls = e, this.config = e.config, this.registerListeners();
  }
  destroy() {
    const e = this.media;
    this.unregisterListeners(), this.onMediaDetached(), this._clear(e);
    const t = this.config;
    t.requestMediaKeySystemAccessFunc = null, t.licenseXhrSetup = t.licenseResponseCallback = void 0, t.drmSystems = t.drmSystemOptions = {}, this.hls = this.config = this.keyIdToKeySessionPromise = null, this.onMediaEncrypted = this.onWaitingForKey = null;
  }
  registerListeners() {
    this.hls.on(m.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.on(m.MEDIA_DETACHED, this.onMediaDetached, this), this.hls.on(m.MANIFEST_LOADING, this.onManifestLoading, this), this.hls.on(m.MANIFEST_LOADED, this.onManifestLoaded, this);
  }
  unregisterListeners() {
    this.hls.off(m.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.off(m.MEDIA_DETACHED, this.onMediaDetached, this), this.hls.off(m.MANIFEST_LOADING, this.onManifestLoading, this), this.hls.off(m.MANIFEST_LOADED, this.onManifestLoaded, this);
  }
  getLicenseServerUrl(e) {
    const {
      drmSystems: t,
      widevineLicenseUrl: s
    } = this.config, i = t[e];
    if (i)
      return i.licenseUrl;
    if (e === se.WIDEVINE && s)
      return s;
  }
  getLicenseServerUrlOrThrow(e) {
    const t = this.getLicenseServerUrl(e);
    if (t === void 0)
      throw new Error(`no license server URL configured for key-system "${e}"`);
    return t;
  }
  getServerCertificateUrl(e) {
    const {
      drmSystems: t
    } = this.config, s = t[e];
    if (s)
      return s.serverCertificateUrl;
    this.log(`No Server Certificate in config.drmSystems["${e}"]`);
  }
  attemptKeySystemAccess(e) {
    const t = this.hls.levels, s = (n, o, c) => !!n && c.indexOf(n) === o, i = t.map((n) => n.audioCodec).filter(s), r = t.map((n) => n.videoCodec).filter(s);
    return i.length + r.length === 0 && r.push("avc1.42e01e"), new Promise((n, o) => {
      const c = (l) => {
        const h = l.shift();
        this.getMediaKeysPromise(h, i, r).then((u) => n({
          keySystem: h,
          mediaKeys: u
        })).catch((u) => {
          l.length ? c(l) : u instanceof Ae ? o(u) : o(new Ae({
            type: K.KEY_SYSTEM_ERROR,
            details: R.KEY_SYSTEM_NO_ACCESS,
            error: u,
            fatal: !0
          }, u.message));
        });
      };
      c(e);
    });
  }
  requestMediaKeySystemAccess(e, t) {
    const {
      requestMediaKeySystemAccessFunc: s
    } = this.config;
    if (typeof s != "function") {
      let i = `Configured requestMediaKeySystemAccess is not a function ${s}`;
      return Bn === null && self.location.protocol === "http:" && (i = `navigator.requestMediaKeySystemAccess is not available over insecure protocol ${location.protocol}`), Promise.reject(new Error(i));
    }
    return s(e, t);
  }
  getMediaKeysPromise(e, t, s) {
    const i = Tl(e, t, s, this.config.drmSystemOptions), r = this.keySystemAccessPromises[e];
    let n = r == null ? void 0 : r.keySystemAccess;
    if (!n) {
      this.log(`Requesting encrypted media "${e}" key-system access with config: ${ae(i)}`), n = this.requestMediaKeySystemAccess(e, i);
      const o = this.keySystemAccessPromises[e] = {
        keySystemAccess: n
      };
      return n.catch((c) => {
        this.log(`Failed to obtain access to key-system "${e}": ${c}`);
      }), n.then((c) => {
        this.log(`Access for key-system "${c.keySystem}" obtained`);
        const l = this.fetchServerCertificate(e);
        return this.log(`Create media-keys for "${e}"`), o.mediaKeys = c.createMediaKeys().then((h) => (this.log(`Media-keys created for "${e}"`), l.then((u) => u ? this.setMediaKeysServerCertificate(h, e, u) : h))), o.mediaKeys.catch((h) => {
          this.error(`Failed to create media-keys for "${e}"}: ${h}`);
        }), o.mediaKeys;
      });
    }
    return n.then(() => r.mediaKeys);
  }
  createMediaKeySessionContext({
    decryptdata: e,
    keySystem: t,
    mediaKeys: s
  }) {
    this.log(`Creating key-system session "${t}" keyId: ${Pe.hexDump(e.keyId || [])}`);
    const i = s.createSession(), r = {
      decryptdata: e,
      keySystem: t,
      mediaKeys: s,
      mediaKeysSession: i,
      keyStatus: "status-pending"
    };
    return this.mediaKeySessions.push(r), r;
  }
  renewKeySession(e) {
    const t = e.decryptdata;
    if (t.pssh) {
      const s = this.createMediaKeySessionContext(e), i = this.getKeyIdString(t), r = "cenc";
      this.keyIdToKeySessionPromise[i] = this.generateRequestWithPreferredKeySession(s, r, t.pssh.buffer, "expired");
    } else
      this.warn("Could not renew expired session. Missing pssh initData.");
    this.removeSession(e);
  }
  getKeyIdString(e) {
    if (!e)
      throw new Error("Could not read keyId of undefined decryptdata");
    if (e.keyId === null)
      throw new Error("keyId is null");
    return Pe.hexDump(e.keyId);
  }
  updateKeySession(e, t) {
    var s;
    const i = e.mediaKeysSession;
    return this.log(`Updating key-session "${i.sessionId}" for keyID ${Pe.hexDump(((s = e.decryptdata) == null ? void 0 : s.keyId) || [])}
      } (data length: ${t && t.byteLength})`), i.update(t);
  }
  selectKeySystemFormat(e) {
    const t = Object.keys(e.levelkeys || {});
    return this.keyFormatPromise || (this.log(`Selecting key-system from fragment (sn: ${e.sn} ${e.type}: ${e.level}) key formats ${t.join(", ")}`), this.keyFormatPromise = this.getKeyFormatPromise(t)), this.keyFormatPromise;
  }
  getKeyFormatPromise(e) {
    return new Promise((t, s) => {
      const i = Kt(this.config), r = e.map(_s).filter((n) => !!n && i.indexOf(n) !== -1);
      return this.getKeySystemSelectionPromise(r).then(({
        keySystem: n
      }) => {
        const o = Cs(n);
        o ? t(o) : s(new Error(`Unable to find format for key-system "${n}"`));
      }).catch(s);
    });
  }
  loadKey(e) {
    const t = e.keyInfo.decryptdata, s = this.getKeyIdString(t), i = `(keyId: ${s} format: "${t.keyFormat}" method: ${t.method} uri: ${t.uri})`;
    this.log(`Starting session for key ${i}`);
    let r = this.keyIdToKeySessionPromise[s];
    return r || (r = this.getKeySystemForKeyPromise(t).then(({
      keySystem: o,
      mediaKeys: c
    }) => (this.throwIfDestroyed(), this.log(`Handle encrypted media sn: ${e.frag.sn} ${e.frag.type}: ${e.frag.level} using key ${i}`), this.attemptSetMediaKeys(o, c).then(() => (this.throwIfDestroyed(), this.createMediaKeySessionContext({
      keySystem: o,
      mediaKeys: c,
      decryptdata: t
    }))))), (this.keyIdToKeySessionPromise[s] = r.then((o) => {
      const c = "cenc", l = t.pssh ? t.pssh.buffer : null;
      return this.generateRequestWithPreferredKeySession(o, c, l, "playlist-key");
    })).catch((o) => this.handleError(o))), r;
  }
  throwIfDestroyed(e = "Invalid state") {
    if (!this.hls)
      throw new Error("invalid state");
  }
  handleError(e) {
    this.hls && (this.error(e.message), e instanceof Ae ? this.hls.trigger(m.ERROR, e.data) : this.hls.trigger(m.ERROR, {
      type: K.KEY_SYSTEM_ERROR,
      details: R.KEY_SYSTEM_NO_KEYS,
      error: e,
      fatal: !0
    }));
  }
  getKeySystemForKeyPromise(e) {
    const t = this.getKeyIdString(e), s = this.keyIdToKeySessionPromise[t];
    if (!s) {
      const i = _s(e.keyFormat), r = i ? [i] : Kt(this.config);
      return this.attemptKeySystemAccess(r);
    }
    return s;
  }
  getKeySystemSelectionPromise(e) {
    if (e.length || (e = Kt(this.config)), e.length === 0)
      throw new Ae({
        type: K.KEY_SYSTEM_ERROR,
        details: R.KEY_SYSTEM_NO_CONFIGURED_LICENSE,
        fatal: !0
      }, `Missing key-system license configuration options ${ae({
        drmSystems: this.config.drmSystems
      })}`);
    return this.attemptKeySystemAccess(e);
  }
  attemptSetMediaKeys(e, t) {
    const s = this.setMediaKeysQueue.slice();
    this.log(`Setting media-keys for "${e}"`);
    const i = Promise.all(s).then(() => {
      if (!this.media)
        throw new Error("Attempted to set mediaKeys without media element attached");
      return this.media.setMediaKeys(t);
    });
    return this.setMediaKeysQueue.push(i), i.then(() => {
      this.log(`Media-keys set for "${e}"`), s.push(i), this.setMediaKeysQueue = this.setMediaKeysQueue.filter((r) => s.indexOf(r) === -1);
    });
  }
  generateRequestWithPreferredKeySession(e, t, s, i) {
    var r, n;
    const o = (r = this.config.drmSystems) == null || (n = r[e.keySystem]) == null ? void 0 : n.generateRequest;
    if (o)
      try {
        const g = o.call(this.hls, t, s, e);
        if (!g)
          throw new Error("Invalid response from configured generateRequest filter");
        t = g.initDataType, s = g.initData ? g.initData : null, e.decryptdata.pssh = s ? new Uint8Array(s) : null;
      } catch (g) {
        var c;
        if (this.warn(g.message), (c = this.hls) != null && c.config.debug)
          throw g;
      }
    if (s === null)
      return this.log(`Skipping key-session request for "${i}" (no initData)`), Promise.resolve(e);
    const l = this.getKeyIdString(e.decryptdata);
    this.log(`Generating key-session request for "${i}": ${l} (init data type: ${t} length: ${s ? s.byteLength : null})`);
    const h = new Ai(), u = e._onmessage = (g) => {
      const p = e.mediaKeysSession;
      if (!p) {
        h.emit("error", new Error("invalid state"));
        return;
      }
      const {
        messageType: E,
        message: y
      } = g;
      this.log(`"${E}" message event for session "${p.sessionId}" message size: ${y.byteLength}`), E === "license-request" || E === "license-renewal" ? this.renewLicense(e, y).catch((S) => {
        h.eventNames().length ? h.emit("error", S) : this.handleError(S);
      }) : E === "license-release" ? e.keySystem === se.FAIRPLAY && (this.updateKeySession(e, ei("acknowledged")), this.removeSession(e)) : this.warn(`unhandled media key message type "${E}"`);
    }, d = e._onkeystatuseschange = (g) => {
      if (!e.mediaKeysSession) {
        h.emit("error", new Error("invalid state"));
        return;
      }
      this.onKeyStatusChange(e);
      const E = e.keyStatus;
      h.emit("keyStatus", E), E === "expired" && (this.warn(`${e.keySystem} expired for key ${l}`), this.renewKeySession(e));
    };
    e.mediaKeysSession.addEventListener("message", u), e.mediaKeysSession.addEventListener("keystatuseschange", d);
    const f = new Promise((g, p) => {
      h.on("error", p), h.on("keyStatus", (E) => {
        E.startsWith("usable") ? g() : E === "output-restricted" ? p(new Ae({
          type: K.KEY_SYSTEM_ERROR,
          details: R.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED,
          fatal: !1
        }, "HDCP level output restricted")) : E === "internal-error" ? p(new Ae({
          type: K.KEY_SYSTEM_ERROR,
          details: R.KEY_SYSTEM_STATUS_INTERNAL_ERROR,
          fatal: !0
        }, `key status changed to "${E}"`)) : E === "expired" ? p(new Error("key expired while generating request")) : this.warn(`unhandled key status change "${E}"`);
      });
    });
    return e.mediaKeysSession.generateRequest(t, s).then(() => {
      var g;
      this.log(`Request generated for key-session "${(g = e.mediaKeysSession) == null ? void 0 : g.sessionId}" keyId: ${l}`);
    }).catch((g) => {
      throw new Ae({
        type: K.KEY_SYSTEM_ERROR,
        details: R.KEY_SYSTEM_NO_SESSION,
        error: g,
        fatal: !1
      }, `Error generating key-session request: ${g}`);
    }).then(() => f).catch((g) => {
      throw h.removeAllListeners(), this.removeSession(e), g;
    }).then(() => (h.removeAllListeners(), e));
  }
  onKeyStatusChange(e) {
    e.mediaKeysSession.keyStatuses.forEach((t, s) => {
      if (typeof s == "string" && typeof t == "object") {
        const i = s;
        s = t, t = i;
      }
      this.log(`key status change "${t}" for keyStatuses keyId: ${Pe.hexDump("buffer" in s ? new Uint8Array(s.buffer, s.byteOffset, s.byteLength) : new Uint8Array(s))} session keyId: ${Pe.hexDump(new Uint8Array(e.decryptdata.keyId || []))} uri: ${e.decryptdata.uri}`), e.keyStatus = t;
    });
  }
  fetchServerCertificate(e) {
    const t = this.config, s = t.loader, i = new s(t), r = this.getServerCertificateUrl(e);
    return r ? (this.log(`Fetching server certificate for "${e}"`), new Promise((n, o) => {
      const c = {
        responseType: "arraybuffer",
        url: r
      }, l = t.certLoadPolicy.default, h = {
        loadPolicy: l,
        timeout: l.maxLoadTimeMs,
        maxRetry: 0,
        retryDelay: 0,
        maxRetryDelay: 0
      }, u = {
        onSuccess: (d, f, g, p) => {
          n(d.data);
        },
        onError: (d, f, g, p) => {
          o(new Ae({
            type: K.KEY_SYSTEM_ERROR,
            details: R.KEY_SYSTEM_SERVER_CERTIFICATE_REQUEST_FAILED,
            fatal: !0,
            networkDetails: g,
            response: te({
              url: c.url,
              data: void 0
            }, d)
          }, `"${e}" certificate request failed (${r}). Status: ${d.code} (${d.text})`));
        },
        onTimeout: (d, f, g) => {
          o(new Ae({
            type: K.KEY_SYSTEM_ERROR,
            details: R.KEY_SYSTEM_SERVER_CERTIFICATE_REQUEST_FAILED,
            fatal: !0,
            networkDetails: g,
            response: {
              url: c.url,
              data: void 0
            }
          }, `"${e}" certificate request timed out (${r})`));
        },
        onAbort: (d, f, g) => {
          o(new Error("aborted"));
        }
      };
      i.load(c, h, u);
    })) : Promise.resolve();
  }
  setMediaKeysServerCertificate(e, t, s) {
    return new Promise((i, r) => {
      e.setServerCertificate(s).then((n) => {
        this.log(`setServerCertificate ${n ? "success" : "not supported by CDM"} (${s == null ? void 0 : s.byteLength}) on "${t}"`), i(e);
      }).catch((n) => {
        r(new Ae({
          type: K.KEY_SYSTEM_ERROR,
          details: R.KEY_SYSTEM_SERVER_CERTIFICATE_UPDATE_FAILED,
          error: n,
          fatal: !0
        }, n.message));
      });
    });
  }
  renewLicense(e, t) {
    return this.requestLicense(e, new Uint8Array(t)).then((s) => this.updateKeySession(e, new Uint8Array(s)).catch((i) => {
      throw new Ae({
        type: K.KEY_SYSTEM_ERROR,
        details: R.KEY_SYSTEM_SESSION_UPDATE_FAILED,
        error: i,
        fatal: !0
      }, i.message);
    }));
  }
  unpackPlayReadyKeyMessage(e, t) {
    const s = String.fromCharCode.apply(null, new Uint16Array(t.buffer));
    if (!s.includes("PlayReadyKeyMessage"))
      return e.setRequestHeader("Content-Type", "text/xml; charset=utf-8"), t;
    const i = new DOMParser().parseFromString(s, "application/xml"), r = i.querySelectorAll("HttpHeader");
    if (r.length > 0) {
      let h;
      for (let u = 0, d = r.length; u < d; u++) {
        var n, o;
        h = r[u];
        const f = (n = h.querySelector("name")) == null ? void 0 : n.textContent, g = (o = h.querySelector("value")) == null ? void 0 : o.textContent;
        f && g && e.setRequestHeader(f, g);
      }
    }
    const c = i.querySelector("Challenge"), l = c == null ? void 0 : c.textContent;
    if (!l)
      throw new Error("Cannot find <Challenge> in key message");
    return ei(atob(l));
  }
  setupLicenseXHR(e, t, s, i) {
    const r = this.config.licenseXhrSetup;
    return r ? Promise.resolve().then(() => {
      if (!s.decryptdata)
        throw new Error("Key removed");
      return r.call(this.hls, e, t, s, i);
    }).catch((n) => {
      if (!s.decryptdata)
        throw n;
      return e.open("POST", t, !0), r.call(this.hls, e, t, s, i);
    }).then((n) => (e.readyState || e.open("POST", t, !0), {
      xhr: e,
      licenseChallenge: n || i
    })) : (e.open("POST", t, !0), Promise.resolve({
      xhr: e,
      licenseChallenge: i
    }));
  }
  requestLicense(e, t) {
    const s = this.config.keyLoadPolicy.default;
    return new Promise((i, r) => {
      const n = this.getLicenseServerUrlOrThrow(e.keySystem);
      this.log(`Sending license request to URL: ${n}`);
      const o = new XMLHttpRequest();
      o.responseType = "arraybuffer", o.onreadystatechange = () => {
        if (!this.hls || !e.mediaKeysSession)
          return r(new Error("invalid state"));
        if (o.readyState === 4)
          if (o.status === 200) {
            this._requestLicenseFailureCount = 0;
            let c = o.response;
            this.log(`License received ${c instanceof ArrayBuffer ? c.byteLength : c}`);
            const l = this.config.licenseResponseCallback;
            if (l)
              try {
                c = l.call(this.hls, o, n, e);
              } catch (h) {
                this.error(h);
              }
            i(c);
          } else {
            const c = s.errorRetry, l = c ? c.maxNumRetry : 0;
            if (this._requestLicenseFailureCount++, this._requestLicenseFailureCount > l || o.status >= 400 && o.status < 500)
              r(new Ae({
                type: K.KEY_SYSTEM_ERROR,
                details: R.KEY_SYSTEM_LICENSE_REQUEST_FAILED,
                fatal: !0,
                networkDetails: o,
                response: {
                  url: n,
                  data: void 0,
                  code: o.status,
                  text: o.statusText
                }
              }, `License Request XHR failed (${n}). Status: ${o.status} (${o.statusText})`));
            else {
              const h = l - this._requestLicenseFailureCount + 1;
              this.warn(`Retrying license request, ${h} attempts left`), this.requestLicense(e, t).then(i, r);
            }
          }
      }, e.licenseXhr && e.licenseXhr.readyState !== XMLHttpRequest.DONE && e.licenseXhr.abort(), e.licenseXhr = o, this.setupLicenseXHR(o, n, e, t).then(({
        xhr: c,
        licenseChallenge: l
      }) => {
        e.keySystem == se.PLAYREADY && (l = this.unpackPlayReadyKeyMessage(c, l)), c.send(l);
      });
    });
  }
  onMediaAttached(e, t) {
    if (!this.config.emeEnabled)
      return;
    const s = t.media;
    this.media = s, s.removeEventListener("encrypted", this.onMediaEncrypted), s.removeEventListener("waitingforkey", this.onWaitingForKey), s.addEventListener("encrypted", this.onMediaEncrypted), s.addEventListener("waitingforkey", this.onWaitingForKey);
  }
  onMediaDetached() {
    const e = this.media;
    e && (e.removeEventListener("encrypted", this.onMediaEncrypted), e.removeEventListener("waitingforkey", this.onWaitingForKey), this.media = null);
  }
  _clear(e) {
    var t;
    const s = this.mediaKeySessions;
    this._requestLicenseFailureCount = 0, this.setMediaKeysQueue = [], this.mediaKeySessions = [], this.keyIdToKeySessionPromise = {}, Ct.clearKeyUriToKeyIdMap();
    const i = s.length;
    ft.CDMCleanupPromise = Promise.all(s.map((r) => this.removeSession(r)).concat(e == null || (t = e.setMediaKeys(null)) == null ? void 0 : t.catch((r) => {
      var n;
      this.log(`Could not clear media keys: ${r}`), (n = this.hls) == null || n.trigger(m.ERROR, {
        type: K.OTHER_ERROR,
        details: R.KEY_SYSTEM_DESTROY_MEDIA_KEYS_ERROR,
        fatal: !1,
        error: new Error(`Could not clear media keys: ${r}`)
      });
    }))).then(() => {
      i && (this.log("finished closing key sessions and clearing media keys"), s.length = 0);
    }).catch((r) => {
      var n;
      this.log(`Could not close sessions and clear media keys: ${r}`), (n = this.hls) == null || n.trigger(m.ERROR, {
        type: K.OTHER_ERROR,
        details: R.KEY_SYSTEM_DESTROY_CLOSE_SESSION_ERROR,
        fatal: !1,
        error: new Error(`Could not close sessions and clear media keys: ${r}`)
      });
    });
  }
  onManifestLoading() {
    this.keyFormatPromise = null;
  }
  onManifestLoaded(e, {
    sessionKeys: t
  }) {
    if (!(!t || !this.config.emeEnabled) && !this.keyFormatPromise) {
      const s = t.reduce((i, r) => (i.indexOf(r.keyFormat) === -1 && i.push(r.keyFormat), i), []);
      this.log(`Selecting key-system from session-keys ${s.join(", ")}`), this.keyFormatPromise = this.getKeyFormatPromise(s);
    }
  }
  removeSession(e) {
    const {
      mediaKeysSession: t,
      licenseXhr: s
    } = e;
    if (t) {
      this.log(`Remove licenses and keys and close session ${t.sessionId}`), e._onmessage && (t.removeEventListener("message", e._onmessage), e._onmessage = void 0), e._onkeystatuseschange && (t.removeEventListener("keystatuseschange", e._onkeystatuseschange), e._onkeystatuseschange = void 0), s && s.readyState !== XMLHttpRequest.DONE && s.abort(), e.mediaKeysSession = e.decryptdata = e.licenseXhr = void 0;
      const i = this.mediaKeySessions.indexOf(e);
      i > -1 && this.mediaKeySessions.splice(i, 1);
      const {
        drmSystemOptions: r
      } = this.config;
      return (vl(r) ? new Promise((o, c) => {
        self.setTimeout(() => c(new Error("MediaKeySession.remove() timeout")), 8e3), t.remove().then(o);
      }) : Promise.resolve()).catch((o) => {
        var c;
        this.log(`Could not remove session: ${o}`), (c = this.hls) == null || c.trigger(m.ERROR, {
          type: K.OTHER_ERROR,
          details: R.KEY_SYSTEM_DESTROY_REMOVE_SESSION_ERROR,
          fatal: !1,
          error: new Error(`Could not remove session: ${o}`)
        });
      }).then(() => t.close()).catch((o) => {
        var c;
        this.log(`Could not close session: ${o}`), (c = this.hls) == null || c.trigger(m.ERROR, {
          type: K.OTHER_ERROR,
          details: R.KEY_SYSTEM_DESTROY_CLOSE_SESSION_ERROR,
          fatal: !1,
          error: new Error(`Could not close session: ${o}`)
        });
      });
    }
  }
}
ft.CDMCleanupPromise = void 0;
class Ae extends Error {
  constructor(e, t) {
    super(t), this.data = void 0, e.error || (e.error = new Error(t)), this.data = e, e.err = e.error;
  }
}
class Dh {
  constructor(e) {
    this.hls = void 0, this.isVideoPlaybackQualityAvailable = !1, this.timer = void 0, this.media = null, this.lastTime = void 0, this.lastDroppedFrames = 0, this.lastDecodedFrames = 0, this.streamController = void 0, this.hls = e, this.registerListeners();
  }
  setStreamController(e) {
    this.streamController = e;
  }
  registerListeners() {
    this.hls.on(m.MEDIA_ATTACHING, this.onMediaAttaching, this), this.hls.on(m.MEDIA_DETACHING, this.onMediaDetaching, this);
  }
  unregisterListeners() {
    this.hls.off(m.MEDIA_ATTACHING, this.onMediaAttaching, this), this.hls.off(m.MEDIA_DETACHING, this.onMediaDetaching, this);
  }
  destroy() {
    this.timer && clearInterval(this.timer), this.unregisterListeners(), this.isVideoPlaybackQualityAvailable = !1, this.media = null;
  }
  onMediaAttaching(e, t) {
    const s = this.hls.config;
    if (s.capLevelOnFPSDrop) {
      const i = t.media instanceof self.HTMLVideoElement ? t.media : null;
      this.media = i, i && typeof i.getVideoPlaybackQuality == "function" && (this.isVideoPlaybackQualityAvailable = !0), self.clearInterval(this.timer), this.timer = self.setInterval(this.checkFPSInterval.bind(this), s.fpsDroppedMonitoringPeriod);
    }
  }
  onMediaDetaching() {
    this.media = null;
  }
  checkFPS(e, t, s) {
    const i = performance.now();
    if (t) {
      if (this.lastTime) {
        const r = i - this.lastTime, n = s - this.lastDroppedFrames, o = t - this.lastDecodedFrames, c = 1e3 * n / r, l = this.hls;
        if (l.trigger(m.FPS_DROP, {
          currentDropped: n,
          currentDecoded: o,
          totalDroppedFrames: s
        }), c > 0 && n > l.config.fpsDroppedMonitoringThreshold * o) {
          let h = l.currentLevel;
          l.logger.warn("drop FPS ratio greater than max allowed value for currentLevel: " + h), h > 0 && (l.autoLevelCapping === -1 || l.autoLevelCapping >= h) && (h = h - 1, l.trigger(m.FPS_DROP_LEVEL_CAPPING, {
            level: h,
            droppedLevel: l.currentLevel
          }), l.autoLevelCapping = h, this.streamController.nextLevelSwitch());
        }
      }
      this.lastTime = i, this.lastDroppedFrames = s, this.lastDecodedFrames = t;
    }
  }
  checkFPSInterval() {
    const e = this.media;
    if (e)
      if (this.isVideoPlaybackQualityAvailable) {
        const t = e.getVideoPlaybackQuality();
        this.checkFPS(e, t.totalVideoFrames, t.droppedVideoFrames);
      } else
        this.checkFPS(e, e.webkitDecodedFrameCount, e.webkitDroppedFrameCount);
  }
}
function Aa(a, e) {
  let t;
  try {
    t = new Event("addtrack");
  } catch {
    t = document.createEvent("Event"), t.initEvent("addtrack", !1, !1);
  }
  t.track = a, e.dispatchEvent(t);
}
function La(a, e) {
  const t = a.mode;
  if (t === "disabled" && (a.mode = "hidden"), a.cues && !a.cues.getCueById(e.id))
    try {
      if (a.addCue(e), !a.cues.getCueById(e.id))
        throw new Error(`addCue is failed for: ${e}`);
    } catch (s) {
      Q.debug(`[texttrack-utils]: ${s}`);
      try {
        const i = new self.TextTrackCue(e.startTime, e.endTime, e.text);
        i.id = e.id, a.addCue(i);
      } catch (i) {
        Q.debug(`[texttrack-utils]: Legacy TextTrackCue fallback failed: ${i}`);
      }
    }
  t === "disabled" && (a.mode = t);
}
function ut(a, e) {
  const t = a.mode;
  if (t === "disabled" && (a.mode = "hidden"), a.cues)
    for (let s = a.cues.length; s--; )
      e && a.cues[s].removeEventListener("enter", e), a.removeCue(a.cues[s]);
  t === "disabled" && (a.mode = t);
}
function li(a, e, t, s) {
  const i = a.mode;
  if (i === "disabled" && (a.mode = "hidden"), a.cues && a.cues.length > 0) {
    const r = Ph(a.cues, e, t);
    for (let n = 0; n < r.length; n++)
      (!s || s(r[n])) && a.removeCue(r[n]);
  }
  i === "disabled" && (a.mode = i);
}
function Ch(a, e) {
  if (e <= a[0].startTime)
    return 0;
  const t = a.length - 1;
  if (e > a[t].endTime)
    return -1;
  let s = 0, i = t, r;
  for (; s <= i; )
    if (r = Math.floor((i + s) / 2), e < a[r].startTime)
      i = r - 1;
    else if (e > a[r].startTime && s < t)
      s = r + 1;
    else
      return r;
  return a[s].startTime - e < e - a[i].startTime ? s : i;
}
function Ph(a, e, t) {
  const s = [], i = Ch(a, e);
  if (i > -1)
    for (let r = i, n = a.length; r < n; r++) {
      const o = a[r];
      if (o.startTime >= e && o.endTime <= t)
        s.push(o);
      else if (o.startTime > t)
        return s;
    }
  return s;
}
function is(a) {
  const e = [];
  for (let t = 0; t < a.length; t++) {
    const s = a[t];
    (s.kind === "subtitles" || s.kind === "captions") && s.label && e.push(a[t]);
  }
  return e;
}
class kh extends Ci {
  constructor(e) {
    super(e, "subtitle-track-controller"), this.media = null, this.tracks = [], this.groupIds = null, this.tracksInGroup = [], this.trackId = -1, this.currentTrack = null, this.selectDefaultTrack = !0, this.queuedDefaultTrack = -1, this.useTextTrackPolling = !1, this.subtitlePollingInterval = -1, this._subtitleDisplay = !0, this.asyncPollTrackChange = () => this.pollTrackChange(0), this.onTextTracksChanged = () => {
      if (this.useTextTrackPolling || self.clearInterval(this.subtitlePollingInterval), !this.media || !this.hls.config.renderTextTracksNatively)
        return;
      let t = null;
      const s = is(this.media.textTracks);
      for (let r = 0; r < s.length; r++)
        if (s[r].mode === "hidden")
          t = s[r];
        else if (s[r].mode === "showing") {
          t = s[r];
          break;
        }
      const i = this.findTrackForTextTrack(t);
      this.subtitleTrack !== i && this.setSubtitleTrack(i);
    }, this.registerListeners();
  }
  destroy() {
    this.unregisterListeners(), this.tracks.length = 0, this.tracksInGroup.length = 0, this.currentTrack = null, this.onTextTracksChanged = this.asyncPollTrackChange = null, super.destroy();
  }
  get subtitleDisplay() {
    return this._subtitleDisplay;
  }
  set subtitleDisplay(e) {
    this._subtitleDisplay = e, this.trackId > -1 && this.toggleTrackModes();
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.MANIFEST_PARSED, this.onManifestParsed, this), e.on(m.LEVEL_LOADING, this.onLevelLoading, this), e.on(m.LEVEL_SWITCHING, this.onLevelSwitching, this), e.on(m.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), e.on(m.ERROR, this.onError, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.MANIFEST_PARSED, this.onManifestParsed, this), e.off(m.LEVEL_LOADING, this.onLevelLoading, this), e.off(m.LEVEL_SWITCHING, this.onLevelSwitching, this), e.off(m.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), e.off(m.ERROR, this.onError, this);
  }
  // Listen for subtitle track change, then extract the current track ID.
  onMediaAttached(e, t) {
    this.media = t.media, this.media && (this.queuedDefaultTrack > -1 && (this.subtitleTrack = this.queuedDefaultTrack, this.queuedDefaultTrack = -1), this.useTextTrackPolling = !(this.media.textTracks && "onchange" in this.media.textTracks), this.useTextTrackPolling ? this.pollTrackChange(500) : this.media.textTracks.addEventListener("change", this.asyncPollTrackChange));
  }
  pollTrackChange(e) {
    self.clearInterval(this.subtitlePollingInterval), this.subtitlePollingInterval = self.setInterval(this.onTextTracksChanged, e);
  }
  onMediaDetaching(e, t) {
    const s = this.media;
    if (!s)
      return;
    const i = !!t.transferMedia;
    if (self.clearInterval(this.subtitlePollingInterval), this.useTextTrackPolling || s.textTracks.removeEventListener("change", this.asyncPollTrackChange), this.trackId > -1 && (this.queuedDefaultTrack = this.trackId), this.subtitleTrack = -1, this.media = null, i)
      return;
    is(s.textTracks).forEach((n) => {
      ut(n);
    });
  }
  onManifestLoading() {
    this.tracks = [], this.groupIds = null, this.tracksInGroup = [], this.trackId = -1, this.currentTrack = null, this.selectDefaultTrack = !0;
  }
  // Fired whenever a new manifest is loaded.
  onManifestParsed(e, t) {
    this.tracks = t.subtitleTracks;
  }
  onSubtitleTrackLoaded(e, t) {
    const {
      id: s,
      groupId: i,
      details: r
    } = t, n = this.tracksInGroup[s];
    if (!n || n.groupId !== i) {
      this.warn(`Subtitle track with id:${s} and group:${i} not found in active group ${n == null ? void 0 : n.groupId}`);
      return;
    }
    const o = n.details;
    n.details = t.details, this.log(`Subtitle track ${s} "${n.name}" lang:${n.lang} group:${i} loaded [${r.startSN}-${r.endSN}]`), s === this.trackId && this.playlistLoaded(s, t, o);
  }
  onLevelLoading(e, t) {
    this.switchLevel(t.level);
  }
  onLevelSwitching(e, t) {
    this.switchLevel(t.level);
  }
  switchLevel(e) {
    const t = this.hls.levels[e];
    if (!t)
      return;
    const s = t.subtitleGroups || null, i = this.groupIds;
    let r = this.currentTrack;
    if (!s || (i == null ? void 0 : i.length) !== (s == null ? void 0 : s.length) || s != null && s.some((n) => (i == null ? void 0 : i.indexOf(n)) === -1)) {
      this.groupIds = s, this.trackId = -1, this.currentTrack = null;
      const n = this.tracks.filter((h) => !s || s.indexOf(h.groupId) !== -1);
      if (n.length)
        this.selectDefaultTrack && !n.some((h) => h.default) && (this.selectDefaultTrack = !1), n.forEach((h, u) => {
          h.id = u;
        });
      else if (!r && !this.tracksInGroup.length)
        return;
      this.tracksInGroup = n;
      const o = this.hls.config.subtitlePreference;
      if (!r && o) {
        this.selectDefaultTrack = !1;
        const h = we(o, n);
        if (h > -1)
          r = n[h];
        else {
          const u = we(o, this.tracks);
          r = this.tracks[u];
        }
      }
      let c = this.findTrackId(r);
      c === -1 && r && (c = this.findTrackId(null));
      const l = {
        subtitleTracks: n
      };
      this.log(`Updating subtitle tracks, ${n.length} track(s) found in "${s == null ? void 0 : s.join(",")}" group-id`), this.hls.trigger(m.SUBTITLE_TRACKS_UPDATED, l), c !== -1 && this.trackId === -1 && this.setSubtitleTrack(c);
    }
  }
  findTrackId(e) {
    const t = this.tracksInGroup, s = this.selectDefaultTrack;
    for (let i = 0; i < t.length; i++) {
      const r = t[i];
      if (!(s && !r.default || !s && !e) && (!e || st(r, e)))
        return i;
    }
    if (e) {
      for (let i = 0; i < t.length; i++) {
        const r = t[i];
        if (Ot(e.attrs, r.attrs, ["LANGUAGE", "ASSOC-LANGUAGE", "CHARACTERISTICS"]))
          return i;
      }
      for (let i = 0; i < t.length; i++) {
        const r = t[i];
        if (Ot(e.attrs, r.attrs, ["LANGUAGE"]))
          return i;
      }
    }
    return -1;
  }
  findTrackForTextTrack(e) {
    if (e) {
      const t = this.tracksInGroup;
      for (let s = 0; s < t.length; s++) {
        const i = t[s];
        if (ni(i, e))
          return s;
      }
    }
    return -1;
  }
  onError(e, t) {
    t.fatal || !t.context || t.context.type === z.SUBTITLE_TRACK && t.context.id === this.trackId && (!this.groupIds || this.groupIds.indexOf(t.context.groupId) !== -1) && this.checkRetry(t);
  }
  get allSubtitleTracks() {
    return this.tracks;
  }
  /** get alternate subtitle tracks list from playlist **/
  get subtitleTracks() {
    return this.tracksInGroup;
  }
  /** get/set index of the selected subtitle track (based on index in subtitle track lists) **/
  get subtitleTrack() {
    return this.trackId;
  }
  set subtitleTrack(e) {
    this.selectDefaultTrack = !1, this.setSubtitleTrack(e);
  }
  setSubtitleOption(e) {
    if (this.hls.config.subtitlePreference = e, e) {
      if (e.id === -1)
        return this.setSubtitleTrack(-1), null;
      const t = this.allSubtitleTracks;
      if (this.selectDefaultTrack = !1, t.length) {
        const s = this.currentTrack;
        if (s && st(e, s))
          return s;
        const i = we(e, this.tracksInGroup);
        if (i > -1) {
          const r = this.tracksInGroup[i];
          return this.setSubtitleTrack(i), r;
        } else {
          if (s)
            return null;
          {
            const r = we(e, t);
            if (r > -1)
              return t[r];
          }
        }
      }
    }
    return null;
  }
  loadPlaylist(e) {
    super.loadPlaylist(), this.shouldLoadPlaylist(this.currentTrack) && this.scheduleLoading(this.currentTrack, e);
  }
  loadingPlaylist(e, t) {
    super.loadingPlaylist(e, t);
    const s = e.id, i = e.groupId, r = this.getUrlWithDirectives(e.url, t), n = e.details, o = n == null ? void 0 : n.age;
    this.log(`Loading subtitle ${s} "${e.name}" lang:${e.lang} group:${i}${(t == null ? void 0 : t.msn) !== void 0 ? " at sn " + t.msn + " part " + t.part : ""}${o && n.live ? " age " + o.toFixed(1) + (n.type && " " + n.type || "") : ""} ${r}`), this.hls.trigger(m.SUBTITLE_TRACK_LOADING, {
      url: r,
      id: s,
      groupId: i,
      deliveryDirectives: t || null,
      track: e
    });
  }
  /**
   * Disables the old subtitleTrack and sets current mode on the next subtitleTrack.
   * This operates on the DOM textTracks.
   * A value of -1 will disable all subtitle tracks.
   */
  toggleTrackModes() {
    const {
      media: e
    } = this;
    if (!e)
      return;
    const t = is(e.textTracks), s = this.currentTrack;
    let i;
    if (s && (i = t.filter((r) => ni(s, r))[0], i || this.warn(`Unable to find subtitle TextTrack with name "${s.name}" and language "${s.lang}"`)), [].slice.call(t).forEach((r) => {
      r.mode !== "disabled" && r !== i && (r.mode = "disabled");
    }), i) {
      const r = this.subtitleDisplay ? "showing" : "hidden";
      i.mode !== r && (i.mode = r);
    }
  }
  /**
   * This method is responsible for validating the subtitle index and periodically reloading if live.
   * Dispatches the SUBTITLE_TRACK_SWITCH event, which instructs the subtitle-stream-controller to load the selected track.
   */
  setSubtitleTrack(e) {
    const t = this.tracksInGroup;
    if (!this.media) {
      this.queuedDefaultTrack = e;
      return;
    }
    if (e < -1 || e >= t.length || !M(e)) {
      this.warn(`Invalid subtitle track id: ${e}`);
      return;
    }
    this.selectDefaultTrack = !1;
    const s = this.currentTrack, i = t[e] || null;
    if (this.trackId = e, this.currentTrack = i, this.toggleTrackModes(), !i) {
      this.hls.trigger(m.SUBTITLE_TRACK_SWITCH, {
        id: e
      });
      return;
    }
    const r = !!i.details && !i.details.live;
    if (e === this.trackId && i === s && r)
      return;
    this.log(`Switching to subtitle-track ${e}` + (i ? ` "${i.name}" lang:${i.lang} group:${i.groupId}` : ""));
    const {
      id: n,
      groupId: o = "",
      name: c,
      type: l,
      url: h
    } = i;
    this.hls.trigger(m.SUBTITLE_TRACK_SWITCH, {
      id: n,
      groupId: o,
      name: c,
      type: l,
      url: h
    });
    const u = this.switchParams(i.url, s == null ? void 0 : s.details, i.details);
    this.loadPlaylist(u);
  }
}
function It(a) {
  let e = 5381, t = a.length;
  for (; t; )
    e = e * 33 ^ a.charCodeAt(--t);
  return (e >>> 0).toString();
}
const gt = 0.025;
let ms = /* @__PURE__ */ function(a) {
  return a[a.Point = 0] = "Point", a[a.Range = 1] = "Range", a;
}({});
function wh(a, e, t) {
  return `${a.identifier}-${t + 1}-${It(e)}`;
}
class Oh {
  constructor(e, t) {
    this.base = void 0, this._duration = null, this._timelineStart = null, this.appendInPlaceDisabled = void 0, this.appendInPlaceStarted = void 0, this.dateRange = void 0, this.hasPlayed = !1, this.cumulativeDuration = 0, this.resumeOffset = NaN, this.playoutLimit = NaN, this.restrictions = {
      skip: !1,
      jump: !1
    }, this.snapOptions = {
      out: !1,
      in: !1
    }, this.assetList = [], this.assetListLoader = void 0, this.assetListResponse = null, this.resumeAnchor = void 0, this.error = void 0, this.resetOnResume = void 0, this.base = t, this.dateRange = e, this.setDateRange(e);
  }
  setDateRange(e) {
    this.dateRange = e, this.resumeOffset = e.attr.optionalFloat("X-RESUME-OFFSET", this.resumeOffset), this.playoutLimit = e.attr.optionalFloat("X-PLAYOUT-LIMIT", this.playoutLimit), this.restrictions = e.attr.enumeratedStringList("X-RESTRICT", this.restrictions), this.snapOptions = e.attr.enumeratedStringList("X-SNAP", this.snapOptions);
  }
  reset() {
    var e;
    this.appendInPlaceStarted = !1, (e = this.assetListLoader) == null || e.destroy(), this.assetListLoader = void 0, this.supplementsPrimary || (this.assetListResponse = null, this.assetList = [], this._duration = null);
  }
  isAssetPastPlayoutLimit(e) {
    if (e >= this.assetList.length)
      return !0;
    const t = this.playoutLimit;
    return e <= 0 || isNaN(t) ? !1 : this.assetList[e].startOffset > t;
  }
  findAssetIndex(e) {
    return this.assetList.indexOf(e);
  }
  get identifier() {
    return this.dateRange.id;
  }
  get startDate() {
    return this.dateRange.startDate;
  }
  get startTime() {
    const e = this.dateRange.startTime;
    if (this.snapOptions.out) {
      const t = this.dateRange.tagAnchor;
      if (t)
        return Us(e, t);
    }
    return e;
  }
  get startOffset() {
    return this.cue.pre ? 0 : this.startTime;
  }
  get startIsAligned() {
    if (this.startTime === 0 || this.snapOptions.out)
      return !0;
    const e = this.dateRange.tagAnchor;
    if (e) {
      const t = this.dateRange.startTime, s = Us(t, e);
      return t - s < 0.1;
    }
    return !1;
  }
  get resumptionOffset() {
    const e = this.resumeOffset, t = M(e) ? e : this.duration;
    return this.cumulativeDuration + t;
  }
  get resumeTime() {
    const e = this.startOffset + this.resumptionOffset;
    if (this.snapOptions.in) {
      const t = this.resumeAnchor;
      if (t)
        return Us(e, t);
    }
    return e;
  }
  get appendInPlace() {
    return this.appendInPlaceStarted ? !0 : this.appendInPlaceDisabled ? !1 : !!(!this.cue.once && !this.cue.pre && // preroll starts at startPosition before startPosition is known (live)
    this.startIsAligned && (isNaN(this.playoutLimit) && isNaN(this.resumeOffset) || this.resumeOffset && this.duration && Math.abs(this.resumeOffset - this.duration) < gt));
  }
  set appendInPlace(e) {
    if (this.appendInPlaceStarted) {
      this.resetOnResume = !e;
      return;
    }
    this.appendInPlaceDisabled = !e;
  }
  // Extended timeline start time
  get timelineStart() {
    return this._timelineStart !== null ? this._timelineStart : this.startTime;
  }
  set timelineStart(e) {
    this._timelineStart = e;
  }
  get duration() {
    const e = this.playoutLimit;
    let t;
    return this._duration !== null ? t = this._duration : this.dateRange.duration ? t = this.dateRange.duration : t = this.dateRange.plannedDuration || 0, !isNaN(e) && e < t && (t = e), t;
  }
  set duration(e) {
    this._duration = e;
  }
  get cue() {
    return this.dateRange.cue;
  }
  get timelineOccupancy() {
    return this.dateRange.attr["X-TIMELINE-OCCUPIES"] === "RANGE" ? ms.Range : ms.Point;
  }
  get supplementsPrimary() {
    return this.dateRange.attr["X-TIMELINE-STYLE"] === "PRIMARY";
  }
  get contentMayVary() {
    return this.dateRange.attr["X-CONTENT-MAY-VARY"] !== "NO";
  }
  get assetUrl() {
    return this.dateRange.attr["X-ASSET-URI"];
  }
  get assetListUrl() {
    return this.dateRange.attr["X-ASSET-LIST"];
  }
  get baseUrl() {
    return this.base.url;
  }
  get assetListLoaded() {
    return this.assetList.length > 0 || this.assetListResponse !== null;
  }
  toString() {
    return Fh(this);
  }
}
function Us(a, e) {
  return a - e.start < e.duration / 2 && !(Math.abs(a - (e.start + e.duration)) < gt) ? e.start : e.start + e.duration;
}
function Ia(a, e, t) {
  const s = new self.URL(a, t);
  return s.protocol !== "data:" && s.searchParams.set("_HLS_primary_id", e), s;
}
function Fh(a) {
  return `["${a.identifier}" ${a.cue.pre ? "<pre>" : a.cue.post ? "<post>" : ""}${a.timelineStart.toFixed(2)}-${a.resumeTime.toFixed(2)}]`;
}
function ci(a) {
  const e = a.timelineStart, t = a.duration || 0;
  return `["${a.identifier}" ${e.toFixed(2)}-${(e + t).toFixed(2)}]`;
}
class Mh {
  constructor(e, t, s, i) {
    this.hls = void 0, this.interstitial = void 0, this.assetItem = void 0, this.tracks = null, this.hasDetails = !1, this.mediaAttached = null, this._currentTime = void 0, this._bufferedEosTime = void 0, this.checkPlayout = () => {
      const l = this.interstitial.playoutLimit, h = this.currentTime;
      this.startOffset + h >= l && this.hls.trigger(m.PLAYOUT_LIMIT_REACHED, {});
    };
    const r = this.hls = new e(t);
    this.interstitial = s, this.assetItem = i;
    let n = i.uri;
    try {
      n = Ia(n, r.sessionId).href;
    } catch {
    }
    r.loadSource(n);
    const o = () => {
      this.hasDetails = !0;
    };
    r.once(m.LEVEL_LOADED, o), r.once(m.AUDIO_TRACK_LOADED, o), r.once(m.SUBTITLE_TRACK_LOADED, o), r.on(m.MEDIA_ATTACHING, (c, {
      media: l
    }) => {
      this.removeMediaListeners(), this.mediaAttached = l, this.interstitial.playoutLimit && l.addEventListener("timeupdate", this.checkPlayout);
    });
  }
  bufferedInPlaceToEnd(e) {
    var t;
    if (!this.interstitial.appendInPlace)
      return !1;
    if ((t = this.hls) != null && t.bufferedToEnd)
      return !0;
    if (!e || !this._bufferedEosTime)
      return !1;
    const s = this.timelineOffset, i = q.bufferInfo(e, s, 0);
    return this.getAssetTime(i.end) >= this._bufferedEosTime - 0.02;
  }
  get destroyed() {
    var e;
    return !((e = this.hls) != null && e.userConfig);
  }
  get assetId() {
    return this.assetItem.identifier;
  }
  get interstitialId() {
    return this.assetItem.parentIdentifier;
  }
  get media() {
    var e;
    return ((e = this.hls) == null ? void 0 : e.media) || null;
  }
  get bufferedEnd() {
    const e = this.media || this.mediaAttached;
    if (!e)
      return this._bufferedEosTime ? this._bufferedEosTime : this.currentTime;
    const t = q.bufferInfo(e, e.currentTime, 1e-3);
    return this.getAssetTime(t.end);
  }
  get currentTime() {
    const e = this.media || this.mediaAttached;
    return e ? this.getAssetTime(e.currentTime) : this._currentTime || 0;
  }
  get duration() {
    const e = this.assetItem.duration;
    return e || 0;
  }
  get remaining() {
    const e = this.duration;
    return e ? Math.max(0, e - this.currentTime) : 0;
  }
  get startOffset() {
    return this.assetItem.startOffset;
  }
  get timelineOffset() {
    var e;
    return ((e = this.hls) == null ? void 0 : e.config.timelineOffset) || 0;
  }
  set timelineOffset(e) {
    const t = this.timelineOffset;
    if (e !== t) {
      const s = e - t;
      if (Math.abs(s) > 1 / 9e4) {
        if (this.hasDetails)
          throw new Error("Cannot set timelineOffset after playlists are loaded");
        this.hls.config.timelineOffset = e;
      }
    }
  }
  getAssetTime(e) {
    const t = this.timelineOffset, s = this.duration;
    return Math.min(Math.max(0, e - t), s);
  }
  removeMediaListeners() {
    const e = this.mediaAttached;
    e && (this._currentTime = e.currentTime, this.bufferSnapShot(), e.removeEventListener("timeupdate", this.checkPlayout));
  }
  bufferSnapShot() {
    if (this.mediaAttached) {
      var e;
      (e = this.hls) != null && e.bufferedToEnd && (this._bufferedEosTime = this.bufferedEnd);
    }
  }
  destroy() {
    this.removeMediaListeners(), this.hls.destroy(), this.hls = this.interstitial = null, this.tracks = this.mediaAttached = this.checkPlayout = null;
  }
  attachMedia(e) {
    this.hls.attachMedia(e);
  }
  detachMedia() {
    this.removeMediaListeners(), this.mediaAttached = null, this.hls.detachMedia();
  }
  resumeBuffering() {
    this.hls.resumeBuffering();
  }
  pauseBuffering() {
    this.hls.pauseBuffering();
  }
  transferMedia() {
    return this.bufferSnapShot(), this.hls.transferMedia();
  }
  on(e, t, s) {
    this.hls.on(e, t);
  }
  once(e, t, s) {
    this.hls.once(e, t);
  }
  off(e, t, s) {
    this.hls.off(e, t);
  }
  toString() {
    var e, t;
    return `HlsAssetPlayer: ${ci(this.assetItem)} ${(e = this.hls) == null ? void 0 : e.sessionId} ${(t = this.interstitial) != null && t.appendInPlace ? "append-in-place" : ""}`;
  }
}
const Wr = 0.033;
class Nh extends Ve {
  constructor(e, t) {
    super("interstitials-sched", t), this.onScheduleUpdate = void 0, this.eventMap = {}, this.events = null, this.items = null, this.durations = {
      primary: 0,
      playout: 0,
      integrated: 0
    }, this.onScheduleUpdate = e;
  }
  destroy() {
    this.reset(), this.onScheduleUpdate = null;
  }
  reset() {
    this.eventMap = {}, this.setDurations(0, 0, 0), this.events && this.events.forEach((e) => e.reset()), this.events = this.items = null;
  }
  resetErrorsInRange(e, t) {
    return this.events ? this.events.reduce((s, i) => e <= i.startOffset && t > i.startOffset ? (delete i.error, s + 1) : s, 0) : 0;
  }
  get duration() {
    const e = this.items;
    return e ? e[e.length - 1].end : 0;
  }
  get length() {
    return this.items ? this.items.length : 0;
  }
  getEvent(e) {
    return e && this.eventMap[e] || null;
  }
  hasEvent(e) {
    return e in this.eventMap;
  }
  findItemIndex(e, t) {
    if (e.event)
      return this.findEventIndex(e.event.identifier);
    let s = -1;
    e.nextEvent ? s = this.findEventIndex(e.nextEvent.identifier) - 1 : e.previousEvent && (s = this.findEventIndex(e.previousEvent.identifier) + 1);
    const i = this.items;
    if (i)
      for (i[s] || (t === void 0 && (t = e.start), s = this.findItemIndexAtTime(t)); s >= 0 && (r = i[s]) != null && r.event; ) {
        var r;
        s--;
      }
    return s;
  }
  findItemIndexAtTime(e, t) {
    const s = this.items;
    if (s)
      for (let i = 0; i < s.length; i++) {
        let r = s[i];
        if (t && t !== "primary" && (r = r[t]), e === r.start || e > r.start && e < r.end)
          return i;
      }
    return -1;
  }
  findJumpRestrictedIndex(e, t) {
    const s = this.items;
    if (s)
      for (let i = e; i <= t && s[i]; i++) {
        const r = s[i].event;
        if (r != null && r.restrictions.jump && !r.appendInPlace)
          return i;
      }
    return -1;
  }
  findEventIndex(e) {
    const t = this.items;
    if (t)
      for (let i = t.length; i--; ) {
        var s;
        if (((s = t[i].event) == null ? void 0 : s.identifier) === e)
          return i;
      }
    return -1;
  }
  findAssetIndex(e, t) {
    const s = e.assetList, i = s.length;
    if (i > 1)
      for (let r = 0; r < i; r++) {
        const n = s[r];
        if (!n.error) {
          const o = n.timelineStart;
          if (t === o || t > o && t < o + (n.duration || 0))
            return r;
        }
      }
    return 0;
  }
  get assetIdAtEnd() {
    var e, t;
    const s = (e = this.items) == null || (t = e[this.length - 1]) == null ? void 0 : t.event;
    if (s) {
      const i = s.assetList, r = i[i.length - 1];
      if (r)
        return r.identifier;
    }
    return null;
  }
  parseInterstitialDateRanges(e, t) {
    const s = e.main.details, {
      dateRanges: i
    } = s, r = this.events, n = this.parseDateRanges(i, {
      url: s.url
    }, t), o = Object.keys(i), c = r ? r.filter((l) => !o.includes(l.identifier)) : [];
    n.length && n.sort((l, h) => {
      const u = l.cue.pre, d = l.cue.post, f = h.cue.pre, g = h.cue.post;
      if (u && !f)
        return -1;
      if (f && !u || d && !g)
        return 1;
      if (g && !d)
        return -1;
      if (!u && !f && !d && !g) {
        const p = l.startTime, E = h.startTime;
        if (p !== E)
          return p - E;
      }
      return l.dateRange.tagOrder - h.dateRange.tagOrder;
    }), this.events = n, c.forEach((l) => {
      this.removeEvent(l);
    }), this.updateSchedule(e, c);
  }
  updateSchedule(e, t = []) {
    const s = this.events || [];
    if (s.length || t.length || this.length < 2) {
      const i = this.items, r = this.parseSchedule(s, e);
      (t.length || (i == null ? void 0 : i.length) !== r.length || r.some((o, c) => Math.abs(o.playout.start - i[c].playout.start) > 5e-3 || Math.abs(o.playout.end - i[c].playout.end) > 5e-3)) && (this.items = r, this.onScheduleUpdate(t, i));
    }
  }
  parseDateRanges(e, t, s) {
    const i = [], r = Object.keys(e);
    for (let n = 0; n < r.length; n++) {
      const o = r[n], c = e[o];
      if (c.isInterstitial) {
        let l = this.eventMap[o];
        l ? l.setDateRange(c) : (l = new Oh(c, t), this.eventMap[o] = l, s === !1 && (l.appendInPlace = s)), i.push(l);
      }
    }
    return i;
  }
  parseSchedule(e, t) {
    const s = [], i = t.main.details, r = i.live ? 1 / 0 : i.edge;
    let n = 0;
    if (e = e.filter((c) => !c.error && !(c.cue.once && c.hasPlayed)), e.length) {
      this.resolveOffsets(e, t);
      let c = 0, l = 0;
      if (e.forEach((h, u) => {
        const d = h.cue.pre, f = h.cue.post, g = e[u - 1] || null, p = h.appendInPlace, E = f ? r : h.startOffset, y = h.duration, S = h.timelineOccupancy === ms.Range ? y : 0, T = h.resumptionOffset, v = (g == null ? void 0 : g.startTime) === E, x = E + h.cumulativeDuration;
        let _ = p ? x + y : E + T;
        if (d || !f && E <= 0) {
          const b = l;
          l += S, h.timelineStart = x;
          const D = n;
          n += y, s.push({
            event: h,
            start: x,
            end: _,
            playout: {
              start: D,
              end: n
            },
            integrated: {
              start: b,
              end: l
            }
          });
        } else if (E <= r) {
          if (!v) {
            const L = E - c;
            if (L > Wr) {
              const k = c, F = l;
              l += L;
              const j = n;
              n += L;
              const w = {
                previousEvent: e[u - 1] || null,
                nextEvent: h,
                start: k,
                end: k + L,
                playout: {
                  start: j,
                  end: n
                },
                integrated: {
                  start: F,
                  end: l
                }
              };
              s.push(w);
            } else L > 0 && g && (g.cumulativeDuration += L, s[s.length - 1].end = E);
          }
          f && (_ = x), h.timelineStart = x;
          const b = l;
          l += S;
          const D = n;
          n += y, s.push({
            event: h,
            start: x,
            end: _,
            playout: {
              start: D,
              end: n
            },
            integrated: {
              start: b,
              end: l
            }
          });
        } else
          return;
        const A = h.resumeTime;
        f || A > r ? c = r : c = A;
      }), c < r) {
        var o;
        const h = c, u = l, d = r - c;
        l += d;
        const f = n;
        n += d, s.push({
          previousEvent: ((o = s[s.length - 1]) == null ? void 0 : o.event) || null,
          nextEvent: null,
          start: c,
          end: h + d,
          playout: {
            start: f,
            end: n
          },
          integrated: {
            start: u,
            end: l
          }
        });
      }
      this.setDurations(r, n, l);
    } else
      s.push({
        previousEvent: null,
        nextEvent: null,
        start: 0,
        end: r,
        playout: {
          start: 0,
          end: r
        },
        integrated: {
          start: 0,
          end: r
        }
      }), this.setDurations(r, r, r);
    return s;
  }
  setDurations(e, t, s) {
    this.durations = {
      primary: e,
      playout: t,
      integrated: s
    };
  }
  resolveOffsets(e, t) {
    const s = t.main.details, i = s.live ? 1 / 0 : s.edge;
    let r = 0, n = -1;
    e.forEach((o, c) => {
      const l = o.cue.pre, h = o.cue.post, u = l ? 0 : h ? i : o.startTime;
      this.updateAssetDurations(o), n === u ? o.cumulativeDuration = r : (r = 0, n = u), !h && o.snapOptions.in && (o.resumeAnchor = it(null, s.fragments, o.startOffset + o.resumptionOffset, 0, 0) || void 0), o.appendInPlace && !o.appendInPlaceStarted && (this.primaryCanResumeInPlaceAt(o, t) || (o.appendInPlace = !1)), !o.appendInPlace && c + 1 < e.length && e[c + 1].startTime - e[c].resumeTime < Wr && (e[c + 1].appendInPlace = !1, e[c + 1].appendInPlace && this.warn(`Could not change append strategy for abutting event ${o}`));
      const f = M(o.resumeOffset) ? o.resumeOffset : o.duration;
      r += f;
    });
  }
  primaryCanResumeInPlaceAt(e, t) {
    const s = e.resumeTime, i = e.startTime + e.resumptionOffset;
    return Math.abs(s - i) > gt ? (this.log(`"${e.identifier}" resumption ${s} not aligned with estimated timeline end ${i}`), !1) : t ? !Object.keys(t).some((n) => {
      const o = t[n].details, c = o.edge;
      if (s >= c)
        return this.log(`"${e.identifier}" resumption ${s} past ${n} playlist end ${c}`), !1;
      const l = it(null, o.fragments, s);
      if (!l)
        return this.log(`"${e.identifier}" resumption ${s} does not align with any fragments in ${n} playlist (${o.fragStart}-${o.fragmentEnd})`), !0;
      const h = n === "audio" ? 0.175 : 0;
      return Math.abs(l.start - s) < gt + h || Math.abs(l.end - s) < gt + h ? !1 : (this.log(`"${e.identifier}" resumption ${s} not aligned with ${n} fragment bounds (${l.start}-${l.end} sn: ${l.sn} cc: ${l.cc})`), !0);
    }) : (this.log(`"${e.identifier}" resumption ${s} can not be aligned with media (none selected)`), !1);
  }
  updateAssetDurations(e) {
    if (!e.assetListLoaded)
      return;
    const t = e.timelineStart;
    let s = 0, i = !1, r = !1;
    e.assetList.forEach((n, o) => {
      const c = t + s;
      n.startOffset = s, n.timelineStart = c, i || (i = n.duration === null), r || (r = !!n.error);
      const l = n.error ? 0 : n.duration || 0;
      s += l;
    }), i && !r ? e.duration = Math.max(s, e.duration) : e.duration = s;
  }
  removeEvent(e) {
    e.reset(), delete this.eventMap[e.identifier];
  }
}
function Ye(a) {
  return `[${a.event ? '"' + a.event.identifier + '"' : "primary"}: ${a.start.toFixed(2)}-${a.end.toFixed(2)}]`;
}
class Bh {
  constructor(e) {
    this.hls = void 0, this.hls = e;
  }
  destroy() {
    this.hls = null;
  }
  loadAssetList(e, t) {
    const s = e.assetListUrl;
    let i;
    try {
      i = Ia(s, this.hls.sessionId, e.baseUrl);
    } catch (d) {
      const f = this.assignAssetListError(e, R.ASSET_LIST_LOAD_ERROR, d, s);
      this.hls.trigger(m.ERROR, f);
      return;
    }
    t && i.protocol !== "data:" && i.searchParams.set("_HLS_start_offset", "" + t);
    const r = this.hls.config, n = r.loader, o = new n(r), c = {
      responseType: "json",
      url: i.href
    }, l = r.interstitialAssetListLoadPolicy.default, h = {
      loadPolicy: l,
      timeout: l.maxLoadTimeMs,
      maxRetry: 0,
      retryDelay: 0,
      maxRetryDelay: 0
    }, u = {
      onSuccess: (d, f, g, p) => {
        const E = d.data, y = E == null ? void 0 : E.ASSETS;
        if (!Array.isArray(y)) {
          const S = this.assignAssetListError(e, R.ASSET_LIST_PARSING_ERROR, new Error("Invalid interstitial asset list"), g.url, f, p);
          this.hls.trigger(m.ERROR, S);
          return;
        }
        e.assetListResponse = E, this.hls.trigger(m.ASSET_LIST_LOADED, {
          event: e,
          assetListResponse: E,
          networkDetails: p
        });
      },
      onError: (d, f, g, p) => {
        const E = this.assignAssetListError(e, R.ASSET_LIST_LOAD_ERROR, new Error(`Error loading X-ASSET-LIST: HTTP status ${d.code} ${d.text} (${f.url})`), f.url, p, g);
        this.hls.trigger(m.ERROR, E);
      },
      onTimeout: (d, f, g) => {
        const p = this.assignAssetListError(e, R.ASSET_LIST_LOAD_TIMEOUT, new Error(`Timeout loading X-ASSET-LIST (${f.url})`), f.url, d, g);
        this.hls.trigger(m.ERROR, p);
      }
    };
    return o.load(c, h, u), this.hls.trigger(m.ASSET_LIST_LOADING, {
      event: e
    }), o;
  }
  assignAssetListError(e, t, s, i, r, n) {
    return e.error = s, {
      type: K.NETWORK_ERROR,
      details: t,
      fatal: !1,
      interstitial: e,
      url: i,
      error: s,
      networkDetails: n,
      stats: r
    };
  }
}
function Ke(a, e, t) {
  Fe(a, e, t), a.addEventListener(e, t);
}
function Fe(a, e, t) {
  a.removeEventListener(e, t);
}
function Yr(a) {
  a == null || a.play().catch(() => {
  });
}
class Uh extends Ve {
  constructor(e, t) {
    super("interstitials", e.logger), this.HlsPlayerClass = void 0, this.hls = void 0, this.assetListLoader = void 0, this.mediaSelection = null, this.altSelection = null, this.media = null, this.detachedData = null, this.requiredTracks = null, this.manager = null, this.playerQueue = [], this.bufferedPos = -1, this.timelinePos = -1, this.schedule = void 0, this.playingItem = null, this.bufferingItem = null, this.waitingItem = null, this.endedItem = null, this.playingAsset = null, this.endedAsset = null, this.bufferingAsset = null, this.shouldPlay = !1, this.onPlay = () => {
      this.shouldPlay = !0;
    }, this.onPause = () => {
      this.shouldPlay = !1;
    }, this.onSeeking = () => {
      const s = this.currentTime;
      if (s === void 0 || this.playbackDisabled)
        return;
      const i = s - this.timelinePos;
      if (Math.abs(i) < 1 / 7056e5)
        return;
      const n = i <= -0.01;
      this.timelinePos = s, this.bufferedPos = s;
      const o = this.playingItem;
      if (!o) {
        this.checkBuffer();
        return;
      }
      if (n && this.schedule.resetErrorsInRange(s, s - i) && this.updateSchedule(), this.checkBuffer(), n && s < o.start || s >= o.end) {
        var c;
        const d = this.schedule.findItemIndexAtTime(this.timelinePos);
        if (!this.isInterstitial(o) && (c = this.media) != null && c.paused && (this.shouldPlay = !1), !n) {
          const f = this.findItemIndex(o);
          if (d > f) {
            const g = this.schedule.findJumpRestrictedIndex(f + 1, d);
            if (g > f) {
              this.setSchedulePosition(g);
              return;
            }
          }
        }
        this.setSchedulePosition(d);
        return;
      }
      const l = this.playingAsset;
      if (!l) {
        if (this.playingLastItem && this.isInterstitial(o)) {
          const d = o.event.assetList[0];
          d && (this.endedItem = this.playingItem, this.playingItem = null, this.setScheduleToAssetAtTime(s, d));
        }
        return;
      }
      const h = l.timelineStart, u = l.duration || 0;
      (n && s < h || s >= h + u) && this.setScheduleToAssetAtTime(s, l);
    }, this.onTimeupdate = () => {
      const s = this.currentTime;
      if (s === void 0 || this.playbackDisabled)
        return;
      if (s > this.timelinePos)
        this.timelinePos = s, s > this.bufferedPos && this.checkBuffer();
      else
        return;
      const i = this.playingItem;
      if (!i || this.playingLastItem)
        return;
      if (s >= i.end) {
        this.timelinePos = i.end;
        const o = this.findItemIndex(i);
        this.setSchedulePosition(o + 1);
      }
      const r = this.playingAsset;
      if (!r)
        return;
      const n = r.timelineStart + (r.duration || 0);
      s >= n && this.setScheduleToAssetAtTime(s, r);
    }, this.onScheduleUpdate = (s, i) => {
      const r = this.schedule, n = this.playingItem, o = r.events || [], c = r.items || [], l = r.durations, h = s.map((f) => f.identifier), u = !!(o.length || h.length);
      if (u && this.log(`INTERSTITIALS_UPDATED (${o.length}): ${o}
Schedule: ${c.map((f) => Ye(f))}`), h.length && this.log(`Removed events ${h}`), this.playerQueue.forEach((f) => {
        if (f.interstitial.appendInPlace) {
          const g = f.assetItem.timelineStart, p = f.timelineOffset - g;
          if (p)
            try {
              f.timelineOffset = g;
            } catch (E) {
              Math.abs(p) > gt && this.warn(`${E} ("${f.assetId}" ${f.timelineOffset}->${g})`);
            }
        }
      }), n) {
        const f = this.updateItem(n, this.timelinePos);
        this.itemsMatch(n, f) && (this.playingItem = f, this.waitingItem = this.endedItem = null);
      } else
        this.waitingItem = this.updateItem(this.waitingItem), this.endedItem = this.updateItem(this.endedItem);
      const d = this.bufferingItem;
      if (d) {
        const f = this.updateItem(d, this.bufferedPos);
        this.itemsMatch(d, f) ? this.bufferingItem = f : d.event && (this.bufferingItem = this.playingItem, this.clearInterstitial(d.event, null));
      }
      if (s.forEach((f) => {
        f.assetList.forEach((g) => {
          this.clearAssetPlayer(g.identifier, null);
        });
      }), u || i) {
        if (this.hls.trigger(m.INTERSTITIALS_UPDATED, {
          events: o.slice(0),
          schedule: c.slice(0),
          durations: l,
          removedIds: h
        }), this.isInterstitial(n) && h.includes(n.event.identifier)) {
          this.warn(`Interstitial "${n.event.identifier}" removed while playing`), this.primaryFallback(n.event);
          return;
        }
        this.checkBuffer();
      }
    }, this.hls = e, this.HlsPlayerClass = t, this.assetListLoader = new Bh(e), this.schedule = new Nh(this.onScheduleUpdate, e.logger), this.registerListeners();
  }
  registerListeners() {
    const e = this.hls;
    e.on(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.on(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.LEVEL_UPDATED, this.onLevelUpdated, this), e.on(m.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.on(m.AUDIO_TRACK_UPDATED, this.onAudioTrackUpdated, this), e.on(m.SUBTITLE_TRACK_SWITCH, this.onSubtitleTrackSwitch, this), e.on(m.SUBTITLE_TRACK_UPDATED, this.onSubtitleTrackUpdated, this), e.on(m.EVENT_CUE_ENTER, this.onInterstitialCueEnter, this), e.on(m.ASSET_LIST_LOADED, this.onAssetListLoaded, this), e.on(m.BUFFER_APPENDED, this.onBufferAppended, this), e.on(m.BUFFER_FLUSHED, this.onBufferFlushed, this), e.on(m.BUFFERED_TO_END, this.onBufferedToEnd, this), e.on(m.MEDIA_ENDED, this.onMediaEnded, this), e.on(m.ERROR, this.onError, this), e.on(m.DESTROYING, this.onDestroying, this);
  }
  unregisterListeners() {
    const e = this.hls;
    e && (e.off(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.off(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.LEVEL_UPDATED, this.onLevelUpdated, this), e.off(m.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.off(m.AUDIO_TRACK_UPDATED, this.onAudioTrackUpdated, this), e.off(m.SUBTITLE_TRACK_SWITCH, this.onSubtitleTrackSwitch, this), e.off(m.SUBTITLE_TRACK_UPDATED, this.onSubtitleTrackUpdated, this), e.off(m.EVENT_CUE_ENTER, this.onInterstitialCueEnter, this), e.off(m.ASSET_LIST_LOADED, this.onAssetListLoaded, this), e.off(m.BUFFER_CODECS, this.onBufferCodecs, this), e.off(m.BUFFER_APPENDED, this.onBufferAppended, this), e.off(m.BUFFER_FLUSHED, this.onBufferFlushed, this), e.off(m.BUFFERED_TO_END, this.onBufferedToEnd, this), e.off(m.MEDIA_ENDED, this.onMediaEnded, this), e.off(m.ERROR, this.onError, this), e.off(m.DESTROYING, this.onDestroying, this));
  }
  startLoad() {
    this.resumeBuffering();
  }
  stopLoad() {
    this.pauseBuffering();
  }
  resumeBuffering() {
    var e;
    (e = this.getBufferingPlayer()) == null || e.resumeBuffering();
  }
  pauseBuffering() {
    var e;
    (e = this.getBufferingPlayer()) == null || e.pauseBuffering();
  }
  destroy() {
    this.unregisterListeners(), this.stopLoad(), this.assetListLoader && this.assetListLoader.destroy(), this.emptyPlayerQueue(), this.clearScheduleState(), this.schedule && this.schedule.destroy(), this.media = this.detachedData = this.mediaSelection = this.requiredTracks = this.altSelection = this.manager = null, this.hls = this.HlsPlayerClass = this.schedule = this.log = null, this.assetListLoader = null, this.onPlay = this.onPause = this.onSeeking = this.onTimeupdate = null, this.onScheduleUpdate = null;
  }
  onDestroying() {
    const e = this.primaryMedia || this.media;
    e && this.removeMediaListeners(e);
  }
  removeMediaListeners(e) {
    Fe(e, "play", this.onPlay), Fe(e, "pause", this.onPause), Fe(e, "seeking", this.onSeeking), Fe(e, "timeupdate", this.onTimeupdate);
  }
  onMediaAttaching(e, t) {
    const s = this.media = t.media;
    Ke(s, "seeking", this.onSeeking), Ke(s, "timeupdate", this.onTimeupdate), Ke(s, "play", this.onPlay), Ke(s, "pause", this.onPause);
  }
  onMediaAttached(e, t) {
    const s = this.effectivePlayingItem, i = this.detachedData;
    if (this.detachedData = null, s === null)
      this.checkStart();
    else if (!i) {
      this.clearScheduleState();
      const r = this.findItemIndex(s);
      this.setSchedulePosition(r);
    }
  }
  clearScheduleState() {
    this.playingItem = this.bufferingItem = this.waitingItem = this.endedItem = this.playingAsset = this.endedAsset = this.bufferingAsset = null;
  }
  onMediaDetaching(e, t) {
    const s = !!t.transferMedia, i = this.media;
    if (this.media = null, !s && (i && this.removeMediaListeners(i), this.detachedData)) {
      const r = this.getBufferingPlayer();
      r && (this.playingAsset = this.endedAsset = this.bufferingAsset = this.bufferingItem = this.waitingItem = this.detachedData = null, r.detachMedia()), this.shouldPlay = !1;
    }
  }
  get interstitialsManager() {
    if (!this.manager) {
      if (!this.hls)
        return null;
      const e = this, t = () => e.bufferingItem || e.waitingItem, s = (u) => u && e.getAssetPlayer(u.identifier), i = (u, d, f, g, p) => {
        if (u) {
          let E = u[d].start;
          const y = u.event;
          if (y) {
            if (d === "playout" || y.timelineOccupancy !== ms.Point) {
              const S = s(f);
              (S == null ? void 0 : S.interstitial) === y && (E += S.assetItem.startOffset + S[p]);
            }
          } else {
            const S = g === "bufferedPos" ? n() : e[g];
            E += S - u.start;
          }
          return E;
        }
        return 0;
      }, r = (u, d) => {
        if (u !== 0 && d !== "primary" && e.schedule.length) {
          var f;
          const g = e.schedule.findItemIndexAtTime(u), p = (f = e.schedule.items) == null ? void 0 : f[g];
          if (p) {
            const E = p[d].start - p.start;
            return u + E;
          }
        }
        return u;
      }, n = () => {
        const u = e.bufferedPos;
        return u === Number.MAX_VALUE ? o("primary") : Math.max(u, 0);
      }, o = (u) => {
        var d;
        return (d = e.primaryDetails) != null && d.live ? e.primaryDetails.edge : e.schedule.durations[u];
      }, c = (u, d) => {
        var f, g;
        const p = e.effectivePlayingItem;
        if (p != null && (f = p.event) != null && f.restrictions.skip)
          return;
        e.log(`seek to ${u} "${d}"`);
        const E = e.effectivePlayingItem, y = e.schedule.findItemIndexAtTime(u, d), S = (g = e.schedule.items) == null ? void 0 : g[y], T = e.getBufferingPlayer(), v = T == null ? void 0 : T.interstitial, x = v == null ? void 0 : v.appendInPlace, _ = E && e.itemsMatch(E, S);
        if (E && (x || _)) {
          const b = s(e.playingAsset), D = (b == null ? void 0 : b.media) || e.primaryMedia;
          if (D) {
            const L = d === "primary" ? D.currentTime : i(E, d, e.playingAsset, "timelinePos", "currentTime"), k = u - L, F = (x ? L : D.currentTime) + k;
            if (F >= 0 && (!b || x || F <= b.duration)) {
              D.currentTime = F;
              return;
            }
          }
        }
        if (S) {
          let b = u;
          if (d !== "primary") {
            const L = S[d].start, k = u - L;
            b = S.start + k;
          }
          const D = !e.isInterstitial(S);
          if ((!e.isInterstitial(E) || E.event.appendInPlace) && (D || S.event.appendInPlace)) {
            const L = e.media || (x ? T == null ? void 0 : T.media : null);
            L && (L.currentTime = b);
          } else if (E) {
            const L = e.findItemIndex(E);
            if (y > L) {
              const F = e.schedule.findJumpRestrictedIndex(L + 1, y);
              if (F > L) {
                e.setSchedulePosition(F);
                return;
              }
            }
            let k = 0;
            if (D)
              e.timelinePos = b, e.checkBuffer();
            else {
              var A;
              const F = S == null || (A = S.event) == null ? void 0 : A.assetList;
              if (F) {
                const j = u - (S[d] || S).start;
                for (let w = F.length; w--; ) {
                  const U = F[w];
                  if (U.duration && j >= U.startOffset && j < U.startOffset + U.duration) {
                    k = w;
                    break;
                  }
                }
              }
            }
            e.setSchedulePosition(y, k);
          }
        }
      }, l = () => {
        const u = e.effectivePlayingItem;
        if (e.isInterstitial(u))
          return u;
        const d = t();
        return e.isInterstitial(d) ? d : null;
      }, h = {
        get currentTime() {
          const u = l(), d = e.effectivePlayingItem;
          return d && d === u ? i(d, "playout", e.effectivePlayingAsset, "timelinePos", "currentTime") - d.playout.start : 0;
        },
        set currentTime(u) {
          const d = l(), f = e.effectivePlayingItem;
          f && f === d && c(u + f.playout.start, "playout");
        },
        get duration() {
          const u = l();
          return u ? u.playout.end - u.playout.start : 0;
        },
        get assetPlayers() {
          var u;
          const d = (u = l()) == null ? void 0 : u.event.assetList;
          return d ? d.map((f) => e.getAssetPlayer(f.identifier)) : [];
        },
        get playingIndex() {
          var u;
          const d = (u = l()) == null ? void 0 : u.event;
          return d && e.effectivePlayingAsset ? d.findAssetIndex(e.effectivePlayingAsset) : -1;
        },
        get scheduleItem() {
          return l();
        }
      };
      this.manager = {
        get events() {
          var u, d;
          return ((u = e.schedule) == null || (d = u.events) == null ? void 0 : d.slice(0)) || [];
        },
        get schedule() {
          var u, d;
          return ((u = e.schedule) == null || (d = u.items) == null ? void 0 : d.slice(0)) || [];
        },
        get interstitialPlayer() {
          return l() ? h : null;
        },
        get playerQueue() {
          return e.playerQueue.slice(0);
        },
        get bufferingAsset() {
          return e.bufferingAsset;
        },
        get bufferingItem() {
          return t();
        },
        get bufferingIndex() {
          const u = t();
          return e.findItemIndex(u);
        },
        get playingAsset() {
          return e.effectivePlayingAsset;
        },
        get playingItem() {
          return e.effectivePlayingItem;
        },
        get playingIndex() {
          const u = e.effectivePlayingItem;
          return e.findItemIndex(u);
        },
        primary: {
          get bufferedEnd() {
            return n();
          },
          get currentTime() {
            const u = e.timelinePos;
            return u > 0 ? u : 0;
          },
          set currentTime(u) {
            c(u, "primary");
          },
          get duration() {
            return o("primary");
          },
          get seekableStart() {
            var u;
            return ((u = e.primaryDetails) == null ? void 0 : u.fragmentStart) || 0;
          }
        },
        integrated: {
          get bufferedEnd() {
            return i(t(), "integrated", e.bufferingAsset, "bufferedPos", "bufferedEnd");
          },
          get currentTime() {
            return i(e.effectivePlayingItem, "integrated", e.effectivePlayingAsset, "timelinePos", "currentTime");
          },
          set currentTime(u) {
            c(u, "integrated");
          },
          get duration() {
            return o("integrated");
          },
          get seekableStart() {
            var u;
            return r(((u = e.primaryDetails) == null ? void 0 : u.fragmentStart) || 0, "integrated");
          }
        },
        skip: () => {
          const u = e.effectivePlayingItem, d = u == null ? void 0 : u.event;
          if (d && !d.restrictions.skip) {
            const f = e.findItemIndex(u);
            if (d.appendInPlace) {
              const g = u.playout.start + u.event.duration;
              c(g + 1e-3, "playout");
            } else
              e.advanceAfterAssetEnded(d, f, 1 / 0);
          }
        }
      };
    }
    return this.manager;
  }
  // Schedule getters
  get effectivePlayingItem() {
    return this.waitingItem || this.playingItem || this.endedItem;
  }
  get effectivePlayingAsset() {
    return this.playingAsset || this.endedAsset;
  }
  get playingLastItem() {
    var e;
    const t = this.playingItem, s = (e = this.schedule) == null ? void 0 : e.items;
    return !this.playbackStarted || !t || !s ? !1 : this.findItemIndex(t) === s.length - 1;
  }
  get playbackStarted() {
    return this.effectivePlayingItem !== null;
  }
  // Media getters and event callbacks
  get currentTime() {
    var e, t, s;
    if (this.mediaSelection === null)
      return;
    const i = this.waitingItem || this.playingItem;
    if (this.isInterstitial(i) && !i.event.appendInPlace)
      return;
    let r = this.media;
    !r && (e = this.bufferingItem) != null && (t = e.event) != null && t.appendInPlace && (r = this.primaryMedia);
    const n = (s = r) == null ? void 0 : s.currentTime;
    if (!(n === void 0 || !M(n)))
      return n;
  }
  get primaryMedia() {
    var e;
    return this.media || ((e = this.detachedData) == null ? void 0 : e.media) || null;
  }
  isInterstitial(e) {
    return !!(e != null && e.event);
  }
  retreiveMediaSource(e, t) {
    const s = this.getAssetPlayer(e);
    s && this.transferMediaFromPlayer(s, t);
  }
  transferMediaFromPlayer(e, t) {
    const s = e.interstitial.appendInPlace, i = e.media;
    if (s && i === this.primaryMedia) {
      if (this.bufferingAsset = null, (!t || this.isInterstitial(t) && !t.event.appendInPlace) && t && i) {
        this.detachedData = {
          media: i
        };
        return;
      }
      const r = e.transferMedia();
      this.log(`transfer MediaSource from ${e} ${ae(r)}`), this.detachedData = r;
    } else t && i && (this.shouldPlay || (this.shouldPlay = !i.paused));
  }
  transferMediaTo(e, t) {
    var s, i;
    if (e.media === t)
      return;
    let r = null;
    const n = this.hls, o = e !== n, c = o && e.interstitial.appendInPlace, l = (s = this.detachedData) == null ? void 0 : s.mediaSource;
    let h;
    if (n.media)
      c && (r = n.transferMedia(), this.detachedData = r), h = "Primary";
    else if (l) {
      const f = this.getBufferingPlayer();
      f ? (r = f.transferMedia(), h = `${f}`) : h = "detached MediaSource";
    } else
      h = "detached media";
    if (!r) {
      if (l)
        r = this.detachedData, this.log(`using detachedData: MediaSource ${ae(r)}`);
      else if (!this.detachedData || n.media === t) {
        const f = this.playerQueue;
        f.length > 1 && f.forEach((g) => {
          if (o && g.interstitial.appendInPlace !== c) {
            const p = g.interstitial;
            this.clearInterstitial(g.interstitial, null), p.appendInPlace = !1, p.appendInPlace && this.warn(`Could not change append strategy for queued assets ${p}`);
          }
        }), this.hls.detachMedia(), this.detachedData = {
          media: t
        };
      }
    }
    const u = r && "mediaSource" in r && ((i = r.mediaSource) == null ? void 0 : i.readyState) !== "closed", d = u && r ? r : t;
    if (this.log(`${u ? "transfering MediaSource" : "attaching media"} to ${o ? e : "Primary"} from ${h}`), d === r) {
      const f = o && e.assetId === this.schedule.assetIdAtEnd;
      d.overrides = {
        duration: this.schedule.duration,
        endOfStream: !o || f,
        cueRemoval: !o
      };
    }
    e.attachMedia(d);
  }
  onInterstitialCueEnter() {
    this.onTimeupdate();
  }
  // Scheduling methods
  checkStart() {
    const e = this.schedule, t = e.events;
    if (!t || this.playbackDisabled || !this.media)
      return;
    this.bufferedPos === -1 && (this.bufferedPos = 0);
    const s = this.timelinePos, i = this.effectivePlayingItem;
    if (s === -1) {
      const r = this.hls.startPosition;
      if (this.timelinePos = r, t.length && t[0].cue.pre) {
        const n = e.findEventIndex(t[0].identifier);
        this.setSchedulePosition(n);
      } else if (r >= 0 || !this.primaryLive) {
        const n = this.timelinePos = r > 0 ? r : 0, o = e.findItemIndexAtTime(n);
        this.setSchedulePosition(o);
      }
    } else if (i && !this.playingItem) {
      const r = e.findItemIndex(i);
      this.setSchedulePosition(r);
    }
  }
  advanceAfterAssetEnded(e, t, s) {
    const i = s + 1;
    if (!e.isAssetPastPlayoutLimit(i) && !e.assetList[i].error)
      this.setSchedulePosition(t, i);
    else {
      const r = this.schedule.items;
      if (r) {
        const n = t + 1, o = r.length;
        if (n >= o) {
          this.setSchedulePosition(-1);
          return;
        }
        const c = e.resumeTime;
        this.timelinePos < c && (this.timelinePos = c, this.checkBuffer()), this.setSchedulePosition(n);
      }
    }
  }
  setScheduleToAssetAtTime(e, t) {
    const s = this.schedule, i = t.parentIdentifier, r = s.getEvent(i);
    if (r) {
      const n = s.findEventIndex(i), o = s.findAssetIndex(r, e);
      this.setSchedulePosition(n, o);
    }
  }
  setSchedulePosition(e, t) {
    const s = this.schedule.items;
    if (!s || this.playbackDisabled)
      return;
    this.log(`setSchedulePosition ${e}, ${t}`);
    const i = e >= 0 ? s[e] : null, r = this.playingItem, n = this.playingLastItem;
    if (this.isInterstitial(r)) {
      var o;
      const l = r.event, h = this.playingAsset, u = h == null ? void 0 : h.identifier, d = u ? this.getAssetPlayer(u) : null;
      if (d && u && (!this.eventItemsMatch(r, i) || t !== void 0 && u !== ((o = l.assetList) == null ? void 0 : o[t].identifier))) {
        var c;
        const f = l.findAssetIndex(h);
        this.log(`INTERSTITIAL_ASSET_ENDED ${f + 1}/${l.assetList.length} ${ci(h)}`), this.endedAsset = h, this.playingAsset = null, this.hls.trigger(m.INTERSTITIAL_ASSET_ENDED, {
          asset: h,
          assetListIndex: f,
          event: l,
          schedule: s.slice(0),
          scheduleIndex: e,
          player: d
        }), this.retreiveMediaSource(u, i), d.media && !((c = this.detachedData) != null && c.mediaSource) && d.detachMedia();
      }
      if (!this.eventItemsMatch(r, i) && (this.endedItem = r, this.playingItem = null, this.log(`INTERSTITIAL_ENDED ${l} ${Ye(r)}`), l.hasPlayed = !0, this.hls.trigger(m.INTERSTITIAL_ENDED, {
        event: l,
        schedule: s.slice(0),
        scheduleIndex: e
      }), l.cue.once)) {
        this.updateSchedule();
        const f = this.schedule.items;
        if (i && f) {
          const g = this.schedule.findItemIndex(i);
          this.advanceSchedule(g, f, t, r, n);
        }
        return;
      }
    }
    this.advanceSchedule(e, s, t, r, n);
  }
  advanceSchedule(e, t, s, i, r) {
    const n = e >= 0 ? t[e] : null, o = this.primaryMedia, c = this.playerQueue;
    if (c.length && c.forEach((l) => {
      const h = l.interstitial, u = this.schedule.findEventIndex(h.identifier);
      (u < e || u > e + 1) && this.clearInterstitial(h, n);
    }), this.isInterstitial(n)) {
      this.timelinePos = Math.min(Math.max(this.timelinePos, n.start), n.end);
      const l = n.event;
      s === void 0 && (s = this.schedule.findAssetIndex(l, this.timelinePos));
      const h = this.waitingItem;
      this.assetsBuffered(n, o) || this.setBufferingItem(n);
      let u = this.preloadAssets(l, s);
      if (this.eventItemsMatch(n, h || i) || (this.waitingItem = n, this.log(`INTERSTITIAL_STARTED ${Ye(n)} ${l.appendInPlace ? "append in place" : ""}`), this.hls.trigger(m.INTERSTITIAL_STARTED, {
        event: l,
        schedule: t.slice(0),
        scheduleIndex: e
      })), !l.assetListLoaded) {
        this.log(`Waiting for ASSET-LIST to complete loading ${l}`);
        return;
      }
      if (l.assetListLoader && (l.assetListLoader.destroy(), l.assetListLoader = void 0), !o) {
        this.log(`Waiting for attachMedia to start Interstitial ${l}`);
        return;
      }
      this.waitingItem = this.endedItem = null, this.playingItem = n;
      const d = l.assetList[s];
      if (!d) {
        const f = t[e + 1], g = this.media;
        f && g && !this.isInterstitial(f) && g.currentTime < f.start && (g.currentTime = this.timelinePos = f.start), this.advanceAfterAssetEnded(l, e, s || 0);
        return;
      }
      if (u || (u = this.getAssetPlayer(d.identifier)), u === null || u.destroyed) {
        const f = l.assetList.length;
        this.warn(`asset ${s + 1}/${f} player destroyed ${l}`), u = this.createAssetPlayer(l, d, s);
      }
      if (!this.eventItemsMatch(n, this.bufferingItem) && l.appendInPlace && this.isAssetBuffered(d))
        return;
      this.startAssetPlayer(u, s, t, e, o), this.shouldPlay && Yr(u.media);
    } else n !== null ? (this.resumePrimary(n, e, i), this.shouldPlay && Yr(this.hls.media)) : r && this.isInterstitial(i) && (this.endedItem = null, this.playingItem = i, i.event.appendInPlace || this.attachPrimary(this.schedule.durations.primary, null));
  }
  get playbackDisabled() {
    return this.hls.config.enableInterstitialPlayback === !1;
  }
  get primaryDetails() {
    var e, t;
    return (e = this.mediaSelection) == null || (t = e.main) == null ? void 0 : t.details;
  }
  get primaryLive() {
    var e;
    return !!((e = this.primaryDetails) != null && e.live);
  }
  resumePrimary(e, t, s) {
    var i;
    if (this.playingItem = e, this.playingAsset = this.endedAsset = null, this.waitingItem = this.endedItem = null, this.bufferedToItem(e), this.log(`resuming ${Ye(e)}`), !((i = this.detachedData) != null && i.mediaSource)) {
      let n = this.timelinePos;
      (n < e.start || n >= e.end) && (n = this.getPrimaryResumption(e, t), this.timelinePos = n), this.attachPrimary(n, e);
    }
    if (!s)
      return;
    const r = this.schedule.items;
    r && (this.log(`resumed ${Ye(e)}`), this.hls.trigger(m.INTERSTITIALS_PRIMARY_RESUMED, {
      schedule: r.slice(0),
      scheduleIndex: t
    }), this.checkBuffer());
  }
  getPrimaryResumption(e, t) {
    const s = e.start;
    if (this.primaryLive) {
      const i = this.primaryDetails;
      if (t === 0)
        return this.hls.startPosition;
      if (i && (s < i.fragmentStart || s > i.edge))
        return this.hls.liveSyncPosition || -1;
    }
    return s;
  }
  isAssetBuffered(e) {
    const t = this.getAssetPlayer(e.identifier);
    return t != null && t.hls ? t.hls.bufferedToEnd : q.bufferInfo(this.primaryMedia, this.timelinePos, 0).end + 1 >= e.timelineStart + (e.duration || 0);
  }
  attachPrimary(e, t, s) {
    t ? this.setBufferingItem(t) : this.bufferingItem = this.playingItem, this.bufferingAsset = null;
    const i = this.primaryMedia;
    if (!i)
      return;
    const r = this.hls;
    r.media ? this.checkBuffer() : (this.transferMediaTo(r, i), s && this.startLoadingPrimaryAt(e, s)), s || (this.timelinePos = e, this.startLoadingPrimaryAt(e, s));
  }
  startLoadingPrimaryAt(e, t) {
    var s;
    const i = this.hls;
    !i.loadingEnabled || !i.media || Math.abs((((s = i.mainForwardBufferInfo) == null ? void 0 : s.start) || i.media.currentTime) - e) > 0.5 ? i.startLoad(e, t) : i.bufferingEnabled || i.resumeBuffering();
  }
  // HLS.js event callbacks
  onManifestLoading() {
    this.stopLoad(), this.schedule.reset(), this.emptyPlayerQueue(), this.clearScheduleState(), this.shouldPlay = !1, this.bufferedPos = this.timelinePos = -1, this.mediaSelection = this.altSelection = this.manager = this.requiredTracks = null, this.hls.off(m.BUFFER_CODECS, this.onBufferCodecs, this), this.hls.on(m.BUFFER_CODECS, this.onBufferCodecs, this);
  }
  onLevelUpdated(e, t) {
    if (t.level === -1)
      return;
    const s = this.hls.levels[t.level], i = te(te({}, this.mediaSelection || this.altSelection), {}, {
      main: s
    });
    this.mediaSelection = i, this.schedule.parseInterstitialDateRanges(i, this.hls.config.interstitialAppendInPlace), !this.effectivePlayingItem && this.schedule.items && this.checkStart();
  }
  onAudioTrackUpdated(e, t) {
    const s = this.hls.audioTracks[t.id], i = this.mediaSelection;
    if (!i) {
      this.altSelection = te(te({}, this.altSelection), {}, {
        audio: s
      });
      return;
    }
    const r = te(te({}, i), {}, {
      audio: s
    });
    this.mediaSelection = r;
  }
  onSubtitleTrackUpdated(e, t) {
    const s = this.hls.subtitleTracks[t.id], i = this.mediaSelection;
    if (!i) {
      this.altSelection = te(te({}, this.altSelection), {}, {
        subtitles: s
      });
      return;
    }
    const r = te(te({}, i), {}, {
      subtitles: s
    });
    this.mediaSelection = r;
  }
  onAudioTrackSwitching(e, t) {
    const s = rr(t);
    this.playerQueue.forEach((i) => i.hls.setAudioOption(t) || i.hls.setAudioOption(s));
  }
  onSubtitleTrackSwitch(e, t) {
    const s = rr(t);
    this.playerQueue.forEach((i) => i.hls.setSubtitleOption(t) || t.id !== -1 && i.hls.setSubtitleOption(s));
  }
  onBufferCodecs(e, t) {
    const s = t.tracks;
    s && (this.requiredTracks = s);
  }
  onBufferAppended(e, t) {
    this.checkBuffer();
  }
  onBufferFlushed(e, t) {
    const s = this.playingItem;
    if (s && !this.itemsMatch(s, this.bufferingItem) && !this.isInterstitial(s)) {
      const i = this.timelinePos;
      this.bufferedPos = i, this.checkBuffer();
    }
  }
  onBufferedToEnd(e) {
    const t = this.schedule.events;
    if (this.bufferedPos < Number.MAX_VALUE && t) {
      for (let i = 0; i < t.length; i++) {
        const r = t[i];
        if (r.cue.post) {
          var s;
          const n = this.schedule.findEventIndex(r.identifier), o = (s = this.schedule.items) == null ? void 0 : s[n];
          this.isInterstitial(o) && this.eventItemsMatch(o, this.bufferingItem) && this.bufferedToItem(o, 0);
          break;
        }
      }
      this.bufferedPos = Number.MAX_VALUE;
    }
  }
  onMediaEnded(e) {
    const t = this.playingItem;
    if (!this.playingLastItem && t) {
      const s = this.findItemIndex(t);
      this.setSchedulePosition(s + 1);
    } else
      this.shouldPlay = !1;
  }
  updateItem(e, t) {
    const s = this.schedule.items;
    if (e && s) {
      const i = this.findItemIndex(e, t);
      return s[i] || null;
    }
    return null;
  }
  itemsMatch(e, t) {
    return !!t && (e === t || e.event && t.event && this.eventItemsMatch(e, t) || !e.event && !t.event && this.findItemIndex(e) === this.findItemIndex(t));
  }
  eventItemsMatch(e, t) {
    var s;
    return !!t && (e === t || e.event.identifier === ((s = t.event) == null ? void 0 : s.identifier));
  }
  findItemIndex(e, t) {
    return e ? this.schedule.findItemIndex(e, t) : -1;
  }
  updateSchedule() {
    const e = this.mediaSelection;
    e && this.schedule.updateSchedule(e, []);
  }
  // Schedule buffer control
  checkBuffer(e) {
    const t = this.schedule.items;
    if (!t)
      return;
    const s = q.bufferInfo(this.primaryMedia, this.timelinePos, 0);
    e && (this.bufferedPos = this.timelinePos), e || (e = s.len < 1), this.updateBufferedPos(s.end, t, e);
  }
  updateBufferedPos(e, t, s) {
    const i = this.schedule, r = this.bufferingItem;
    if (this.bufferedPos > e)
      return;
    if (t.length === 1 && this.itemsMatch(t[0], r)) {
      this.bufferedPos = e;
      return;
    }
    const n = this.playingItem, o = this.findItemIndex(n);
    let c = i.findItemIndexAtTime(e);
    if (this.bufferedPos < e) {
      var l, h;
      const u = this.findItemIndex(r), d = Math.min(u + 1, t.length - 1), f = t[d];
      if ((c === -1 && r && e >= r.end || (l = f.event) != null && l.appendInPlace && e + 0.01 >= f.start) && (c = d), d - o > 1 && (r == null || (h = r.event) == null ? void 0 : h.appendInPlace) === !1)
        return;
      if (this.bufferedPos = e, c > u && c > o)
        this.bufferedToItem(f);
      else {
        const g = this.primaryDetails;
        this.primaryLive && g && e > g.edge - g.targetduration && f.start < g.edge + this.hls.config.interstitialLiveLookAhead && this.isInterstitial(f) && this.preloadAssets(f.event, 0);
      }
    } else s && n && !this.itemsMatch(n, r) && (c === o ? this.bufferedToItem(n) : c === o + 1 && this.bufferedToItem(t[c]));
  }
  assetsBuffered(e, t) {
    return e.event.assetList.length === 0 ? !1 : !e.event.assetList.some((i) => {
      const r = this.getAssetPlayer(i.identifier);
      return !(r != null && r.bufferedInPlaceToEnd(t));
    });
  }
  setBufferingItem(e) {
    const t = this.bufferingItem, s = this.schedule;
    if (this.itemsMatch(e, t))
      this.bufferingItem !== e && (this.bufferingItem = e);
    else {
      const {
        items: i,
        events: r
      } = s;
      if (!i || !r)
        return t;
      const n = this.isInterstitial(e), o = this.getBufferingPlayer();
      if (this.bufferingItem = e, this.bufferedPos = Math.max(e.start, Math.min(e.end, this.timelinePos)), !this.playbackDisabled) {
        const c = o ? o.remaining : t ? t.end - this.timelinePos : 0;
        this.log(`buffered to boundary ${Ye(e)}` + (t ? ` (${c.toFixed(2)} remaining)` : "")), n ? e.event.assetList.forEach((l) => {
          const h = this.getAssetPlayer(l.identifier);
          h && h.resumeBuffering();
        }) : (this.hls.resumeBuffering(), this.playerQueue.forEach((l) => l.pauseBuffering()));
      }
      this.hls.trigger(m.INTERSTITIALS_BUFFERED_TO_BOUNDARY, {
        events: r.slice(0),
        schedule: i.slice(0),
        bufferingIndex: this.findItemIndex(e),
        playingIndex: this.findItemIndex(this.playingItem)
      });
    }
    return t;
  }
  bufferedToItem(e, t = 0) {
    const s = this.setBufferingItem(e);
    if (!this.playbackDisabled) {
      if (this.isInterstitial(e))
        this.bufferedToEvent(e, t);
      else if (s !== null) {
        this.bufferingAsset = null;
        const i = this.detachedData;
        i ? i.mediaSource ? this.attachPrimary(e.start, e, !0) : this.preloadPrimary(e) : this.preloadPrimary(e);
      }
    }
  }
  preloadPrimary(e) {
    const t = this.findItemIndex(e), s = this.getPrimaryResumption(e, t);
    this.startLoadingPrimaryAt(s);
  }
  bufferedToEvent(e, t) {
    const s = e.event, i = s.assetList.length === 0 && !s.assetListLoader, r = s.cue.once;
    if (i || !r) {
      const n = this.preloadAssets(s, t);
      if (n != null && n.interstitial.appendInPlace) {
        const o = s.assetList[t], c = this.primaryMedia;
        o && c && this.bufferAssetPlayer(n, c);
      }
    }
  }
  preloadAssets(e, t) {
    const s = e.assetUrl, i = e.assetList.length, r = i === 0 && !e.assetListLoader, n = e.cue.once;
    if (r) {
      const c = e.timelineStart;
      if (e.appendInPlace) {
        var o;
        const d = this.playingItem;
        !this.isInterstitial(d) && (d == null || (o = d.nextEvent) == null ? void 0 : o.identifier) === e.identifier && this.flushFrontBuffer(c + 0.25);
      }
      let l, h = 0;
      if (!this.playingItem && this.primaryLive && (h = this.hls.startPosition, h === -1 && (h = this.hls.liveSyncPosition || 0)), h && !(e.cue.pre || e.cue.post)) {
        const d = h - c;
        d > 0 && (l = Math.round(d * 1e3) / 1e3);
      }
      if (this.log(`Load interstitial asset ${t + 1}/${s ? 1 : i} ${e}${l ? ` live-start: ${h} start-offset: ${l}` : ""}`), s)
        return this.createAsset(e, 0, 0, c, e.duration, s);
      const u = this.assetListLoader.loadAssetList(e, l);
      u && (e.assetListLoader = u);
    } else if (!n && i) {
      for (let c = t; c < i; c++) {
        const l = e.assetList[c], h = this.getAssetPlayerQueueIndex(l.identifier);
        (h === -1 || this.playerQueue[h].destroyed) && !l.error && this.createAssetPlayer(e, l, c);
      }
      return this.getAssetPlayer(e.assetList[t].identifier);
    }
    return null;
  }
  flushFrontBuffer(e) {
    const t = this.requiredTracks;
    if (!t)
      return;
    this.log(`Removing front buffer starting at ${e}`), Object.keys(t).forEach((i) => {
      this.hls.trigger(m.BUFFER_FLUSHING, {
        startOffset: e,
        endOffset: 1 / 0,
        type: i
      });
    });
  }
  // Interstitial Asset Player control
  getAssetPlayerQueueIndex(e) {
    const t = this.playerQueue;
    for (let s = 0; s < t.length; s++)
      if (e === t[s].assetId)
        return s;
    return -1;
  }
  getAssetPlayer(e) {
    const t = this.getAssetPlayerQueueIndex(e);
    return this.playerQueue[t] || null;
  }
  getBufferingPlayer() {
    const {
      playerQueue: e,
      primaryMedia: t
    } = this;
    if (t) {
      for (let s = 0; s < e.length; s++)
        if (e[s].media === t)
          return e[s];
    }
    return null;
  }
  createAsset(e, t, s, i, r, n) {
    const o = {
      parentIdentifier: e.identifier,
      identifier: wh(e, n, t),
      duration: r,
      startOffset: s,
      timelineStart: i,
      uri: n
    };
    return this.createAssetPlayer(e, o, t);
  }
  createAssetPlayer(e, t, s) {
    this.log(`create HLSAssetPlayer for ${ci(t)}`);
    const i = this.hls, r = i.userConfig;
    let n = r.videoPreference;
    const o = i.loadLevelObj || i.levels[i.currentLevel];
    (n || o) && (n = re({}, n), o.videoCodec && (n.videoCodec = o.videoCodec), o.videoRange && (n.allowedVideoRanges = [o.videoRange]));
    const c = i.audioTracks[i.audioTrack], l = i.subtitleTracks[i.subtitleTrack];
    let h = 0;
    if (this.primaryLive || e.appendInPlace) {
      const T = this.timelinePos - t.timelineStart;
      if (T > 1) {
        const v = t.duration;
        v && T < v && (h = T);
      }
    }
    const u = t.identifier, d = te(te({}, r), {}, {
      autoStartLoad: !0,
      startFragPrefetch: !0,
      primarySessionId: i.sessionId,
      assetPlayerId: u,
      abrEwmaDefaultEstimate: i.bandwidthEstimate,
      interstitialsController: void 0,
      startPosition: h,
      liveDurationInfinity: !1,
      testBandwidth: !1,
      videoPreference: n,
      audioPreference: c || r.audioPreference,
      subtitlePreference: l || r.subtitlePreference
    });
    e.appendInPlace && (e.appendInPlaceStarted = !0, t.timelineStart && (d.timelineOffset = t.timelineStart));
    const f = d.cmcd;
    f != null && f.sessionId && f.contentId && (d.cmcd = re({}, f, {
      contentId: It(t.uri)
    })), this.getAssetPlayer(u) && this.warn(`Duplicate date range identifier ${e} and asset ${u}`);
    const g = new Mh(this.HlsPlayerClass, d, e, t);
    this.playerQueue.push(g), e.assetList[s] = t;
    const p = (T) => {
      if (T.live) {
        const _ = new Error(`Interstitials MUST be VOD assets ${e}`), A = {
          fatal: !0,
          type: K.OTHER_ERROR,
          details: R.INTERSTITIAL_ASSET_ITEM_ERROR,
          error: _
        };
        this.handleAssetItemError(A, e, this.schedule.findEventIndex(e.identifier), s, _.message);
        return;
      }
      const v = T.edge - T.fragmentStart, x = t.duration;
      (x === null || v > x) && (this.log(`Interstitial asset "${u}" duration change ${x} > ${v}`), t.duration = v, this.updateSchedule());
    };
    g.on(m.LEVEL_UPDATED, (T, {
      details: v
    }) => p(v)), g.on(m.LEVEL_PTS_UPDATED, (T, {
      details: v
    }) => p(v));
    const E = (T, v) => {
      const x = this.getAssetPlayer(u);
      if (x && v.tracks) {
        x.off(m.BUFFER_CODECS, E), x.tracks = v.tracks;
        const _ = this.primaryMedia;
        this.bufferingAsset === x.assetItem && _ && !x.media && this.bufferAssetPlayer(x, _);
      }
    };
    g.on(m.BUFFER_CODECS, E);
    const y = () => {
      var T;
      const v = this.getAssetPlayer(u);
      if (this.log(`buffered to end of asset ${v}`), !v)
        return;
      const x = this.schedule.findEventIndex(e.identifier), _ = e.findAssetIndex(t), A = _ + 1, b = (T = this.schedule.items) == null ? void 0 : T[x];
      if (this.isInterstitial(b))
        if (_ !== -1 && !e.isAssetPastPlayoutLimit(A) && !e.assetList[A].error)
          this.bufferedToItem(b, A);
        else {
          var D;
          const L = (D = this.schedule.items) == null ? void 0 : D[x + 1];
          L && this.bufferedToItem(L);
        }
    };
    g.on(m.BUFFERED_TO_END, y);
    const S = (T) => () => {
      if (!this.getAssetPlayer(u))
        return;
      this.shouldPlay = !0;
      const x = this.schedule.findEventIndex(e.identifier);
      this.advanceAfterAssetEnded(e, x, T);
    };
    return g.once(m.MEDIA_ENDED, S(s)), g.once(m.PLAYOUT_LIMIT_REACHED, S(1 / 0)), g.on(m.ERROR, (T, v) => {
      const x = this.getAssetPlayer(u);
      if (v.details === R.BUFFER_STALLED_ERROR) {
        if (x != null && x.media) {
          const _ = x.currentTime, A = x.duration - _;
          _ && e.appendInPlace && A / x.media.playbackRate < 0.5 ? (this.log(`Advancing buffer past end of asset ${u} ${e} at ${x.media.currentTime}`), y()) : (this.warn(`Stalled at ${_} of ${_ + A} in asset ${u} ${e}`), this.onTimeupdate(), this.checkBuffer(!0));
        }
        return;
      }
      this.handleAssetItemError(v, e, this.schedule.findEventIndex(e.identifier), s, `Asset player error ${v.error} ${e}`);
    }), g.on(m.DESTROYING, () => {
      if (!this.getAssetPlayer(u))
        return;
      const v = new Error(`Asset player destroyed unexpectedly ${u}`), x = {
        fatal: !0,
        type: K.OTHER_ERROR,
        details: R.INTERSTITIAL_ASSET_ITEM_ERROR,
        error: v
      };
      this.handleAssetItemError(x, e, this.schedule.findEventIndex(e.identifier), s, v.message);
    }), this.hls.trigger(m.INTERSTITIAL_ASSET_PLAYER_CREATED, {
      asset: t,
      assetListIndex: s,
      event: e,
      player: g
    }), g;
  }
  clearInterstitial(e, t) {
    e.assetList.forEach((s) => {
      this.clearAssetPlayer(s.identifier, t);
    }), e.reset();
  }
  clearAssetPlayer(e, t) {
    const s = this.getAssetPlayerQueueIndex(e);
    if (s !== -1) {
      this.log(`clearAssetPlayer "${e}" toSegment: ${t && Ye(t)}`);
      const i = this.playerQueue[s];
      this.transferMediaFromPlayer(i, t), this.playerQueue.splice(s, 1), i.destroy();
    }
  }
  emptyPlayerQueue() {
    let e;
    for (; e = this.playerQueue.pop(); )
      e.destroy();
    this.playerQueue = [];
  }
  startAssetPlayer(e, t, s, i, r) {
    const {
      interstitial: n,
      assetItem: o,
      assetId: c
    } = e, l = n.assetList.length, h = this.playingAsset;
    this.endedAsset = null, this.playingAsset = o, (!h || h.identifier !== c) && (h && (this.clearAssetPlayer(h.identifier, s[i]), delete h.error), this.log(`INTERSTITIAL_ASSET_STARTED ${t + 1}/${l} ${e}`), this.hls.trigger(m.INTERSTITIAL_ASSET_STARTED, {
      asset: o,
      assetListIndex: t,
      event: n,
      schedule: s.slice(0),
      scheduleIndex: i,
      player: e
    })), this.bufferAssetPlayer(e, r);
  }
  bufferAssetPlayer(e, t) {
    var s, i;
    const {
      interstitial: r,
      assetItem: n,
      assetId: o
    } = e, c = this.schedule.findEventIndex(r.identifier), l = (s = this.schedule.items) == null ? void 0 : s[c];
    if (!l)
      return;
    this.setBufferingItem(l), this.bufferingAsset = n;
    const h = this.getBufferingPlayer();
    if (h === e)
      return;
    const u = r.appendInPlace;
    if (u && (h == null ? void 0 : h.interstitial.appendInPlace) === !1)
      return;
    const d = (h == null ? void 0 : h.tracks) || ((i = this.detachedData) == null ? void 0 : i.tracks) || this.requiredTracks;
    if (u && n !== this.playingAsset) {
      if (!e.tracks)
        return;
      if (d && !En(d, e.tracks)) {
        const f = new Error(`Asset "${o}" SourceBuffer tracks ('${Object.keys(e.tracks)}') are not compatible with primary content tracks ('${Object.keys(d)}')`), g = {
          fatal: !0,
          type: K.OTHER_ERROR,
          details: R.INTERSTITIAL_ASSET_ITEM_ERROR,
          error: f
        }, p = r.findAssetIndex(n);
        this.handleAssetItemError(g, r, c, p, f.message);
        return;
      }
    }
    this.transferMediaTo(e, t);
  }
  handleAssetItemError(e, t, s, i, r) {
    if (e.details === R.BUFFER_STALLED_ERROR)
      return;
    const n = t.assetList[i] || null;
    let o = null;
    if (n) {
      const u = this.getAssetPlayerQueueIndex(n.identifier);
      o = this.playerQueue[u] || null;
    }
    const c = this.schedule.items, l = re({}, e, {
      fatal: !1,
      errorAction: Dt(!0),
      asset: n,
      assetListIndex: i,
      event: t,
      schedule: c,
      scheduleIndex: s,
      player: o
    });
    if (this.warn(`Asset item error: ${e.error}`), this.hls.trigger(m.INTERSTITIAL_ASSET_ERROR, l), !e.fatal)
      return;
    const h = new Error(r);
    n && (this.playingAsset !== n && this.clearAssetPlayer(n.identifier, null), n.error = h), t.assetList.some((u) => !u.error) ? t.appendInPlace && (t.error = h) : t.error = h, this.primaryFallback(t);
  }
  primaryFallback(e) {
    const t = e.timelineStart, s = this.effectivePlayingItem;
    if (this.updateSchedule(), s) {
      this.log(`Fallback to primary from event "${e.identifier}" start: ${t} pos: ${this.timelinePos} playing: ${s ? Ye(s) : "<none>"} error: ${e.error}`), e.appendInPlace && (this.attachPrimary(t, null), this.flushFrontBuffer(t));
      let i = this.timelinePos;
      i === -1 && (i = this.hls.startPosition);
      const r = this.updateItem(s, i);
      if (this.itemsMatch(s, r))
        this.clearInterstitial(e, null);
      else {
        const n = this.schedule.findItemIndexAtTime(i);
        this.setSchedulePosition(n);
      }
    } else
      this.checkStart();
  }
  // Asset List loading
  onAssetListLoaded(e, t) {
    var s;
    const i = t.event, r = i.identifier, n = t.assetListResponse.ASSETS;
    if (!this.schedule.hasEvent(r))
      return;
    const o = i.timelineStart, c = i.duration;
    let l = 0;
    n.forEach((g, p) => {
      const E = parseFloat(g.DURATION);
      this.createAsset(i, p, l, o + l, E, g.URI), l += E;
    }), i.duration = l, this.log(`Loaded asset-list with duration: ${l} (was: ${c}) ${i}`);
    const h = this.waitingItem, u = (h == null ? void 0 : h.event.identifier) === r;
    this.updateSchedule();
    const d = (s = this.bufferingItem) == null ? void 0 : s.event;
    if (u) {
      var f;
      const g = this.schedule.findEventIndex(r), p = (f = this.schedule.items) == null ? void 0 : f[g];
      if (p) {
        if (!this.playingItem && this.timelinePos > p.end && this.schedule.findItemIndexAtTime(this.timelinePos) !== g) {
          i.error = new Error(`Interstitial no longer within playback range ${this.timelinePos} ${i}`), this.primaryFallback(i);
          return;
        }
        this.setBufferingItem(p);
      }
      this.setSchedulePosition(g);
    } else if ((d == null ? void 0 : d.identifier) === r && d.appendInPlace) {
      const g = i.assetList[0], p = this.getAssetPlayer(g.identifier), E = this.primaryMedia;
      g && p && E && this.bufferAssetPlayer(p, E);
    }
  }
  onError(e, t) {
    switch (t.details) {
      case R.ASSET_LIST_PARSING_ERROR:
      case R.ASSET_LIST_LOAD_ERROR:
      case R.ASSET_LIST_LOAD_TIMEOUT: {
        const s = t.interstitial;
        s && this.primaryFallback(s);
        break;
      }
      case R.BUFFER_STALLED_ERROR: {
        this.onTimeupdate(), this.checkBuffer(!0);
        break;
      }
    }
  }
}
const qr = 500;
class $h extends xi {
  constructor(e, t, s) {
    super(e, t, s, "subtitle-stream-controller", G.SUBTITLE), this.currentTrackId = -1, this.tracksBuffered = [], this.mainDetails = null, this.registerListeners();
  }
  onHandlerDestroying() {
    this.unregisterListeners(), super.onHandlerDestroying(), this.mainDetails = null;
  }
  registerListeners() {
    super.registerListeners();
    const {
      hls: e
    } = this;
    e.on(m.LEVEL_LOADED, this.onLevelLoaded, this), e.on(m.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), e.on(m.SUBTITLE_TRACK_SWITCH, this.onSubtitleTrackSwitch, this), e.on(m.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), e.on(m.SUBTITLE_FRAG_PROCESSED, this.onSubtitleFragProcessed, this), e.on(m.BUFFER_FLUSHING, this.onBufferFlushing, this);
  }
  unregisterListeners() {
    super.unregisterListeners();
    const {
      hls: e
    } = this;
    e.off(m.LEVEL_LOADED, this.onLevelLoaded, this), e.off(m.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), e.off(m.SUBTITLE_TRACK_SWITCH, this.onSubtitleTrackSwitch, this), e.off(m.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), e.off(m.SUBTITLE_FRAG_PROCESSED, this.onSubtitleFragProcessed, this), e.off(m.BUFFER_FLUSHING, this.onBufferFlushing, this);
  }
  startLoad(e, t) {
    this.stopLoad(), this.state = C.IDLE, this.setInterval(qr), this.nextLoadPosition = this.lastCurrentTime = e + this.timelineOffset, this.startPosition = t ? -1 : e, this.tick();
  }
  onManifestLoading() {
    super.onManifestLoading(), this.mainDetails = null;
  }
  onMediaDetaching(e, t) {
    this.tracksBuffered = [], super.onMediaDetaching(e, t);
  }
  onLevelLoaded(e, t) {
    this.mainDetails = t.details;
  }
  onSubtitleFragProcessed(e, t) {
    const {
      frag: s,
      success: i
    } = t;
    if (ue(s) && (this.fragPrevious = s), this.state = C.IDLE, !i)
      return;
    const r = this.tracksBuffered[this.currentTrackId];
    if (!r)
      return;
    let n;
    const o = s.start;
    for (let l = 0; l < r.length; l++)
      if (o >= r[l].start && o <= r[l].end) {
        n = r[l];
        break;
      }
    const c = s.start + s.duration;
    n ? n.end = c : (n = {
      start: o,
      end: c
    }, r.push(n)), this.fragmentTracker.fragBuffered(s), this.fragBufferedComplete(s, null), this.media && this.tick();
  }
  onBufferFlushing(e, t) {
    const {
      startOffset: s,
      endOffset: i
    } = t;
    if (s === 0 && i !== Number.POSITIVE_INFINITY) {
      const r = i - 1;
      if (r <= 0)
        return;
      t.endOffsetSubtitles = Math.max(0, r), this.tracksBuffered.forEach((n) => {
        for (let o = 0; o < n.length; ) {
          if (n[o].end <= r) {
            n.shift();
            continue;
          } else if (n[o].start < r)
            n[o].start = r;
          else
            break;
          o++;
        }
      }), this.fragmentTracker.removeFragmentsInRange(s, r, G.SUBTITLE);
    }
  }
  // If something goes wrong, proceed to next frag, if we were processing one.
  onError(e, t) {
    const s = t.frag;
    (s == null ? void 0 : s.type) === G.SUBTITLE && (t.details === R.FRAG_GAP && this.fragmentTracker.fragBuffered(s, !0), this.fragCurrent && this.fragCurrent.abortRequests(), this.state !== C.STOPPED && (this.state = C.IDLE));
  }
  // Got all new subtitle levels.
  onSubtitleTracksUpdated(e, {
    subtitleTracks: t
  }) {
    if (this.levels && pa(this.levels, t)) {
      this.levels = t.map((s) => new _t(s));
      return;
    }
    this.tracksBuffered = [], this.levels = t.map((s) => {
      const i = new _t(s);
      return this.tracksBuffered[i.id] = [], i;
    }), this.fragmentTracker.removeFragmentsInRange(0, Number.POSITIVE_INFINITY, G.SUBTITLE), this.fragPrevious = null, this.mediaBuffer = null;
  }
  onSubtitleTrackSwitch(e, t) {
    var s;
    if (this.currentTrackId = t.id, !((s = this.levels) != null && s.length) || this.currentTrackId === -1) {
      this.clearInterval();
      return;
    }
    const i = this.levels[this.currentTrackId];
    i != null && i.details ? this.mediaBuffer = this.mediaBufferTimeRanges : this.mediaBuffer = null, i && this.state !== C.STOPPED && this.setInterval(qr);
  }
  // Got a new set of subtitle fragments.
  onSubtitleTrackLoaded(e, t) {
    var s;
    const {
      currentTrackId: i,
      levels: r
    } = this, {
      details: n,
      id: o
    } = t;
    if (!r) {
      this.warn(`Subtitle tracks were reset while loading level ${o}`);
      return;
    }
    const c = r[o];
    if (o >= r.length || !c)
      return;
    this.log(`Subtitle track ${o} loaded [${n.startSN},${n.endSN}]${n.lastPartSn ? `[part-${n.lastPartSn}-${n.lastPartIndex}]` : ""},duration:${n.totalduration}`), this.mediaBuffer = this.mediaBufferTimeRanges;
    let l = 0;
    if (n.live || (s = c.details) != null && s.live) {
      const u = this.mainDetails;
      if (n.deltaUpdateFailed || !u)
        return;
      const d = u.fragments[0];
      if (!c.details)
        n.hasProgramDateTime && u.hasProgramDateTime ? (fs(n, u), l = n.fragmentStart) : d && (l = d.start, si(n, l));
      else {
        var h;
        l = this.alignPlaylists(n, c.details, (h = this.levelLastLoaded) == null ? void 0 : h.details), l === 0 && d && (l = d.start, si(n, l));
      }
    }
    c.details = n, this.levelLastLoaded = c, o === i && (this.hls.trigger(m.SUBTITLE_TRACK_UPDATED, {
      details: n,
      id: o,
      groupId: t.groupId
    }), this.tick(), n.live && !this.fragCurrent && this.media && this.state === C.IDLE && (it(null, n.fragments, this.media.currentTime, 0) || (this.warn("Subtitle playlist not aligned with playback"), c.details = void 0)));
  }
  _handleFragmentLoadComplete(e) {
    const {
      frag: t,
      payload: s
    } = e, i = t.decryptdata, r = this.hls;
    if (!this.fragContextChanged(t) && s && s.byteLength > 0 && i != null && i.key && i.iv && dt(i.method)) {
      const n = performance.now();
      this.decrypter.decrypt(new Uint8Array(s), i.key.buffer, i.iv.buffer, Si(i.method)).catch((o) => {
        throw r.trigger(m.ERROR, {
          type: K.MEDIA_ERROR,
          details: R.FRAG_DECRYPT_ERROR,
          fatal: !1,
          error: o,
          reason: o.message,
          frag: t
        }), o;
      }).then((o) => {
        const c = performance.now();
        r.trigger(m.FRAG_DECRYPTED, {
          frag: t,
          payload: o,
          stats: {
            tstart: n,
            tdecrypt: c
          }
        });
      }).catch((o) => {
        this.warn(`${o.name}: ${o.message}`), this.state = C.IDLE;
      });
    }
  }
  doTick() {
    if (!this.media) {
      this.state = C.IDLE;
      return;
    }
    if (this.state === C.IDLE) {
      const {
        currentTrackId: e,
        levels: t
      } = this, s = t == null ? void 0 : t[e];
      if (!s || !t.length || !s.details || this.waitForLive(s))
        return;
      const {
        config: i
      } = this, r = this.getLoadPosition(), n = q.bufferedInfo(this.tracksBuffered[this.currentTrackId] || [], r, i.maxBufferHole), {
        end: o,
        len: c
      } = n, l = s.details, h = this.hls.maxBufferLength + l.levelTargetDuration;
      if (c > h)
        return;
      const u = l.fragments, d = u.length, f = l.edge;
      let g = null;
      const p = this.fragPrevious;
      if (o < f) {
        const S = i.maxFragLookUpTolerance, T = o > f - S ? 0 : S;
        g = it(p, u, Math.max(u[0].start, o), T), !g && p && p.start < u[0].start && (g = u[0]);
      } else
        g = u[d - 1];
      if (g = this.filterReplacedPrimary(g, s.details), !g)
        return;
      const E = g.sn - l.startSN, y = u[E - 1];
      if (y && y.cc === g.cc && this.fragmentTracker.getState(y) === ce.NOT_LOADED && (g = y), this.fragmentTracker.getState(g) === ce.NOT_LOADED) {
        const S = this.mapToInitFragWhenRequired(g);
        S && this.loadFragment(S, s, o);
      }
    }
  }
  loadFragment(e, t, s) {
    ue(e) ? super.loadFragment(e, t, s) : this._loadInitSegment(e, t);
  }
  get mediaBufferTimeRanges() {
    return new Gh(this.tracksBuffered[this.currentTrackId] || []);
  }
}
class Gh {
  constructor(e) {
    this.buffered = void 0;
    const t = (s, i, r) => {
      if (i = i >>> 0, i > r - 1)
        throw new DOMException(`Failed to execute '${s}' on 'TimeRanges': The index provided (${i}) is greater than the maximum bound (${r})`);
      return e[i][s];
    };
    this.buffered = {
      get length() {
        return e.length;
      },
      end(s) {
        return t("end", s, e.length);
      },
      start(s) {
        return t("start", s, e.length);
      }
    };
  }
}
const Kh = {
  42: 225,
  // lowercase a, acute accent
  92: 233,
  // lowercase e, acute accent
  94: 237,
  // lowercase i, acute accent
  95: 243,
  // lowercase o, acute accent
  96: 250,
  // lowercase u, acute accent
  123: 231,
  // lowercase c with cedilla
  124: 247,
  // division symbol
  125: 209,
  // uppercase N tilde
  126: 241,
  // lowercase n tilde
  127: 9608,
  // Full block
  // THIS BLOCK INCLUDES THE 16 EXTENDED (TWO-BYTE) LINE 21 CHARACTERS
  // THAT COME FROM HI BYTE=0x11 AND LOW BETWEEN 0x30 AND 0x3F
  // THIS MEANS THAT \x50 MUST BE ADDED TO THE VALUES
  128: 174,
  // Registered symbol (R)
  129: 176,
  // degree sign
  130: 189,
  // 1/2 symbol
  131: 191,
  // Inverted (open) question mark
  132: 8482,
  // Trademark symbol (TM)
  133: 162,
  // Cents symbol
  134: 163,
  // Pounds sterling
  135: 9834,
  // Music 8'th note
  136: 224,
  // lowercase a, grave accent
  137: 32,
  // transparent space (regular)
  138: 232,
  // lowercase e, grave accent
  139: 226,
  // lowercase a, circumflex accent
  140: 234,
  // lowercase e, circumflex accent
  141: 238,
  // lowercase i, circumflex accent
  142: 244,
  // lowercase o, circumflex accent
  143: 251,
  // lowercase u, circumflex accent
  // THIS BLOCK INCLUDES THE 32 EXTENDED (TWO-BYTE) LINE 21 CHARACTERS
  // THAT COME FROM HI BYTE=0x12 AND LOW BETWEEN 0x20 AND 0x3F
  144: 193,
  // capital letter A with acute
  145: 201,
  // capital letter E with acute
  146: 211,
  // capital letter O with acute
  147: 218,
  // capital letter U with acute
  148: 220,
  // capital letter U with diaresis
  149: 252,
  // lowercase letter U with diaeresis
  150: 8216,
  // opening single quote
  151: 161,
  // inverted exclamation mark
  152: 42,
  // asterisk
  153: 8217,
  // closing single quote
  154: 9473,
  // box drawings heavy horizontal
  155: 169,
  // copyright sign
  156: 8480,
  // Service mark
  157: 8226,
  // (round) bullet
  158: 8220,
  // Left double quotation mark
  159: 8221,
  // Right double quotation mark
  160: 192,
  // uppercase A, grave accent
  161: 194,
  // uppercase A, circumflex
  162: 199,
  // uppercase C with cedilla
  163: 200,
  // uppercase E, grave accent
  164: 202,
  // uppercase E, circumflex
  165: 203,
  // capital letter E with diaresis
  166: 235,
  // lowercase letter e with diaresis
  167: 206,
  // uppercase I, circumflex
  168: 207,
  // uppercase I, with diaresis
  169: 239,
  // lowercase i, with diaresis
  170: 212,
  // uppercase O, circumflex
  171: 217,
  // uppercase U, grave accent
  172: 249,
  // lowercase u, grave accent
  173: 219,
  // uppercase U, circumflex
  174: 171,
  // left-pointing double angle quotation mark
  175: 187,
  // right-pointing double angle quotation mark
  // THIS BLOCK INCLUDES THE 32 EXTENDED (TWO-BYTE) LINE 21 CHARACTERS
  // THAT COME FROM HI BYTE=0x13 AND LOW BETWEEN 0x20 AND 0x3F
  176: 195,
  // Uppercase A, tilde
  177: 227,
  // Lowercase a, tilde
  178: 205,
  // Uppercase I, acute accent
  179: 204,
  // Uppercase I, grave accent
  180: 236,
  // Lowercase i, grave accent
  181: 210,
  // Uppercase O, grave accent
  182: 242,
  // Lowercase o, grave accent
  183: 213,
  // Uppercase O, tilde
  184: 245,
  // Lowercase o, tilde
  185: 123,
  // Open curly brace
  186: 125,
  // Closing curly brace
  187: 92,
  // Backslash
  188: 94,
  // Caret
  189: 95,
  // Underscore
  190: 124,
  // Pipe (vertical line)
  191: 8764,
  // Tilde operator
  192: 196,
  // Uppercase A, umlaut
  193: 228,
  // Lowercase A, umlaut
  194: 214,
  // Uppercase O, umlaut
  195: 246,
  // Lowercase o, umlaut
  196: 223,
  // Esszett (sharp S)
  197: 165,
  // Yen symbol
  198: 164,
  // Generic currency sign
  199: 9475,
  // Box drawings heavy vertical
  200: 197,
  // Uppercase A, ring
  201: 229,
  // Lowercase A, ring
  202: 216,
  // Uppercase O, stroke
  203: 248,
  // Lowercase o, strok
  204: 9487,
  // Box drawings heavy down and right
  205: 9491,
  // Box drawings heavy down and left
  206: 9495,
  // Box drawings heavy up and right
  207: 9499
  // Box drawings heavy up and left
}, Ra = (a) => String.fromCharCode(Kh[a] || a), be = 15, Be = 100, Vh = {
  17: 1,
  18: 3,
  21: 5,
  22: 7,
  23: 9,
  16: 11,
  19: 12,
  20: 14
}, Hh = {
  17: 2,
  18: 4,
  21: 6,
  22: 8,
  23: 10,
  19: 13,
  20: 15
}, Wh = {
  25: 1,
  26: 3,
  29: 5,
  30: 7,
  31: 9,
  24: 11,
  27: 12,
  28: 14
}, Yh = {
  25: 2,
  26: 4,
  29: 6,
  30: 8,
  31: 10,
  27: 13,
  28: 15
}, qh = ["white", "green", "blue", "cyan", "red", "yellow", "magenta", "black", "transparent"];
class jh {
  constructor() {
    this.time = null, this.verboseLevel = 0;
  }
  log(e, t) {
    if (this.verboseLevel >= e) {
      const s = typeof t == "function" ? t() : t;
      Q.log(`${this.time} [${e}] ${s}`);
    }
  }
}
const et = function(e) {
  const t = [];
  for (let s = 0; s < e.length; s++)
    t.push(e[s].toString(16));
  return t;
};
class ba {
  constructor() {
    this.foreground = "white", this.underline = !1, this.italics = !1, this.background = "black", this.flash = !1;
  }
  reset() {
    this.foreground = "white", this.underline = !1, this.italics = !1, this.background = "black", this.flash = !1;
  }
  setStyles(e) {
    const t = ["foreground", "underline", "italics", "background", "flash"];
    for (let s = 0; s < t.length; s++) {
      const i = t[s];
      e.hasOwnProperty(i) && (this[i] = e[i]);
    }
  }
  isDefault() {
    return this.foreground === "white" && !this.underline && !this.italics && this.background === "black" && !this.flash;
  }
  equals(e) {
    return this.foreground === e.foreground && this.underline === e.underline && this.italics === e.italics && this.background === e.background && this.flash === e.flash;
  }
  copy(e) {
    this.foreground = e.foreground, this.underline = e.underline, this.italics = e.italics, this.background = e.background, this.flash = e.flash;
  }
  toString() {
    return "color=" + this.foreground + ", underline=" + this.underline + ", italics=" + this.italics + ", background=" + this.background + ", flash=" + this.flash;
  }
}
class Xh {
  constructor() {
    this.uchar = " ", this.penState = new ba();
  }
  reset() {
    this.uchar = " ", this.penState.reset();
  }
  setChar(e, t) {
    this.uchar = e, this.penState.copy(t);
  }
  setPenState(e) {
    this.penState.copy(e);
  }
  equals(e) {
    return this.uchar === e.uchar && this.penState.equals(e.penState);
  }
  copy(e) {
    this.uchar = e.uchar, this.penState.copy(e.penState);
  }
  isEmpty() {
    return this.uchar === " " && this.penState.isDefault();
  }
}
class zh {
  constructor(e) {
    this.chars = [], this.pos = 0, this.currPenState = new ba(), this.cueStartTime = null, this.logger = void 0;
    for (let t = 0; t < Be; t++)
      this.chars.push(new Xh());
    this.logger = e;
  }
  equals(e) {
    for (let t = 0; t < Be; t++)
      if (!this.chars[t].equals(e.chars[t]))
        return !1;
    return !0;
  }
  copy(e) {
    for (let t = 0; t < Be; t++)
      this.chars[t].copy(e.chars[t]);
  }
  isEmpty() {
    let e = !0;
    for (let t = 0; t < Be; t++)
      if (!this.chars[t].isEmpty()) {
        e = !1;
        break;
      }
    return e;
  }
  /**
   *  Set the cursor to a valid column.
   */
  setCursor(e) {
    this.pos !== e && (this.pos = e), this.pos < 0 ? (this.logger.log(3, "Negative cursor position " + this.pos), this.pos = 0) : this.pos > Be && (this.logger.log(3, "Too large cursor position " + this.pos), this.pos = Be);
  }
  /**
   * Move the cursor relative to current position.
   */
  moveCursor(e) {
    const t = this.pos + e;
    if (e > 1)
      for (let s = this.pos + 1; s < t + 1; s++)
        this.chars[s].setPenState(this.currPenState);
    this.setCursor(t);
  }
  /**
   * Backspace, move one step back and clear character.
   */
  backSpace() {
    this.moveCursor(-1), this.chars[this.pos].setChar(" ", this.currPenState);
  }
  insertChar(e) {
    e >= 144 && this.backSpace();
    const t = Ra(e);
    if (this.pos >= Be) {
      this.logger.log(0, () => "Cannot insert " + e.toString(16) + " (" + t + ") at position " + this.pos + ". Skipping it!");
      return;
    }
    this.chars[this.pos].setChar(t, this.currPenState), this.moveCursor(1);
  }
  clearFromPos(e) {
    let t;
    for (t = e; t < Be; t++)
      this.chars[t].reset();
  }
  clear() {
    this.clearFromPos(0), this.pos = 0, this.currPenState.reset();
  }
  clearToEndOfRow() {
    this.clearFromPos(this.pos);
  }
  getTextString() {
    const e = [];
    let t = !0;
    for (let s = 0; s < Be; s++) {
      const i = this.chars[s].uchar;
      i !== " " && (t = !1), e.push(i);
    }
    return t ? "" : e.join("");
  }
  setPenStyles(e) {
    this.currPenState.setStyles(e), this.chars[this.pos].setPenState(this.currPenState);
  }
}
class $s {
  constructor(e) {
    this.rows = [], this.currRow = be - 1, this.nrRollUpRows = null, this.lastOutputScreen = null, this.logger = void 0;
    for (let t = 0; t < be; t++)
      this.rows.push(new zh(e));
    this.logger = e;
  }
  reset() {
    for (let e = 0; e < be; e++)
      this.rows[e].clear();
    this.currRow = be - 1;
  }
  equals(e) {
    let t = !0;
    for (let s = 0; s < be; s++)
      if (!this.rows[s].equals(e.rows[s])) {
        t = !1;
        break;
      }
    return t;
  }
  copy(e) {
    for (let t = 0; t < be; t++)
      this.rows[t].copy(e.rows[t]);
  }
  isEmpty() {
    let e = !0;
    for (let t = 0; t < be; t++)
      if (!this.rows[t].isEmpty()) {
        e = !1;
        break;
      }
    return e;
  }
  backSpace() {
    this.rows[this.currRow].backSpace();
  }
  clearToEndOfRow() {
    this.rows[this.currRow].clearToEndOfRow();
  }
  /**
   * Insert a character (without styling) in the current row.
   */
  insertChar(e) {
    this.rows[this.currRow].insertChar(e);
  }
  setPen(e) {
    this.rows[this.currRow].setPenStyles(e);
  }
  moveCursor(e) {
    this.rows[this.currRow].moveCursor(e);
  }
  setCursor(e) {
    this.logger.log(2, "setCursor: " + e), this.rows[this.currRow].setCursor(e);
  }
  setPAC(e) {
    this.logger.log(2, () => "pacData = " + ae(e));
    let t = e.row - 1;
    if (this.nrRollUpRows && t < this.nrRollUpRows - 1 && (t = this.nrRollUpRows - 1), this.nrRollUpRows && this.currRow !== t) {
      for (let o = 0; o < be; o++)
        this.rows[o].clear();
      const r = this.currRow + 1 - this.nrRollUpRows, n = this.lastOutputScreen;
      if (n) {
        const o = n.rows[r].cueStartTime, c = this.logger.time;
        if (o !== null && c !== null && o < c)
          for (let l = 0; l < this.nrRollUpRows; l++)
            this.rows[t - this.nrRollUpRows + l + 1].copy(n.rows[r + l]);
      }
    }
    this.currRow = t;
    const s = this.rows[this.currRow];
    if (e.indent !== null) {
      const r = e.indent, n = Math.max(r - 1, 0);
      s.setCursor(e.indent), e.color = s.chars[n].penState.foreground;
    }
    const i = {
      foreground: e.color,
      underline: e.underline,
      italics: e.italics,
      background: "black",
      flash: !1
    };
    this.setPen(i);
  }
  /**
   * Set background/extra foreground, but first do back_space, and then insert space (backwards compatibility).
   */
  setBkgData(e) {
    this.logger.log(2, () => "bkgData = " + ae(e)), this.backSpace(), this.setPen(e), this.insertChar(32);
  }
  setRollUpRows(e) {
    this.nrRollUpRows = e;
  }
  rollUp() {
    if (this.nrRollUpRows === null) {
      this.logger.log(3, "roll_up but nrRollUpRows not set yet");
      return;
    }
    this.logger.log(1, () => this.getDisplayText());
    const e = this.currRow + 1 - this.nrRollUpRows, t = this.rows.splice(e, 1)[0];
    t.clear(), this.rows.splice(this.currRow, 0, t), this.logger.log(2, "Rolling up");
  }
  /**
   * Get all non-empty rows with as unicode text.
   */
  getDisplayText(e) {
    e = e || !1;
    const t = [];
    let s = "", i = -1;
    for (let r = 0; r < be; r++) {
      const n = this.rows[r].getTextString();
      n && (i = r + 1, e ? t.push("Row " + i + ": '" + n + "'") : t.push(n.trim()));
    }
    return t.length > 0 && (e ? s = "[" + t.join(" | ") + "]" : s = t.join(`
`)), s;
  }
  getTextAndFormat() {
    return this.rows;
  }
}
class jr {
  constructor(e, t, s) {
    this.chNr = void 0, this.outputFilter = void 0, this.mode = void 0, this.verbose = void 0, this.displayedMemory = void 0, this.nonDisplayedMemory = void 0, this.lastOutputScreen = void 0, this.currRollUpRow = void 0, this.writeScreen = void 0, this.cueStartTime = void 0, this.logger = void 0, this.chNr = e, this.outputFilter = t, this.mode = null, this.verbose = 0, this.displayedMemory = new $s(s), this.nonDisplayedMemory = new $s(s), this.lastOutputScreen = new $s(s), this.currRollUpRow = this.displayedMemory.rows[be - 1], this.writeScreen = this.displayedMemory, this.mode = null, this.cueStartTime = null, this.logger = s;
  }
  reset() {
    this.mode = null, this.displayedMemory.reset(), this.nonDisplayedMemory.reset(), this.lastOutputScreen.reset(), this.outputFilter.reset(), this.currRollUpRow = this.displayedMemory.rows[be - 1], this.writeScreen = this.displayedMemory, this.mode = null, this.cueStartTime = null;
  }
  getHandler() {
    return this.outputFilter;
  }
  setHandler(e) {
    this.outputFilter = e;
  }
  setPAC(e) {
    this.writeScreen.setPAC(e);
  }
  setBkgData(e) {
    this.writeScreen.setBkgData(e);
  }
  setMode(e) {
    e !== this.mode && (this.mode = e, this.logger.log(2, () => "MODE=" + e), this.mode === "MODE_POP-ON" ? this.writeScreen = this.nonDisplayedMemory : (this.writeScreen = this.displayedMemory, this.writeScreen.reset()), this.mode !== "MODE_ROLL-UP" && (this.displayedMemory.nrRollUpRows = null, this.nonDisplayedMemory.nrRollUpRows = null), this.mode = e);
  }
  insertChars(e) {
    for (let s = 0; s < e.length; s++)
      this.writeScreen.insertChar(e[s]);
    const t = this.writeScreen === this.displayedMemory ? "DISP" : "NON_DISP";
    this.logger.log(2, () => t + ": " + this.writeScreen.getDisplayText(!0)), (this.mode === "MODE_PAINT-ON" || this.mode === "MODE_ROLL-UP") && (this.logger.log(1, () => "DISPLAYED: " + this.displayedMemory.getDisplayText(!0)), this.outputDataUpdate());
  }
  ccRCL() {
    this.logger.log(2, "RCL - Resume Caption Loading"), this.setMode("MODE_POP-ON");
  }
  ccBS() {
    this.logger.log(2, "BS - BackSpace"), this.mode !== "MODE_TEXT" && (this.writeScreen.backSpace(), this.writeScreen === this.displayedMemory && this.outputDataUpdate());
  }
  ccAOF() {
  }
  ccAON() {
  }
  ccDER() {
    this.logger.log(2, "DER- Delete to End of Row"), this.writeScreen.clearToEndOfRow(), this.outputDataUpdate();
  }
  ccRU(e) {
    this.logger.log(2, "RU(" + e + ") - Roll Up"), this.writeScreen = this.displayedMemory, this.setMode("MODE_ROLL-UP"), this.writeScreen.setRollUpRows(e);
  }
  ccFON() {
    this.logger.log(2, "FON - Flash On"), this.writeScreen.setPen({
      flash: !0
    });
  }
  ccRDC() {
    this.logger.log(2, "RDC - Resume Direct Captioning"), this.setMode("MODE_PAINT-ON");
  }
  ccTR() {
    this.logger.log(2, "TR"), this.setMode("MODE_TEXT");
  }
  ccRTD() {
    this.logger.log(2, "RTD"), this.setMode("MODE_TEXT");
  }
  ccEDM() {
    this.logger.log(2, "EDM - Erase Displayed Memory"), this.displayedMemory.reset(), this.outputDataUpdate(!0);
  }
  ccCR() {
    this.logger.log(2, "CR - Carriage Return"), this.writeScreen.rollUp(), this.outputDataUpdate(!0);
  }
  ccENM() {
    this.logger.log(2, "ENM - Erase Non-displayed Memory"), this.nonDisplayedMemory.reset();
  }
  ccEOC() {
    if (this.logger.log(2, "EOC - End Of Caption"), this.mode === "MODE_POP-ON") {
      const e = this.displayedMemory;
      this.displayedMemory = this.nonDisplayedMemory, this.nonDisplayedMemory = e, this.writeScreen = this.nonDisplayedMemory, this.logger.log(1, () => "DISP: " + this.displayedMemory.getDisplayText());
    }
    this.outputDataUpdate(!0);
  }
  ccTO(e) {
    this.logger.log(2, "TO(" + e + ") - Tab Offset"), this.writeScreen.moveCursor(e);
  }
  ccMIDROW(e) {
    const t = {
      flash: !1
    };
    if (t.underline = e % 2 === 1, t.italics = e >= 46, t.italics)
      t.foreground = "white";
    else {
      const s = Math.floor(e / 2) - 16, i = ["white", "green", "blue", "cyan", "red", "yellow", "magenta"];
      t.foreground = i[s];
    }
    this.logger.log(2, "MIDROW: " + ae(t)), this.writeScreen.setPen(t);
  }
  outputDataUpdate(e = !1) {
    const t = this.logger.time;
    t !== null && this.outputFilter && (this.cueStartTime === null && !this.displayedMemory.isEmpty() ? this.cueStartTime = t : this.displayedMemory.equals(this.lastOutputScreen) || (this.outputFilter.newCue(this.cueStartTime, t, this.lastOutputScreen), e && this.outputFilter.dispatchCue && this.outputFilter.dispatchCue(), this.cueStartTime = this.displayedMemory.isEmpty() ? null : t), this.lastOutputScreen.copy(this.displayedMemory));
  }
  cueSplitAtTime(e) {
    this.outputFilter && (this.displayedMemory.isEmpty() || (this.outputFilter.newCue && this.outputFilter.newCue(this.cueStartTime, e, this.displayedMemory), this.cueStartTime = e));
  }
}
class Xr {
  constructor(e, t, s) {
    this.channels = void 0, this.currentChannel = 0, this.cmdHistory = Zh(), this.logger = void 0;
    const i = this.logger = new jh();
    this.channels = [null, new jr(e, t, i), new jr(e + 1, s, i)];
  }
  getHandler(e) {
    return this.channels[e].getHandler();
  }
  setHandler(e, t) {
    this.channels[e].setHandler(t);
  }
  /**
   * Add data for time t in forms of list of bytes (unsigned ints). The bytes are treated as pairs.
   */
  addData(e, t) {
    this.logger.time = e;
    for (let s = 0; s < t.length; s += 2) {
      const i = t[s] & 127, r = t[s + 1] & 127;
      let n = !1, o = null;
      if (i === 0 && r === 0)
        continue;
      this.logger.log(3, () => "[" + et([t[s], t[s + 1]]) + "] -> (" + et([i, r]) + ")");
      const c = this.cmdHistory;
      if (i >= 16 && i <= 31) {
        if (Qh(i, r, c)) {
          qt(null, null, c), this.logger.log(3, () => "Repeated command (" + et([i, r]) + ") is dropped");
          continue;
        }
        qt(i, r, this.cmdHistory), n = this.parseCmd(i, r), n || (n = this.parseMidrow(i, r)), n || (n = this.parsePAC(i, r)), n || (n = this.parseBackgroundAttributes(i, r));
      } else
        qt(null, null, c);
      if (!n && (o = this.parseChars(i, r), o)) {
        const h = this.currentChannel;
        h && h > 0 ? this.channels[h].insertChars(o) : this.logger.log(2, "No channel found yet. TEXT-MODE?");
      }
      !n && !o && this.logger.log(2, () => "Couldn't parse cleaned data " + et([i, r]) + " orig: " + et([t[s], t[s + 1]]));
    }
  }
  /**
   * Parse Command.
   * @returns True if a command was found
   */
  parseCmd(e, t) {
    const s = (e === 20 || e === 28 || e === 21 || e === 29) && t >= 32 && t <= 47, i = (e === 23 || e === 31) && t >= 33 && t <= 35;
    if (!(s || i))
      return !1;
    const r = e === 20 || e === 21 || e === 23 ? 1 : 2, n = this.channels[r];
    return e === 20 || e === 21 || e === 28 || e === 29 ? t === 32 ? n.ccRCL() : t === 33 ? n.ccBS() : t === 34 ? n.ccAOF() : t === 35 ? n.ccAON() : t === 36 ? n.ccDER() : t === 37 ? n.ccRU(2) : t === 38 ? n.ccRU(3) : t === 39 ? n.ccRU(4) : t === 40 ? n.ccFON() : t === 41 ? n.ccRDC() : t === 42 ? n.ccTR() : t === 43 ? n.ccRTD() : t === 44 ? n.ccEDM() : t === 45 ? n.ccCR() : t === 46 ? n.ccENM() : t === 47 && n.ccEOC() : n.ccTO(t - 32), this.currentChannel = r, !0;
  }
  /**
   * Parse midrow styling command
   */
  parseMidrow(e, t) {
    let s = 0;
    if ((e === 17 || e === 25) && t >= 32 && t <= 47) {
      if (e === 17 ? s = 1 : s = 2, s !== this.currentChannel)
        return this.logger.log(0, "Mismatch channel in midrow parsing"), !1;
      const i = this.channels[s];
      return i ? (i.ccMIDROW(t), this.logger.log(3, () => "MIDROW (" + et([e, t]) + ")"), !0) : !1;
    }
    return !1;
  }
  /**
   * Parse Preable Access Codes (Table 53).
   * @returns {Boolean} Tells if PAC found
   */
  parsePAC(e, t) {
    let s;
    const i = (e >= 17 && e <= 23 || e >= 25 && e <= 31) && t >= 64 && t <= 127, r = (e === 16 || e === 24) && t >= 64 && t <= 95;
    if (!(i || r))
      return !1;
    const n = e <= 23 ? 1 : 2;
    t >= 64 && t <= 95 ? s = n === 1 ? Vh[e] : Wh[e] : s = n === 1 ? Hh[e] : Yh[e];
    const o = this.channels[n];
    return o ? (o.setPAC(this.interpretPAC(s, t)), this.currentChannel = n, !0) : !1;
  }
  /**
   * Interpret the second byte of the pac, and return the information.
   * @returns pacData with style parameters
   */
  interpretPAC(e, t) {
    let s;
    const i = {
      color: null,
      italics: !1,
      indent: null,
      underline: !1,
      row: e
    };
    return t > 95 ? s = t - 96 : s = t - 64, i.underline = (s & 1) === 1, s <= 13 ? i.color = ["white", "green", "blue", "cyan", "red", "yellow", "magenta", "white"][Math.floor(s / 2)] : s <= 15 ? (i.italics = !0, i.color = "white") : i.indent = Math.floor((s - 16) / 2) * 4, i;
  }
  /**
   * Parse characters.
   * @returns An array with 1 to 2 codes corresponding to chars, if found. null otherwise.
   */
  parseChars(e, t) {
    let s, i = null, r = null;
    if (e >= 25 ? (s = 2, r = e - 8) : (s = 1, r = e), r >= 17 && r <= 19) {
      let n;
      r === 17 ? n = t + 80 : r === 18 ? n = t + 112 : n = t + 144, this.logger.log(2, () => "Special char '" + Ra(n) + "' in channel " + s), i = [n];
    } else e >= 32 && e <= 127 && (i = t === 0 ? [e] : [e, t]);
    return i && this.logger.log(3, () => "Char codes =  " + et(i).join(",")), i;
  }
  /**
   * Parse extended background attributes as well as new foreground color black.
   * @returns True if background attributes are found
   */
  parseBackgroundAttributes(e, t) {
    const s = (e === 16 || e === 24) && t >= 32 && t <= 47, i = (e === 23 || e === 31) && t >= 45 && t <= 47;
    if (!(s || i))
      return !1;
    let r;
    const n = {};
    e === 16 || e === 24 ? (r = Math.floor((t - 32) / 2), n.background = qh[r], t % 2 === 1 && (n.background = n.background + "_semi")) : t === 45 ? n.background = "transparent" : (n.foreground = "black", t === 47 && (n.underline = !0));
    const o = e <= 23 ? 1 : 2;
    return this.channels[o].setBkgData(n), !0;
  }
  /**
   * Reset state of parser and its channels.
   */
  reset() {
    for (let e = 0; e < Object.keys(this.channels).length; e++) {
      const t = this.channels[e];
      t && t.reset();
    }
    qt(null, null, this.cmdHistory);
  }
  /**
   * Trigger the generation of a cue, and the start of a new one if displayScreens are not empty.
   */
  cueSplitAtTime(e) {
    for (let t = 0; t < this.channels.length; t++) {
      const s = this.channels[t];
      s && s.cueSplitAtTime(e);
    }
  }
}
function qt(a, e, t) {
  t.a = a, t.b = e;
}
function Qh(a, e, t) {
  return t.a === a && t.b === e;
}
function Zh() {
  return {
    a: null,
    b: null
  };
}
var wi = function() {
  if (ds != null && ds.VTTCue)
    return self.VTTCue;
  const a = ["", "lr", "rl"], e = ["start", "middle", "end", "left", "right"];
  function t(o, c) {
    if (typeof c != "string" || !Array.isArray(o))
      return !1;
    const l = c.toLowerCase();
    return ~o.indexOf(l) ? l : !1;
  }
  function s(o) {
    return t(a, o);
  }
  function i(o) {
    return t(e, o);
  }
  function r(o, ...c) {
    let l = 1;
    for (; l < arguments.length; l++) {
      const h = arguments[l];
      for (const u in h)
        o[u] = h[u];
    }
    return o;
  }
  function n(o, c, l) {
    const h = this, u = {
      enumerable: !0
    };
    h.hasBeenReset = !1;
    let d = "", f = !1, g = o, p = c, E = l, y = null, S = "", T = !0, v = "auto", x = "start", _ = 50, A = "middle", b = 50, D = "middle";
    Object.defineProperty(h, "id", r({}, u, {
      get: function() {
        return d;
      },
      set: function(L) {
        d = "" + L;
      }
    })), Object.defineProperty(h, "pauseOnExit", r({}, u, {
      get: function() {
        return f;
      },
      set: function(L) {
        f = !!L;
      }
    })), Object.defineProperty(h, "startTime", r({}, u, {
      get: function() {
        return g;
      },
      set: function(L) {
        if (typeof L != "number")
          throw new TypeError("Start time must be set to a number.");
        g = L, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "endTime", r({}, u, {
      get: function() {
        return p;
      },
      set: function(L) {
        if (typeof L != "number")
          throw new TypeError("End time must be set to a number.");
        p = L, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "text", r({}, u, {
      get: function() {
        return E;
      },
      set: function(L) {
        E = "" + L, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "region", r({}, u, {
      get: function() {
        return y;
      },
      set: function(L) {
        y = L, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "vertical", r({}, u, {
      get: function() {
        return S;
      },
      set: function(L) {
        const k = s(L);
        if (k === !1)
          throw new SyntaxError("An invalid or illegal string was specified.");
        S = k, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "snapToLines", r({}, u, {
      get: function() {
        return T;
      },
      set: function(L) {
        T = !!L, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "line", r({}, u, {
      get: function() {
        return v;
      },
      set: function(L) {
        if (typeof L != "number" && L !== "auto")
          throw new SyntaxError("An invalid number or illegal string was specified.");
        v = L, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "lineAlign", r({}, u, {
      get: function() {
        return x;
      },
      set: function(L) {
        const k = i(L);
        if (!k)
          throw new SyntaxError("An invalid or illegal string was specified.");
        x = k, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "position", r({}, u, {
      get: function() {
        return _;
      },
      set: function(L) {
        if (L < 0 || L > 100)
          throw new Error("Position must be between 0 and 100.");
        _ = L, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "positionAlign", r({}, u, {
      get: function() {
        return A;
      },
      set: function(L) {
        const k = i(L);
        if (!k)
          throw new SyntaxError("An invalid or illegal string was specified.");
        A = k, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "size", r({}, u, {
      get: function() {
        return b;
      },
      set: function(L) {
        if (L < 0 || L > 100)
          throw new Error("Size must be between 0 and 100.");
        b = L, this.hasBeenReset = !0;
      }
    })), Object.defineProperty(h, "align", r({}, u, {
      get: function() {
        return D;
      },
      set: function(L) {
        const k = i(L);
        if (!k)
          throw new SyntaxError("An invalid or illegal string was specified.");
        D = k, this.hasBeenReset = !0;
      }
    })), h.displayState = void 0;
  }
  return n.prototype.getCueAsHTML = function() {
    return self.WebVTT.convertCueToDOMTree(self, this.text);
  }, n;
}();
class Jh {
  decode(e, t) {
    if (!e)
      return "";
    if (typeof e != "string")
      throw new Error("Error - expected string data.");
    return decodeURIComponent(encodeURIComponent(e));
  }
}
function _a(a) {
  function e(s, i, r, n) {
    return (s | 0) * 3600 + (i | 0) * 60 + (r | 0) + parseFloat(n || 0);
  }
  const t = a.match(/^(?:(\d+):)?(\d{2}):(\d{2})(\.\d+)?/);
  return t ? parseFloat(t[2]) > 59 ? e(t[2], t[3], 0, t[4]) : e(t[1], t[2], t[3], t[4]) : null;
}
class eu {
  constructor() {
    this.values = /* @__PURE__ */ Object.create(null);
  }
  // Only accept the first assignment to any key.
  set(e, t) {
    !this.get(e) && t !== "" && (this.values[e] = t);
  }
  // Return the value for a key, or a default value.
  // If 'defaultKey' is passed then 'dflt' is assumed to be an object with
  // a number of possible default values as properties where 'defaultKey' is
  // the key of the property that will be chosen; otherwise it's assumed to be
  // a single value.
  get(e, t, s) {
    return s ? this.has(e) ? this.values[e] : t[s] : this.has(e) ? this.values[e] : t;
  }
  // Check whether we have a value for a key.
  has(e) {
    return e in this.values;
  }
  // Accept a setting if its one of the given alternatives.
  alt(e, t, s) {
    for (let i = 0; i < s.length; ++i)
      if (t === s[i]) {
        this.set(e, t);
        break;
      }
  }
  // Accept a setting if its a valid (signed) integer.
  integer(e, t) {
    /^-?\d+$/.test(t) && this.set(e, parseInt(t, 10));
  }
  // Accept a setting if its a valid percentage.
  percent(e, t) {
    if (/^([\d]{1,3})(\.[\d]*)?%$/.test(t)) {
      const s = parseFloat(t);
      if (s >= 0 && s <= 100)
        return this.set(e, s), !0;
    }
    return !1;
  }
}
function Da(a, e, t, s) {
  const i = s ? a.split(s) : [a];
  for (const r in i) {
    if (typeof i[r] != "string")
      continue;
    const n = i[r].split(t);
    if (n.length !== 2)
      continue;
    const o = n[0], c = n[1];
    e(o, c);
  }
}
const hi = new wi(0, 0, ""), jt = hi.align === "middle" ? "middle" : "center";
function tu(a, e, t) {
  const s = a;
  function i() {
    const o = _a(a);
    if (o === null)
      throw new Error("Malformed timestamp: " + s);
    return a = a.replace(/^[^\sa-zA-Z-]+/, ""), o;
  }
  function r(o, c) {
    const l = new eu();
    Da(o, function(d, f) {
      let g;
      switch (d) {
        case "region":
          for (let p = t.length - 1; p >= 0; p--)
            if (t[p].id === f) {
              l.set(d, t[p].region);
              break;
            }
          break;
        case "vertical":
          l.alt(d, f, ["rl", "lr"]);
          break;
        case "line":
          g = f.split(","), l.integer(d, g[0]), l.percent(d, g[0]) && l.set("snapToLines", !1), l.alt(d, g[0], ["auto"]), g.length === 2 && l.alt("lineAlign", g[1], ["start", jt, "end"]);
          break;
        case "position":
          g = f.split(","), l.percent(d, g[0]), g.length === 2 && l.alt("positionAlign", g[1], ["start", jt, "end", "line-left", "line-right", "auto"]);
          break;
        case "size":
          l.percent(d, f);
          break;
        case "align":
          l.alt(d, f, ["start", jt, "end", "left", "right"]);
          break;
      }
    }, /:/, /\s/), c.region = l.get("region", null), c.vertical = l.get("vertical", "");
    let h = l.get("line", "auto");
    h === "auto" && hi.line === -1 && (h = -1), c.line = h, c.lineAlign = l.get("lineAlign", "start"), c.snapToLines = l.get("snapToLines", !0), c.size = l.get("size", 100), c.align = l.get("align", jt);
    let u = l.get("position", "auto");
    u === "auto" && hi.position === 50 && (u = c.align === "start" || c.align === "left" ? 0 : c.align === "end" || c.align === "right" ? 100 : 50), c.position = u;
  }
  function n() {
    a = a.replace(/^\s+/, "");
  }
  if (n(), e.startTime = i(), n(), a.slice(0, 3) !== "-->")
    throw new Error("Malformed time stamp (time stamps must be separated by '-->'): " + s);
  a = a.slice(3), n(), e.endTime = i(), n(), r(a, e);
}
function Ca(a) {
  return a.replace(/<br(?: \/)?>/gi, `
`);
}
class su {
  constructor() {
    this.state = "INITIAL", this.buffer = "", this.decoder = new Jh(), this.regionList = [], this.cue = null, this.oncue = void 0, this.onparsingerror = void 0, this.onflush = void 0;
  }
  parse(e) {
    const t = this;
    e && (t.buffer += t.decoder.decode(e, {
      stream: !0
    }));
    function s() {
      let r = t.buffer, n = 0;
      for (r = Ca(r); n < r.length && r[n] !== "\r" && r[n] !== `
`; )
        ++n;
      const o = r.slice(0, n);
      return r[n] === "\r" && ++n, r[n] === `
` && ++n, t.buffer = r.slice(n), o;
    }
    function i(r) {
      Da(r, function(n, o) {
      }, /:/);
    }
    try {
      let r = "";
      if (t.state === "INITIAL") {
        if (!/\r\n|\n/.test(t.buffer))
          return this;
        r = s();
        const o = r.match(/^(ï»¿)?WEBVTT([ \t].*)?$/);
        if (!(o != null && o[0]))
          throw new Error("Malformed WebVTT signature.");
        t.state = "HEADER";
      }
      let n = !1;
      for (; t.buffer; ) {
        if (!/\r\n|\n/.test(t.buffer))
          return this;
        switch (n ? n = !1 : r = s(), t.state) {
          case "HEADER":
            /:/.test(r) ? i(r) : r || (t.state = "ID");
            continue;
          case "NOTE":
            r || (t.state = "ID");
            continue;
          case "ID":
            if (/^NOTE($|[ \t])/.test(r)) {
              t.state = "NOTE";
              break;
            }
            if (!r)
              continue;
            if (t.cue = new wi(0, 0, ""), t.state = "CUE", r.indexOf("-->") === -1) {
              t.cue.id = r;
              continue;
            }
          case "CUE":
            if (!t.cue) {
              t.state = "BADCUE";
              continue;
            }
            try {
              tu(r, t.cue, t.regionList);
            } catch {
              t.cue = null, t.state = "BADCUE";
              continue;
            }
            t.state = "CUETEXT";
            continue;
          case "CUETEXT":
            {
              const o = r.indexOf("-->") !== -1;
              if (!r || o && (n = !0)) {
                t.oncue && t.cue && t.oncue(t.cue), t.cue = null, t.state = "ID";
                continue;
              }
              if (t.cue === null)
                continue;
              t.cue.text && (t.cue.text += `
`), t.cue.text += r;
            }
            continue;
          case "BADCUE":
            r || (t.state = "ID");
        }
      }
    } catch {
      t.state === "CUETEXT" && t.cue && t.oncue && t.oncue(t.cue), t.cue = null, t.state = t.state === "INITIAL" ? "BADWEBVTT" : "BADCUE";
    }
    return this;
  }
  flush() {
    const e = this;
    try {
      if ((e.cue || e.state === "HEADER") && (e.buffer += `

`, e.parse()), e.state === "INITIAL" || e.state === "BADWEBVTT")
        throw new Error("Malformed WebVTT signature.");
    } catch (t) {
      e.onparsingerror && e.onparsingerror(t);
    }
    return e.onflush && e.onflush(), this;
  }
}
const iu = /\r\n|\n\r|\n|\r/g, Gs = function(e, t, s = 0) {
  return e.slice(s, s + t.length) === t;
}, ru = function(e) {
  let t = parseInt(e.slice(-3));
  const s = parseInt(e.slice(-6, -4)), i = parseInt(e.slice(-9, -7)), r = e.length > 9 ? parseInt(e.substring(0, e.indexOf(":"))) : 0;
  if (!M(t) || !M(s) || !M(i) || !M(r))
    throw Error(`Malformed X-TIMESTAMP-MAP: Local:${e}`);
  return t += 1e3 * s, t += 60 * 1e3 * i, t += 60 * 60 * 1e3 * r, t;
};
function Oi(a, e, t) {
  return It(a.toString()) + It(e.toString()) + It(t);
}
const nu = function(e, t, s) {
  let i = e[t], r = e[i.prevCC];
  if (!r || !r.new && i.new) {
    e.ccOffset = e.presentationOffset = i.start, i.new = !1;
    return;
  }
  for (; (n = r) != null && n.new; ) {
    var n;
    e.ccOffset += i.start - r.start, i.new = !1, i = r, r = e[i.prevCC];
  }
  e.presentationOffset = s;
};
function au(a, e, t, s, i, r, n) {
  const o = new su(), c = ve(new Uint8Array(a)).trim().replace(iu, `
`).split(`
`), l = [], h = e ? Lc(e.baseTime, e.timescale) : 0;
  let u = "00:00.000", d = 0, f = 0, g, p = !0;
  o.oncue = function(E) {
    const y = t[s];
    let S = t.ccOffset;
    const T = (d - h) / 9e4;
    if (y != null && y.new && (f !== void 0 ? S = t.ccOffset = y.start : nu(t, s, T)), T) {
      if (!e) {
        g = new Error("Missing initPTS for VTT MPEGTS");
        return;
      }
      S = T - t.presentationOffset;
    }
    const v = E.endTime - E.startTime, x = Le((E.startTime + S - f) * 9e4, i * 9e4) / 9e4;
    E.startTime = Math.max(x, 0), E.endTime = Math.max(x + v, 0);
    const _ = E.text.trim();
    E.text = decodeURIComponent(encodeURIComponent(_)), E.id || (E.id = Oi(E.startTime, E.endTime, _)), E.endTime > 0 && l.push(E);
  }, o.onparsingerror = function(E) {
    g = E;
  }, o.onflush = function() {
    if (g) {
      n(g);
      return;
    }
    r(l);
  }, c.forEach((E) => {
    if (p)
      if (Gs(E, "X-TIMESTAMP-MAP=")) {
        p = !1, E.slice(16).split(",").forEach((y) => {
          Gs(y, "LOCAL:") ? u = y.slice(6) : Gs(y, "MPEGTS:") && (d = parseInt(y.slice(7)));
        });
        try {
          f = ru(u) / 1e3;
        } catch (y) {
          g = y;
        }
        return;
      } else E === "" && (p = !1);
    o.parse(E + `
`);
  }), o.flush();
}
const Ks = "stpp.ttml.im1t", Pa = /^(\d{2,}):(\d{2}):(\d{2}):(\d{2})\.?(\d+)?$/, ka = /^(\d*(?:\.\d*)?)(h|m|s|ms|f|t)$/, ou = {
  left: "start",
  center: "center",
  right: "end",
  start: "start",
  end: "end"
};
function zr(a, e, t, s) {
  const i = Y(new Uint8Array(a), ["mdat"]);
  if (i.length === 0) {
    s(new Error("Could not parse IMSC1 mdat"));
    return;
  }
  const r = i.map((o) => ve(o)), n = Ac(e.baseTime, 1, e.timescale);
  try {
    r.forEach((o) => t(lu(o, n)));
  } catch (o) {
    s(o);
  }
}
function lu(a, e) {
  const i = new DOMParser().parseFromString(a, "text/xml").getElementsByTagName("tt")[0];
  if (!i)
    throw new Error("Invalid ttml");
  const r = {
    frameRate: 30,
    subFrameRate: 1,
    frameRateMultiplier: 0,
    tickRate: 0
  }, n = Object.keys(r).reduce((u, d) => (u[d] = i.getAttribute(`ttp:${d}`) || r[d], u), {}), o = i.getAttribute("xml:space") !== "preserve", c = Qr(Vs(i, "styling", "style")), l = Qr(Vs(i, "layout", "region")), h = Vs(i, "body", "[begin]");
  return [].map.call(h, (u) => {
    const d = wa(u, o);
    if (!d || !u.hasAttribute("begin"))
      return null;
    const f = Ws(u.getAttribute("begin"), n), g = Ws(u.getAttribute("dur"), n);
    let p = Ws(u.getAttribute("end"), n);
    if (f === null)
      throw Zr(u);
    if (p === null) {
      if (g === null)
        throw Zr(u);
      p = f + g;
    }
    const E = new wi(f - e, p - e, d);
    E.id = Oi(E.startTime, E.endTime, E.text);
    const y = l[u.getAttribute("region")], S = c[u.getAttribute("style")], T = cu(y, S, c), {
      textAlign: v
    } = T;
    if (v) {
      const x = ou[v];
      x && (E.lineAlign = x), E.align = v;
    }
    return re(E, T), E;
  }).filter((u) => u !== null);
}
function Vs(a, e, t) {
  const s = a.getElementsByTagName(e)[0];
  return s ? [].slice.call(s.querySelectorAll(t)) : [];
}
function Qr(a) {
  return a.reduce((e, t) => {
    const s = t.getAttribute("xml:id");
    return s && (e[s] = t), e;
  }, {});
}
function wa(a, e) {
  return [].slice.call(a.childNodes).reduce((t, s, i) => {
    var r;
    return s.nodeName === "br" && i ? t + `
` : (r = s.childNodes) != null && r.length ? wa(s, e) : e ? t + s.textContent.trim().replace(/\s+/g, " ") : t + s.textContent;
  }, "");
}
function cu(a, e, t) {
  const s = "http://www.w3.org/ns/ttml#styling";
  let i = null;
  const r = [
    "displayAlign",
    "textAlign",
    "color",
    "backgroundColor",
    "fontSize",
    "fontFamily"
    // 'fontWeight',
    // 'lineHeight',
    // 'wrapOption',
    // 'fontStyle',
    // 'direction',
    // 'writingMode'
  ], n = a != null && a.hasAttribute("style") ? a.getAttribute("style") : null;
  return n && t.hasOwnProperty(n) && (i = t[n]), r.reduce((o, c) => {
    const l = Hs(e, s, c) || Hs(a, s, c) || Hs(i, s, c);
    return l && (o[c] = l), o;
  }, {});
}
function Hs(a, e, t) {
  return a && a.hasAttributeNS(e, t) ? a.getAttributeNS(e, t) : null;
}
function Zr(a) {
  return new Error(`Could not parse ttml timestamp ${a}`);
}
function Ws(a, e) {
  if (!a)
    return null;
  let t = _a(a);
  return t === null && (Pa.test(a) ? t = hu(a, e) : ka.test(a) && (t = uu(a, e))), t;
}
function hu(a, e) {
  const t = Pa.exec(a), s = (t[4] | 0) + (t[5] | 0) / e.subFrameRate;
  return (t[1] | 0) * 3600 + (t[2] | 0) * 60 + (t[3] | 0) + s / e.frameRate;
}
function uu(a, e) {
  const t = ka.exec(a), s = Number(t[1]);
  switch (t[2]) {
    case "h":
      return s * 3600;
    case "m":
      return s * 60;
    case "ms":
      return s * 1e3;
    case "f":
      return s / e.frameRate;
    case "t":
      return s / e.tickRate;
  }
  return s;
}
class Xt {
  constructor(e, t) {
    this.timelineController = void 0, this.cueRanges = [], this.trackName = void 0, this.startTime = null, this.endTime = null, this.screen = null, this.timelineController = e, this.trackName = t;
  }
  dispatchCue() {
    this.startTime !== null && (this.timelineController.addCues(this.trackName, this.startTime, this.endTime, this.screen, this.cueRanges), this.startTime = null);
  }
  newCue(e, t, s) {
    (this.startTime === null || this.startTime > e) && (this.startTime = e), this.endTime = t, this.screen = s, this.timelineController.createCaptionsTrack(this.trackName);
  }
  reset() {
    this.cueRanges = [], this.startTime = null;
  }
}
class du {
  constructor(e) {
    this.hls = void 0, this.media = null, this.config = void 0, this.enabled = !0, this.Cues = void 0, this.textTracks = [], this.tracks = [], this.initPTS = [], this.unparsedVttFrags = [], this.captionsTracks = {}, this.nonNativeCaptionsTracks = {}, this.cea608Parser1 = void 0, this.cea608Parser2 = void 0, this.lastCc = -1, this.lastSn = -1, this.lastPartIndex = -1, this.prevCC = -1, this.vttCCs = en(), this.captionsProperties = void 0, this.hls = e, this.config = e.config, this.Cues = e.config.cueHandler, this.captionsProperties = {
      textTrack1: {
        label: this.config.captionsTextTrack1Label,
        languageCode: this.config.captionsTextTrack1LanguageCode
      },
      textTrack2: {
        label: this.config.captionsTextTrack2Label,
        languageCode: this.config.captionsTextTrack2LanguageCode
      },
      textTrack3: {
        label: this.config.captionsTextTrack3Label,
        languageCode: this.config.captionsTextTrack3LanguageCode
      },
      textTrack4: {
        label: this.config.captionsTextTrack4Label,
        languageCode: this.config.captionsTextTrack4LanguageCode
      }
    }, e.on(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.MANIFEST_LOADED, this.onManifestLoaded, this), e.on(m.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), e.on(m.FRAG_LOADING, this.onFragLoading, this), e.on(m.FRAG_LOADED, this.onFragLoaded, this), e.on(m.FRAG_PARSING_USERDATA, this.onFragParsingUserdata, this), e.on(m.FRAG_DECRYPTED, this.onFragDecrypted, this), e.on(m.INIT_PTS_FOUND, this.onInitPtsFound, this), e.on(m.SUBTITLE_TRACKS_CLEARED, this.onSubtitleTracksCleared, this), e.on(m.BUFFER_FLUSHING, this.onBufferFlushing, this);
  }
  destroy() {
    const {
      hls: e
    } = this;
    e.off(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.MANIFEST_LOADED, this.onManifestLoaded, this), e.off(m.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), e.off(m.FRAG_LOADING, this.onFragLoading, this), e.off(m.FRAG_LOADED, this.onFragLoaded, this), e.off(m.FRAG_PARSING_USERDATA, this.onFragParsingUserdata, this), e.off(m.FRAG_DECRYPTED, this.onFragDecrypted, this), e.off(m.INIT_PTS_FOUND, this.onInitPtsFound, this), e.off(m.SUBTITLE_TRACKS_CLEARED, this.onSubtitleTracksCleared, this), e.off(m.BUFFER_FLUSHING, this.onBufferFlushing, this), this.hls = this.config = this.media = null, this.cea608Parser1 = this.cea608Parser2 = void 0;
  }
  initCea608Parsers() {
    const e = new Xt(this, "textTrack1"), t = new Xt(this, "textTrack2"), s = new Xt(this, "textTrack3"), i = new Xt(this, "textTrack4");
    this.cea608Parser1 = new Xr(1, e, t), this.cea608Parser2 = new Xr(3, s, i);
  }
  addCues(e, t, s, i, r) {
    let n = !1;
    for (let o = r.length; o--; ) {
      const c = r[o], l = fu(c[0], c[1], t, s);
      if (l >= 0 && (c[0] = Math.min(c[0], t), c[1] = Math.max(c[1], s), n = !0, l / (s - t) > 0.5))
        return;
    }
    if (n || r.push([t, s]), this.config.renderTextTracksNatively) {
      const o = this.captionsTracks[e];
      this.Cues.newCue(o, t, s, i);
    } else {
      const o = this.Cues.newCue(null, t, s, i);
      this.hls.trigger(m.CUES_PARSED, {
        type: "captions",
        cues: o,
        track: e
      });
    }
  }
  // Triggered when an initial PTS is found; used for synchronisation of WebVTT.
  onInitPtsFound(e, {
    frag: t,
    id: s,
    initPTS: i,
    timescale: r
  }) {
    const {
      unparsedVttFrags: n
    } = this;
    s === G.MAIN && (this.initPTS[t.cc] = {
      baseTime: i,
      timescale: r
    }), n.length && (this.unparsedVttFrags = [], n.forEach((o) => {
      this.onFragLoaded(m.FRAG_LOADED, o);
    }));
  }
  getExistingTrack(e, t) {
    const {
      media: s
    } = this;
    if (s)
      for (let i = 0; i < s.textTracks.length; i++) {
        const r = s.textTracks[i];
        if (Jr(r, {
          name: e,
          lang: t,
          characteristics: "transcribes-spoken-dialog,describes-music-and-sound"
        }))
          return r;
      }
    return null;
  }
  createCaptionsTrack(e) {
    this.config.renderTextTracksNatively ? this.createNativeTrack(e) : this.createNonNativeTrack(e);
  }
  createNativeTrack(e) {
    if (this.captionsTracks[e])
      return;
    const {
      captionsProperties: t,
      captionsTracks: s,
      media: i
    } = this, {
      label: r,
      languageCode: n
    } = t[e], o = this.getExistingTrack(r, n);
    if (o)
      s[e] = o, ut(s[e]), Aa(s[e], i);
    else {
      const c = this.createTextTrack("captions", r, n);
      c && (c[e] = !0, s[e] = c);
    }
  }
  createNonNativeTrack(e) {
    if (this.nonNativeCaptionsTracks[e])
      return;
    const t = this.captionsProperties[e];
    if (!t)
      return;
    const s = t.label, i = {
      _id: e,
      label: s,
      kind: "captions",
      default: t.media ? !!t.media.default : !1,
      closedCaptions: t.media
    };
    this.nonNativeCaptionsTracks[e] = i, this.hls.trigger(m.NON_NATIVE_TEXT_TRACKS_FOUND, {
      tracks: [i]
    });
  }
  createTextTrack(e, t, s) {
    const i = this.media;
    if (i)
      return i.addTextTrack(e, t, s);
  }
  onMediaAttaching(e, t) {
    this.media = t.media, t.mediaSource || this._cleanTracks();
  }
  onMediaDetaching(e, t) {
    const s = !!t.transferMedia;
    if (this.media = null, s)
      return;
    const {
      captionsTracks: i
    } = this;
    Object.keys(i).forEach((r) => {
      ut(i[r]), delete i[r];
    }), this.nonNativeCaptionsTracks = {};
  }
  onManifestLoading() {
    this.lastCc = -1, this.lastSn = -1, this.lastPartIndex = -1, this.prevCC = -1, this.vttCCs = en(), this._cleanTracks(), this.tracks = [], this.captionsTracks = {}, this.nonNativeCaptionsTracks = {}, this.textTracks = [], this.unparsedVttFrags = [], this.initPTS = [], this.cea608Parser1 && this.cea608Parser2 && (this.cea608Parser1.reset(), this.cea608Parser2.reset());
  }
  _cleanTracks() {
    const {
      media: e
    } = this;
    if (!e)
      return;
    const t = e.textTracks;
    if (t)
      for (let s = 0; s < t.length; s++)
        ut(t[s]);
  }
  onSubtitleTracksUpdated(e, t) {
    const s = t.subtitleTracks || [], i = s.some((r) => r.textCodec === Ks);
    if (this.config.enableWebVTT || i && this.config.enableIMSC1) {
      if (pa(this.tracks, s)) {
        this.tracks = s;
        return;
      }
      if (this.textTracks = [], this.tracks = s, this.config.renderTextTracksNatively) {
        const n = this.media, o = n ? is(n.textTracks) : null;
        if (this.tracks.forEach((c, l) => {
          let h;
          if (o) {
            let u = null;
            for (let d = 0; d < o.length; d++)
              if (o[d] && Jr(o[d], c)) {
                u = o[d], o[d] = null;
                break;
              }
            u && (h = u);
          }
          if (h)
            ut(h);
          else {
            const u = Oa(c);
            h = this.createTextTrack(u, c.name, c.lang), h && (h.mode = "disabled");
          }
          h && this.textTracks.push(h);
        }), o != null && o.length) {
          const c = o.filter((l) => l !== null).map((l) => l.label);
          c.length && this.hls.logger.warn(`Media element contains unused subtitle tracks: ${c.join(", ")}. Replace media element for each source to clear TextTracks and captions menu.`);
        }
      } else if (this.tracks.length) {
        const n = this.tracks.map((o) => ({
          label: o.name,
          kind: o.type.toLowerCase(),
          default: o.default,
          subtitleTrack: o
        }));
        this.hls.trigger(m.NON_NATIVE_TEXT_TRACKS_FOUND, {
          tracks: n
        });
      }
    }
  }
  onManifestLoaded(e, t) {
    this.config.enableCEA708Captions && t.captions && t.captions.forEach((s) => {
      const i = /(?:CC|SERVICE)([1-4])/.exec(s.instreamId);
      if (!i)
        return;
      const r = `textTrack${i[1]}`, n = this.captionsProperties[r];
      n && (n.label = s.name, s.lang && (n.languageCode = s.lang), n.media = s);
    });
  }
  closedCaptionsForLevel(e) {
    const t = this.hls.levels[e.level];
    return t == null ? void 0 : t.attrs["CLOSED-CAPTIONS"];
  }
  onFragLoading(e, t) {
    if (this.enabled && t.frag.type === G.MAIN) {
      var s, i;
      const {
        cea608Parser1: r,
        cea608Parser2: n,
        lastSn: o
      } = this, {
        cc: c,
        sn: l
      } = t.frag, h = (s = (i = t.part) == null ? void 0 : i.index) != null ? s : -1;
      r && n && (l !== o + 1 || l === o && h !== this.lastPartIndex + 1 || c !== this.lastCc) && (r.reset(), n.reset()), this.lastCc = c, this.lastSn = l, this.lastPartIndex = h;
    }
  }
  onFragLoaded(e, t) {
    const {
      frag: s,
      payload: i
    } = t;
    if (s.type === G.SUBTITLE)
      if (i.byteLength) {
        const r = s.decryptdata, n = "stats" in t;
        if (r == null || !r.encrypted || n) {
          const o = this.tracks[s.level], c = this.vttCCs;
          c[s.cc] || (c[s.cc] = {
            start: s.start,
            prevCC: this.prevCC,
            new: !0
          }, this.prevCC = s.cc), o && o.textCodec === Ks ? this._parseIMSC1(s, i) : this._parseVTTs(t);
        }
      } else
        this.hls.trigger(m.SUBTITLE_FRAG_PROCESSED, {
          success: !1,
          frag: s,
          error: new Error("Empty subtitle payload")
        });
  }
  _parseIMSC1(e, t) {
    const s = this.hls;
    zr(t, this.initPTS[e.cc], (i) => {
      this._appendCues(i, e.level), s.trigger(m.SUBTITLE_FRAG_PROCESSED, {
        success: !0,
        frag: e
      });
    }, (i) => {
      s.logger.log(`Failed to parse IMSC1: ${i}`), s.trigger(m.SUBTITLE_FRAG_PROCESSED, {
        success: !1,
        frag: e,
        error: i
      });
    });
  }
  _parseVTTs(e) {
    var t;
    const {
      frag: s,
      payload: i
    } = e, {
      initPTS: r,
      unparsedVttFrags: n
    } = this, o = r.length - 1;
    if (!r[s.cc] && o === -1) {
      n.push(e);
      return;
    }
    const c = this.hls, l = (t = s.initSegment) != null && t.data ? Ie(s.initSegment.data, new Uint8Array(i)).buffer : i;
    au(l, this.initPTS[s.cc], this.vttCCs, s.cc, s.start, (h) => {
      this._appendCues(h, s.level), c.trigger(m.SUBTITLE_FRAG_PROCESSED, {
        success: !0,
        frag: s
      });
    }, (h) => {
      const u = h.message === "Missing initPTS for VTT MPEGTS";
      u ? n.push(e) : this._fallbackToIMSC1(s, i), c.logger.log(`Failed to parse VTT cue: ${h}`), !(u && o > s.cc) && c.trigger(m.SUBTITLE_FRAG_PROCESSED, {
        success: !1,
        frag: s,
        error: h
      });
    });
  }
  _fallbackToIMSC1(e, t) {
    const s = this.tracks[e.level];
    s.textCodec || zr(t, this.initPTS[e.cc], () => {
      s.textCodec = Ks, this._parseIMSC1(e, t);
    }, () => {
      s.textCodec = "wvtt";
    });
  }
  _appendCues(e, t) {
    const s = this.hls;
    if (this.config.renderTextTracksNatively) {
      const i = this.textTracks[t];
      if (!i || i.mode === "disabled")
        return;
      e.forEach((r) => La(i, r));
    } else {
      const i = this.tracks[t];
      if (!i)
        return;
      const r = i.default ? "default" : "subtitles" + t;
      s.trigger(m.CUES_PARSED, {
        type: "subtitles",
        cues: e,
        track: r
      });
    }
  }
  onFragDecrypted(e, t) {
    const {
      frag: s
    } = t;
    s.type === G.SUBTITLE && this.onFragLoaded(m.FRAG_LOADED, t);
  }
  onSubtitleTracksCleared() {
    this.tracks = [], this.captionsTracks = {};
  }
  onFragParsingUserdata(e, t) {
    if (!this.enabled || !this.config.enableCEA708Captions)
      return;
    const {
      frag: s,
      samples: i
    } = t;
    if (!(s.type === G.MAIN && this.closedCaptionsForLevel(s) === "NONE"))
      for (let r = 0; r < i.length; r++) {
        const n = i[r].bytes;
        if (n) {
          this.cea608Parser1 || this.initCea608Parsers();
          const o = this.extractCea608Data(n);
          this.cea608Parser1.addData(i[r].pts, o[0]), this.cea608Parser2.addData(i[r].pts, o[1]);
        }
      }
  }
  onBufferFlushing(e, {
    startOffset: t,
    endOffset: s,
    endOffsetSubtitles: i,
    type: r
  }) {
    const {
      media: n
    } = this;
    if (!(!n || n.currentTime < s)) {
      if (!r || r === "video") {
        const {
          captionsTracks: o
        } = this;
        Object.keys(o).forEach((c) => li(o[c], t, s));
      }
      if (this.config.renderTextTracksNatively && t === 0 && i !== void 0) {
        const {
          textTracks: o
        } = this;
        Object.keys(o).forEach((c) => li(o[c], t, i));
      }
    }
  }
  extractCea608Data(e) {
    const t = [[], []], s = e[0] & 31;
    let i = 2;
    for (let r = 0; r < s; r++) {
      const n = e[i++], o = 127 & e[i++], c = 127 & e[i++];
      if (o === 0 && c === 0)
        continue;
      if ((4 & n) !== 0) {
        const h = 3 & n;
        (h === 0 || h === 1) && (t[h].push(o), t[h].push(c));
      }
    }
    return t;
  }
}
function Oa(a) {
  return a.characteristics && /transcribes-spoken-dialog/gi.test(a.characteristics) && /describes-music-and-sound/gi.test(a.characteristics) ? "captions" : "subtitles";
}
function Jr(a, e) {
  return !!a && a.kind === Oa(e) && ni(e, a);
}
function fu(a, e, t, s) {
  return Math.min(e, s) - Math.max(a, t);
}
function en() {
  return {
    ccOffset: 0,
    presentationOffset: 0,
    0: {
      start: 0,
      prevCC: -1,
      new: !0
    }
  };
}
const gu = /\s/, mu = {
  newCue(a, e, t, s) {
    const i = [];
    let r, n, o, c, l;
    const h = self.VTTCue || self.TextTrackCue;
    for (let d = 0; d < s.rows.length; d++)
      if (r = s.rows[d], o = !0, c = 0, l = "", !r.isEmpty()) {
        var u;
        for (let p = 0; p < r.chars.length; p++)
          gu.test(r.chars[p].uchar) && o ? c++ : (l += r.chars[p].uchar, o = !1);
        r.cueStartTime = e, e === t && (t += 1e-4), c >= 16 ? c-- : c++;
        const f = Ca(l.trim()), g = Oi(e, t, f);
        a != null && (u = a.cues) != null && u.getCueById(g) || (n = new h(e, t, f), n.id = g, n.line = d + 1, n.align = "left", n.position = 10 + Math.min(80, Math.floor(c * 8 / 32) * 10), i.push(n));
      }
    return a && i.length && (i.sort((d, f) => d.line === "auto" || f.line === "auto" ? 0 : d.line > 8 && f.line > 8 ? f.line - d.line : d.line - f.line), i.forEach((d) => La(a, d))), i;
  }
};
function pu() {
  if (
    // @ts-ignore
    self.fetch && self.AbortController && self.ReadableStream && self.Request
  )
    try {
      return new self.ReadableStream({}), !0;
    } catch {
    }
  return !1;
}
const Eu = /(\d+)-(\d+)\/(\d+)/;
class tn {
  constructor(e) {
    this.fetchSetup = void 0, this.requestTimeout = void 0, this.request = null, this.response = null, this.controller = void 0, this.context = null, this.config = null, this.callbacks = null, this.stats = void 0, this.loader = null, this.fetchSetup = e.fetchSetup || vu, this.controller = new self.AbortController(), this.stats = new gi();
  }
  destroy() {
    this.loader = this.callbacks = this.context = this.config = this.request = null, this.abortInternal(), this.response = null, this.fetchSetup = this.controller = this.stats = null;
  }
  abortInternal() {
    this.controller && !this.stats.loading.end && (this.stats.aborted = !0, this.controller.abort());
  }
  abort() {
    var e;
    this.abortInternal(), (e = this.callbacks) != null && e.onAbort && this.callbacks.onAbort(this.stats, this.context, this.response);
  }
  load(e, t, s) {
    const i = this.stats;
    if (i.loading.start)
      throw new Error("Loader can only be used once.");
    i.loading.start = self.performance.now();
    const r = yu(e, this.controller.signal), n = e.responseType === "arraybuffer", o = n ? "byteLength" : "length", {
      maxTimeToFirstByteMs: c,
      maxLoadTimeMs: l
    } = t.loadPolicy;
    this.context = e, this.config = t, this.callbacks = s, this.request = this.fetchSetup(e, r), self.clearTimeout(this.requestTimeout), t.timeout = c && M(c) ? c : l, this.requestTimeout = self.setTimeout(() => {
      this.callbacks && (this.abortInternal(), this.callbacks.onTimeout(i, e, this.response));
    }, t.timeout), (wt(this.request) ? this.request.then(self.fetch) : self.fetch(this.request)).then((u) => {
      var d;
      this.response = this.loader = u;
      const f = Math.max(self.performance.now(), i.loading.start);
      if (self.clearTimeout(this.requestTimeout), t.timeout = l, this.requestTimeout = self.setTimeout(() => {
        this.callbacks && (this.abortInternal(), this.callbacks.onTimeout(i, e, this.response));
      }, l - (f - i.loading.start)), !u.ok) {
        const {
          status: p,
          statusText: E
        } = u;
        throw new xu(E || "fetch, bad network response", p, u);
      }
      i.loading.first = f, i.total = Su(u.headers) || i.total;
      const g = (d = this.callbacks) == null ? void 0 : d.onProgress;
      return g && M(t.highWaterMark) ? this.loadProgressively(u, i, e, t.highWaterMark, g) : n ? u.arrayBuffer() : e.responseType === "json" ? u.json() : u.text();
    }).then((u) => {
      var d, f;
      const g = this.response;
      if (!g)
        throw new Error("loader destroyed");
      self.clearTimeout(this.requestTimeout), i.loading.end = Math.max(self.performance.now(), i.loading.first);
      const p = u[o];
      p && (i.loaded = i.total = p);
      const E = {
        url: g.url,
        data: u,
        code: g.status
      }, y = (d = this.callbacks) == null ? void 0 : d.onProgress;
      y && !M(t.highWaterMark) && y(i, e, u, g), (f = this.callbacks) == null || f.onSuccess(E, i, e, g);
    }).catch((u) => {
      var d;
      if (self.clearTimeout(this.requestTimeout), i.aborted)
        return;
      const f = u && u.code || 0, g = u ? u.message : null;
      (d = this.callbacks) == null || d.onError({
        code: f,
        text: g
      }, e, u ? u.details : null, i);
    });
  }
  getCacheAge() {
    let e = null;
    if (this.response) {
      const t = this.response.headers.get("age");
      e = t ? parseFloat(t) : null;
    }
    return e;
  }
  getResponseHeader(e) {
    return this.response ? this.response.headers.get(e) : null;
  }
  loadProgressively(e, t, s, i = 0, r) {
    const n = new Xn(), o = e.body.getReader(), c = () => o.read().then((l) => {
      if (l.done)
        return n.dataLength && r(t, s, n.flush().buffer, e), Promise.resolve(new ArrayBuffer(0));
      const h = l.value, u = h.length;
      return t.loaded += u, u < i || n.dataLength ? (n.push(h), n.dataLength >= i && r(t, s, n.flush().buffer, e)) : r(t, s, h.buffer, e), c();
    }).catch(() => Promise.reject());
    return c();
  }
}
function yu(a, e) {
  const t = {
    method: "GET",
    mode: "cors",
    credentials: "same-origin",
    signal: e,
    headers: new self.Headers(re({}, a.headers))
  };
  return a.rangeEnd && t.headers.set("Range", "bytes=" + a.rangeStart + "-" + String(a.rangeEnd - 1)), t;
}
function Tu(a) {
  const e = Eu.exec(a);
  if (e)
    return parseInt(e[2]) - parseInt(e[1]) + 1;
}
function Su(a) {
  const e = a.get("Content-Range");
  if (e) {
    const s = Tu(e);
    if (M(s))
      return s;
  }
  const t = a.get("Content-Length");
  if (t)
    return parseInt(t);
}
function vu(a, e) {
  return new self.Request(a.url, e);
}
class xu extends Error {
  constructor(e, t, s) {
    super(e), this.code = void 0, this.details = void 0, this.code = t, this.details = s;
  }
}
const Au = /^age:\s*[\d.]+\s*$/im;
class Fa {
  constructor(e) {
    this.xhrSetup = void 0, this.requestTimeout = void 0, this.retryTimeout = void 0, this.retryDelay = void 0, this.config = null, this.callbacks = null, this.context = null, this.loader = null, this.stats = void 0, this.xhrSetup = e && e.xhrSetup || null, this.stats = new gi(), this.retryDelay = 0;
  }
  destroy() {
    this.callbacks = null, this.abortInternal(), this.loader = null, this.config = null, this.context = null, this.xhrSetup = null;
  }
  abortInternal() {
    const e = this.loader;
    self.clearTimeout(this.requestTimeout), self.clearTimeout(this.retryTimeout), e && (e.onreadystatechange = null, e.onprogress = null, e.readyState !== 4 && (this.stats.aborted = !0, e.abort()));
  }
  abort() {
    var e;
    this.abortInternal(), (e = this.callbacks) != null && e.onAbort && this.callbacks.onAbort(this.stats, this.context, this.loader);
  }
  load(e, t, s) {
    if (this.stats.loading.start)
      throw new Error("Loader can only be used once.");
    this.stats.loading.start = self.performance.now(), this.context = e, this.config = t, this.callbacks = s, this.loadInternal();
  }
  loadInternal() {
    const {
      config: e,
      context: t
    } = this;
    if (!e || !t)
      return;
    const s = this.loader = new self.XMLHttpRequest(), i = this.stats;
    i.loading.first = 0, i.loaded = 0, i.aborted = !1;
    const r = this.xhrSetup;
    r ? Promise.resolve().then(() => {
      if (!(this.loader !== s || this.stats.aborted))
        return r(s, t.url);
    }).catch((n) => {
      if (!(this.loader !== s || this.stats.aborted))
        return s.open("GET", t.url, !0), r(s, t.url);
    }).then(() => {
      this.loader !== s || this.stats.aborted || this.openAndSendXhr(s, t, e);
    }).catch((n) => {
      var o;
      (o = this.callbacks) == null || o.onError({
        code: s.status,
        text: n.message
      }, t, s, i);
    }) : this.openAndSendXhr(s, t, e);
  }
  openAndSendXhr(e, t, s) {
    e.readyState || e.open("GET", t.url, !0);
    const i = t.headers, {
      maxTimeToFirstByteMs: r,
      maxLoadTimeMs: n
    } = s.loadPolicy;
    if (i)
      for (const o in i)
        e.setRequestHeader(o, i[o]);
    t.rangeEnd && e.setRequestHeader("Range", "bytes=" + t.rangeStart + "-" + (t.rangeEnd - 1)), e.onreadystatechange = this.readystatechange.bind(this), e.onprogress = this.loadprogress.bind(this), e.responseType = t.responseType, self.clearTimeout(this.requestTimeout), s.timeout = r && M(r) ? r : n, this.requestTimeout = self.setTimeout(this.loadtimeout.bind(this), s.timeout), e.send();
  }
  readystatechange() {
    const {
      context: e,
      loader: t,
      stats: s
    } = this;
    if (!e || !t)
      return;
    const i = t.readyState, r = this.config;
    if (!s.aborted && i >= 2 && (s.loading.first === 0 && (s.loading.first = Math.max(self.performance.now(), s.loading.start), r.timeout !== r.loadPolicy.maxLoadTimeMs && (self.clearTimeout(this.requestTimeout), r.timeout = r.loadPolicy.maxLoadTimeMs, this.requestTimeout = self.setTimeout(this.loadtimeout.bind(this), r.loadPolicy.maxLoadTimeMs - (s.loading.first - s.loading.start)))), i === 4)) {
      self.clearTimeout(this.requestTimeout), t.onreadystatechange = null, t.onprogress = null;
      const l = t.status, h = t.responseType === "text" ? t.responseText : null;
      if (l >= 200 && l < 300) {
        const g = h ?? t.response;
        if (g != null) {
          var n, o;
          s.loading.end = Math.max(self.performance.now(), s.loading.first);
          const p = t.responseType === "arraybuffer" ? g.byteLength : g.length;
          s.loaded = s.total = p, s.bwEstimate = s.total * 8e3 / (s.loading.end - s.loading.first);
          const E = (n = this.callbacks) == null ? void 0 : n.onProgress;
          E && E(s, e, g, t);
          const y = {
            url: t.responseURL,
            data: g,
            code: l
          };
          (o = this.callbacks) == null || o.onSuccess(y, s, e, t);
          return;
        }
      }
      const u = r.loadPolicy.errorRetry, d = s.retry, f = {
        url: e.url,
        data: void 0,
        code: l
      };
      if (us(u, d, !1, f))
        this.retry(u);
      else {
        var c;
        Q.error(`${l} while loading ${e.url}`), (c = this.callbacks) == null || c.onError({
          code: l,
          text: t.statusText
        }, e, t, s);
      }
    }
  }
  loadtimeout() {
    if (!this.config) return;
    const e = this.config.loadPolicy.timeoutRetry, t = this.stats.retry;
    if (us(e, t, !0))
      this.retry(e);
    else {
      var s;
      Q.warn(`timeout while loading ${(s = this.context) == null ? void 0 : s.url}`);
      const i = this.callbacks;
      i && (this.abortInternal(), i.onTimeout(this.stats, this.context, this.loader));
    }
  }
  retry(e) {
    const {
      context: t,
      stats: s
    } = this;
    this.retryDelay = Ei(e, s.retry), s.retry++, Q.warn(`${status ? "HTTP Status " + status : "Timeout"} while loading ${t == null ? void 0 : t.url}, retrying ${s.retry}/${e.maxNumRetry} in ${this.retryDelay}ms`), this.abortInternal(), this.loader = null, self.clearTimeout(this.retryTimeout), this.retryTimeout = self.setTimeout(this.loadInternal.bind(this), this.retryDelay);
  }
  loadprogress(e) {
    const t = this.stats;
    t.loaded = e.loaded, e.lengthComputable && (t.total = e.total);
  }
  getCacheAge() {
    let e = null;
    if (this.loader && Au.test(this.loader.getAllResponseHeaders())) {
      const t = this.loader.getResponseHeader("age");
      e = t ? parseFloat(t) : null;
    }
    return e;
  }
  getResponseHeader(e) {
    return this.loader && new RegExp(`^${e}:\\s*[\\d.]+\\s*$`, "im").test(this.loader.getAllResponseHeaders()) ? this.loader.getResponseHeader(e) : null;
  }
}
const Lu = {
  maxTimeToFirstByteMs: 8e3,
  maxLoadTimeMs: 2e4,
  timeoutRetry: null,
  errorRetry: null
}, Iu = te(te({
  autoStartLoad: !0,
  // used by stream-controller
  startPosition: -1,
  // used by stream-controller
  defaultAudioCodec: void 0,
  // used by stream-controller
  debug: !1,
  // used by logger
  capLevelOnFPSDrop: !1,
  // used by fps-controller
  capLevelToPlayerSize: !1,
  // used by cap-level-controller
  ignoreDevicePixelRatio: !1,
  // used by cap-level-controller
  maxDevicePixelRatio: Number.POSITIVE_INFINITY,
  // used by cap-level-controller
  preferManagedMediaSource: !0,
  initialLiveManifestSize: 1,
  // used by stream-controller
  maxBufferLength: 30,
  // used by stream-controller
  backBufferLength: 1 / 0,
  // used by buffer-controller
  frontBufferFlushThreshold: 1 / 0,
  maxBufferSize: 60 * 1e3 * 1e3,
  // used by stream-controller
  maxFragLookUpTolerance: 0.25,
  // used by stream-controller
  maxBufferHole: 0.1,
  // used by stream-controller and gap-controller
  detectStallWithCurrentTimeMs: 1250,
  // used by gap-controller
  highBufferWatchdogPeriod: 2,
  // used by gap-controller
  nudgeOffset: 0.1,
  // used by gap-controller
  nudgeMaxRetry: 3,
  // used by gap-controller
  nudgeOnVideoHole: !0,
  // used by gap-controller
  liveSyncDurationCount: 3,
  // used by latency-controller
  liveSyncOnStallIncrease: 1,
  // used by latency-controller
  liveMaxLatencyDurationCount: 1 / 0,
  // used by latency-controller
  liveSyncDuration: void 0,
  // used by latency-controller
  liveMaxLatencyDuration: void 0,
  // used by latency-controller
  maxLiveSyncPlaybackRate: 1,
  // used by latency-controller
  liveDurationInfinity: !1,
  // used by buffer-controller
  /**
   * @deprecated use backBufferLength
   */
  liveBackBufferLength: null,
  // used by buffer-controller
  maxMaxBufferLength: 600,
  // used by stream-controller
  enableWorker: !0,
  // used by transmuxer
  workerPath: null,
  // used by transmuxer
  enableSoftwareAES: !0,
  // used by decrypter
  startLevel: void 0,
  // used by level-controller
  startFragPrefetch: !1,
  // used by stream-controller
  fpsDroppedMonitoringPeriod: 5e3,
  // used by fps-controller
  fpsDroppedMonitoringThreshold: 0.2,
  // used by fps-controller
  appendErrorMaxRetry: 3,
  // used by buffer-controller
  ignorePlaylistParsingErrors: !1,
  loader: Fa,
  // loader: FetchLoader,
  fLoader: void 0,
  // used by fragment-loader
  pLoader: void 0,
  // used by playlist-loader
  xhrSetup: void 0,
  // used by xhr-loader
  licenseXhrSetup: void 0,
  // used by eme-controller
  licenseResponseCallback: void 0,
  // used by eme-controller
  abrController: qo,
  bufferController: Uc,
  capLevelController: Pi,
  errorController: Jo,
  fpsController: Dh,
  stretchShortVideoTrack: !1,
  // used by mp4-remuxer
  maxAudioFramesDrift: 1,
  // used by mp4-remuxer
  forceKeyFrameOnDiscontinuity: !0,
  // used by ts-demuxer
  abrEwmaFastLive: 3,
  // used by abr-controller
  abrEwmaSlowLive: 9,
  // used by abr-controller
  abrEwmaFastVoD: 3,
  // used by abr-controller
  abrEwmaSlowVoD: 9,
  // used by abr-controller
  abrEwmaDefaultEstimate: 5e5,
  // 500 kbps  // used by abr-controller
  abrEwmaDefaultEstimateMax: 5e6,
  // 5 mbps
  abrBandWidthFactor: 0.95,
  // used by abr-controller
  abrBandWidthUpFactor: 0.7,
  // used by abr-controller
  abrMaxWithRealBitrate: !1,
  // used by abr-controller
  maxStarvationDelay: 4,
  // used by abr-controller
  maxLoadingDelay: 4,
  // used by abr-controller
  minAutoBitrate: 0,
  // used by hls
  emeEnabled: !1,
  // used by eme-controller
  widevineLicenseUrl: void 0,
  // used by eme-controller
  drmSystems: {},
  // used by eme-controller
  drmSystemOptions: {},
  // used by eme-controller
  requestMediaKeySystemAccessFunc: Bn,
  // used by eme-controller
  testBandwidth: !0,
  progressive: !1,
  lowLatencyMode: !0,
  cmcd: void 0,
  enableDateRangeMetadataCues: !0,
  enableEmsgMetadataCues: !0,
  enableEmsgKLVMetadata: !1,
  enableID3MetadataCues: !0,
  enableInterstitialPlayback: !0,
  interstitialAppendInPlace: !0,
  interstitialLiveLookAhead: 10,
  useMediaCapabilities: !0,
  certLoadPolicy: {
    default: Lu
  },
  keyLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 8e3,
      maxLoadTimeMs: 2e4,
      timeoutRetry: {
        maxNumRetry: 1,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 2e4,
        backoff: "linear"
      },
      errorRetry: {
        maxNumRetry: 8,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 2e4,
        backoff: "linear"
      }
    }
  },
  manifestLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1 / 0,
      maxLoadTimeMs: 2e4,
      timeoutRetry: {
        maxNumRetry: 2,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 1,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  playlistLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1e4,
      maxLoadTimeMs: 2e4,
      timeoutRetry: {
        maxNumRetry: 2,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 2,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  fragLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1e4,
      maxLoadTimeMs: 12e4,
      timeoutRetry: {
        maxNumRetry: 4,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 6,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  steeringManifestLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1e4,
      maxLoadTimeMs: 2e4,
      timeoutRetry: {
        maxNumRetry: 2,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 1,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  interstitialAssetListLoadPolicy: {
    default: {
      maxTimeToFirstByteMs: 1e4,
      maxLoadTimeMs: 3e4,
      timeoutRetry: {
        maxNumRetry: 0,
        retryDelayMs: 0,
        maxRetryDelayMs: 0
      },
      errorRetry: {
        maxNumRetry: 0,
        retryDelayMs: 1e3,
        maxRetryDelayMs: 8e3
      }
    }
  },
  // These default settings are deprecated in favor of the above policies
  // and are maintained for backwards compatibility
  manifestLoadingTimeOut: 1e4,
  manifestLoadingMaxRetry: 1,
  manifestLoadingRetryDelay: 1e3,
  manifestLoadingMaxRetryTimeout: 64e3,
  levelLoadingTimeOut: 1e4,
  levelLoadingMaxRetry: 4,
  levelLoadingRetryDelay: 1e3,
  levelLoadingMaxRetryTimeout: 64e3,
  fragLoadingTimeOut: 2e4,
  fragLoadingMaxRetry: 6,
  fragLoadingRetryDelay: 1e3,
  fragLoadingMaxRetryTimeout: 64e3
}, Ru()), {}, {
  subtitleStreamController: $h,
  subtitleTrackController: kh,
  timelineController: du,
  audioStreamController: Fc,
  audioTrackController: Mc,
  emeController: ft,
  cmcdController: Rh,
  contentSteeringController: _h,
  interstitialsController: Uh
});
function Ru() {
  return {
    cueHandler: mu,
    // used by timeline-controller
    enableWebVTT: !0,
    // used by timeline-controller
    enableIMSC1: !0,
    // used by timeline-controller
    enableCEA708Captions: !0,
    // used by timeline-controller
    captionsTextTrack1Label: "English",
    // used by timeline-controller
    captionsTextTrack1LanguageCode: "en",
    // used by timeline-controller
    captionsTextTrack2Label: "Spanish",
    // used by timeline-controller
    captionsTextTrack2LanguageCode: "es",
    // used by timeline-controller
    captionsTextTrack3Label: "Unknown CC",
    // used by timeline-controller
    captionsTextTrack3LanguageCode: "",
    // used by timeline-controller
    captionsTextTrack4Label: "Unknown CC",
    // used by timeline-controller
    captionsTextTrack4LanguageCode: "",
    // used by timeline-controller
    renderTextTracksNatively: !0
  };
}
function bu(a, e, t) {
  if ((e.liveSyncDurationCount || e.liveMaxLatencyDurationCount) && (e.liveSyncDuration || e.liveMaxLatencyDuration))
    throw new Error("Illegal hls.js config: don't mix up liveSyncDurationCount/liveMaxLatencyDurationCount and liveSyncDuration/liveMaxLatencyDuration");
  if (e.liveMaxLatencyDurationCount !== void 0 && (e.liveSyncDurationCount === void 0 || e.liveMaxLatencyDurationCount <= e.liveSyncDurationCount))
    throw new Error('Illegal hls.js config: "liveMaxLatencyDurationCount" must be greater than "liveSyncDurationCount"');
  if (e.liveMaxLatencyDuration !== void 0 && (e.liveSyncDuration === void 0 || e.liveMaxLatencyDuration <= e.liveSyncDuration))
    throw new Error('Illegal hls.js config: "liveMaxLatencyDuration" must be greater than "liveSyncDuration"');
  const s = ui(a), i = ["manifest", "level", "frag"], r = ["TimeOut", "MaxRetry", "RetryDelay", "MaxRetryTimeout"];
  return i.forEach((n) => {
    const o = `${n === "level" ? "playlist" : n}LoadPolicy`, c = e[o] === void 0, l = [];
    r.forEach((h) => {
      const u = `${n}Loading${h}`, d = e[u];
      if (d !== void 0 && c) {
        l.push(u);
        const f = s[o].default;
        switch (e[o] = {
          default: f
        }, h) {
          case "TimeOut":
            f.maxLoadTimeMs = d, f.maxTimeToFirstByteMs = d;
            break;
          case "MaxRetry":
            f.errorRetry.maxNumRetry = d, f.timeoutRetry.maxNumRetry = d;
            break;
          case "RetryDelay":
            f.errorRetry.retryDelayMs = d, f.timeoutRetry.retryDelayMs = d;
            break;
          case "MaxRetryTimeout":
            f.errorRetry.maxRetryDelayMs = d, f.timeoutRetry.maxRetryDelayMs = d;
            break;
        }
      }
    }), l.length && t.warn(`hls.js config: "${l.join('", "')}" setting(s) are deprecated, use "${o}": ${ae(e[o])}`);
  }), te(te({}, s), e);
}
function ui(a) {
  return a && typeof a == "object" ? Array.isArray(a) ? a.map(ui) : Object.keys(a).reduce((e, t) => (e[t] = ui(a[t]), e), {}) : a;
}
function _u(a, e) {
  const t = a.loader;
  t !== tn && t !== Fa ? (e.log("[config]: Custom loader detected, cannot enable progressive streaming"), a.progressive = !1) : pu() && (a.loader = tn, a.progressive = !0, a.enableSoftwareAES = !0, e.log("[config]: Progressive streaming enabled, using FetchLoader"));
}
const rs = 2, Du = 0.1, Cu = 0.05, Pu = 100;
class ku extends Fn {
  constructor(e, t) {
    super("gap-controller", e.logger), this.hls = null, this.fragmentTracker = null, this.media = null, this.mediaSource = void 0, this.nudgeRetry = 0, this.stallReported = !1, this.stalled = null, this.moved = !1, this.seeking = !1, this.buffered = {}, this.lastCurrentTime = 0, this.ended = 0, this.waiting = 0, this.onMediaPlaying = () => {
      this.ended = 0, this.waiting = 0;
    }, this.onMediaWaiting = () => {
      var s;
      (s = this.media) != null && s.seeking || (this.waiting = self.performance.now(), this.tick());
    }, this.onMediaEnded = () => {
      if (this.hls) {
        var s;
        this.ended = ((s = this.media) == null ? void 0 : s.currentTime) || 1, this.hls.trigger(m.MEDIA_ENDED, {
          stalled: !1
        });
      }
    }, this.hls = e, this.fragmentTracker = t, this.registerListeners();
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e && (e.on(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(m.BUFFER_APPENDED, this.onBufferAppended, this));
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e && (e.off(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(m.BUFFER_APPENDED, this.onBufferAppended, this));
  }
  destroy() {
    super.destroy(), this.unregisterListeners(), this.media = this.hls = this.fragmentTracker = null, this.mediaSource = void 0;
  }
  onMediaAttached(e, t) {
    this.setInterval(Pu), this.mediaSource = t.mediaSource;
    const s = this.media = t.media;
    Ke(s, "playing", this.onMediaPlaying), Ke(s, "waiting", this.onMediaWaiting), Ke(s, "ended", this.onMediaEnded);
  }
  onMediaDetaching(e, t) {
    this.clearInterval();
    const {
      media: s
    } = this;
    s && (Fe(s, "playing", this.onMediaPlaying), Fe(s, "waiting", this.onMediaWaiting), Fe(s, "ended", this.onMediaEnded), this.media = null), this.mediaSource = void 0;
  }
  onBufferAppended(e, t) {
    this.buffered = t.timeRanges;
  }
  get hasBuffered() {
    return Object.keys(this.buffered).length > 0;
  }
  tick() {
    var e;
    if (!((e = this.media) != null && e.readyState) || !this.hasBuffered)
      return;
    const t = this.media.currentTime;
    this.poll(t, this.lastCurrentTime), this.lastCurrentTime = t;
  }
  /**
   * Checks if the playhead is stuck within a gap, and if so, attempts to free it.
   * A gap is an unbuffered range between two buffered ranges (or the start and the first buffered range).
   *
   * @param lastCurrentTime - Previously read playhead position
   */
  poll(e, t) {
    var s, i;
    const r = (s = this.hls) == null ? void 0 : s.config;
    if (!r)
      return;
    const {
      media: n,
      stalled: o
    } = this;
    if (!n)
      return;
    const {
      seeking: c
    } = n, l = this.seeking && !c, h = !this.seeking && c, u = n.paused && !c || n.ended || n.playbackRate === 0;
    if (this.seeking = c, e !== t) {
      t && (this.ended = 0), this.moved = !0, c || (this.nudgeRetry = 0, r.nudgeOnVideoHole && !u && e > t && this.nudgeOnVideoHole(e, t)), this.waiting === 0 && this.stallResolved(e);
      return;
    }
    if (h || l) {
      l && this.stallResolved(e);
      return;
    }
    if (u) {
      this.nudgeRetry = 0, this.stallResolved(e), !this.ended && n.ended && this.hls && (this.ended = e || 1, this.hls.trigger(m.MEDIA_ENDED, {
        stalled: !1
      }));
      return;
    }
    if (!q.getBuffered(n).length) {
      this.nudgeRetry = 0;
      return;
    }
    const d = q.bufferInfo(n, e, 0), f = d.nextStart || 0, g = this.fragmentTracker;
    if (c && g && this.hls) {
      const _ = sn(this.hls.inFlightFragments, e), A = d.len > rs, b = !f || _ || f - e > rs && !g.getPartialFragment(e);
      if (A || b)
        return;
      this.moved = !1;
    }
    const p = (i = this.hls) == null ? void 0 : i.latestLevelDetails;
    if (!this.moved && this.stalled !== null && g) {
      if (!(d.len > 0) && !f)
        return;
      const A = Math.max(f, d.start || 0) - e, D = !!(p != null && p.live) ? p.targetduration * 2 : rs, L = g.getPartialFragment(e);
      if (A > 0 && (A <= D || L)) {
        n.paused || this._trySkipBufferHole(L);
        return;
      }
    }
    const E = r.detectStallWithCurrentTimeMs, y = self.performance.now(), S = this.waiting;
    if (o === null) {
      S > 0 && y - S < E ? this.stalled = S : this.stalled = y;
      return;
    }
    const T = y - o;
    if (!c && (T >= E || S) && this.hls) {
      var v;
      if (((v = this.mediaSource) == null ? void 0 : v.readyState) === "ended" && !(p != null && p.live) && Math.abs(e - ((p == null ? void 0 : p.edge) || 0)) < 1) {
        if (this.ended)
          return;
        this.ended = e || 1, this.hls.trigger(m.MEDIA_ENDED, {
          stalled: !0
        });
        return;
      }
      if (this._reportStall(d), !this.media || !this.hls)
        return;
    }
    const x = q.bufferInfo(n, e, r.maxBufferHole);
    this._tryFixBufferStall(x, T);
  }
  stallResolved(e) {
    const t = this.stalled;
    if (t && this.hls && (this.stalled = null, this.stallReported)) {
      const s = self.performance.now() - t;
      this.log(`playback not stuck anymore @${e}, after ${Math.round(s)}ms`), this.stallReported = !1, this.waiting = 0, this.hls.trigger(m.STALL_RESOLVED, {});
    }
  }
  nudgeOnVideoHole(e, t) {
    var s;
    const i = this.buffered.video;
    if (this.hls && this.media && this.fragmentTracker && (s = this.buffered.audio) != null && s.length && i && i.length > 1 && e > i.end(0)) {
      const r = q.bufferedInfo(q.timeRangesToArray(this.buffered.audio), e, 0);
      if (r.len > 1 && t >= r.start) {
        const n = q.timeRangesToArray(i), o = q.bufferedInfo(n, t, 0).bufferedIndex;
        if (o > -1 && o < n.length - 1) {
          const c = q.bufferedInfo(n, e, 0).bufferedIndex, l = n[o].end, h = n[o + 1].start;
          if ((c === -1 || c > o) && h - l < 1 && // `maxBufferHole` may be too small and setting it to 0 should not disable this feature
          e - l < 2) {
            const u = new Error(`nudging playhead to flush pipeline after video hole. currentTime: ${e} hole: ${l} -> ${h} buffered index: ${c}`);
            this.warn(u.message), this.media.currentTime += 1e-6;
            const d = this.fragmentTracker.getPartialFragment(e) || void 0, f = q.bufferInfo(this.media, e, 0);
            this.hls.trigger(m.ERROR, {
              type: K.MEDIA_ERROR,
              details: R.BUFFER_SEEK_OVER_HOLE,
              fatal: !1,
              error: u,
              reason: u.message,
              frag: d,
              buffer: f.len,
              bufferInfo: f
            });
          }
        }
      }
    }
  }
  /**
   * Detects and attempts to fix known buffer stalling issues.
   * @param bufferInfo - The properties of the current buffer.
   * @param stalledDurationMs - The amount of time Hls.js has been stalling for.
   * @private
   */
  _tryFixBufferStall(e, t) {
    var s, i;
    const {
      fragmentTracker: r,
      media: n
    } = this, o = (s = this.hls) == null ? void 0 : s.config;
    if (!n || !r || !o)
      return;
    const c = n.currentTime, l = (i = this.hls) == null ? void 0 : i.latestLevelDetails, h = r.getPartialFragment(c);
    if ((h || l != null && l.live && c < l.fragmentStart) && (this._trySkipBufferHole(h) || !this.media))
      return;
    const u = e.buffered;
    (u && u.length > 1 && e.len > o.maxBufferHole || e.nextStart && e.nextStart - c < o.maxBufferHole) && (t > o.highBufferWatchdogPeriod * 1e3 || this.waiting) && (this.warn("Trying to nudge playhead over buffer-hole"), this._tryNudgeBuffer(e));
  }
  /**
   * Triggers a BUFFER_STALLED_ERROR event, but only once per stall period.
   * @param bufferLen - The playhead distance from the end of the current buffer segment.
   * @private
   */
  _reportStall(e) {
    const {
      hls: t,
      media: s,
      stallReported: i,
      stalled: r
    } = this;
    if (!i && r !== null && s && t) {
      this.stallReported = !0;
      const n = new Error(`Playback stalling at @${s.currentTime} due to low buffer (${ae(e)})`);
      this.warn(n.message), t.trigger(m.ERROR, {
        type: K.MEDIA_ERROR,
        details: R.BUFFER_STALLED_ERROR,
        fatal: !1,
        error: n,
        buffer: e.len,
        bufferInfo: e,
        stalled: {
          start: r
        }
      });
    }
  }
  /**
   * Attempts to fix buffer stalls by jumping over known gaps caused by partial fragments
   * @param partial - The partial fragment found at the current time (where playback is stalling).
   * @private
   */
  _trySkipBufferHole(e) {
    var t;
    const {
      fragmentTracker: s,
      media: i
    } = this, r = (t = this.hls) == null ? void 0 : t.config;
    if (!i || !s || !r)
      return 0;
    const n = i.currentTime, o = q.bufferInfo(i, n, 0), c = n < o.start ? o.start : o.nextStart;
    if (c && this.hls) {
      const h = o.len <= r.maxBufferHole, u = o.len > 0 && o.len < 1 && i.readyState < 3, d = c - n;
      if (d > 0 && (h || u)) {
        if (d > r.maxBufferHole) {
          let g = !1;
          if (n === 0) {
            const p = s.getAppendedFrag(0, G.MAIN);
            p && c < p.end && (g = !0);
          }
          if (!g) {
            const p = e || s.getAppendedFrag(n, G.MAIN);
            if (p) {
              var l;
              if (!((l = this.hls.loadLevelObj) != null && l.details) || sn(this.hls.inFlightFragments, c))
                return 0;
              let y = !1, S = p.end;
              for (; S < c; ) {
                const T = s.getPartialFragment(S);
                if (T)
                  S += T.duration;
                else {
                  y = !0;
                  break;
                }
              }
              if (y)
                return 0;
            }
          }
        }
        const f = Math.max(c + Cu, n + Du);
        if (this.warn(`skipping hole, adjusting currentTime from ${n} to ${f}`), this.moved = !0, i.currentTime = f, !(e != null && e.gap)) {
          const g = new Error(`fragment loaded with buffer holes, seeking from ${n} to ${f}`);
          this.hls.trigger(m.ERROR, {
            type: K.MEDIA_ERROR,
            details: R.BUFFER_SEEK_OVER_HOLE,
            fatal: !1,
            error: g,
            reason: g.message,
            frag: e || void 0,
            buffer: o.len,
            bufferInfo: o
          });
        }
        return f;
      }
    }
    return 0;
  }
  /**
   * Attempts to fix buffer stalls by advancing the mediaElement's current time by a small amount.
   * @private
   */
  _tryNudgeBuffer(e) {
    const {
      hls: t,
      media: s,
      nudgeRetry: i
    } = this, r = t == null ? void 0 : t.config;
    if (!s || !r)
      return 0;
    const n = s.currentTime;
    if (this.nudgeRetry++, i < r.nudgeMaxRetry) {
      const o = n + (i + 1) * r.nudgeOffset, c = new Error(`Nudging 'currentTime' from ${n} to ${o}`);
      this.warn(c.message), s.currentTime = o, t.trigger(m.ERROR, {
        type: K.MEDIA_ERROR,
        details: R.BUFFER_NUDGE_ON_STALL,
        error: c,
        fatal: !1,
        buffer: e.len,
        bufferInfo: e
      });
    } else {
      const o = new Error(`Playhead still not moving while enough data buffered @${n} after ${r.nudgeMaxRetry} nudges`);
      this.error(o.message), t.trigger(m.ERROR, {
        type: K.MEDIA_ERROR,
        details: R.BUFFER_STALLED_ERROR,
        error: o,
        fatal: !0,
        buffer: e.len,
        bufferInfo: e
      });
    }
  }
}
function sn(a, e) {
  const t = rn(a.main);
  if (t && t.start <= e)
    return t;
  const s = rn(a.audio);
  return s && s.start <= e ? s : null;
}
function rn(a) {
  if (!a)
    return null;
  switch (a.state) {
    case C.IDLE:
    case C.STOPPED:
    case C.ENDED:
    case C.ERROR:
      return null;
  }
  return a.frag;
}
const wu = 0.25;
function di() {
  if (!(typeof self > "u"))
    return self.VTTCue || self.TextTrackCue;
}
function nn(a, e, t, s, i) {
  let r = new a(e, t, "");
  try {
    r.value = s, i && (r.type = i);
  } catch {
    r = new a(e, t, ae(i ? te({
      type: i
    }, s) : s));
  }
  return r;
}
const zt = (() => {
  const a = di();
  try {
    a && new a(0, Number.POSITIVE_INFINITY, "");
  } catch {
    return Number.MAX_VALUE;
  }
  return Number.POSITIVE_INFINITY;
})();
function Ou(a) {
  return Uint8Array.from(a.replace(/^0x/, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")).buffer;
}
class Fu {
  constructor(e) {
    this.hls = void 0, this.id3Track = null, this.media = null, this.dateRangeCuesAppended = {}, this.removeCues = !0, this.onEventCueEnter = () => {
      this.hls && this.hls.trigger(m.EVENT_CUE_ENTER, {});
    }, this.hls = e, this._registerListeners();
  }
  destroy() {
    this._unregisterListeners(), this.id3Track = null, this.media = null, this.dateRangeCuesAppended = {}, this.hls = this.onEventCueEnter = null;
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.on(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.FRAG_PARSING_METADATA, this.onFragParsingMetadata, this), e.on(m.BUFFER_FLUSHING, this.onBufferFlushing, this), e.on(m.LEVEL_UPDATED, this.onLevelUpdated, this), e.on(m.LEVEL_PTS_UPDATED, this.onLevelPtsUpdated, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(m.MEDIA_ATTACHING, this.onMediaAttaching, this), e.off(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.FRAG_PARSING_METADATA, this.onFragParsingMetadata, this), e.off(m.BUFFER_FLUSHING, this.onBufferFlushing, this), e.off(m.LEVEL_UPDATED, this.onLevelUpdated, this), e.off(m.LEVEL_PTS_UPDATED, this.onLevelPtsUpdated, this);
  }
  // Add ID3 metatadata text track.
  onMediaAttaching(e, t) {
    var s;
    this.media = t.media, ((s = t.overrides) == null ? void 0 : s.cueRemoval) === !1 && (this.removeCues = !1);
  }
  onMediaAttached() {
    const e = this.hls.latestLevelDetails;
    e && this.updateDateRangeCues(e);
  }
  onMediaDetaching(e, t) {
    this.media = null, !t.transferMedia && (this.id3Track && (this.removeCues && ut(this.id3Track, this.onEventCueEnter), this.id3Track = null), this.dateRangeCuesAppended = {});
  }
  onManifestLoading() {
    this.dateRangeCuesAppended = {};
  }
  createTrack(e) {
    const t = this.getID3Track(e.textTracks);
    return t.mode = "hidden", t;
  }
  getID3Track(e) {
    if (this.media) {
      for (let t = 0; t < e.length; t++) {
        const s = e[t];
        if (s.kind === "metadata" && s.label === "id3")
          return Aa(s, this.media), s;
      }
      return this.media.addTextTrack("metadata", "id3");
    }
  }
  onFragParsingMetadata(e, t) {
    if (!this.media)
      return;
    const {
      hls: {
        config: {
          enableEmsgMetadataCues: s,
          enableID3MetadataCues: i
        }
      }
    } = this;
    if (!s && !i)
      return;
    const {
      samples: r
    } = t;
    this.id3Track || (this.id3Track = this.createTrack(this.media));
    const n = di();
    if (n)
      for (let o = 0; o < r.length; o++) {
        const c = r[o].type;
        if (c === Te.emsg && !s || !i)
          continue;
        const l = ia(r[o].data);
        if (l) {
          const h = r[o].pts;
          let u = h + r[o].duration;
          u > zt && (u = zt), u - h <= 0 && (u = h + wu);
          for (let f = 0; f < l.length; f++) {
            const g = l[f];
            if (!ra(g)) {
              this.updateId3CueEnds(h, c);
              const p = nn(n, h, u, g, c);
              p && this.id3Track.addCue(p);
            }
          }
        }
      }
  }
  updateId3CueEnds(e, t) {
    var s;
    const i = (s = this.id3Track) == null ? void 0 : s.cues;
    if (i)
      for (let r = i.length; r--; ) {
        const n = i[r];
        n.type === t && n.startTime < e && n.endTime === zt && (n.endTime = e);
      }
  }
  onBufferFlushing(e, {
    startOffset: t,
    endOffset: s,
    type: i
  }) {
    const {
      id3Track: r,
      hls: n
    } = this;
    if (!n)
      return;
    const {
      config: {
        enableEmsgMetadataCues: o,
        enableID3MetadataCues: c
      }
    } = n;
    if (r && (o || c)) {
      let l;
      i === "audio" ? l = (h) => h.type === Te.audioId3 && c : i === "video" ? l = (h) => h.type === Te.emsg && o : l = (h) => h.type === Te.audioId3 && c || h.type === Te.emsg && o, li(r, t, s, l);
    }
  }
  onLevelUpdated(e, {
    details: t
  }) {
    this.updateDateRangeCues(t, !0);
  }
  onLevelPtsUpdated(e, t) {
    Math.abs(t.drift) > 0.01 && this.updateDateRangeCues(t.details);
  }
  updateDateRangeCues(e, t) {
    if (!this.media || !e.hasProgramDateTime || !this.hls.config.enableDateRangeMetadataCues)
      return;
    const {
      id3Track: s
    } = this, {
      dateRanges: i
    } = e, r = Object.keys(i);
    let n = this.dateRangeCuesAppended;
    if (s && t) {
      var o;
      if ((o = s.cues) != null && o.length) {
        const h = Object.keys(n).filter((u) => !r.includes(u));
        for (let u = h.length; u--; ) {
          const d = h[u], f = n[d].cues;
          delete n[d], Object.keys(f).forEach((g) => {
            try {
              const p = f[g];
              p.removeEventListener("enter", this.onEventCueEnter), s.removeCue(p);
            } catch {
            }
          });
        }
      } else
        n = this.dateRangeCuesAppended = {};
    }
    const c = e.fragments[e.fragments.length - 1];
    if (r.length === 0 || !M(c == null ? void 0 : c.programDateTime))
      return;
    this.id3Track || (this.id3Track = this.createTrack(this.media));
    const l = di();
    for (let h = 0; h < r.length; h++) {
      const u = r[h], d = i[u], f = d.startTime, g = n[u], p = (g == null ? void 0 : g.cues) || {};
      let E = (g == null ? void 0 : g.durationKnown) || !1, y = zt;
      const {
        duration: S,
        endDate: T
      } = d;
      if (T && S !== null)
        y = f + S, E = !0;
      else if (d.endOnNext && !E) {
        const x = r.reduce((_, A) => {
          if (A !== d.id) {
            const b = i[A];
            if (b.class === d.class && b.startDate > d.startDate && (!_ || d.startDate < _.startDate))
              return b;
          }
          return _;
        }, null);
        x && (y = x.startTime, E = !0);
      }
      const v = Object.keys(d.attr);
      for (let x = 0; x < v.length; x++) {
        const _ = v[x];
        if (!dl(_))
          continue;
        const A = p[_];
        if (A)
          E && !g.durationKnown ? A.endTime = y : Math.abs(A.startTime - f) > 0.01 && (A.startTime = f, A.endTime = y);
        else if (l) {
          let b = d.attr[_];
          fl(_) && (b = Ou(b));
          const L = nn(l, f, y, {
            key: _,
            data: b
          }, Te.dateRange);
          L && (L.id = u, this.id3Track.addCue(L), p[_] = L, this.hls.config.interstitialsController && (_ === "X-ASSET-LIST" || _ === "X-ASSET-URL") && L.addEventListener("enter", this.onEventCueEnter));
        }
      }
      n[u] = {
        cues: p,
        dateRange: d,
        durationKnown: E
      };
    }
  }
}
class Mu {
  constructor(e) {
    this.hls = void 0, this.config = void 0, this.media = null, this.currentTime = 0, this.stallCount = 0, this._latency = null, this._targetLatencyUpdated = !1, this.onTimeupdate = () => {
      const {
        media: t
      } = this, s = this.levelDetails;
      if (!t || !s)
        return;
      this.currentTime = t.currentTime;
      const i = this.computeLatency();
      if (i === null)
        return;
      this._latency = i;
      const {
        lowLatencyMode: r,
        maxLiveSyncPlaybackRate: n
      } = this.config;
      if (!r || n === 1 || !s.live)
        return;
      const o = this.targetLatency;
      if (o === null)
        return;
      const c = i - o, l = Math.min(this.maxLatency, o + s.targetduration);
      if (c < l && c > 0.05 && this.forwardBufferLength > 1) {
        const u = Math.min(2, Math.max(1, n)), d = Math.round(2 / (1 + Math.exp(-0.75 * c - this.edgeStalled)) * 20) / 20, f = Math.min(u, Math.max(1, d));
        this.changeMediaPlaybackRate(t, f);
      } else t.playbackRate !== 1 && t.playbackRate !== 0 && this.changeMediaPlaybackRate(t, 1);
    }, this.hls = e, this.config = e.config, this.registerListeners();
  }
  get levelDetails() {
    var e;
    return ((e = this.hls) == null ? void 0 : e.latestLevelDetails) || null;
  }
  get latency() {
    return this._latency || 0;
  }
  get maxLatency() {
    const {
      config: e
    } = this;
    if (e.liveMaxLatencyDuration !== void 0)
      return e.liveMaxLatencyDuration;
    const t = this.levelDetails;
    return t ? e.liveMaxLatencyDurationCount * t.targetduration : 0;
  }
  get targetLatency() {
    const e = this.levelDetails;
    if (e === null || this.hls === null)
      return null;
    const {
      holdBack: t,
      partHoldBack: s,
      targetduration: i
    } = e, {
      liveSyncDuration: r,
      liveSyncDurationCount: n,
      lowLatencyMode: o
    } = this.config, c = this.hls.userConfig;
    let l = o && s || t;
    (this._targetLatencyUpdated || c.liveSyncDuration || c.liveSyncDurationCount || l === 0) && (l = r !== void 0 ? r : n * i);
    const h = i;
    return l + Math.min(this.stallCount * this.config.liveSyncOnStallIncrease, h);
  }
  set targetLatency(e) {
    this.stallCount = 0, this.config.liveSyncDuration = e, this._targetLatencyUpdated = !0;
  }
  get liveSyncPosition() {
    const e = this.estimateLiveEdge(), t = this.targetLatency;
    if (e === null || t === null)
      return null;
    const s = this.levelDetails;
    if (s === null)
      return null;
    const i = s.edge, r = e - t - this.edgeStalled, n = i - s.totalduration, o = i - (this.config.lowLatencyMode && s.partTarget || s.targetduration);
    return Math.min(Math.max(n, r), o);
  }
  get drift() {
    const e = this.levelDetails;
    return e === null ? 1 : e.drift;
  }
  get edgeStalled() {
    const e = this.levelDetails;
    if (e === null)
      return 0;
    const t = (this.config.lowLatencyMode && e.partTarget || e.targetduration) * 3;
    return Math.max(e.age - t, 0);
  }
  get forwardBufferLength() {
    const {
      media: e
    } = this, t = this.levelDetails;
    if (!e || !t)
      return 0;
    const s = e.buffered.length;
    return (s ? e.buffered.end(s - 1) : t.edge) - this.currentTime;
  }
  destroy() {
    this.unregisterListeners(), this.onMediaDetaching(), this.hls = null;
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e && (e.on(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.on(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.LEVEL_UPDATED, this.onLevelUpdated, this), e.on(m.ERROR, this.onError, this));
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e && (e.off(m.MEDIA_ATTACHED, this.onMediaAttached, this), e.off(m.MEDIA_DETACHING, this.onMediaDetaching, this), e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.LEVEL_UPDATED, this.onLevelUpdated, this), e.off(m.ERROR, this.onError, this));
  }
  onMediaAttached(e, t) {
    this.media = t.media, this.media.addEventListener("timeupdate", this.onTimeupdate);
  }
  onMediaDetaching() {
    this.media && (this.media.removeEventListener("timeupdate", this.onTimeupdate), this.media = null);
  }
  onManifestLoading() {
    this._latency = null, this.stallCount = 0;
  }
  onLevelUpdated(e, {
    details: t
  }) {
    t.advanced && this.onTimeupdate(), !t.live && this.media && this.media.removeEventListener("timeupdate", this.onTimeupdate);
  }
  onError(e, t) {
    var s;
    t.details === R.BUFFER_STALLED_ERROR && (this.stallCount++, this.hls && (s = this.levelDetails) != null && s.live && this.hls.logger.warn("[latency-controller]: Stall detected, adjusting target latency"));
  }
  changeMediaPlaybackRate(e, t) {
    var s, i;
    e.playbackRate !== t && ((s = this.hls) == null || s.logger.debug(`[latency-controller]: latency=${this.latency.toFixed(3)}, targetLatency=${(i = this.targetLatency) == null ? void 0 : i.toFixed(3)}, forwardBufferLength=${this.forwardBufferLength.toFixed(3)}: adjusting playback rate from ${e.playbackRate} to ${t}`), e.playbackRate = t);
  }
  estimateLiveEdge() {
    const e = this.levelDetails;
    return e === null ? null : e.edge + e.age;
  }
  computeLatency() {
    const e = this.estimateLiveEdge();
    return e === null ? null : e - this.currentTime;
  }
}
class Nu extends Ci {
  constructor(e, t) {
    super(e, "level-controller"), this._levels = [], this._firstLevel = -1, this._maxAutoLevel = -1, this._startLevel = void 0, this.currentLevel = null, this.currentLevelIndex = -1, this.manualLevelIndex = -1, this.steering = void 0, this.onParsedComplete = void 0, this.steering = t, this._registerListeners();
  }
  _registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.MANIFEST_LOADED, this.onManifestLoaded, this), e.on(m.LEVEL_LOADED, this.onLevelLoaded, this), e.on(m.LEVELS_UPDATED, this.onLevelsUpdated, this), e.on(m.FRAG_BUFFERED, this.onFragBuffered, this), e.on(m.ERROR, this.onError, this);
  }
  _unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.MANIFEST_LOADED, this.onManifestLoaded, this), e.off(m.LEVEL_LOADED, this.onLevelLoaded, this), e.off(m.LEVELS_UPDATED, this.onLevelsUpdated, this), e.off(m.FRAG_BUFFERED, this.onFragBuffered, this), e.off(m.ERROR, this.onError, this);
  }
  destroy() {
    this._unregisterListeners(), this.steering = null, this.resetLevels(), super.destroy();
  }
  stopLoad() {
    this._levels.forEach((t) => {
      t.loadError = 0, t.fragmentError = 0;
    }), super.stopLoad();
  }
  resetLevels() {
    this._startLevel = void 0, this.manualLevelIndex = -1, this.currentLevelIndex = -1, this.currentLevel = null, this._levels = [], this._maxAutoLevel = -1;
  }
  onManifestLoading(e, t) {
    this.resetLevels();
  }
  onManifestLoaded(e, t) {
    const s = this.hls.config.preferManagedMediaSource, i = [], r = {}, n = {};
    let o = !1, c = !1, l = !1;
    t.levels.forEach((h) => {
      var u;
      const d = h.attrs;
      let {
        audioCodec: f,
        videoCodec: g
      } = h;
      f && (h.audioCodec = f = os(f, s) || void 0), ((u = g) == null ? void 0 : u.indexOf("avc1")) === 0 && (g = h.videoCodec = wo(g));
      const {
        width: p,
        height: E,
        unknownCodecs: y
      } = h;
      let S = y ? y.length : 0;
      if (y)
        for (let k = S; k--; ) {
          const F = y[k];
          this.isAudioSupported(F) ? (h.audioCodec = f = f ? `${f},${F}` : F, S--, mt.audio[f.substring(0, 4)] = 2) : this.isVideoSupported(F) && (h.videoCodec = g = g ? `${g},${F}` : F, S--, mt.video[g.substring(0, 4)] = 2);
        }
      if (o || (o = !!(p && E)), c || (c = !!g), l || (l = !!f), S || f && !this.isAudioSupported(f) || g && !this.isVideoSupported(g)) {
        this.log(`Some or all CODECS not supported "${d.CODECS}"`);
        return;
      }
      const {
        CODECS: T,
        "FRAME-RATE": v,
        "HDCP-LEVEL": x,
        "PATHWAY-ID": _,
        RESOLUTION: A,
        "VIDEO-RANGE": b
      } = d, L = `${`${_ || "."}-`}${h.bitrate}-${A}-${v}-${T}-${b}-${x}`;
      if (r[L])
        if (r[L].uri !== h.url && !h.attrs["PATHWAY-ID"]) {
          const k = n[L] += 1;
          h.attrs["PATHWAY-ID"] = new Array(k + 1).join(".");
          const F = this.createLevel(h);
          r[L] = F, i.push(F);
        } else
          r[L].addGroupId("audio", d.AUDIO), r[L].addGroupId("text", d.SUBTITLES);
      else {
        const k = this.createLevel(h);
        r[L] = k, n[L] = 1, i.push(k);
      }
    }), this.filterAndSortMediaOptions(i, t, o, c, l);
  }
  createLevel(e) {
    const t = new _t(e), s = e.supplemental;
    if (s != null && s.videoCodec && !this.isVideoSupported(s.videoCodec)) {
      const i = new Error(`SUPPLEMENTAL-CODECS not supported "${s.videoCodec}"`);
      this.log(i.message), t.supportedResult = Pn(i, []);
    }
    return t;
  }
  isAudioSupported(e) {
    return Qs(e, "audio", this.hls.config.preferManagedMediaSource);
  }
  isVideoSupported(e) {
    return Qs(e, "video", this.hls.config.preferManagedMediaSource);
  }
  filterAndSortMediaOptions(e, t, s, i, r) {
    let n = [], o = [], c = e;
    if ((s || i) && r && (c = c.filter(({
      videoCodec: E,
      videoRange: y,
      width: S,
      height: T
    }) => (!!E || !!(S && T)) && Bo(y))), c.length === 0) {
      Promise.resolve().then(() => {
        if (this.hls) {
          let E = "no level with compatible codecs found in manifest", y = E;
          t.levels.length && (y = `one or more CODECS in variant not supported: ${ae(t.levels.map((T) => T.attrs.CODECS).filter((T, v, x) => x.indexOf(T) === v))}`, this.warn(y), E += ` (${y})`);
          const S = new Error(E);
          this.hls.trigger(m.ERROR, {
            type: K.MEDIA_ERROR,
            details: R.MANIFEST_INCOMPATIBLE_CODECS_ERROR,
            fatal: !0,
            url: t.url,
            error: S,
            reason: y
          });
        }
      });
      return;
    }
    t.audioTracks && (n = t.audioTracks.filter((E) => !E.audioCodec || this.isAudioSupported(E.audioCodec)), an(n)), t.subtitles && (o = t.subtitles, an(o));
    const l = c.slice(0);
    c.sort((E, y) => {
      if (E.attrs["HDCP-LEVEL"] !== y.attrs["HDCP-LEVEL"])
        return (E.attrs["HDCP-LEVEL"] || "") > (y.attrs["HDCP-LEVEL"] || "") ? 1 : -1;
      if (s && E.height !== y.height)
        return E.height - y.height;
      if (E.frameRate !== y.frameRate)
        return E.frameRate - y.frameRate;
      if (E.videoRange !== y.videoRange)
        return ls.indexOf(E.videoRange) - ls.indexOf(y.videoRange);
      if (E.videoCodec !== y.videoCodec) {
        const S = Zi(E.videoCodec), T = Zi(y.videoCodec);
        if (S !== T)
          return T - S;
      }
      if (E.uri === y.uri && E.codecSet !== y.codecSet) {
        const S = as(E.codecSet), T = as(y.codecSet);
        if (S !== T)
          return T - S;
      }
      return E.averageBitrate !== y.averageBitrate ? E.averageBitrate - y.averageBitrate : 0;
    });
    let h = l[0];
    if (this.steering && (c = this.steering.filterParsedLevels(c), c.length !== l.length)) {
      for (let E = 0; E < l.length; E++)
        if (l[E].pathwayId === c[0].pathwayId) {
          h = l[E];
          break;
        }
    }
    this._levels = c;
    for (let E = 0; E < c.length; E++)
      if (c[E] === h) {
        var u;
        this._firstLevel = E;
        const y = h.bitrate, S = this.hls.bandwidthEstimate;
        if (this.log(`manifest loaded, ${c.length} level(s) found, first bitrate: ${y}`), ((u = this.hls.userConfig) == null ? void 0 : u.abrEwmaDefaultEstimate) === void 0) {
          const T = Math.min(y, this.hls.config.abrEwmaDefaultEstimateMax);
          T > S && S === this.hls.abrEwmaDefaultEstimate && (this.hls.bandwidthEstimate = T);
        }
        break;
      }
    const d = r && !i, f = this.hls.config, g = !!(f.audioStreamController && f.audioTrackController), p = {
      levels: c,
      audioTracks: n,
      subtitleTracks: o,
      sessionData: t.sessionData,
      sessionKeys: t.sessionKeys,
      firstLevel: this._firstLevel,
      stats: t.stats,
      audio: r,
      video: i,
      altAudio: g && !d && n.some((E) => !!E.url)
    };
    this.hls.trigger(m.MANIFEST_PARSED, p);
  }
  get levels() {
    return this._levels.length === 0 ? null : this._levels;
  }
  get loadLevelObj() {
    return this.currentLevel;
  }
  get level() {
    return this.currentLevelIndex;
  }
  set level(e) {
    const t = this._levels;
    if (t.length === 0)
      return;
    if (e < 0 || e >= t.length) {
      const h = new Error("invalid level idx"), u = e < 0;
      if (this.hls.trigger(m.ERROR, {
        type: K.OTHER_ERROR,
        details: R.LEVEL_SWITCH_ERROR,
        level: e,
        fatal: u,
        error: h,
        reason: h.message
      }), u)
        return;
      e = Math.min(e, t.length - 1);
    }
    const s = this.currentLevelIndex, i = this.currentLevel, r = i ? i.attrs["PATHWAY-ID"] : void 0, n = t[e], o = n.attrs["PATHWAY-ID"];
    if (this.currentLevelIndex = e, this.currentLevel = n, s === e && i && r === o)
      return;
    this.log(`Switching to level ${e} (${n.height ? n.height + "p " : ""}${n.videoRange ? n.videoRange + " " : ""}${n.codecSet ? n.codecSet + " " : ""}@${n.bitrate})${o ? " with Pathway " + o : ""} from level ${s}${r ? " with Pathway " + r : ""}`);
    const c = {
      level: e,
      attrs: n.attrs,
      details: n.details,
      bitrate: n.bitrate,
      averageBitrate: n.averageBitrate,
      maxBitrate: n.maxBitrate,
      realBitrate: n.realBitrate,
      width: n.width,
      height: n.height,
      codecSet: n.codecSet,
      audioCodec: n.audioCodec,
      videoCodec: n.videoCodec,
      audioGroups: n.audioGroups,
      subtitleGroups: n.subtitleGroups,
      loaded: n.loaded,
      loadError: n.loadError,
      fragmentError: n.fragmentError,
      name: n.name,
      id: n.id,
      uri: n.uri,
      url: n.url,
      urlId: 0,
      audioGroupIds: n.audioGroupIds,
      textGroupIds: n.textGroupIds
    };
    this.hls.trigger(m.LEVEL_SWITCHING, c);
    const l = n.details;
    if (!l || l.live) {
      const h = this.switchParams(n.uri, i == null ? void 0 : i.details, l);
      this.loadPlaylist(h);
    }
  }
  get manualLevel() {
    return this.manualLevelIndex;
  }
  set manualLevel(e) {
    this.manualLevelIndex = e, this._startLevel === void 0 && (this._startLevel = e), e !== -1 && (this.level = e);
  }
  get firstLevel() {
    return this._firstLevel;
  }
  set firstLevel(e) {
    this._firstLevel = e;
  }
  get startLevel() {
    if (this._startLevel === void 0) {
      const e = this.hls.config.startLevel;
      return e !== void 0 ? e : this.hls.firstAutoLevel;
    }
    return this._startLevel;
  }
  set startLevel(e) {
    this._startLevel = e;
  }
  get pathways() {
    return this.steering ? this.steering.pathways() : [];
  }
  get pathwayPriority() {
    return this.steering ? this.steering.pathwayPriority : null;
  }
  set pathwayPriority(e) {
    if (this.steering) {
      const t = this.steering.pathways(), s = e.filter((i) => t.indexOf(i) !== -1);
      if (e.length < 1) {
        this.warn(`pathwayPriority ${e} should contain at least one pathway from list: ${t}`);
        return;
      }
      this.steering.pathwayPriority = s;
    }
  }
  onError(e, t) {
    t.fatal || !t.context || t.context.type === z.LEVEL && t.context.level === this.level && this.checkRetry(t);
  }
  // reset errors on the successful load of a fragment
  onFragBuffered(e, {
    frag: t
  }) {
    if (t !== void 0 && t.type === G.MAIN) {
      const s = t.elementaryStreams;
      if (!Object.keys(s).some((r) => !!s[r]))
        return;
      const i = this._levels[t.level];
      i != null && i.loadError && (this.log(`Resetting level error count of ${i.loadError} on frag buffered`), i.loadError = 0);
    }
  }
  onLevelLoaded(e, t) {
    var s;
    const {
      level: i,
      details: r
    } = t, n = t.levelInfo;
    if (!n) {
      var o;
      this.warn(`Invalid level index ${i}`), (o = t.deliveryDirectives) != null && o.skip && (r.deltaUpdateFailed = !0);
      return;
    }
    if (n === this.currentLevel || t.withoutMultiVariant) {
      n.fragmentError === 0 && (n.loadError = 0);
      let c = n.details;
      c === t.details && c.advanced && (c = void 0), this.playlistLoaded(i, t, c);
    } else (s = t.deliveryDirectives) != null && s.skip && (r.deltaUpdateFailed = !0);
  }
  loadPlaylist(e) {
    super.loadPlaylist(), this.shouldLoadPlaylist(this.currentLevel) && this.scheduleLoading(this.currentLevel, e);
  }
  loadingPlaylist(e, t) {
    super.loadingPlaylist(e, t);
    const s = this.getUrlWithDirectives(e.uri, t), i = this.currentLevelIndex, r = e.attrs["PATHWAY-ID"], n = e.details, o = n == null ? void 0 : n.age;
    this.log(`Loading level index ${i}${(t == null ? void 0 : t.msn) !== void 0 ? " at sn " + t.msn + " part " + t.part : ""}${r ? " Pathway " + r : ""}${o && n.live ? " age " + o.toFixed(1) + (n.type && " " + n.type || "") : ""} ${s}`), this.hls.trigger(m.LEVEL_LOADING, {
      url: s,
      level: i,
      levelInfo: e,
      pathwayId: e.attrs["PATHWAY-ID"],
      id: 0,
      // Deprecated Level urlId
      deliveryDirectives: t || null
    });
  }
  get nextLoadLevel() {
    return this.manualLevelIndex !== -1 ? this.manualLevelIndex : this.hls.nextAutoLevel;
  }
  set nextLoadLevel(e) {
    this.level = e, this.manualLevelIndex === -1 && (this.hls.nextAutoLevel = e);
  }
  removeLevel(e) {
    var t;
    if (this._levels.length === 1)
      return;
    const s = this._levels.filter((r, n) => n !== e ? !0 : (this.steering && this.steering.removeLevel(r), r === this.currentLevel && (this.currentLevel = null, this.currentLevelIndex = -1, r.details && r.details.fragments.forEach((o) => o.level = -1)), !1));
    Yn(s), this._levels = s, this.currentLevelIndex > -1 && (t = this.currentLevel) != null && t.details && (this.currentLevelIndex = this.currentLevel.details.fragments[0].level), this.manualLevelIndex > -1 && (this.manualLevelIndex = this.currentLevelIndex);
    const i = s.length - 1;
    this._firstLevel = Math.min(this._firstLevel, i), this._startLevel && (this._startLevel = Math.min(this._startLevel, i)), this.hls.trigger(m.LEVELS_UPDATED, {
      levels: s
    });
  }
  onLevelsUpdated(e, {
    levels: t
  }) {
    this._levels = t;
  }
  checkMaxAutoUpdated() {
    const {
      autoLevelCapping: e,
      maxAutoLevel: t,
      maxHdcpLevel: s
    } = this.hls;
    this._maxAutoLevel !== t && (this._maxAutoLevel = t, this.hls.trigger(m.MAX_AUTO_LEVEL_UPDATED, {
      autoLevelCapping: e,
      levels: this.levels,
      maxAutoLevel: t,
      minAutoLevel: this.hls.minAutoLevel,
      maxHdcpLevel: s
    }));
  }
}
function an(a) {
  const e = {};
  a.forEach((t) => {
    const s = t.groupId || "";
    t.id = e[s] = e[s] || 0, e[s]++;
  });
}
function Ma() {
  return self.SourceBuffer || self.WebKitSourceBuffer;
}
function Na() {
  if (!ze())
    return !1;
  const e = Ma();
  return !e || e.prototype && typeof e.prototype.appendBuffer == "function" && typeof e.prototype.remove == "function";
}
function Bu() {
  if (!Na())
    return !1;
  const a = ze();
  return typeof (a == null ? void 0 : a.isTypeSupported) == "function" && (["avc1.42E01E,mp4a.40.2", "av01.0.01M.08", "vp09.00.50.08"].some((e) => a.isTypeSupported(bt(e, "video"))) || ["mp4a.40.2", "fLaC"].some((e) => a.isTypeSupported(bt(e, "audio"))));
}
function Uu() {
  var a;
  const e = Ma();
  return typeof (e == null || (a = e.prototype) == null ? void 0 : a.changeType) == "function";
}
const $u = 100;
class Gu extends xi {
  constructor(e, t, s) {
    super(e, t, s, "stream-controller", G.MAIN), this.audioCodecSwap = !1, this.level = -1, this._forceStartLoad = !1, this._hasEnoughToStart = !1, this.altAudio = 0, this.audioOnly = !1, this.fragPlaying = null, this.fragLastKbps = 0, this.couldBacktrack = !1, this.backtrackFragment = null, this.audioCodecSwitch = !1, this.videoBuffer = null, this.onMediaPlaying = () => {
      this.tick();
    }, this.onMediaSeeked = () => {
      const i = this.media, r = i ? i.currentTime : null;
      if (r === null || !M(r) || (this.log(`Media seeked to ${r.toFixed(3)}`), !this.getBufferedFrag(r)))
        return;
      const n = this.getFwdBufferInfoAtPos(i, r, G.MAIN, 0);
      if (n === null || n.len === 0) {
        this.warn(`Main forward buffer length at ${r} on "seeked" event ${n ? n.len : "empty"})`);
        return;
      }
      this.tick();
    }, this.registerListeners();
  }
  registerListeners() {
    super.registerListeners();
    const {
      hls: e
    } = this;
    e.on(m.MANIFEST_PARSED, this.onManifestParsed, this), e.on(m.LEVEL_LOADING, this.onLevelLoading, this), e.on(m.LEVEL_LOADED, this.onLevelLoaded, this), e.on(m.FRAG_LOAD_EMERGENCY_ABORTED, this.onFragLoadEmergencyAborted, this), e.on(m.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.on(m.AUDIO_TRACK_SWITCHED, this.onAudioTrackSwitched, this), e.on(m.BUFFER_CREATED, this.onBufferCreated, this), e.on(m.BUFFER_FLUSHED, this.onBufferFlushed, this), e.on(m.LEVELS_UPDATED, this.onLevelsUpdated, this), e.on(m.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  unregisterListeners() {
    super.unregisterListeners();
    const {
      hls: e
    } = this;
    e.off(m.MANIFEST_PARSED, this.onManifestParsed, this), e.off(m.LEVEL_LOADED, this.onLevelLoaded, this), e.off(m.FRAG_LOAD_EMERGENCY_ABORTED, this.onFragLoadEmergencyAborted, this), e.off(m.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), e.off(m.AUDIO_TRACK_SWITCHED, this.onAudioTrackSwitched, this), e.off(m.BUFFER_CREATED, this.onBufferCreated, this), e.off(m.BUFFER_FLUSHED, this.onBufferFlushed, this), e.off(m.LEVELS_UPDATED, this.onLevelsUpdated, this), e.off(m.FRAG_BUFFERED, this.onFragBuffered, this);
  }
  onHandlerDestroying() {
    this.onMediaPlaying = this.onMediaSeeked = null, this.unregisterListeners(), super.onHandlerDestroying();
  }
  startLoad(e, t) {
    if (this.levels) {
      const {
        lastCurrentTime: s,
        hls: i
      } = this;
      if (this.stopLoad(), this.setInterval($u), this.level = -1, !this.startFragRequested) {
        let r = i.startLevel;
        r === -1 && (i.config.testBandwidth && this.levels.length > 1 ? (r = 0, this.bitrateTest = !0) : r = i.firstAutoLevel), i.nextLoadLevel = r, this.level = i.loadLevel, this._hasEnoughToStart = !!t;
      }
      s > 0 && e === -1 && !t && (this.log(`Override startPosition with lastCurrentTime @${s.toFixed(3)}`), e = s), this.state = C.IDLE, this.nextLoadPosition = this.lastCurrentTime = e + this.timelineOffset, this.startPosition = t ? -1 : e, this.tick();
    } else
      this._forceStartLoad = !0, this.state = C.STOPPED;
  }
  stopLoad() {
    this._forceStartLoad = !1, super.stopLoad();
  }
  doTick() {
    switch (this.state) {
      case C.WAITING_LEVEL: {
        const {
          levels: t,
          level: s
        } = this, i = t == null ? void 0 : t[s], r = i == null ? void 0 : i.details;
        if (r && (!r.live || this.levelLastLoaded === i && !this.waitForLive(i))) {
          if (this.waitForCdnTuneIn(r))
            break;
          this.state = C.IDLE;
          break;
        } else if (this.hls.nextLoadLevel !== this.level) {
          this.state = C.IDLE;
          break;
        }
        break;
      }
      case C.FRAG_LOADING_WAITING_RETRY:
        {
          var e;
          const t = self.performance.now(), s = this.retryDate;
          if (!s || t >= s || (e = this.media) != null && e.seeking) {
            const {
              levels: i,
              level: r
            } = this, n = i == null ? void 0 : i[r];
            this.resetStartWhenNotLoaded(n || null), this.state = C.IDLE;
          }
        }
        break;
    }
    this.state === C.IDLE && this.doTickIdle(), this.onTickEnd();
  }
  onTickEnd() {
    var e;
    super.onTickEnd(), (e = this.media) != null && e.readyState && this.media.seeking === !1 && (this.lastCurrentTime = this.media.currentTime), this.checkFragmentChanged();
  }
  doTickIdle() {
    const {
      hls: e,
      levelLastLoaded: t,
      levels: s,
      media: i
    } = this;
    if (t === null || !i && !this.primaryPrefetch && (this.startFragRequested || !e.config.startFragPrefetch) || this.altAudio && this.audioOnly)
      return;
    const r = this.buffering ? e.nextLoadLevel : e.loadLevel;
    if (!(s != null && s[r]))
      return;
    const n = s[r], o = this.getMainFwdBufferInfo();
    if (o === null)
      return;
    const c = this.getLevelDetails();
    if (c && this._streamEnded(o, c)) {
      const p = {};
      this.altAudio === 2 && (p.type = "video"), this.hls.trigger(m.BUFFER_EOS, p), this.state = C.ENDED;
      return;
    }
    if (!this.buffering)
      return;
    e.loadLevel !== r && e.manualLevel === -1 && this.log(`Adapting to level ${r} from level ${this.level}`), this.level = e.nextLoadLevel = r;
    const l = n.details;
    if (!l || this.state === C.WAITING_LEVEL || this.waitForLive(n)) {
      this.level = r, this.state = C.WAITING_LEVEL, this.startFragRequested = !1;
      return;
    }
    const h = o.len, u = this.getMaxBufferLength(n.maxBitrate);
    if (h >= u)
      return;
    this.backtrackFragment && this.backtrackFragment.start > o.end && (this.backtrackFragment = null);
    const d = this.backtrackFragment ? this.backtrackFragment.start : o.end;
    let f = this.getNextFragment(d, l);
    if (this.couldBacktrack && !this.fragPrevious && f && ue(f) && this.fragmentTracker.getState(f) !== ce.OK) {
      var g;
      const E = ((g = this.backtrackFragment) != null ? g : f).sn - l.startSN, y = l.fragments[E - 1];
      y && f.cc === y.cc && (f = y, this.fragmentTracker.removeFragment(y));
    } else this.backtrackFragment && o.len && (this.backtrackFragment = null);
    if (f && this.isLoopLoading(f, d)) {
      if (!f.gap) {
        const E = this.audioOnly && !this.altAudio ? ie.AUDIO : ie.VIDEO, y = (E === ie.VIDEO ? this.videoBuffer : this.mediaBuffer) || this.media;
        y && this.afterBufferFlushed(y, E, G.MAIN);
      }
      f = this.getNextFragmentLoopLoading(f, l, o, G.MAIN, u);
    }
    f && (f.initSegment && !f.initSegment.data && !this.bitrateTest && (f = f.initSegment), this.loadFragment(f, n, d));
  }
  loadFragment(e, t, s) {
    const i = this.fragmentTracker.getState(e);
    i === ce.NOT_LOADED || i === ce.PARTIAL ? ue(e) ? this.bitrateTest ? (this.log(`Fragment ${e.sn} of level ${e.level} is being downloaded to test bitrate and will not be buffered`), this._loadBitrateTestFrag(e, t)) : super.loadFragment(e, t, s) : this._loadInitSegment(e, t) : this.clearTrackerIfNeeded(e);
  }
  getBufferedFrag(e) {
    return this.fragmentTracker.getBufferedFrag(e, G.MAIN);
  }
  followingBufferedFrag(e) {
    return e ? this.getBufferedFrag(e.end + 0.5) : null;
  }
  /*
    on immediate level switch :
     - pause playback if playing
     - cancel any pending load request
     - and trigger a buffer flush
  */
  immediateLevelSwitch() {
    this.abortCurrentFrag(), this.flushMainBuffer(0, Number.POSITIVE_INFINITY);
  }
  /**
   * try to switch ASAP without breaking video playback:
   * in order to ensure smooth but quick level switching,
   * we need to find the next flushable buffer range
   * we should take into account new segment fetch time
   */
  nextLevelSwitch() {
    const {
      levels: e,
      media: t
    } = this;
    if (t != null && t.readyState) {
      let s;
      const i = this.getAppendedFrag(t.currentTime);
      i && i.start > 1 && this.flushMainBuffer(0, i.start - 1);
      const r = this.getLevelDetails();
      if (r != null && r.live) {
        const o = this.getMainFwdBufferInfo();
        if (!o || o.len < r.targetduration * 2)
          return;
      }
      if (!t.paused && e) {
        const o = this.hls.nextLoadLevel, c = e[o], l = this.fragLastKbps;
        l && this.fragCurrent ? s = this.fragCurrent.duration * c.maxBitrate / (1e3 * l) + 1 : s = 0;
      } else
        s = 0;
      const n = this.getBufferedFrag(t.currentTime + s);
      if (n) {
        const o = this.followingBufferedFrag(n);
        if (o) {
          this.abortCurrentFrag();
          const c = o.maxStartPTS ? o.maxStartPTS : o.start, l = o.duration, h = Math.max(n.end, c + Math.min(Math.max(l - this.config.maxFragLookUpTolerance, l * (this.couldBacktrack ? 0.5 : 0.125)), l * (this.couldBacktrack ? 0.75 : 0.25)));
          this.flushMainBuffer(h, Number.POSITIVE_INFINITY);
        }
      }
    }
  }
  abortCurrentFrag() {
    const e = this.fragCurrent;
    switch (this.fragCurrent = null, this.backtrackFragment = null, e && (e.abortRequests(), this.fragmentTracker.removeFragment(e)), this.state) {
      case C.KEY_LOADING:
      case C.FRAG_LOADING:
      case C.FRAG_LOADING_WAITING_RETRY:
      case C.PARSING:
      case C.PARSED:
        this.state = C.IDLE;
        break;
    }
    this.nextLoadPosition = this.getLoadPosition();
  }
  flushMainBuffer(e, t) {
    super.flushMainBuffer(e, t, this.altAudio === 2 ? "video" : null);
  }
  onMediaAttached(e, t) {
    super.onMediaAttached(e, t);
    const s = t.media;
    Ke(s, "playing", this.onMediaPlaying), Ke(s, "seeked", this.onMediaSeeked);
  }
  onMediaDetaching(e, t) {
    const {
      media: s
    } = this;
    s && (Fe(s, "playing", this.onMediaPlaying), Fe(s, "seeked", this.onMediaSeeked)), this.videoBuffer = null, this.fragPlaying = null, super.onMediaDetaching(e, t), !t.transferMedia && (this._hasEnoughToStart = !1);
  }
  onManifestLoading() {
    super.onManifestLoading(), this.log("Trigger BUFFER_RESET"), this.hls.trigger(m.BUFFER_RESET, void 0), this.couldBacktrack = !1, this.fragLastKbps = 0, this.fragPlaying = this.backtrackFragment = null, this.altAudio = 0, this.audioOnly = !1;
  }
  onManifestParsed(e, t) {
    let s = !1, i = !1;
    t.levels.forEach((r) => {
      const n = r.audioCodec;
      n && (s = s || n.indexOf("mp4a.40.2") !== -1, i = i || n.indexOf("mp4a.40.5") !== -1);
    }), this.audioCodecSwitch = s && i && !Uu(), this.audioCodecSwitch && this.log("Both AAC/HE-AAC audio found in levels; declaring level codec as HE-AAC"), this.levels = t.levels, this.startFragRequested = !1;
  }
  onLevelLoading(e, t) {
    const {
      levels: s
    } = this;
    if (!s || this.state !== C.IDLE)
      return;
    const i = t.levelInfo;
    (!i.details || i.details.live && (this.levelLastLoaded !== i || i.details.expired) || this.waitForCdnTuneIn(i.details)) && (this.state = C.WAITING_LEVEL);
  }
  onLevelLoaded(e, t) {
    var s;
    const {
      levels: i,
      startFragRequested: r
    } = this, n = t.level, o = t.details, c = o.totalduration;
    if (!i) {
      this.warn(`Levels were reset while loading level ${n}`);
      return;
    }
    this.log(`Level ${n} loaded [${o.startSN},${o.endSN}]${o.lastPartSn ? `[part-${o.lastPartSn}-${o.lastPartIndex}]` : ""}, cc [${o.startCC}, ${o.endCC}] duration:${c}`);
    const l = t.levelInfo, h = this.fragCurrent;
    h && (this.state === C.FRAG_LOADING || this.state === C.FRAG_LOADING_WAITING_RETRY) && h.level !== t.level && h.loader && this.abortCurrentFrag();
    let u = 0;
    if (o.live || (s = l.details) != null && s.live) {
      var d;
      if (this.checkLiveUpdate(o), o.deltaUpdateFailed)
        return;
      u = this.alignPlaylists(o, l.details, (d = this.levelLastLoaded) == null ? void 0 : d.details);
    }
    if (l.details = o, this.levelLastLoaded = l, r || this.setStartPosition(o, u), this.hls.trigger(m.LEVEL_UPDATED, {
      details: o,
      level: n
    }), this.state === C.WAITING_LEVEL) {
      if (this.waitForCdnTuneIn(o))
        return;
      this.state = C.IDLE;
    }
    r && o.live && this.synchronizeToLiveEdge(o), this.tick();
  }
  synchronizeToLiveEdge(e) {
    const {
      config: t,
      media: s
    } = this;
    if (!s)
      return;
    const i = this.hls.liveSyncPosition, r = this.getLoadPosition(), n = e.fragmentStart, o = e.edge, c = r >= n - t.maxFragLookUpTolerance && r <= o;
    if (i !== null && s.duration > i && (r < i || !c)) {
      const l = t.liveMaxLatencyDuration !== void 0 ? t.liveMaxLatencyDuration : t.liveMaxLatencyDurationCount * e.targetduration;
      (!c && s.readyState < 4 || r < o - l) && (this._hasEnoughToStart || (this.nextLoadPosition = i), s.readyState && (this.warn(`Playback: ${r.toFixed(3)} is located too far from the end of live sliding playlist: ${o}, reset currentTime to : ${i.toFixed(3)}`), s.currentTime = i));
    }
  }
  _handleFragmentLoadProgress(e) {
    var t;
    const s = e.frag, {
      part: i,
      payload: r
    } = e, {
      levels: n
    } = this;
    if (!n) {
      this.warn(`Levels were reset while fragment load was in progress. Fragment ${s.sn} of level ${s.level} will not be buffered`);
      return;
    }
    const o = n[s.level];
    if (!o) {
      this.warn(`Level ${s.level} not found on progress`);
      return;
    }
    const c = o.details;
    if (!c) {
      this.warn(`Dropping fragment ${s.sn} of level ${s.level} after level details were reset`), this.fragmentTracker.removeFragment(s);
      return;
    }
    const l = o.videoCodec, h = c.PTSKnown || !c.live, u = (t = s.initSegment) == null ? void 0 : t.data, d = this._getAudioCodec(o), f = this.transmuxer = this.transmuxer || new ma(this.hls, G.MAIN, this._handleTransmuxComplete.bind(this), this._handleTransmuxerFlush.bind(this)), g = i ? i.index : -1, p = g !== -1, E = new Ti(s.level, s.sn, s.stats.chunkCount, r.byteLength, g, p), y = this.initPTS[s.cc];
    f.push(r, u, d, l, s, i, c.totalduration, h, E, y);
  }
  onAudioTrackSwitching(e, t) {
    const s = this.hls, i = this.altAudio === 2;
    if (cs(t.url, s))
      this.altAudio = 1;
    else {
      if (this.mediaBuffer !== this.media) {
        this.log("Switching on main audio, use media.buffered to schedule main fragment loading"), this.mediaBuffer = this.media;
        const n = this.fragCurrent;
        n && (this.log("Switching to main audio track, cancel main fragment load"), n.abortRequests(), this.fragmentTracker.removeFragment(n)), this.resetTransmuxer(), this.resetLoadingState();
      } else this.audioOnly && this.resetTransmuxer();
      if (i) {
        this.fragmentTracker.removeAllFragments(), s.once(m.BUFFER_FLUSHED, () => {
          var n;
          (n = this.hls) == null || n.trigger(m.AUDIO_TRACK_SWITCHED, t);
        }), s.trigger(m.BUFFER_FLUSHING, {
          startOffset: 0,
          endOffset: Number.POSITIVE_INFINITY,
          type: null
        });
        return;
      }
      s.trigger(m.AUDIO_TRACK_SWITCHED, t);
    }
  }
  onAudioTrackSwitched(e, t) {
    const s = cs(t.url, this.hls);
    if (s) {
      const i = this.videoBuffer;
      i && this.mediaBuffer !== i && (this.log("Switching on alternate audio, use video.buffered to schedule main fragment loading"), this.mediaBuffer = i);
    }
    this.altAudio = s ? 2 : 0, this.tick();
  }
  onBufferCreated(e, t) {
    const s = t.tracks;
    let i, r, n = !1;
    for (const o in s) {
      const c = s[o];
      if (c.id === "main") {
        if (r = o, i = c, o === "video") {
          const l = s[o];
          l && (this.videoBuffer = l.buffer);
        }
      } else
        n = !0;
    }
    n && i ? (this.log(`Alternate track found, use ${r}.buffered to schedule main fragment loading`), this.mediaBuffer = i.buffer) : this.mediaBuffer = this.media;
  }
  onFragBuffered(e, t) {
    const {
      frag: s,
      part: i
    } = t, r = s.type === G.MAIN;
    if (r) {
      if (this.fragContextChanged(s)) {
        this.warn(`Fragment ${s.sn}${i ? " p: " + i.index : ""} of level ${s.level} finished buffering, but was aborted. state: ${this.state}`), this.state === C.PARSED && (this.state = C.IDLE);
        return;
      }
      const o = i ? i.stats : s.stats;
      this.fragLastKbps = Math.round(8 * o.total / (o.buffering.end - o.loading.first)), ue(s) && (this.fragPrevious = s), this.fragBufferedComplete(s, i);
    }
    const n = this.media;
    n && (!this._hasEnoughToStart && q.getBuffered(n).length && (this._hasEnoughToStart = !0, this.seekToStartPos()), r && this.tick());
  }
  get hasEnoughToStart() {
    return this._hasEnoughToStart;
  }
  onError(e, t) {
    var s;
    if (t.fatal) {
      this.state = C.ERROR;
      return;
    }
    switch (t.details) {
      case R.FRAG_GAP:
      case R.FRAG_PARSING_ERROR:
      case R.FRAG_DECRYPT_ERROR:
      case R.FRAG_LOAD_ERROR:
      case R.FRAG_LOAD_TIMEOUT:
      case R.KEY_LOAD_ERROR:
      case R.KEY_LOAD_TIMEOUT:
        this.onFragmentOrKeyLoadError(G.MAIN, t);
        break;
      case R.LEVEL_LOAD_ERROR:
      case R.LEVEL_LOAD_TIMEOUT:
      case R.LEVEL_PARSING_ERROR:
        !t.levelRetry && this.state === C.WAITING_LEVEL && ((s = t.context) == null ? void 0 : s.type) === z.LEVEL && (this.state = C.IDLE);
        break;
      case R.BUFFER_ADD_CODEC_ERROR:
      case R.BUFFER_APPEND_ERROR:
        if (t.parent !== "main")
          return;
        this.resetLoadingState();
        break;
      case R.BUFFER_FULL_ERROR:
        if (t.parent !== "main")
          return;
        this.reduceLengthAndFlushBuffer(t) && this.flushMainBuffer(0, Number.POSITIVE_INFINITY);
        break;
      case R.INTERNAL_EXCEPTION:
        this.recoverWorkerError(t);
        break;
    }
  }
  onFragLoadEmergencyAborted() {
    this.state = C.IDLE, this._hasEnoughToStart || (this.startFragRequested = !1, this.nextLoadPosition = this.lastCurrentTime), this.tickImmediate();
  }
  onBufferFlushed(e, {
    type: t
  }) {
    if (t !== ie.AUDIO || !this.altAudio) {
      const s = (t === ie.VIDEO ? this.videoBuffer : this.mediaBuffer) || this.media;
      s && (this.afterBufferFlushed(s, t, G.MAIN), this.tick());
    }
  }
  onLevelsUpdated(e, t) {
    this.level > -1 && this.fragCurrent && (this.level = this.fragCurrent.level, this.level === -1 && this.resetWhenMissingContext(this.fragCurrent)), this.levels = t.levels;
  }
  swapAudioCodec() {
    this.audioCodecSwap = !this.audioCodecSwap;
  }
  /**
   * Seeks to the set startPosition if not equal to the mediaElement's current time.
   */
  seekToStartPos() {
    const {
      media: e
    } = this;
    if (!e)
      return;
    const t = e.currentTime;
    let s = this.startPosition;
    if (s >= 0 && t < s) {
      if (e.seeking) {
        this.log(`could not seek to ${s}, already seeking at ${t}`);
        return;
      }
      const i = this.timelineOffset;
      i && s && (s += i);
      const r = this.getLevelDetails(), n = q.getBuffered(e), o = n.length ? n.start(0) : 0, c = o - s, l = Math.max(this.config.maxBufferHole, this.config.maxFragLookUpTolerance);
      c > 0 && (c < l || this.loadingParts && c < 2 * ((r == null ? void 0 : r.partTarget) || 0)) && (this.log(`adjusting start position by ${c} to match buffer start`), s += c, this.startPosition = s), t < s && (this.log(`seek to target start position ${s} from current time ${t} buffer start ${o}`), e.currentTime = s);
    }
  }
  _getAudioCodec(e) {
    let t = this.config.defaultAudioCodec || e.audioCodec;
    return this.audioCodecSwap && t && (this.log("Swapping audio codec"), t.indexOf("mp4a.40.5") !== -1 ? t = "mp4a.40.2" : t = "mp4a.40.5"), t;
  }
  _loadBitrateTestFrag(e, t) {
    e.bitrateTest = !0, this._doFragLoad(e, t).then((s) => {
      const {
        hls: i
      } = this, r = s == null ? void 0 : s.frag;
      if (!r || this.fragContextChanged(r))
        return;
      t.fragmentError = 0, this.state = C.IDLE, this.startFragRequested = !1, this.bitrateTest = !1;
      const n = r.stats;
      n.parsing.start = n.parsing.end = n.buffering.start = n.buffering.end = self.performance.now(), i.trigger(m.FRAG_LOADED, s), r.bitrateTest = !1;
    });
  }
  _handleTransmuxComplete(e) {
    var t;
    const s = this.playlistType, {
      hls: i
    } = this, {
      remuxResult: r,
      chunkMeta: n
    } = e, o = this.getCurrentContext(n);
    if (!o) {
      this.resetWhenMissingContext(n);
      return;
    }
    const {
      frag: c,
      part: l,
      level: h
    } = o, {
      video: u,
      text: d,
      id3: f,
      initSegment: g
    } = r, {
      details: p
    } = h, E = this.altAudio ? void 0 : r.audio;
    if (this.fragContextChanged(c)) {
      this.fragmentTracker.removeFragment(c);
      return;
    }
    if (this.state = C.PARSING, g) {
      if (g != null && g.tracks) {
        const T = c.initSegment || c;
        this._bufferInitSegment(h, g.tracks, T, n), i.trigger(m.FRAG_PARSING_INIT_SEGMENT, {
          frag: T,
          id: s,
          tracks: g.tracks
        });
      }
      const y = g.initPTS, S = g.timescale;
      M(y) && (this.initPTS[c.cc] = {
        baseTime: y,
        timescale: S
      }, i.trigger(m.INIT_PTS_FOUND, {
        frag: c,
        id: s,
        initPTS: y,
        timescale: S
      }));
    }
    if (u && p) {
      E && u.type === "audiovideo" && this.logMuxedErr(c);
      const y = p.fragments[c.sn - 1 - p.startSN], S = c.sn === p.startSN, T = !y || c.cc > y.cc;
      if (r.independent !== !1) {
        const {
          startPTS: v,
          endPTS: x,
          startDTS: _,
          endDTS: A
        } = u;
        if (l)
          l.elementaryStreams[u.type] = {
            startPTS: v,
            endPTS: x,
            startDTS: _,
            endDTS: A
          };
        else if (u.firstKeyFrame && u.independent && n.id === 1 && !T && (this.couldBacktrack = !0), u.dropped && u.independent) {
          const b = this.getMainFwdBufferInfo(), D = (b ? b.end : this.getLoadPosition()) + this.config.maxBufferHole, L = u.firstKeyFramePTS ? u.firstKeyFramePTS : v;
          if (!S && D < L - this.config.maxBufferHole && !T) {
            this.backtrack(c);
            return;
          } else T && (c.gap = !0);
          c.setElementaryStreamInfo(u.type, c.start, x, c.start, A, !0);
        } else S && v - (p.appliedTimelineOffset || 0) > rs && (c.gap = !0);
        c.setElementaryStreamInfo(u.type, v, x, _, A), this.backtrackFragment && (this.backtrackFragment = c), this.bufferFragmentData(u, c, l, n, S || T);
      } else if (S || T)
        c.gap = !0;
      else {
        this.backtrack(c);
        return;
      }
    }
    if (E) {
      const {
        startPTS: y,
        endPTS: S,
        startDTS: T,
        endDTS: v
      } = E;
      l && (l.elementaryStreams[ie.AUDIO] = {
        startPTS: y,
        endPTS: S,
        startDTS: T,
        endDTS: v
      }), c.setElementaryStreamInfo(ie.AUDIO, y, S, T, v), this.bufferFragmentData(E, c, l, n);
    }
    if (p && f != null && (t = f.samples) != null && t.length) {
      const y = {
        id: s,
        frag: c,
        details: p,
        samples: f.samples
      };
      i.trigger(m.FRAG_PARSING_METADATA, y);
    }
    if (p && d) {
      const y = {
        id: s,
        frag: c,
        details: p,
        samples: d.samples
      };
      i.trigger(m.FRAG_PARSING_USERDATA, y);
    }
  }
  logMuxedErr(e) {
    this.warn(`${ue(e) ? "Media" : "Init"} segment with muxed audiovideo where only video expected: ${e.url}`);
  }
  _bufferInitSegment(e, t, s, i) {
    if (this.state !== C.PARSING)
      return;
    this.audioOnly = !!t.audio && !t.video, this.altAudio && !this.audioOnly && (delete t.audio, t.audiovideo && this.logMuxedErr(s));
    const {
      audio: r,
      video: n,
      audiovideo: o
    } = t;
    if (r) {
      let l = Zt(r.codec, e.audioCodec);
      l === "mp4a" && (l = "mp4a.40.5");
      const h = navigator.userAgent.toLowerCase();
      if (this.audioCodecSwitch) {
        l && (l.indexOf("mp4a.40.5") !== -1 ? l = "mp4a.40.2" : l = "mp4a.40.5");
        const u = r.metadata;
        u && "channelCount" in u && (u.channelCount || 1) !== 1 && h.indexOf("firefox") === -1 && (l = "mp4a.40.5");
      }
      l && l.indexOf("mp4a.40.5") !== -1 && h.indexOf("android") !== -1 && r.container !== "audio/mpeg" && (l = "mp4a.40.2", this.log(`Android: force audio codec to ${l}`)), e.audioCodec && e.audioCodec !== l && this.log(`Swapping manifest audio codec "${e.audioCodec}" for "${l}"`), r.levelCodec = l, r.id = G.MAIN, this.log(`Init audio buffer, container:${r.container}, codecs[selected/level/parsed]=[${l || ""}/${e.audioCodec || ""}/${r.codec}]`), delete t.audiovideo;
    }
    if (n) {
      n.levelCodec = e.videoCodec, n.id = G.MAIN;
      const l = n.codec;
      if ((l == null ? void 0 : l.length) === 4)
        switch (l) {
          case "hvc1":
          case "hev1":
            n.codec = "hvc1.1.6.L120.90";
            break;
          case "av01":
            n.codec = "av01.0.04M.08";
            break;
          case "avc1":
            n.codec = "avc1.42e01e";
            break;
        }
      this.log(`Init video buffer, container:${n.container}, codecs[level/parsed]=[${e.videoCodec || ""}/${l}]${n.codec !== l ? " parsed-corrected=" + n.codec : ""}${n.supplemental ? " supplemental=" + n.supplemental : ""}`), delete t.audiovideo;
    }
    o && (this.log(`Init audiovideo buffer, container:${o.container}, codecs[level/parsed]=[${e.codecs}/${o.codec}]`), delete t.video, delete t.audio);
    const c = Object.keys(t);
    if (c.length) {
      if (this.hls.trigger(m.BUFFER_CODECS, t), !this.hls)
        return;
      c.forEach((l) => {
        const u = t[l].initSegment;
        u != null && u.byteLength && this.hls.trigger(m.BUFFER_APPENDING, {
          type: l,
          data: u,
          frag: s,
          part: null,
          chunkMeta: i,
          parent: s.type
        });
      });
    }
    this.tickImmediate();
  }
  getMainFwdBufferInfo() {
    const e = this.mediaBuffer && this.altAudio === 2 ? this.mediaBuffer : this.media;
    return this.getFwdBufferInfo(e, G.MAIN);
  }
  get maxBufferLength() {
    const {
      levels: e,
      level: t
    } = this, s = e == null ? void 0 : e[t];
    return s ? this.getMaxBufferLength(s.maxBitrate) : this.config.maxBufferLength;
  }
  backtrack(e) {
    this.couldBacktrack = !0, this.backtrackFragment = e, this.resetTransmuxer(), this.flushBufferGap(e), this.fragmentTracker.removeFragment(e), this.fragPrevious = null, this.nextLoadPosition = e.start, this.state = C.IDLE;
  }
  checkFragmentChanged() {
    const e = this.media;
    let t = null;
    if (e && e.readyState > 1 && e.seeking === !1) {
      const s = e.currentTime;
      if (q.isBuffered(e, s) ? t = this.getAppendedFrag(s) : q.isBuffered(e, s + 0.1) && (t = this.getAppendedFrag(s + 0.1)), t) {
        this.backtrackFragment = null;
        const i = this.fragPlaying, r = t.level;
        (!i || t.sn !== i.sn || i.level !== r) && (this.fragPlaying = t, this.hls.trigger(m.FRAG_CHANGED, {
          frag: t
        }), (!i || i.level !== r) && this.hls.trigger(m.LEVEL_SWITCHED, {
          level: r
        }));
      }
    }
  }
  get nextLevel() {
    const e = this.nextBufferedFrag;
    return e ? e.level : -1;
  }
  get currentFrag() {
    var e;
    if (this.fragPlaying)
      return this.fragPlaying;
    const t = ((e = this.media) == null ? void 0 : e.currentTime) || this.lastCurrentTime;
    return M(t) ? this.getAppendedFrag(t) : null;
  }
  get currentProgramDateTime() {
    var e;
    const t = ((e = this.media) == null ? void 0 : e.currentTime) || this.lastCurrentTime;
    if (M(t)) {
      const s = this.getLevelDetails(), i = this.currentFrag || (s ? it(null, s.fragments, t) : null);
      if (i) {
        const r = i.programDateTime;
        if (r !== null) {
          const n = r + (t - i.start) * 1e3;
          return new Date(n);
        }
      }
    }
    return null;
  }
  get currentLevel() {
    const e = this.currentFrag;
    return e ? e.level : -1;
  }
  get nextBufferedFrag() {
    const e = this.currentFrag;
    return e ? this.followingBufferedFrag(e) : null;
  }
  get forceStartLoad() {
    return this._forceStartLoad;
  }
}
class Ku {
  constructor(e) {
    this.config = void 0, this.keyUriToKeyInfo = {}, this.emeController = null, this.config = e;
  }
  abort(e) {
    for (const s in this.keyUriToKeyInfo) {
      const i = this.keyUriToKeyInfo[s].loader;
      if (i) {
        var t;
        if (e && e !== ((t = i.context) == null ? void 0 : t.frag.type))
          return;
        i.abort();
      }
    }
  }
  detach() {
    for (const e in this.keyUriToKeyInfo) {
      const t = this.keyUriToKeyInfo[e];
      (t.mediaKeySessionContext || t.decryptdata.isCommonEncryption) && delete this.keyUriToKeyInfo[e];
    }
  }
  destroy() {
    this.detach();
    for (const e in this.keyUriToKeyInfo) {
      const t = this.keyUriToKeyInfo[e].loader;
      t && t.destroy();
    }
    this.keyUriToKeyInfo = {};
  }
  createKeyLoadError(e, t = R.KEY_LOAD_ERROR, s, i, r) {
    return new Ue({
      type: K.NETWORK_ERROR,
      details: t,
      fatal: !1,
      frag: e,
      response: r,
      error: s,
      networkDetails: i
    });
  }
  loadClear(e, t) {
    if (this.emeController && this.config.emeEnabled) {
      const {
        sn: s,
        cc: i
      } = e;
      for (let r = 0; r < t.length; r++) {
        const n = t[r];
        if (i <= n.cc && (s === "initSegment" || n.sn === "initSegment" || s < n.sn)) {
          this.emeController.selectKeySystemFormat(n).then((o) => {
            n.setKeyFormat(o);
          });
          break;
        }
      }
    }
  }
  load(e) {
    return !e.decryptdata && e.encrypted && this.emeController && this.config.emeEnabled ? this.emeController.selectKeySystemFormat(e).then((t) => this.loadInternal(e, t)) : this.loadInternal(e);
  }
  loadInternal(e, t) {
    var s, i;
    t && e.setKeyFormat(t);
    const r = e.decryptdata;
    if (!r) {
      const l = new Error(t ? `Expected frag.decryptdata to be defined after setting format ${t}` : "Missing decryption data on fragment in onKeyLoading");
      return Promise.reject(this.createKeyLoadError(e, R.KEY_LOAD_ERROR, l));
    }
    const n = r.uri;
    if (!n)
      return Promise.reject(this.createKeyLoadError(e, R.KEY_LOAD_ERROR, new Error(`Invalid key URI: "${n}"`)));
    let o = this.keyUriToKeyInfo[n];
    if ((s = o) != null && s.decryptdata.key)
      return r.key = o.decryptdata.key, Promise.resolve({
        frag: e,
        keyInfo: o
      });
    if ((i = o) != null && i.keyLoadPromise) {
      var c;
      switch ((c = o.mediaKeySessionContext) == null ? void 0 : c.keyStatus) {
        case void 0:
        case "status-pending":
        case "usable":
        case "usable-in-future":
          return o.keyLoadPromise.then((l) => (r.key = l.keyInfo.decryptdata.key, {
            frag: e,
            keyInfo: o
          }));
      }
    }
    switch (o = this.keyUriToKeyInfo[n] = {
      decryptdata: r,
      keyLoadPromise: null,
      loader: null,
      mediaKeySessionContext: null
    }, r.method) {
      case "ISO-23001-7":
      case "SAMPLE-AES":
      case "SAMPLE-AES-CENC":
      case "SAMPLE-AES-CTR":
        return r.keyFormat === "identity" ? this.loadKeyHTTP(o, e) : this.loadKeyEME(o, e);
      case "AES-128":
      case "AES-256":
      case "AES-256-CTR":
        return this.loadKeyHTTP(o, e);
      default:
        return Promise.reject(this.createKeyLoadError(e, R.KEY_LOAD_ERROR, new Error(`Key supplied with unsupported METHOD: "${r.method}"`)));
    }
  }
  loadKeyEME(e, t) {
    const s = {
      frag: t,
      keyInfo: e
    };
    if (this.emeController && this.config.emeEnabled) {
      const i = this.emeController.loadKey(s);
      if (i)
        return (e.keyLoadPromise = i.then((r) => (e.mediaKeySessionContext = r, s))).catch((r) => {
          throw e.keyLoadPromise = null, r;
        });
    }
    return Promise.resolve(s);
  }
  loadKeyHTTP(e, t) {
    const s = this.config, i = s.loader, r = new i(s);
    return t.keyLoader = e.loader = r, e.keyLoadPromise = new Promise((n, o) => {
      const c = {
        keyInfo: e,
        frag: t,
        responseType: "arraybuffer",
        url: e.decryptdata.uri
      }, l = s.keyLoadPolicy.default, h = {
        loadPolicy: l,
        timeout: l.maxLoadTimeMs,
        maxRetry: 0,
        retryDelay: 0,
        maxRetryDelay: 0
      }, u = {
        onSuccess: (d, f, g, p) => {
          const {
            frag: E,
            keyInfo: y,
            url: S
          } = g;
          if (!E.decryptdata || y !== this.keyUriToKeyInfo[S])
            return o(this.createKeyLoadError(E, R.KEY_LOAD_ERROR, new Error("after key load, decryptdata unset or changed"), p));
          y.decryptdata.key = E.decryptdata.key = new Uint8Array(d.data), E.keyLoader = null, y.loader = null, n({
            frag: E,
            keyInfo: y
          });
        },
        onError: (d, f, g, p) => {
          this.resetLoader(f), o(this.createKeyLoadError(t, R.KEY_LOAD_ERROR, new Error(`HTTP Error ${d.code} loading key ${d.text}`), g, te({
            url: c.url,
            data: void 0
          }, d)));
        },
        onTimeout: (d, f, g) => {
          this.resetLoader(f), o(this.createKeyLoadError(t, R.KEY_LOAD_TIMEOUT, new Error("key loading timed out"), g));
        },
        onAbort: (d, f, g) => {
          this.resetLoader(f), o(this.createKeyLoadError(t, R.INTERNAL_ABORTED, new Error("key loading aborted"), g));
        }
      };
      r.load(c, h, u);
    });
  }
  resetLoader(e) {
    const {
      frag: t,
      keyInfo: s,
      url: i
    } = e, r = s.loader;
    t.keyLoader === r && (t.keyLoader = null, s.loader = null), delete this.keyUriToKeyInfo[i], r && r.destroy();
  }
}
function on(a) {
  const {
    type: e
  } = a;
  switch (e) {
    case z.AUDIO_TRACK:
      return G.AUDIO;
    case z.SUBTITLE_TRACK:
      return G.SUBTITLE;
    default:
      return G.MAIN;
  }
}
function Ys(a, e) {
  let t = a.url;
  return (t === void 0 || t.indexOf("data:") === 0) && (t = e.url), t;
}
class Vu {
  constructor(e) {
    this.hls = void 0, this.loaders = /* @__PURE__ */ Object.create(null), this.variableList = null, this.onManifestLoaded = this.checkAutostartLoad, this.hls = e, this.registerListeners();
  }
  startLoad(e) {
  }
  stopLoad() {
    this.destroyInternalLoaders();
  }
  registerListeners() {
    const {
      hls: e
    } = this;
    e.on(m.MANIFEST_LOADING, this.onManifestLoading, this), e.on(m.LEVEL_LOADING, this.onLevelLoading, this), e.on(m.AUDIO_TRACK_LOADING, this.onAudioTrackLoading, this), e.on(m.SUBTITLE_TRACK_LOADING, this.onSubtitleTrackLoading, this), e.on(m.LEVELS_UPDATED, this.onLevelsUpdated, this);
  }
  unregisterListeners() {
    const {
      hls: e
    } = this;
    e.off(m.MANIFEST_LOADING, this.onManifestLoading, this), e.off(m.LEVEL_LOADING, this.onLevelLoading, this), e.off(m.AUDIO_TRACK_LOADING, this.onAudioTrackLoading, this), e.off(m.SUBTITLE_TRACK_LOADING, this.onSubtitleTrackLoading, this), e.off(m.LEVELS_UPDATED, this.onLevelsUpdated, this);
  }
  /**
   * Returns defaults or configured loader-type overloads (pLoader and loader config params)
   */
  createInternalLoader(e) {
    const t = this.hls.config, s = t.pLoader, i = t.loader, r = s || i, n = new r(t);
    return this.loaders[e.type] = n, n;
  }
  getInternalLoader(e) {
    return this.loaders[e.type];
  }
  resetInternalLoader(e) {
    this.loaders[e] && delete this.loaders[e];
  }
  /**
   * Call `destroy` on all internal loader instances mapped (one per context type)
   */
  destroyInternalLoaders() {
    for (const e in this.loaders) {
      const t = this.loaders[e];
      t && t.destroy(), this.resetInternalLoader(e);
    }
  }
  destroy() {
    this.variableList = null, this.unregisterListeners(), this.destroyInternalLoaders();
  }
  onManifestLoading(e, t) {
    const {
      url: s
    } = t;
    this.variableList = null, this.load({
      id: null,
      level: 0,
      responseType: "text",
      type: z.MANIFEST,
      url: s,
      deliveryDirectives: null,
      levelOrTrack: null
    });
  }
  onLevelLoading(e, t) {
    const {
      id: s,
      level: i,
      pathwayId: r,
      url: n,
      deliveryDirectives: o,
      levelInfo: c
    } = t;
    this.load({
      id: s,
      level: i,
      pathwayId: r,
      responseType: "text",
      type: z.LEVEL,
      url: n,
      deliveryDirectives: o,
      levelOrTrack: c
    });
  }
  onAudioTrackLoading(e, t) {
    const {
      id: s,
      groupId: i,
      url: r,
      deliveryDirectives: n,
      track: o
    } = t;
    this.load({
      id: s,
      groupId: i,
      level: null,
      responseType: "text",
      type: z.AUDIO_TRACK,
      url: r,
      deliveryDirectives: n,
      levelOrTrack: o
    });
  }
  onSubtitleTrackLoading(e, t) {
    const {
      id: s,
      groupId: i,
      url: r,
      deliveryDirectives: n,
      track: o
    } = t;
    this.load({
      id: s,
      groupId: i,
      level: null,
      responseType: "text",
      type: z.SUBTITLE_TRACK,
      url: r,
      deliveryDirectives: n,
      levelOrTrack: o
    });
  }
  onLevelsUpdated(e, t) {
    const s = this.loaders[z.LEVEL];
    if (s) {
      const i = s.context;
      i && !t.levels.some((r) => r === i.levelOrTrack) && (s.abort(), delete this.loaders[z.LEVEL]);
    }
  }
  load(e) {
    var t;
    const s = this.hls.config;
    let i = this.getInternalLoader(e);
    if (i) {
      const l = this.hls.logger, h = i.context;
      if (h && h.levelOrTrack === e.levelOrTrack && (h.url === e.url || h.deliveryDirectives && !e.deliveryDirectives)) {
        h.url === e.url ? l.log(`[playlist-loader]: ignore ${e.url} ongoing request`) : l.log(`[playlist-loader]: ignore ${e.url} in favor of ${h.url}`);
        return;
      }
      l.log(`[playlist-loader]: aborting previous loader for type: ${e.type}`), i.abort();
    }
    let r;
    if (e.type === z.MANIFEST ? r = s.manifestLoadPolicy.default : r = re({}, s.playlistLoadPolicy.default, {
      timeoutRetry: null,
      errorRetry: null
    }), i = this.createInternalLoader(e), M((t = e.deliveryDirectives) == null ? void 0 : t.part)) {
      let l;
      if (e.type === z.LEVEL && e.level !== null ? l = this.hls.levels[e.level].details : e.type === z.AUDIO_TRACK && e.id !== null ? l = this.hls.audioTracks[e.id].details : e.type === z.SUBTITLE_TRACK && e.id !== null && (l = this.hls.subtitleTracks[e.id].details), l) {
        const h = l.partTarget, u = l.targetduration;
        if (h && u) {
          const d = Math.max(h * 3, u * 0.8) * 1e3;
          r = re({}, r, {
            maxTimeToFirstByteMs: Math.min(d, r.maxTimeToFirstByteMs),
            maxLoadTimeMs: Math.min(d, r.maxTimeToFirstByteMs)
          });
        }
      }
    }
    const n = r.errorRetry || r.timeoutRetry || {}, o = {
      loadPolicy: r,
      timeout: r.maxLoadTimeMs,
      maxRetry: n.maxNumRetry || 0,
      retryDelay: n.retryDelayMs || 0,
      maxRetryDelay: n.maxRetryDelayMs || 0
    }, c = {
      onSuccess: (l, h, u, d) => {
        const f = this.getInternalLoader(u);
        this.resetInternalLoader(u.type);
        const g = l.data;
        if (g.indexOf("#EXTM3U") !== 0) {
          this.handleManifestParsingError(l, u, new Error("no EXTM3U delimiter"), d || null, h);
          return;
        }
        h.parsing.start = performance.now(), Oe.isMediaPlaylist(g) || u.type !== z.MANIFEST ? this.handleTrackOrLevelPlaylist(l, h, u, d || null, f) : this.handleMasterPlaylist(l, h, u, d);
      },
      onError: (l, h, u, d) => {
        this.handleNetworkError(h, u, !1, l, d);
      },
      onTimeout: (l, h, u) => {
        this.handleNetworkError(h, u, !0, void 0, l);
      }
    };
    i.load(e, o, c);
  }
  checkAutostartLoad() {
    if (!this.hls)
      return;
    const {
      config: {
        autoStartLoad: e,
        startPosition: t
      },
      forceStartLoad: s
    } = this.hls;
    (e || s) && (this.hls.logger.log(`${e ? "auto" : "force"} startLoad with configured startPosition ${t}`), this.hls.startLoad(t));
  }
  handleMasterPlaylist(e, t, s, i) {
    const r = this.hls, n = e.data, o = Ys(e, s), c = Oe.parseMasterPlaylist(n, o);
    if (c.playlistParsingError) {
      this.handleManifestParsingError(e, s, c.playlistParsingError, i, t);
      return;
    }
    const {
      contentSteering: l,
      levels: h,
      sessionData: u,
      sessionKeys: d,
      startTimeOffset: f,
      variableList: g
    } = c;
    this.variableList = g;
    const {
      AUDIO: p = [],
      SUBTITLES: E,
      "CLOSED-CAPTIONS": y
    } = Oe.parseMasterPlaylistMedia(n, o, c);
    p.length && !p.some((T) => !T.url) && h[0].audioCodec && !h[0].attrs.AUDIO && (this.hls.logger.log("[playlist-loader]: audio codec signaled in quality level, but no embedded audio track signaled, create one"), p.unshift({
      type: "main",
      name: "main",
      groupId: "main",
      default: !1,
      autoselect: !1,
      forced: !1,
      id: -1,
      attrs: new oe({}),
      bitrate: 0,
      url: ""
    })), r.trigger(m.MANIFEST_LOADED, {
      levels: h,
      audioTracks: p,
      subtitles: E,
      captions: y,
      contentSteering: l,
      url: o,
      stats: t,
      networkDetails: i,
      sessionData: u,
      sessionKeys: d,
      startTimeOffset: f,
      variableList: g
    });
  }
  handleTrackOrLevelPlaylist(e, t, s, i, r) {
    const n = this.hls, {
      id: o,
      level: c,
      type: l
    } = s, h = Ys(e, s), u = M(c) ? c : M(o) ? o : 0, d = on(s), f = Oe.parseLevelPlaylist(e.data, h, u, d, 0, this.variableList);
    if (l === z.MANIFEST) {
      const g = {
        attrs: new oe({}),
        bitrate: 0,
        details: f,
        name: "",
        url: h
      };
      f.requestScheduled = t.loading.start + Vn(f, 0), n.trigger(m.MANIFEST_LOADED, {
        levels: [g],
        audioTracks: [],
        url: h,
        stats: t,
        networkDetails: i,
        sessionData: null,
        sessionKeys: null,
        contentSteering: null,
        startTimeOffset: null,
        variableList: null
      });
    }
    t.parsing.end = performance.now(), s.levelDetails = f, this.handlePlaylistLoaded(f, e, t, s, i, r);
  }
  handleManifestParsingError(e, t, s, i, r) {
    this.hls.trigger(m.ERROR, {
      type: K.NETWORK_ERROR,
      details: R.MANIFEST_PARSING_ERROR,
      fatal: t.type === z.MANIFEST,
      url: e.url,
      err: s,
      error: s,
      reason: s.message,
      response: e,
      context: t,
      networkDetails: i,
      stats: r
    });
  }
  handleNetworkError(e, t, s = !1, i, r) {
    let n = `A network ${s ? "timeout" : "error" + (i ? " (status " + i.code + ")" : "")} occurred while loading ${e.type}`;
    e.type === z.LEVEL ? n += `: ${e.level} id: ${e.id}` : (e.type === z.AUDIO_TRACK || e.type === z.SUBTITLE_TRACK) && (n += ` id: ${e.id} group-id: "${e.groupId}"`);
    const o = new Error(n);
    this.hls.logger.warn(`[playlist-loader]: ${n}`);
    let c = R.UNKNOWN, l = !1;
    const h = this.getInternalLoader(e);
    switch (e.type) {
      case z.MANIFEST:
        c = s ? R.MANIFEST_LOAD_TIMEOUT : R.MANIFEST_LOAD_ERROR, l = !0;
        break;
      case z.LEVEL:
        c = s ? R.LEVEL_LOAD_TIMEOUT : R.LEVEL_LOAD_ERROR, l = !1;
        break;
      case z.AUDIO_TRACK:
        c = s ? R.AUDIO_TRACK_LOAD_TIMEOUT : R.AUDIO_TRACK_LOAD_ERROR, l = !1;
        break;
      case z.SUBTITLE_TRACK:
        c = s ? R.SUBTITLE_TRACK_LOAD_TIMEOUT : R.SUBTITLE_LOAD_ERROR, l = !1;
        break;
    }
    h && this.resetInternalLoader(e.type);
    const u = {
      type: K.NETWORK_ERROR,
      details: c,
      fatal: l,
      url: e.url,
      loader: h,
      context: e,
      error: o,
      networkDetails: t,
      stats: r
    };
    if (i) {
      const d = (t == null ? void 0 : t.url) || e.url;
      u.response = te({
        url: d,
        data: void 0
      }, i);
    }
    this.hls.trigger(m.ERROR, u);
  }
  handlePlaylistLoaded(e, t, s, i, r, n) {
    const o = this.hls, {
      type: c,
      level: l,
      id: h,
      groupId: u,
      deliveryDirectives: d
    } = i, f = Ys(t, i), g = on(i), p = typeof i.level == "number" && g === G.MAIN ? l : void 0;
    if (!e.fragments.length) {
      const y = e.playlistParsingError = new Error("No Segments found in Playlist");
      o.trigger(m.ERROR, {
        type: K.NETWORK_ERROR,
        details: R.LEVEL_EMPTY_ERROR,
        fatal: !1,
        url: f,
        error: y,
        reason: y.message,
        response: t,
        context: i,
        level: p,
        parent: g,
        networkDetails: r,
        stats: s
      });
      return;
    }
    e.targetduration || (e.playlistParsingError = new Error("Missing Target Duration"));
    const E = e.playlistParsingError;
    if (E) {
      if (this.hls.logger.warn(E), !o.config.ignorePlaylistParsingErrors) {
        o.trigger(m.ERROR, {
          type: K.NETWORK_ERROR,
          details: R.LEVEL_PARSING_ERROR,
          fatal: !1,
          url: f,
          error: E,
          reason: E.message,
          response: t,
          context: i,
          level: p,
          parent: g,
          networkDetails: r,
          stats: s
        });
        return;
      }
      e.playlistParsingError = null;
    }
    switch (e.live && n && (n.getCacheAge && (e.ageHeader = n.getCacheAge() || 0), (!n.getCacheAge || isNaN(e.ageHeader)) && (e.ageHeader = 0)), c) {
      case z.MANIFEST:
      case z.LEVEL:
        o.trigger(m.LEVEL_LOADED, {
          details: e,
          levelInfo: i.levelOrTrack || o.levels[0],
          level: p || 0,
          id: h || 0,
          stats: s,
          networkDetails: r,
          deliveryDirectives: d,
          withoutMultiVariant: c === z.MANIFEST
        });
        break;
      case z.AUDIO_TRACK:
        o.trigger(m.AUDIO_TRACK_LOADED, {
          details: e,
          track: i.levelOrTrack,
          id: h || 0,
          groupId: u || "",
          stats: s,
          networkDetails: r,
          deliveryDirectives: d
        });
        break;
      case z.SUBTITLE_TRACK:
        o.trigger(m.SUBTITLE_TRACK_LOADED, {
          details: e,
          track: i.levelOrTrack,
          id: h || 0,
          groupId: u || "",
          stats: s,
          networkDetails: r,
          deliveryDirectives: d
        });
        break;
    }
  }
}
class Se {
  /**
   * Get the video-dev/hls.js package version.
   */
  static get version() {
    return Pt;
  }
  /**
   * Check if the required MediaSource Extensions are available.
   */
  static isMSESupported() {
    return Na();
  }
  /**
   * Check if MediaSource Extensions are available and isTypeSupported checks pass for any baseline codecs.
   */
  static isSupported() {
    return Bu();
  }
  /**
   * Get the MediaSource global used for MSE playback (ManagedMediaSource, MediaSource, or WebKitMediaSource).
   */
  static getMediaSource() {
    return ze();
  }
  static get Events() {
    return m;
  }
  static get MetadataSchema() {
    return Te;
  }
  static get ErrorTypes() {
    return K;
  }
  static get ErrorDetails() {
    return R;
  }
  /**
   * Get the default configuration applied to new instances.
   */
  static get DefaultConfig() {
    return Se.defaultConfig ? Se.defaultConfig : Iu;
  }
  /**
   * Replace the default configuration applied to new instances.
   */
  static set DefaultConfig(e) {
    Se.defaultConfig = e;
  }
  /**
   * Creates an instance of an HLS client that can attach to exactly one `HTMLMediaElement`.
   * @param userConfig - Configuration options applied over `Hls.DefaultConfig`
   */
  constructor(e = {}) {
    this.config = void 0, this.userConfig = void 0, this.logger = void 0, this.coreComponents = void 0, this.networkControllers = void 0, this._emitter = new Ai(), this._autoLevelCapping = -1, this._maxHdcpLevel = null, this.abrController = void 0, this.bufferController = void 0, this.capLevelController = void 0, this.latencyController = void 0, this.levelController = void 0, this.streamController = void 0, this.audioStreamController = void 0, this.subtititleStreamController = void 0, this.audioTrackController = void 0, this.subtitleTrackController = void 0, this.interstitialsController = void 0, this.gapController = void 0, this.emeController = void 0, this.cmcdController = void 0, this._media = null, this._url = null, this._sessionId = void 0, this.triggeringException = void 0, this.started = !1;
    const t = this.logger = oo(e.debug || !1, "Hls instance", e.assetPlayerId), s = this.config = bu(Se.DefaultConfig, e, t);
    this.userConfig = e, s.progressive && _u(s, t);
    const {
      abrController: i,
      bufferController: r,
      capLevelController: n,
      errorController: o,
      fpsController: c
    } = s, l = new o(this), h = this.abrController = new i(this), u = new el(this), d = s.interstitialsController, f = d ? this.interstitialsController = new d(this, Se) : null, g = this.bufferController = new r(this, u), p = this.capLevelController = new n(this), E = new c(this), y = new Vu(this), S = s.contentSteeringController, T = S ? new S(this) : null, v = this.levelController = new Nu(this, T), x = new Fu(this), _ = new Ku(this.config), A = this.streamController = new Gu(this, u, _), b = this.gapController = new ku(this, u);
    p.setStreamController(A), E.setStreamController(A);
    const D = [y, v, A];
    f && D.splice(1, 0, f), T && D.splice(1, 0, T), this.networkControllers = D;
    const L = [h, g, b, p, E, x, u];
    this.audioTrackController = this.createController(s.audioTrackController, D);
    const k = s.audioStreamController;
    k && D.push(this.audioStreamController = new k(this, u, _)), this.subtitleTrackController = this.createController(s.subtitleTrackController, D);
    const F = s.subtitleStreamController;
    F && D.push(this.subtititleStreamController = new F(this, u, _)), this.createController(s.timelineController, L), _.emeController = this.emeController = this.createController(s.emeController, L), this.cmcdController = this.createController(s.cmcdController, L), this.latencyController = this.createController(Mu, L), this.coreComponents = L, D.push(l);
    const j = l.onErrorOut;
    typeof j == "function" && this.on(m.ERROR, j, l), this.on(m.MANIFEST_LOADED, y.onManifestLoaded, y);
  }
  createController(e, t) {
    if (e) {
      const s = new e(this);
      return t && t.push(s), s;
    }
    return null;
  }
  // Delegate the EventEmitter through the public API of Hls.js
  on(e, t, s = this) {
    this._emitter.on(e, t, s);
  }
  once(e, t, s = this) {
    this._emitter.once(e, t, s);
  }
  removeAllListeners(e) {
    this._emitter.removeAllListeners(e);
  }
  off(e, t, s = this, i) {
    this._emitter.off(e, t, s, i);
  }
  listeners(e) {
    return this._emitter.listeners(e);
  }
  emit(e, t, s) {
    return this._emitter.emit(e, t, s);
  }
  trigger(e, t) {
    if (this.config.debug)
      return this.emit(e, e, t);
    try {
      return this.emit(e, e, t);
    } catch (s) {
      if (this.logger.error("An internal error happened while handling event " + e + '. Error message: "' + s.message + '". Here is a stacktrace:', s), !this.triggeringException) {
        this.triggeringException = !0;
        const i = e === m.ERROR;
        this.trigger(m.ERROR, {
          type: K.OTHER_ERROR,
          details: R.INTERNAL_EXCEPTION,
          fatal: i,
          event: e,
          error: s
        }), this.triggeringException = !1;
      }
    }
    return !1;
  }
  listenerCount(e) {
    return this._emitter.listenerCount(e);
  }
  /**
   * Dispose of the instance
   */
  destroy() {
    this.logger.log("destroy"), this.trigger(m.DESTROYING, void 0), this.detachMedia(), this.removeAllListeners(), this._autoLevelCapping = -1, this._url = null, this.networkControllers.forEach((t) => t.destroy()), this.networkControllers.length = 0, this.coreComponents.forEach((t) => t.destroy()), this.coreComponents.length = 0;
    const e = this.config;
    e.xhrSetup = e.fetchSetup = void 0, this.userConfig = null;
  }
  /**
   * Attaches Hls.js to a media element
   */
  attachMedia(e) {
    if (!e || "media" in e && !e.media) {
      const r = new Error(`attachMedia failed: invalid argument (${e})`);
      this.trigger(m.ERROR, {
        type: K.OTHER_ERROR,
        details: R.ATTACH_MEDIA_ERROR,
        fatal: !0,
        error: r
      });
      return;
    }
    this.logger.log("attachMedia"), this._media && (this.logger.warn("media must be detached before attaching"), this.detachMedia());
    const t = "media" in e, s = t ? e.media : e, i = t ? e : {
      media: s
    };
    this._media = s, this.trigger(m.MEDIA_ATTACHING, i);
  }
  /**
   * Detach Hls.js from the media
   */
  detachMedia() {
    this.logger.log("detachMedia"), this.trigger(m.MEDIA_DETACHING, {}), this._media = null;
  }
  /**
   * Detach HTMLMediaElement, MediaSource, and SourceBuffers without reset, for attaching to another instance
   */
  transferMedia() {
    this._media = null;
    const e = this.bufferController.transferMedia();
    return this.trigger(m.MEDIA_DETACHING, {
      transferMedia: e
    }), e;
  }
  /**
   * Set the source URL. Can be relative or absolute.
   */
  loadSource(e) {
    this.stopLoad();
    const t = this.media, s = this._url, i = this._url = fi.buildAbsoluteURL(self.location.href, e, {
      alwaysNormalize: !0
    });
    this._autoLevelCapping = -1, this._maxHdcpLevel = null, this.logger.log(`loadSource:${i}`), t && s && (s !== i || this.bufferController.hasSourceTypes()) && (this.detachMedia(), this.attachMedia(t)), this.trigger(m.MANIFEST_LOADING, {
      url: e
    });
  }
  /**
   * Gets the currently loaded URL
   */
  get url() {
    return this._url;
  }
  /**
   * Whether or not enough has been buffered to seek to start position or use `media.currentTime` to determine next load position
   */
  get hasEnoughToStart() {
    return this.streamController.hasEnoughToStart;
  }
  /**
   * Get the startPosition set on startLoad(position) or on autostart with config.startPosition
   */
  get startPosition() {
    return this.streamController.startPositionValue;
  }
  /**
   * Start loading data from the stream source.
   * Depending on default config, client starts loading automatically when a source is set.
   *
   * @param startPosition - Set the start position to stream from.
   * Defaults to -1 (None: starts from earliest point)
   */
  startLoad(e = -1, t) {
    this.logger.log(`startLoad(${e + (t ? ", <skip seek to start>" : "")})`), this.started = !0, this.resumeBuffering();
    for (let s = 0; s < this.networkControllers.length && (this.networkControllers[s].startLoad(e, t), !(!this.started || !this.networkControllers)); s++)
      ;
  }
  /**
   * Stop loading of any stream data.
   */
  stopLoad() {
    this.logger.log("stopLoad"), this.started = !1;
    for (let e = 0; e < this.networkControllers.length && (this.networkControllers[e].stopLoad(), !(this.started || !this.networkControllers)); e++)
      ;
  }
  /**
   * Returns whether loading, toggled with `startLoad()` and `stopLoad()`, is active or not`.
   */
  get loadingEnabled() {
    return this.started;
  }
  /**
   * Returns state of fragment loading toggled by calling `pauseBuffering()` and `resumeBuffering()`.
   */
  get bufferingEnabled() {
    return this.streamController.bufferingEnabled;
  }
  /**
   * Resumes stream controller segment loading after `pauseBuffering` has been called.
   */
  resumeBuffering() {
    this.bufferingEnabled || (this.logger.log("resume buffering"), this.networkControllers.forEach((e) => {
      e.resumeBuffering && e.resumeBuffering();
    }));
  }
  /**
   * Prevents stream controller from loading new segments until `resumeBuffering` is called.
   * This allows for media buffering to be paused without interupting playlist loading.
   */
  pauseBuffering() {
    this.bufferingEnabled && (this.logger.log("pause buffering"), this.networkControllers.forEach((e) => {
      e.pauseBuffering && e.pauseBuffering();
    }));
  }
  get inFlightFragments() {
    const e = {
      [G.MAIN]: this.streamController.inFlightFrag
    };
    return this.audioStreamController && (e[G.AUDIO] = this.audioStreamController.inFlightFrag), this.subtititleStreamController && (e[G.SUBTITLE] = this.subtititleStreamController.inFlightFrag), e;
  }
  /**
   * Swap through possible audio codecs in the stream (for example to switch from stereo to 5.1)
   */
  swapAudioCodec() {
    this.logger.log("swapAudioCodec"), this.streamController.swapAudioCodec();
  }
  /**
   * When the media-element fails, this allows to detach and then re-attach it
   * as one call (convenience method).
   *
   * Automatic recovery of media-errors by this process is configurable.
   */
  recoverMediaError() {
    this.logger.log("recoverMediaError");
    const e = this._media, t = e == null ? void 0 : e.currentTime;
    this.detachMedia(), e && (this.attachMedia(e), t && this.startLoad(t));
  }
  removeLevel(e) {
    this.levelController.removeLevel(e);
  }
  /**
   * @returns a UUID for this player instance
   */
  get sessionId() {
    let e = this._sessionId;
    return e || (e = this._sessionId = Zl()), e;
  }
  /**
   * @returns an array of levels (variants) sorted by HDCP-LEVEL, RESOLUTION (height), FRAME-RATE, CODECS, VIDEO-RANGE, and BANDWIDTH
   */
  get levels() {
    const e = this.levelController.levels;
    return e || [];
  }
  /**
   * @returns LevelDetails of last loaded level (variant) or `null` prior to loading a media playlist.
   */
  get latestLevelDetails() {
    return this.streamController.getLevelDetails() || null;
  }
  /**
   * @returns Level object of selected level (variant) or `null` prior to selecting a level or once the level is removed.
   */
  get loadLevelObj() {
    return this.levelController.loadLevelObj;
  }
  /**
   * Index of quality level (variant) currently played
   */
  get currentLevel() {
    return this.streamController.currentLevel;
  }
  /**
   * Set quality level index immediately. This will flush the current buffer to replace the quality asap. That means playback will interrupt at least shortly to re-buffer and re-sync eventually. Set to -1 for automatic level selection.
   */
  set currentLevel(e) {
    this.logger.log(`set currentLevel:${e}`), this.levelController.manualLevel = e, this.streamController.immediateLevelSwitch();
  }
  /**
   * Index of next quality level loaded as scheduled by stream controller.
   */
  get nextLevel() {
    return this.streamController.nextLevel;
  }
  /**
   * Set quality level index for next loaded data.
   * This will switch the video quality asap, without interrupting playback.
   * May abort current loading of data, and flush parts of buffer (outside currently played fragment region).
   * @param newLevel - Pass -1 for automatic level selection
   */
  set nextLevel(e) {
    this.logger.log(`set nextLevel:${e}`), this.levelController.manualLevel = e, this.streamController.nextLevelSwitch();
  }
  /**
   * Return the quality level of the currently or last (of none is loaded currently) segment
   */
  get loadLevel() {
    return this.levelController.level;
  }
  /**
   * Set quality level index for next loaded data in a conservative way.
   * This will switch the quality without flushing, but interrupt current loading.
   * Thus the moment when the quality switch will appear in effect will only be after the already existing buffer.
   * @param newLevel - Pass -1 for automatic level selection
   */
  set loadLevel(e) {
    this.logger.log(`set loadLevel:${e}`), this.levelController.manualLevel = e;
  }
  /**
   * get next quality level loaded
   */
  get nextLoadLevel() {
    return this.levelController.nextLoadLevel;
  }
  /**
   * Set quality level of next loaded segment in a fully "non-destructive" way.
   * Same as `loadLevel` but will wait for next switch (until current loading is done).
   */
  set nextLoadLevel(e) {
    this.levelController.nextLoadLevel = e;
  }
  /**
   * Return "first level": like a default level, if not set,
   * falls back to index of first level referenced in manifest
   */
  get firstLevel() {
    return Math.max(this.levelController.firstLevel, this.minAutoLevel);
  }
  /**
   * Sets "first-level", see getter.
   */
  set firstLevel(e) {
    this.logger.log(`set firstLevel:${e}`), this.levelController.firstLevel = e;
  }
  /**
   * Return the desired start level for the first fragment that will be loaded.
   * The default value of -1 indicates automatic start level selection.
   * Setting hls.nextAutoLevel without setting a startLevel will result in
   * the nextAutoLevel value being used for one fragment load.
   */
  get startLevel() {
    const e = this.levelController.startLevel;
    return e === -1 && this.abrController.forcedAutoLevel > -1 ? this.abrController.forcedAutoLevel : e;
  }
  /**
   * set  start level (level of first fragment that will be played back)
   * if not overrided by user, first level appearing in manifest will be used as start level
   * if -1 : automatic start level selection, playback will start from level matching download bandwidth
   * (determined from download of first segment)
   */
  set startLevel(e) {
    this.logger.log(`set startLevel:${e}`), e !== -1 && (e = Math.max(e, this.minAutoLevel)), this.levelController.startLevel = e;
  }
  /**
   * Whether level capping is enabled.
   * Default value is set via `config.capLevelToPlayerSize`.
   */
  get capLevelToPlayerSize() {
    return this.config.capLevelToPlayerSize;
  }
  /**
   * Enables or disables level capping. If disabled after previously enabled, `nextLevelSwitch` will be immediately called.
   */
  set capLevelToPlayerSize(e) {
    const t = !!e;
    t !== this.config.capLevelToPlayerSize && (t ? this.capLevelController.startCapping() : (this.capLevelController.stopCapping(), this.autoLevelCapping = -1, this.streamController.nextLevelSwitch()), this.config.capLevelToPlayerSize = t);
  }
  /**
   * Capping/max level value that should be used by automatic level selection algorithm (`ABRController`)
   */
  get autoLevelCapping() {
    return this._autoLevelCapping;
  }
  /**
   * Returns the current bandwidth estimate in bits per second, when available. Otherwise, `NaN` is returned.
   */
  get bandwidthEstimate() {
    const {
      bwEstimator: e
    } = this.abrController;
    return e ? e.getEstimate() : NaN;
  }
  set bandwidthEstimate(e) {
    this.abrController.resetEstimator(e);
  }
  get abrEwmaDefaultEstimate() {
    const {
      bwEstimator: e
    } = this.abrController;
    return e ? e.defaultEstimate : NaN;
  }
  /**
   * get time to first byte estimate
   * @type {number}
   */
  get ttfbEstimate() {
    const {
      bwEstimator: e
    } = this.abrController;
    return e ? e.getEstimateTTFB() : NaN;
  }
  /**
   * Capping/max level value that should be used by automatic level selection algorithm (`ABRController`)
   */
  set autoLevelCapping(e) {
    this._autoLevelCapping !== e && (this.logger.log(`set autoLevelCapping:${e}`), this._autoLevelCapping = e, this.levelController.checkMaxAutoUpdated());
  }
  get maxHdcpLevel() {
    return this._maxHdcpLevel;
  }
  set maxHdcpLevel(e) {
    No(e) && this._maxHdcpLevel !== e && (this._maxHdcpLevel = e, this.levelController.checkMaxAutoUpdated());
  }
  /**
   * True when automatic level selection enabled
   */
  get autoLevelEnabled() {
    return this.levelController.manualLevel === -1;
  }
  /**
   * Level set manually (if any)
   */
  get manualLevel() {
    return this.levelController.manualLevel;
  }
  /**
   * min level selectable in auto mode according to config.minAutoBitrate
   */
  get minAutoLevel() {
    const {
      levels: e,
      config: {
        minAutoBitrate: t
      }
    } = this;
    if (!e) return 0;
    const s = e.length;
    for (let i = 0; i < s; i++)
      if (e[i].maxBitrate >= t)
        return i;
    return 0;
  }
  /**
   * max level selectable in auto mode according to autoLevelCapping
   */
  get maxAutoLevel() {
    const {
      levels: e,
      autoLevelCapping: t,
      maxHdcpLevel: s
    } = this;
    let i;
    if (t === -1 && e != null && e.length ? i = e.length - 1 : i = t, s)
      for (let r = i; r--; ) {
        const n = e[r].attrs["HDCP-LEVEL"];
        if (n && n <= s)
          return r;
      }
    return i;
  }
  get firstAutoLevel() {
    return this.abrController.firstAutoLevel;
  }
  /**
   * next automatically selected quality level
   */
  get nextAutoLevel() {
    return this.abrController.nextAutoLevel;
  }
  /**
   * this setter is used to force next auto level.
   * this is useful to force a switch down in auto mode:
   * in case of load error on level N, hls.js can set nextAutoLevel to N-1 for example)
   * forced value is valid for one fragment. upon successful frag loading at forced level,
   * this value will be resetted to -1 by ABR controller.
   */
  set nextAutoLevel(e) {
    this.abrController.nextAutoLevel = e;
  }
  /**
   * get the datetime value relative to media.currentTime for the active level Program Date Time if present
   */
  get playingDate() {
    return this.streamController.currentProgramDateTime;
  }
  get mainForwardBufferInfo() {
    return this.streamController.getMainFwdBufferInfo();
  }
  get maxBufferLength() {
    return this.streamController.maxBufferLength;
  }
  /**
   * Find and select the best matching audio track, making a level switch when a Group change is necessary.
   * Updates `hls.config.audioPreference`. Returns the selected track, or null when no matching track is found.
   */
  setAudioOption(e) {
    var t;
    return ((t = this.audioTrackController) == null ? void 0 : t.setAudioOption(e)) || null;
  }
  /**
   * Find and select the best matching subtitle track, making a level switch when a Group change is necessary.
   * Updates `hls.config.subtitlePreference`. Returns the selected track, or null when no matching track is found.
   */
  setSubtitleOption(e) {
    var t;
    return ((t = this.subtitleTrackController) == null ? void 0 : t.setSubtitleOption(e)) || null;
  }
  /**
   * Get the complete list of audio tracks across all media groups
   */
  get allAudioTracks() {
    const e = this.audioTrackController;
    return e ? e.allAudioTracks : [];
  }
  /**
   * Get the list of selectable audio tracks
   */
  get audioTracks() {
    const e = this.audioTrackController;
    return e ? e.audioTracks : [];
  }
  /**
   * index of the selected audio track (index in audio track lists)
   */
  get audioTrack() {
    const e = this.audioTrackController;
    return e ? e.audioTrack : -1;
  }
  /**
   * selects an audio track, based on its index in audio track lists
   */
  set audioTrack(e) {
    const t = this.audioTrackController;
    t && (t.audioTrack = e);
  }
  /**
   * get the complete list of subtitle tracks across all media groups
   */
  get allSubtitleTracks() {
    const e = this.subtitleTrackController;
    return e ? e.allSubtitleTracks : [];
  }
  /**
   * get alternate subtitle tracks list from playlist
   */
  get subtitleTracks() {
    const e = this.subtitleTrackController;
    return e ? e.subtitleTracks : [];
  }
  /**
   * index of the selected subtitle track (index in subtitle track lists)
   */
  get subtitleTrack() {
    const e = this.subtitleTrackController;
    return e ? e.subtitleTrack : -1;
  }
  get media() {
    return this._media;
  }
  /**
   * select an subtitle track, based on its index in subtitle track lists
   */
  set subtitleTrack(e) {
    const t = this.subtitleTrackController;
    t && (t.subtitleTrack = e);
  }
  /**
   * Whether subtitle display is enabled or not
   */
  get subtitleDisplay() {
    const e = this.subtitleTrackController;
    return e ? e.subtitleDisplay : !1;
  }
  /**
   * Enable/disable subtitle display rendering
   */
  set subtitleDisplay(e) {
    const t = this.subtitleTrackController;
    t && (t.subtitleDisplay = e);
  }
  /**
   * get mode for Low-Latency HLS loading
   */
  get lowLatencyMode() {
    return this.config.lowLatencyMode;
  }
  /**
   * Enable/disable Low-Latency HLS part playlist and segment loading, and start live streams at playlist PART-HOLD-BACK rather than HOLD-BACK.
   */
  set lowLatencyMode(e) {
    this.config.lowLatencyMode = e;
  }
  /**
   * Position (in seconds) of live sync point (ie edge of live position minus safety delay defined by ```hls.config.liveSyncDuration```)
   * @returns null prior to loading live Playlist
   */
  get liveSyncPosition() {
    return this.latencyController.liveSyncPosition;
  }
  /**
   * Estimated position (in seconds) of live edge (ie edge of live playlist plus time sync playlist advanced)
   * @returns 0 before first playlist is loaded
   */
  get latency() {
    return this.latencyController.latency;
  }
  /**
   * maximum distance from the edge before the player seeks forward to ```hls.liveSyncPosition```
   * configured using ```liveMaxLatencyDurationCount``` (multiple of target duration) or ```liveMaxLatencyDuration```
   * @returns 0 before first playlist is loaded
   */
  get maxLatency() {
    return this.latencyController.maxLatency;
  }
  /**
   * target distance from the edge as calculated by the latency controller
   */
  get targetLatency() {
    return this.latencyController.targetLatency;
  }
  set targetLatency(e) {
    this.latencyController.targetLatency = e;
  }
  /**
   * the rate at which the edge of the current live playlist is advancing or 1 if there is none
   */
  get drift() {
    return this.latencyController.drift;
  }
  /**
   * set to true when startLoad is called before MANIFEST_PARSED event
   */
  get forceStartLoad() {
    return this.streamController.forceStartLoad;
  }
  /**
   * ContentSteering pathways getter
   */
  get pathways() {
    return this.levelController.pathways;
  }
  /**
   * ContentSteering pathwayPriority getter/setter
   */
  get pathwayPriority() {
    return this.levelController.pathwayPriority;
  }
  set pathwayPriority(e) {
    this.levelController.pathwayPriority = e;
  }
  /**
   * returns true when all SourceBuffers are buffered to the end
   */
  get bufferedToEnd() {
    var e;
    return !!((e = this.bufferController) != null && e.bufferedToEnd);
  }
  /**
   * returns Interstitials Program Manager
   */
  get interstitialsManager() {
    var e;
    return ((e = this.interstitialsController) == null ? void 0 : e.interstitialsManager) || null;
  }
  /**
   * returns mediaCapabilities.decodingInfo for a variant/rendition
   */
  getMediaDecodingInfo(e, t = this.allAudioTracks) {
    const s = wn(t);
    return kn(e, s, navigator.mediaCapabilities);
  }
}
Se.defaultConfig = void 0;
const {
  SvelteComponent: Hu,
  action_destroyer: Wu,
  add_render_callback: Yu,
  assign: ln,
  attr: qe,
  binding_callbacks: qu,
  bubble: qs,
  children: ju,
  claim_element: cn,
  claim_space: Xu,
  create_slot: zu,
  detach: Qt,
  element: hn,
  exclude_internal_props: un,
  get_all_dirty_from_scope: Qu,
  get_slot_changes: Zu,
  get_svelte_dataset: Ju,
  init: ed,
  insert_hydration: js,
  is_function: td,
  listen: fe,
  raf: sd,
  run_all: id,
  safe_not_equal: rd,
  space: nd,
  src_url_equal: dn,
  toggle_class: fn,
  transition_in: ad,
  transition_out: od,
  update_slot_base: ld
} = window.__gradio__svelte__internal, { createEventDispatcher: cd } = window.__gradio__svelte__internal;
function hd(a) {
  let e, t = '<span class="load-wrap svelte-1pwzuub"><span class="loader svelte-1pwzuub"></span></span>', s, i, r, n, o = !1, c, l = !0, h, u, d, f;
  const g = (
    /*#slots*/
    a[18].default
  ), p = zu(
    g,
    a,
    /*$$scope*/
    a[17],
    null
  );
  function E() {
    cancelAnimationFrame(c), i.paused || (c = sd(E), o = !0), a[22].call(i);
  }
  return {
    c() {
      e = hn("div"), e.innerHTML = t, s = nd(), i = hn("video"), p && p.c(), this.h();
    },
    l(y) {
      e = cn(y, "DIV", { class: !0, "data-svelte-h": !0 }), Ju(e) !== "svelte-mez4j5" && (e.innerHTML = t), s = Xu(y), i = cn(y, "VIDEO", {
        src: !0,
        preload: !0,
        "data-testid": !0,
        crossorigin: !0
      });
      var S = ju(i);
      p && p.l(S), S.forEach(Qt), this.h();
    },
    h() {
      qe(e, "class", "overlay svelte-1pwzuub"), fn(e, "hidden", !/*processingVideo*/
      a[10]), dn(i.src, r = /*resolved_src*/
      a[11]) || qe(i, "src", r), i.muted = /*muted*/
      a[4], i.playsInline = /*playsinline*/
      a[5], qe(
        i,
        "preload",
        /*preload*/
        a[6]
      ), i.autoplay = /*autoplay*/
      a[7], i.controls = /*controls*/
      a[8], i.loop = /*loop*/
      a[9], qe(i, "data-testid", n = /*$$props*/
      a[13]["data-testid"]), qe(i, "crossorigin", "anonymous"), /*duration*/
      a[2] === void 0 && Yu(() => (
        /*video_durationchange_handler*/
        a[23].call(i)
      ));
    },
    m(y, S) {
      js(y, e, S), js(y, s, S), js(y, i, S), p && p.m(i, null), a[25](i), u = !0, d || (f = [
        fe(
          i,
          "loadeddata",
          /*dispatch*/
          a[12].bind(null, "loadeddata")
        ),
        fe(
          i,
          "click",
          /*dispatch*/
          a[12].bind(null, "click")
        ),
        fe(
          i,
          "play",
          /*dispatch*/
          a[12].bind(null, "play")
        ),
        fe(
          i,
          "pause",
          /*dispatch*/
          a[12].bind(null, "pause")
        ),
        fe(
          i,
          "ended",
          /*dispatch*/
          a[12].bind(null, "ended")
        ),
        fe(
          i,
          "mouseover",
          /*dispatch*/
          a[12].bind(null, "mouseover")
        ),
        fe(
          i,
          "mouseout",
          /*dispatch*/
          a[12].bind(null, "mouseout")
        ),
        fe(
          i,
          "focus",
          /*dispatch*/
          a[12].bind(null, "focus")
        ),
        fe(
          i,
          "blur",
          /*dispatch*/
          a[12].bind(null, "blur")
        ),
        fe(
          i,
          "loadstart",
          /*loadstart_handler*/
          a[19]
        ),
        fe(
          i,
          "loadeddata",
          /*loadeddata_handler*/
          a[20]
        ),
        fe(
          i,
          "loadedmetadata",
          /*loadedmetadata_handler*/
          a[21]
        ),
        fe(i, "timeupdate", E),
        fe(
          i,
          "durationchange",
          /*video_durationchange_handler*/
          a[23]
        ),
        fe(
          i,
          "play",
          /*video_play_pause_handler*/
          a[24]
        ),
        fe(
          i,
          "pause",
          /*video_play_pause_handler*/
          a[24]
        ),
        Wu(h = Ha.call(null, i, { autoplay: (
          /*autoplay*/
          a[7] ?? !1
        ) }))
      ], d = !0);
    },
    p(y, [S]) {
      (!u || S & /*processingVideo*/
      1024) && fn(e, "hidden", !/*processingVideo*/
      y[10]), p && p.p && (!u || S & /*$$scope*/
      131072) && ld(
        p,
        g,
        y,
        /*$$scope*/
        y[17],
        u ? Zu(
          g,
          /*$$scope*/
          y[17],
          S,
          null
        ) : Qu(
          /*$$scope*/
          y[17]
        ),
        null
      ), (!u || S & /*resolved_src*/
      2048 && !dn(i.src, r = /*resolved_src*/
      y[11])) && qe(i, "src", r), (!u || S & /*muted*/
      16) && (i.muted = /*muted*/
      y[4]), (!u || S & /*playsinline*/
      32) && (i.playsInline = /*playsinline*/
      y[5]), (!u || S & /*preload*/
      64) && qe(
        i,
        "preload",
        /*preload*/
        y[6]
      ), (!u || S & /*autoplay*/
      128) && (i.autoplay = /*autoplay*/
      y[7]), (!u || S & /*controls*/
      256) && (i.controls = /*controls*/
      y[8]), (!u || S & /*loop*/
      512) && (i.loop = /*loop*/
      y[9]), (!u || S & /*$$props*/
      8192 && n !== (n = /*$$props*/
      y[13]["data-testid"])) && qe(i, "data-testid", n), !o && S & /*currentTime*/
      2 && !isNaN(
        /*currentTime*/
        y[1]
      ) && (i.currentTime = /*currentTime*/
      y[1]), o = !1, S & /*paused*/
      8 && l !== (l = /*paused*/
      y[3]) && i[l ? "pause" : "play"](), h && td(h.update) && S & /*autoplay*/
      128 && h.update.call(null, { autoplay: (
        /*autoplay*/
        y[7] ?? !1
      ) });
    },
    i(y) {
      u || (ad(p, y), u = !0);
    },
    o(y) {
      od(p, y), u = !1;
    },
    d(y) {
      y && (Qt(e), Qt(s), Qt(i)), p && p.d(y), a[25](null), d = !1, id(f);
    }
  };
}
function ud(a, e, t) {
  let { $$slots: s = {}, $$scope: i } = e, { src: r = void 0 } = e, { muted: n = void 0 } = e, { playsinline: o = void 0 } = e, { preload: c = void 0 } = e, { autoplay: l = void 0 } = e, { controls: h = void 0 } = e, { currentTime: u = void 0 } = e, { duration: d = void 0 } = e, { paused: f = void 0 } = e, { node: g = void 0 } = e, { loop: p } = e, { is_stream: E } = e, { processingVideo: y = !1 } = e, S, T = !1, v;
  const x = cd();
  function _(w, U, N) {
    if (!(!w || !U) && N && Se.isSupported() && !T) {
      const B = new Se({
        maxBufferLength: 1,
        // 0.5 seconds (500 ms)
        maxMaxBufferLength: 1,
        // Maximum max buffer length in seconds
        lowLatencyMode: !0
        // Enable low latency mode
      });
      B.loadSource(w), B.attachMedia(N), B.on(Se.Events.MANIFEST_PARSED, function() {
        N.play();
      }), B.on(Se.Events.ERROR, function($, P) {
        if (console.error("HLS error:", $, P), P.fatal)
          switch (P.type) {
            case Se.ErrorTypes.NETWORK_ERROR:
              console.error("Fatal network error encountered, trying to recover"), B.startLoad();
              break;
            case Se.ErrorTypes.MEDIA_ERROR:
              console.error("Fatal media error encountered, trying to recover"), B.recoverMediaError();
              break;
            default:
              console.error("Fatal error, cannot recover"), B.destroy();
              break;
          }
      }), T = !0;
    }
  }
  function A(w) {
    qs.call(this, a, w);
  }
  function b(w) {
    qs.call(this, a, w);
  }
  function D(w) {
    qs.call(this, a, w);
  }
  function L() {
    u = this.currentTime, t(1, u);
  }
  function k() {
    d = this.duration, t(2, d);
  }
  function F() {
    f = this.paused, t(3, f);
  }
  function j(w) {
    qu[w ? "unshift" : "push"](() => {
      g = w, t(0, g);
    });
  }
  return a.$$set = (w) => {
    t(13, e = ln(ln({}, e), un(w))), "src" in w && t(14, r = w.src), "muted" in w && t(4, n = w.muted), "playsinline" in w && t(5, o = w.playsinline), "preload" in w && t(6, c = w.preload), "autoplay" in w && t(7, l = w.autoplay), "controls" in w && t(8, h = w.controls), "currentTime" in w && t(1, u = w.currentTime), "duration" in w && t(2, d = w.duration), "paused" in w && t(3, f = w.paused), "node" in w && t(0, g = w.node), "loop" in w && t(9, p = w.loop), "is_stream" in w && t(15, E = w.is_stream), "processingVideo" in w && t(10, y = w.processingVideo), "$$scope" in w && t(17, i = w.$$scope);
  }, a.$$.update = () => {
    if (a.$$.dirty & /*src, latest_src*/
    81920) {
      t(11, S = r), t(16, v = r);
      const w = r;
      Za(w).then((U) => {
        v === w && t(11, S = U);
      });
    }
    a.$$.dirty & /*src*/
    16384 && (T = !1), a.$$.dirty & /*src, is_stream, node*/
    49153 && _(r, E, g);
  }, e = un(e), [
    g,
    u,
    d,
    f,
    n,
    o,
    c,
    l,
    h,
    p,
    y,
    S,
    x,
    e,
    r,
    E,
    v,
    i,
    s,
    A,
    b,
    D,
    L,
    k,
    F,
    j
  ];
}
class dd extends Hu {
  constructor(e) {
    super(), ed(this, e, ud, hd, rd, {
      src: 14,
      muted: 4,
      playsinline: 5,
      preload: 6,
      autoplay: 7,
      controls: 8,
      currentTime: 1,
      duration: 2,
      paused: 3,
      node: 0,
      loop: 9,
      is_stream: 15,
      processingVideo: 10
    });
  }
}
new Intl.Collator(0, { numeric: 1 }).compare;
typeof process < "u" && process.versions && process.versions.node;
var Ge;
class gf extends TransformStream {
  /** Constructs a new instance. */
  constructor(t = { allowCR: !1 }) {
    super({
      transform: (s, i) => {
        for (s = nt(this, Ge) + s; ; ) {
          const r = s.indexOf(`
`), n = t.allowCR ? s.indexOf("\r") : -1;
          if (n !== -1 && n !== s.length - 1 && (r === -1 || r - 1 > n)) {
            i.enqueue(s.slice(0, n)), s = s.slice(n + 1);
            continue;
          }
          if (r === -1)
            break;
          const o = s[r - 1] === "\r" ? r - 1 : r;
          i.enqueue(s.slice(0, o)), s = s.slice(r + 1);
        }
        Hi(this, Ge, s);
      },
      flush: (s) => {
        if (nt(this, Ge) === "")
          return;
        const i = t.allowCR && nt(this, Ge).endsWith("\r") ? nt(this, Ge).slice(0, -1) : nt(this, Ge);
        s.enqueue(i);
      }
    });
    Vi(this, Ge, "");
  }
}
Ge = new WeakMap();
const {
  SvelteComponent: fd,
  add_flush_callback: gd,
  append_hydration: md,
  attr: pd,
  bind: Ed,
  binding_callbacks: yd,
  check_outros: Td,
  children: Ba,
  claim_component: Sd,
  claim_element: Ua,
  claim_text: vd,
  create_component: xd,
  destroy_component: Ad,
  detach: yt,
  element: $a,
  empty: ps,
  group_outros: Ld,
  init: Id,
  insert_hydration: Ss,
  is_function: gn,
  mount_component: Rd,
  noop: mn,
  safe_not_equal: bd,
  set_data: _d,
  text: Dd,
  toggle_class: ht,
  transition_in: Rt,
  transition_out: Es
} = window.__gradio__svelte__internal;
function pn(a) {
  let e, t, s, i;
  const r = [Pd, Cd], n = [];
  function o(c, l) {
    return 0;
  }
  return e = o(), t = n[e] = r[e](a), {
    c() {
      t.c(), s = ps();
    },
    l(c) {
      t.l(c), s = ps();
    },
    m(c, l) {
      n[e].m(c, l), Ss(c, s, l), i = !0;
    },
    p(c, l) {
      t.p(c, l);
    },
    i(c) {
      i || (Rt(t), i = !0);
    },
    o(c) {
      Es(t), i = !1;
    },
    d(c) {
      c && yt(s), n[e].d(c);
    }
  };
}
function Cd(a) {
  let e, t;
  return {
    c() {
      e = $a("div"), t = Dd(
        /*value*/
        a[2]
      );
    },
    l(s) {
      e = Ua(s, "DIV", {});
      var i = Ba(e);
      t = vd(
        i,
        /*value*/
        a[2]
      ), i.forEach(yt);
    },
    m(s, i) {
      Ss(s, e, i), md(e, t);
    },
    p(s, i) {
      i & /*value*/
      4 && _d(
        t,
        /*value*/
        s[2]
      );
    },
    i: mn,
    o: mn,
    d(s) {
      s && yt(e);
    }
  };
}
function Pd(a) {
  var o;
  let e, t, s, i;
  function r(c) {
    a[6](c);
  }
  let n = {
    muted: !0,
    playsinline: !0,
    src: (
      /*value*/
      (o = a[2]) == null ? void 0 : o.video.url
    ),
    is_stream: !1,
    loop: (
      /*loop*/
      a[3]
    )
  };
  return (
    /*video*/
    a[4] !== void 0 && (n.node = /*video*/
    a[4]), t = new dd({ props: n }), yd.push(() => Ed(t, "node", r)), t.$on(
      "loadeddata",
      /*init*/
      a[5]
    ), t.$on("mouseover", function() {
      gn(
        /*video*/
        a[4].play.bind(
          /*video*/
          a[4]
        )
      ) && a[4].play.bind(
        /*video*/
        a[4]
      ).apply(this, arguments);
    }), t.$on("mouseout", function() {
      gn(
        /*video*/
        a[4].pause.bind(
          /*video*/
          a[4]
        )
      ) && a[4].pause.bind(
        /*video*/
        a[4]
      ).apply(this, arguments);
    }), {
      c() {
        e = $a("div"), xd(t.$$.fragment), this.h();
      },
      l(c) {
        e = Ua(c, "DIV", { class: !0 });
        var l = Ba(e);
        Sd(t.$$.fragment, l), l.forEach(yt), this.h();
      },
      h() {
        pd(e, "class", "container svelte-13u05e4"), ht(
          e,
          "table",
          /*type*/
          a[0] === "table"
        ), ht(
          e,
          "gallery",
          /*type*/
          a[0] === "gallery"
        ), ht(
          e,
          "selected",
          /*selected*/
          a[1]
        );
      },
      m(c, l) {
        Ss(c, e, l), Rd(t, e, null), i = !0;
      },
      p(c, l) {
        var u;
        a = c;
        const h = {};
        l & /*value*/
        4 && (h.src = /*value*/
        (u = a[2]) == null ? void 0 : u.video.url), l & /*loop*/
        8 && (h.loop = /*loop*/
        a[3]), !s && l & /*video*/
        16 && (s = !0, h.node = /*video*/
        a[4], gd(() => s = !1)), t.$set(h), (!i || l & /*type*/
        1) && ht(
          e,
          "table",
          /*type*/
          a[0] === "table"
        ), (!i || l & /*type*/
        1) && ht(
          e,
          "gallery",
          /*type*/
          a[0] === "gallery"
        ), (!i || l & /*selected*/
        2) && ht(
          e,
          "selected",
          /*selected*/
          a[1]
        );
      },
      i(c) {
        i || (Rt(t.$$.fragment, c), i = !0);
      },
      o(c) {
        Es(t.$$.fragment, c), i = !1;
      },
      d(c) {
        c && yt(e), Ad(t);
      }
    }
  );
}
function kd(a) {
  let e, t, s = (
    /*value*/
    a[2] && pn(a)
  );
  return {
    c() {
      s && s.c(), e = ps();
    },
    l(i) {
      s && s.l(i), e = ps();
    },
    m(i, r) {
      s && s.m(i, r), Ss(i, e, r), t = !0;
    },
    p(i, [r]) {
      /*value*/
      i[2] ? s ? (s.p(i, r), r & /*value*/
      4 && Rt(s, 1)) : (s = pn(i), s.c(), Rt(s, 1), s.m(e.parentNode, e)) : s && (Ld(), Es(s, 1, 1, () => {
        s = null;
      }), Td());
    },
    i(i) {
      t || (Rt(s), t = !0);
    },
    o(i) {
      Es(s), t = !1;
    },
    d(i) {
      i && yt(e), s && s.d(i);
    }
  };
}
function wd(a, e, t) {
  let { type: s } = e, { selected: i = !1 } = e, { value: r } = e, { loop: n } = e, o;
  async function c() {
    t(4, o.muted = !0, o), t(4, o.playsInline = !0, o), t(4, o.controls = !1, o), o.setAttribute("muted", ""), await o.play(), o.pause();
  }
  function l(h) {
    o = h, t(4, o);
  }
  return a.$$set = (h) => {
    "type" in h && t(0, s = h.type), "selected" in h && t(1, i = h.selected), "value" in h && t(2, r = h.value), "loop" in h && t(3, n = h.loop);
  }, [s, i, r, n, o, c, l];
}
class mf extends fd {
  constructor(e) {
    super(), Id(this, e, wd, kd, bd, { type: 0, selected: 1, value: 2, loop: 3 });
  }
}
export {
  mf as default
};
